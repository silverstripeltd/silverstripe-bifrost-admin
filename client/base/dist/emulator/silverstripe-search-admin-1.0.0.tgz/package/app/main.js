(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all2) => {
    for (var name in all2)
      __defProp(target, name, { get: all2[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/react/cjs/react.production.min.js
  var require_react_production_min = __commonJS({
    "node_modules/react/cjs/react.production.min.js"(exports2) {
      "use strict";
      var l = Symbol.for("react.element");
      var n = Symbol.for("react.portal");
      var p = Symbol.for("react.fragment");
      var q = Symbol.for("react.strict_mode");
      var r = Symbol.for("react.profiler");
      var t = Symbol.for("react.provider");
      var u = Symbol.for("react.context");
      var v = Symbol.for("react.forward_ref");
      var w = Symbol.for("react.suspense");
      var x = Symbol.for("react.memo");
      var y = Symbol.for("react.lazy");
      var z = Symbol.iterator;
      function A(a) {
        if (null === a || "object" !== typeof a) return null;
        a = z && a[z] || a["@@iterator"];
        return "function" === typeof a ? a : null;
      }
      var B = { isMounted: function() {
        return false;
      }, enqueueForceUpdate: function() {
      }, enqueueReplaceState: function() {
      }, enqueueSetState: function() {
      } };
      var C = Object.assign;
      var D = {};
      function E(a, b, e) {
        this.props = a;
        this.context = b;
        this.refs = D;
        this.updater = e || B;
      }
      E.prototype.isReactComponent = {};
      E.prototype.setState = function(a, b) {
        if ("object" !== typeof a && "function" !== typeof a && null != a) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, a, b, "setState");
      };
      E.prototype.forceUpdate = function(a) {
        this.updater.enqueueForceUpdate(this, a, "forceUpdate");
      };
      function F() {
      }
      F.prototype = E.prototype;
      function G(a, b, e) {
        this.props = a;
        this.context = b;
        this.refs = D;
        this.updater = e || B;
      }
      var H = G.prototype = new F();
      H.constructor = G;
      C(H, E.prototype);
      H.isPureReactComponent = true;
      var I = Array.isArray;
      var J = Object.prototype.hasOwnProperty;
      var K = { current: null };
      var L = { key: true, ref: true, __self: true, __source: true };
      function M(a, b, e) {
        var d, c = {}, k = null, h2 = null;
        if (null != b) for (d in void 0 !== b.ref && (h2 = b.ref), void 0 !== b.key && (k = "" + b.key), b) J.call(b, d) && !L.hasOwnProperty(d) && (c[d] = b[d]);
        var g = arguments.length - 2;
        if (1 === g) c.children = e;
        else if (1 < g) {
          for (var f = Array(g), m = 0; m < g; m++) f[m] = arguments[m + 2];
          c.children = f;
        }
        if (a && a.defaultProps) for (d in g = a.defaultProps, g) void 0 === c[d] && (c[d] = g[d]);
        return { $$typeof: l, type: a, key: k, ref: h2, props: c, _owner: K.current };
      }
      function N(a, b) {
        return { $$typeof: l, type: a.type, key: b, ref: a.ref, props: a.props, _owner: a._owner };
      }
      function O(a) {
        return "object" === typeof a && null !== a && a.$$typeof === l;
      }
      function escape(a) {
        var b = { "=": "=0", ":": "=2" };
        return "$" + a.replace(/[=:]/g, function(a2) {
          return b[a2];
        });
      }
      var P = /\/+/g;
      function Q(a, b) {
        return "object" === typeof a && null !== a && null != a.key ? escape("" + a.key) : b.toString(36);
      }
      function R(a, b, e, d, c) {
        var k = typeof a;
        if ("undefined" === k || "boolean" === k) a = null;
        var h2 = false;
        if (null === a) h2 = true;
        else switch (k) {
          case "string":
          case "number":
            h2 = true;
            break;
          case "object":
            switch (a.$$typeof) {
              case l:
              case n:
                h2 = true;
            }
        }
        if (h2) return h2 = a, c = c(h2), a = "" === d ? "." + Q(h2, 0) : d, I(c) ? (e = "", null != a && (e = a.replace(P, "$&/") + "/"), R(c, b, e, "", function(a2) {
          return a2;
        })) : null != c && (O(c) && (c = N(c, e + (!c.key || h2 && h2.key === c.key ? "" : ("" + c.key).replace(P, "$&/") + "/") + a)), b.push(c)), 1;
        h2 = 0;
        d = "" === d ? "." : d + ":";
        if (I(a)) for (var g = 0; g < a.length; g++) {
          k = a[g];
          var f = d + Q(k, g);
          h2 += R(k, b, e, f, c);
        }
        else if (f = A(a), "function" === typeof f) for (a = f.call(a), g = 0; !(k = a.next()).done; ) k = k.value, f = d + Q(k, g++), h2 += R(k, b, e, f, c);
        else if ("object" === k) throw b = String(a), Error("Objects are not valid as a React child (found: " + ("[object Object]" === b ? "object with keys {" + Object.keys(a).join(", ") + "}" : b) + "). If you meant to render a collection of children, use an array instead.");
        return h2;
      }
      function S(a, b, e) {
        if (null == a) return a;
        var d = [], c = 0;
        R(a, d, "", "", function(a2) {
          return b.call(e, a2, c++);
        });
        return d;
      }
      function T(a) {
        if (-1 === a._status) {
          var b = a._result;
          b = b();
          b.then(function(b2) {
            if (0 === a._status || -1 === a._status) a._status = 1, a._result = b2;
          }, function(b2) {
            if (0 === a._status || -1 === a._status) a._status = 2, a._result = b2;
          });
          -1 === a._status && (a._status = 0, a._result = b);
        }
        if (1 === a._status) return a._result.default;
        throw a._result;
      }
      var U = { current: null };
      var V = { transition: null };
      var W = { ReactCurrentDispatcher: U, ReactCurrentBatchConfig: V, ReactCurrentOwner: K };
      function X() {
        throw Error("act(...) is not supported in production builds of React.");
      }
      exports2.Children = { map: S, forEach: function(a, b, e) {
        S(a, function() {
          b.apply(this, arguments);
        }, e);
      }, count: function(a) {
        var b = 0;
        S(a, function() {
          b++;
        });
        return b;
      }, toArray: function(a) {
        return S(a, function(a2) {
          return a2;
        }) || [];
      }, only: function(a) {
        if (!O(a)) throw Error("React.Children.only expected to receive a single React element child.");
        return a;
      } };
      exports2.Component = E;
      exports2.Fragment = p;
      exports2.Profiler = r;
      exports2.PureComponent = G;
      exports2.StrictMode = q;
      exports2.Suspense = w;
      exports2.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = W;
      exports2.act = X;
      exports2.cloneElement = function(a, b, e) {
        if (null === a || void 0 === a) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + a + ".");
        var d = C({}, a.props), c = a.key, k = a.ref, h2 = a._owner;
        if (null != b) {
          void 0 !== b.ref && (k = b.ref, h2 = K.current);
          void 0 !== b.key && (c = "" + b.key);
          if (a.type && a.type.defaultProps) var g = a.type.defaultProps;
          for (f in b) J.call(b, f) && !L.hasOwnProperty(f) && (d[f] = void 0 === b[f] && void 0 !== g ? g[f] : b[f]);
        }
        var f = arguments.length - 2;
        if (1 === f) d.children = e;
        else if (1 < f) {
          g = Array(f);
          for (var m = 0; m < f; m++) g[m] = arguments[m + 2];
          d.children = g;
        }
        return { $$typeof: l, type: a.type, key: c, ref: k, props: d, _owner: h2 };
      };
      exports2.createContext = function(a) {
        a = { $$typeof: u, _currentValue: a, _currentValue2: a, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null };
        a.Provider = { $$typeof: t, _context: a };
        return a.Consumer = a;
      };
      exports2.createElement = M;
      exports2.createFactory = function(a) {
        var b = M.bind(null, a);
        b.type = a;
        return b;
      };
      exports2.createRef = function() {
        return { current: null };
      };
      exports2.forwardRef = function(a) {
        return { $$typeof: v, render: a };
      };
      exports2.isValidElement = O;
      exports2.lazy = function(a) {
        return { $$typeof: y, _payload: { _status: -1, _result: a }, _init: T };
      };
      exports2.memo = function(a, b) {
        return { $$typeof: x, type: a, compare: void 0 === b ? null : b };
      };
      exports2.startTransition = function(a) {
        var b = V.transition;
        V.transition = {};
        try {
          a();
        } finally {
          V.transition = b;
        }
      };
      exports2.unstable_act = X;
      exports2.useCallback = function(a, b) {
        return U.current.useCallback(a, b);
      };
      exports2.useContext = function(a) {
        return U.current.useContext(a);
      };
      exports2.useDebugValue = function() {
      };
      exports2.useDeferredValue = function(a) {
        return U.current.useDeferredValue(a);
      };
      exports2.useEffect = function(a, b) {
        return U.current.useEffect(a, b);
      };
      exports2.useId = function() {
        return U.current.useId();
      };
      exports2.useImperativeHandle = function(a, b, e) {
        return U.current.useImperativeHandle(a, b, e);
      };
      exports2.useInsertionEffect = function(a, b) {
        return U.current.useInsertionEffect(a, b);
      };
      exports2.useLayoutEffect = function(a, b) {
        return U.current.useLayoutEffect(a, b);
      };
      exports2.useMemo = function(a, b) {
        return U.current.useMemo(a, b);
      };
      exports2.useReducer = function(a, b, e) {
        return U.current.useReducer(a, b, e);
      };
      exports2.useRef = function(a) {
        return U.current.useRef(a);
      };
      exports2.useState = function(a) {
        return U.current.useState(a);
      };
      exports2.useSyncExternalStore = function(a, b, e) {
        return U.current.useSyncExternalStore(a, b, e);
      };
      exports2.useTransition = function() {
        return U.current.useTransition();
      };
      exports2.version = "18.3.1";
    }
  });

  // node_modules/react/index.js
  var require_react = __commonJS({
    "node_modules/react/index.js"(exports2, module2) {
      "use strict";
      if (true) {
        module2.exports = require_react_production_min();
      } else {
        module2.exports = null;
      }
    }
  });

  // node_modules/scheduler/cjs/scheduler.production.min.js
  var require_scheduler_production_min = __commonJS({
    "node_modules/scheduler/cjs/scheduler.production.min.js"(exports2) {
      "use strict";
      function f(a, b) {
        var c = a.length;
        a.push(b);
        a: for (; 0 < c; ) {
          var d = c - 1 >>> 1, e = a[d];
          if (0 < g(e, b)) a[d] = b, a[c] = e, c = d;
          else break a;
        }
      }
      function h2(a) {
        return 0 === a.length ? null : a[0];
      }
      function k(a) {
        if (0 === a.length) return null;
        var b = a[0], c = a.pop();
        if (c !== b) {
          a[0] = c;
          a: for (var d = 0, e = a.length, w = e >>> 1; d < w; ) {
            var m = 2 * (d + 1) - 1, C = a[m], n = m + 1, x = a[n];
            if (0 > g(C, c)) n < e && 0 > g(x, C) ? (a[d] = x, a[n] = c, d = n) : (a[d] = C, a[m] = c, d = m);
            else if (n < e && 0 > g(x, c)) a[d] = x, a[n] = c, d = n;
            else break a;
          }
        }
        return b;
      }
      function g(a, b) {
        var c = a.sortIndex - b.sortIndex;
        return 0 !== c ? c : a.id - b.id;
      }
      if ("object" === typeof performance && "function" === typeof performance.now) {
        l = performance;
        exports2.unstable_now = function() {
          return l.now();
        };
      } else {
        p = Date, q = p.now();
        exports2.unstable_now = function() {
          return p.now() - q;
        };
      }
      var l;
      var p;
      var q;
      var r = [];
      var t = [];
      var u = 1;
      var v = null;
      var y = 3;
      var z = false;
      var A = false;
      var B = false;
      var D = "function" === typeof setTimeout ? setTimeout : null;
      var E = "function" === typeof clearTimeout ? clearTimeout : null;
      var F = "undefined" !== typeof setImmediate ? setImmediate : null;
      "undefined" !== typeof navigator && void 0 !== navigator.scheduling && void 0 !== navigator.scheduling.isInputPending && navigator.scheduling.isInputPending.bind(navigator.scheduling);
      function G(a) {
        for (var b = h2(t); null !== b; ) {
          if (null === b.callback) k(t);
          else if (b.startTime <= a) k(t), b.sortIndex = b.expirationTime, f(r, b);
          else break;
          b = h2(t);
        }
      }
      function H(a) {
        B = false;
        G(a);
        if (!A) if (null !== h2(r)) A = true, I(J);
        else {
          var b = h2(t);
          null !== b && K(H, b.startTime - a);
        }
      }
      function J(a, b) {
        A = false;
        B && (B = false, E(L), L = -1);
        z = true;
        var c = y;
        try {
          G(b);
          for (v = h2(r); null !== v && (!(v.expirationTime > b) || a && !M()); ) {
            var d = v.callback;
            if ("function" === typeof d) {
              v.callback = null;
              y = v.priorityLevel;
              var e = d(v.expirationTime <= b);
              b = exports2.unstable_now();
              "function" === typeof e ? v.callback = e : v === h2(r) && k(r);
              G(b);
            } else k(r);
            v = h2(r);
          }
          if (null !== v) var w = true;
          else {
            var m = h2(t);
            null !== m && K(H, m.startTime - b);
            w = false;
          }
          return w;
        } finally {
          v = null, y = c, z = false;
        }
      }
      var N = false;
      var O = null;
      var L = -1;
      var P = 5;
      var Q = -1;
      function M() {
        return exports2.unstable_now() - Q < P ? false : true;
      }
      function R() {
        if (null !== O) {
          var a = exports2.unstable_now();
          Q = a;
          var b = true;
          try {
            b = O(true, a);
          } finally {
            b ? S() : (N = false, O = null);
          }
        } else N = false;
      }
      var S;
      if ("function" === typeof F) S = function() {
        F(R);
      };
      else if ("undefined" !== typeof MessageChannel) {
        T = new MessageChannel(), U = T.port2;
        T.port1.onmessage = R;
        S = function() {
          U.postMessage(null);
        };
      } else S = function() {
        D(R, 0);
      };
      var T;
      var U;
      function I(a) {
        O = a;
        N || (N = true, S());
      }
      function K(a, b) {
        L = D(function() {
          a(exports2.unstable_now());
        }, b);
      }
      exports2.unstable_IdlePriority = 5;
      exports2.unstable_ImmediatePriority = 1;
      exports2.unstable_LowPriority = 4;
      exports2.unstable_NormalPriority = 3;
      exports2.unstable_Profiling = null;
      exports2.unstable_UserBlockingPriority = 2;
      exports2.unstable_cancelCallback = function(a) {
        a.callback = null;
      };
      exports2.unstable_continueExecution = function() {
        A || z || (A = true, I(J));
      };
      exports2.unstable_forceFrameRate = function(a) {
        0 > a || 125 < a ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : P = 0 < a ? Math.floor(1e3 / a) : 5;
      };
      exports2.unstable_getCurrentPriorityLevel = function() {
        return y;
      };
      exports2.unstable_getFirstCallbackNode = function() {
        return h2(r);
      };
      exports2.unstable_next = function(a) {
        switch (y) {
          case 1:
          case 2:
          case 3:
            var b = 3;
            break;
          default:
            b = y;
        }
        var c = y;
        y = b;
        try {
          return a();
        } finally {
          y = c;
        }
      };
      exports2.unstable_pauseExecution = function() {
      };
      exports2.unstable_requestPaint = function() {
      };
      exports2.unstable_runWithPriority = function(a, b) {
        switch (a) {
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            break;
          default:
            a = 3;
        }
        var c = y;
        y = a;
        try {
          return b();
        } finally {
          y = c;
        }
      };
      exports2.unstable_scheduleCallback = function(a, b, c) {
        var d = exports2.unstable_now();
        "object" === typeof c && null !== c ? (c = c.delay, c = "number" === typeof c && 0 < c ? d + c : d) : c = d;
        switch (a) {
          case 1:
            var e = -1;
            break;
          case 2:
            e = 250;
            break;
          case 5:
            e = 1073741823;
            break;
          case 4:
            e = 1e4;
            break;
          default:
            e = 5e3;
        }
        e = c + e;
        a = { id: u++, callback: b, priorityLevel: a, startTime: c, expirationTime: e, sortIndex: -1 };
        c > d ? (a.sortIndex = c, f(t, a), null === h2(r) && a === h2(t) && (B ? (E(L), L = -1) : B = true, K(H, c - d))) : (a.sortIndex = e, f(r, a), A || z || (A = true, I(J)));
        return a;
      };
      exports2.unstable_shouldYield = M;
      exports2.unstable_wrapCallback = function(a) {
        var b = y;
        return function() {
          var c = y;
          y = b;
          try {
            return a.apply(this, arguments);
          } finally {
            y = c;
          }
        };
      };
    }
  });

  // node_modules/scheduler/index.js
  var require_scheduler = __commonJS({
    "node_modules/scheduler/index.js"(exports2, module2) {
      "use strict";
      if (true) {
        module2.exports = require_scheduler_production_min();
      } else {
        module2.exports = null;
      }
    }
  });

  // node_modules/react-dom/cjs/react-dom.production.min.js
  var require_react_dom_production_min = __commonJS({
    "node_modules/react-dom/cjs/react-dom.production.min.js"(exports2) {
      "use strict";
      var aa = require_react();
      var ca = require_scheduler();
      function p(a) {
        for (var b = "https://reactjs.org/docs/error-decoder.html?invariant=" + a, c = 1; c < arguments.length; c++) b += "&args[]=" + encodeURIComponent(arguments[c]);
        return "Minified React error #" + a + "; visit " + b + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
      }
      var da = /* @__PURE__ */ new Set();
      var ea = {};
      function fa(a, b) {
        ha(a, b);
        ha(a + "Capture", b);
      }
      function ha(a, b) {
        ea[a] = b;
        for (a = 0; a < b.length; a++) da.add(b[a]);
      }
      var ia = !("undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement);
      var ja = Object.prototype.hasOwnProperty;
      var ka = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/;
      var la = {};
      var ma = {};
      function oa(a) {
        if (ja.call(ma, a)) return true;
        if (ja.call(la, a)) return false;
        if (ka.test(a)) return ma[a] = true;
        la[a] = true;
        return false;
      }
      function pa(a, b, c, d) {
        if (null !== c && 0 === c.type) return false;
        switch (typeof b) {
          case "function":
          case "symbol":
            return true;
          case "boolean":
            if (d) return false;
            if (null !== c) return !c.acceptsBooleans;
            a = a.toLowerCase().slice(0, 5);
            return "data-" !== a && "aria-" !== a;
          default:
            return false;
        }
      }
      function qa(a, b, c, d) {
        if (null === b || "undefined" === typeof b || pa(a, b, c, d)) return true;
        if (d) return false;
        if (null !== c) switch (c.type) {
          case 3:
            return !b;
          case 4:
            return false === b;
          case 5:
            return isNaN(b);
          case 6:
            return isNaN(b) || 1 > b;
        }
        return false;
      }
      function v(a, b, c, d, e, f, g) {
        this.acceptsBooleans = 2 === b || 3 === b || 4 === b;
        this.attributeName = d;
        this.attributeNamespace = e;
        this.mustUseProperty = c;
        this.propertyName = a;
        this.type = b;
        this.sanitizeURL = f;
        this.removeEmptyString = g;
      }
      var z = {};
      "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a) {
        z[a] = new v(a, 0, false, a, null, false, false);
      });
      [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(a) {
        var b = a[0];
        z[b] = new v(b, 1, false, a[1], null, false, false);
      });
      ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(a) {
        z[a] = new v(a, 2, false, a.toLowerCase(), null, false, false);
      });
      ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(a) {
        z[a] = new v(a, 2, false, a, null, false, false);
      });
      "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a) {
        z[a] = new v(a, 3, false, a.toLowerCase(), null, false, false);
      });
      ["checked", "multiple", "muted", "selected"].forEach(function(a) {
        z[a] = new v(a, 3, true, a, null, false, false);
      });
      ["capture", "download"].forEach(function(a) {
        z[a] = new v(a, 4, false, a, null, false, false);
      });
      ["cols", "rows", "size", "span"].forEach(function(a) {
        z[a] = new v(a, 6, false, a, null, false, false);
      });
      ["rowSpan", "start"].forEach(function(a) {
        z[a] = new v(a, 5, false, a.toLowerCase(), null, false, false);
      });
      var ra = /[\-:]([a-z])/g;
      function sa(a) {
        return a[1].toUpperCase();
      }
      "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a) {
        var b = a.replace(
          ra,
          sa
        );
        z[b] = new v(b, 1, false, a, null, false, false);
      });
      "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a) {
        var b = a.replace(ra, sa);
        z[b] = new v(b, 1, false, a, "http://www.w3.org/1999/xlink", false, false);
      });
      ["xml:base", "xml:lang", "xml:space"].forEach(function(a) {
        var b = a.replace(ra, sa);
        z[b] = new v(b, 1, false, a, "http://www.w3.org/XML/1998/namespace", false, false);
      });
      ["tabIndex", "crossOrigin"].forEach(function(a) {
        z[a] = new v(a, 1, false, a.toLowerCase(), null, false, false);
      });
      z.xlinkHref = new v("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
      ["src", "href", "action", "formAction"].forEach(function(a) {
        z[a] = new v(a, 1, false, a.toLowerCase(), null, true, true);
      });
      function ta(a, b, c, d) {
        var e = z.hasOwnProperty(b) ? z[b] : null;
        if (null !== e ? 0 !== e.type : d || !(2 < b.length) || "o" !== b[0] && "O" !== b[0] || "n" !== b[1] && "N" !== b[1]) qa(b, c, e, d) && (c = null), d || null === e ? oa(b) && (null === c ? a.removeAttribute(b) : a.setAttribute(b, "" + c)) : e.mustUseProperty ? a[e.propertyName] = null === c ? 3 === e.type ? false : "" : c : (b = e.attributeName, d = e.attributeNamespace, null === c ? a.removeAttribute(b) : (e = e.type, c = 3 === e || 4 === e && true === c ? "" : "" + c, d ? a.setAttributeNS(d, b, c) : a.setAttribute(b, c)));
      }
      var ua = aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
      var va = Symbol.for("react.element");
      var wa = Symbol.for("react.portal");
      var ya = Symbol.for("react.fragment");
      var za = Symbol.for("react.strict_mode");
      var Aa = Symbol.for("react.profiler");
      var Ba = Symbol.for("react.provider");
      var Ca = Symbol.for("react.context");
      var Da = Symbol.for("react.forward_ref");
      var Ea = Symbol.for("react.suspense");
      var Fa = Symbol.for("react.suspense_list");
      var Ga = Symbol.for("react.memo");
      var Ha = Symbol.for("react.lazy");
      Symbol.for("react.scope");
      Symbol.for("react.debug_trace_mode");
      var Ia = Symbol.for("react.offscreen");
      Symbol.for("react.legacy_hidden");
      Symbol.for("react.cache");
      Symbol.for("react.tracing_marker");
      var Ja = Symbol.iterator;
      function Ka(a) {
        if (null === a || "object" !== typeof a) return null;
        a = Ja && a[Ja] || a["@@iterator"];
        return "function" === typeof a ? a : null;
      }
      var A = Object.assign;
      var La;
      function Ma(a) {
        if (void 0 === La) try {
          throw Error();
        } catch (c) {
          var b = c.stack.trim().match(/\n( *(at )?)/);
          La = b && b[1] || "";
        }
        return "\n" + La + a;
      }
      var Na = false;
      function Oa(a, b) {
        if (!a || Na) return "";
        Na = true;
        var c = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        try {
          if (b) if (b = function() {
            throw Error();
          }, Object.defineProperty(b.prototype, "props", { set: function() {
            throw Error();
          } }), "object" === typeof Reflect && Reflect.construct) {
            try {
              Reflect.construct(b, []);
            } catch (l) {
              var d = l;
            }
            Reflect.construct(a, [], b);
          } else {
            try {
              b.call();
            } catch (l) {
              d = l;
            }
            a.call(b.prototype);
          }
          else {
            try {
              throw Error();
            } catch (l) {
              d = l;
            }
            a();
          }
        } catch (l) {
          if (l && d && "string" === typeof l.stack) {
            for (var e = l.stack.split("\n"), f = d.stack.split("\n"), g = e.length - 1, h2 = f.length - 1; 1 <= g && 0 <= h2 && e[g] !== f[h2]; ) h2--;
            for (; 1 <= g && 0 <= h2; g--, h2--) if (e[g] !== f[h2]) {
              if (1 !== g || 1 !== h2) {
                do
                  if (g--, h2--, 0 > h2 || e[g] !== f[h2]) {
                    var k = "\n" + e[g].replace(" at new ", " at ");
                    a.displayName && k.includes("<anonymous>") && (k = k.replace("<anonymous>", a.displayName));
                    return k;
                  }
                while (1 <= g && 0 <= h2);
              }
              break;
            }
          }
        } finally {
          Na = false, Error.prepareStackTrace = c;
        }
        return (a = a ? a.displayName || a.name : "") ? Ma(a) : "";
      }
      function Pa(a) {
        switch (a.tag) {
          case 5:
            return Ma(a.type);
          case 16:
            return Ma("Lazy");
          case 13:
            return Ma("Suspense");
          case 19:
            return Ma("SuspenseList");
          case 0:
          case 2:
          case 15:
            return a = Oa(a.type, false), a;
          case 11:
            return a = Oa(a.type.render, false), a;
          case 1:
            return a = Oa(a.type, true), a;
          default:
            return "";
        }
      }
      function Qa(a) {
        if (null == a) return null;
        if ("function" === typeof a) return a.displayName || a.name || null;
        if ("string" === typeof a) return a;
        switch (a) {
          case ya:
            return "Fragment";
          case wa:
            return "Portal";
          case Aa:
            return "Profiler";
          case za:
            return "StrictMode";
          case Ea:
            return "Suspense";
          case Fa:
            return "SuspenseList";
        }
        if ("object" === typeof a) switch (a.$$typeof) {
          case Ca:
            return (a.displayName || "Context") + ".Consumer";
          case Ba:
            return (a._context.displayName || "Context") + ".Provider";
          case Da:
            var b = a.render;
            a = a.displayName;
            a || (a = b.displayName || b.name || "", a = "" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
            return a;
          case Ga:
            return b = a.displayName || null, null !== b ? b : Qa(a.type) || "Memo";
          case Ha:
            b = a._payload;
            a = a._init;
            try {
              return Qa(a(b));
            } catch (c) {
            }
        }
        return null;
      }
      function Ra(a) {
        var b = a.type;
        switch (a.tag) {
          case 24:
            return "Cache";
          case 9:
            return (b.displayName || "Context") + ".Consumer";
          case 10:
            return (b._context.displayName || "Context") + ".Provider";
          case 18:
            return "DehydratedFragment";
          case 11:
            return a = b.render, a = a.displayName || a.name || "", b.displayName || ("" !== a ? "ForwardRef(" + a + ")" : "ForwardRef");
          case 7:
            return "Fragment";
          case 5:
            return b;
          case 4:
            return "Portal";
          case 3:
            return "Root";
          case 6:
            return "Text";
          case 16:
            return Qa(b);
          case 8:
            return b === za ? "StrictMode" : "Mode";
          case 22:
            return "Offscreen";
          case 12:
            return "Profiler";
          case 21:
            return "Scope";
          case 13:
            return "Suspense";
          case 19:
            return "SuspenseList";
          case 25:
            return "TracingMarker";
          case 1:
          case 0:
          case 17:
          case 2:
          case 14:
          case 15:
            if ("function" === typeof b) return b.displayName || b.name || null;
            if ("string" === typeof b) return b;
        }
        return null;
      }
      function Sa(a) {
        switch (typeof a) {
          case "boolean":
          case "number":
          case "string":
          case "undefined":
            return a;
          case "object":
            return a;
          default:
            return "";
        }
      }
      function Ta(a) {
        var b = a.type;
        return (a = a.nodeName) && "input" === a.toLowerCase() && ("checkbox" === b || "radio" === b);
      }
      function Ua(a) {
        var b = Ta(a) ? "checked" : "value", c = Object.getOwnPropertyDescriptor(a.constructor.prototype, b), d = "" + a[b];
        if (!a.hasOwnProperty(b) && "undefined" !== typeof c && "function" === typeof c.get && "function" === typeof c.set) {
          var e = c.get, f = c.set;
          Object.defineProperty(a, b, { configurable: true, get: function() {
            return e.call(this);
          }, set: function(a2) {
            d = "" + a2;
            f.call(this, a2);
          } });
          Object.defineProperty(a, b, { enumerable: c.enumerable });
          return { getValue: function() {
            return d;
          }, setValue: function(a2) {
            d = "" + a2;
          }, stopTracking: function() {
            a._valueTracker = null;
            delete a[b];
          } };
        }
      }
      function Va(a) {
        a._valueTracker || (a._valueTracker = Ua(a));
      }
      function Wa(a) {
        if (!a) return false;
        var b = a._valueTracker;
        if (!b) return true;
        var c = b.getValue();
        var d = "";
        a && (d = Ta(a) ? a.checked ? "true" : "false" : a.value);
        a = d;
        return a !== c ? (b.setValue(a), true) : false;
      }
      function Xa(a) {
        a = a || ("undefined" !== typeof document ? document : void 0);
        if ("undefined" === typeof a) return null;
        try {
          return a.activeElement || a.body;
        } catch (b) {
          return a.body;
        }
      }
      function Ya(a, b) {
        var c = b.checked;
        return A({}, b, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: null != c ? c : a._wrapperState.initialChecked });
      }
      function Za(a, b) {
        var c = null == b.defaultValue ? "" : b.defaultValue, d = null != b.checked ? b.checked : b.defaultChecked;
        c = Sa(null != b.value ? b.value : c);
        a._wrapperState = { initialChecked: d, initialValue: c, controlled: "checkbox" === b.type || "radio" === b.type ? null != b.checked : null != b.value };
      }
      function ab(a, b) {
        b = b.checked;
        null != b && ta(a, "checked", b, false);
      }
      function bb(a, b) {
        ab(a, b);
        var c = Sa(b.value), d = b.type;
        if (null != c) if ("number" === d) {
          if (0 === c && "" === a.value || a.value != c) a.value = "" + c;
        } else a.value !== "" + c && (a.value = "" + c);
        else if ("submit" === d || "reset" === d) {
          a.removeAttribute("value");
          return;
        }
        b.hasOwnProperty("value") ? cb(a, b.type, c) : b.hasOwnProperty("defaultValue") && cb(a, b.type, Sa(b.defaultValue));
        null == b.checked && null != b.defaultChecked && (a.defaultChecked = !!b.defaultChecked);
      }
      function db(a, b, c) {
        if (b.hasOwnProperty("value") || b.hasOwnProperty("defaultValue")) {
          var d = b.type;
          if (!("submit" !== d && "reset" !== d || void 0 !== b.value && null !== b.value)) return;
          b = "" + a._wrapperState.initialValue;
          c || b === a.value || (a.value = b);
          a.defaultValue = b;
        }
        c = a.name;
        "" !== c && (a.name = "");
        a.defaultChecked = !!a._wrapperState.initialChecked;
        "" !== c && (a.name = c);
      }
      function cb(a, b, c) {
        if ("number" !== b || Xa(a.ownerDocument) !== a) null == c ? a.defaultValue = "" + a._wrapperState.initialValue : a.defaultValue !== "" + c && (a.defaultValue = "" + c);
      }
      var eb = Array.isArray;
      function fb(a, b, c, d) {
        a = a.options;
        if (b) {
          b = {};
          for (var e = 0; e < c.length; e++) b["$" + c[e]] = true;
          for (c = 0; c < a.length; c++) e = b.hasOwnProperty("$" + a[c].value), a[c].selected !== e && (a[c].selected = e), e && d && (a[c].defaultSelected = true);
        } else {
          c = "" + Sa(c);
          b = null;
          for (e = 0; e < a.length; e++) {
            if (a[e].value === c) {
              a[e].selected = true;
              d && (a[e].defaultSelected = true);
              return;
            }
            null !== b || a[e].disabled || (b = a[e]);
          }
          null !== b && (b.selected = true);
        }
      }
      function gb(a, b) {
        if (null != b.dangerouslySetInnerHTML) throw Error(p(91));
        return A({}, b, { value: void 0, defaultValue: void 0, children: "" + a._wrapperState.initialValue });
      }
      function hb(a, b) {
        var c = b.value;
        if (null == c) {
          c = b.children;
          b = b.defaultValue;
          if (null != c) {
            if (null != b) throw Error(p(92));
            if (eb(c)) {
              if (1 < c.length) throw Error(p(93));
              c = c[0];
            }
            b = c;
          }
          null == b && (b = "");
          c = b;
        }
        a._wrapperState = { initialValue: Sa(c) };
      }
      function ib(a, b) {
        var c = Sa(b.value), d = Sa(b.defaultValue);
        null != c && (c = "" + c, c !== a.value && (a.value = c), null == b.defaultValue && a.defaultValue !== c && (a.defaultValue = c));
        null != d && (a.defaultValue = "" + d);
      }
      function jb(a) {
        var b = a.textContent;
        b === a._wrapperState.initialValue && "" !== b && null !== b && (a.value = b);
      }
      function kb(a) {
        switch (a) {
          case "svg":
            return "http://www.w3.org/2000/svg";
          case "math":
            return "http://www.w3.org/1998/Math/MathML";
          default:
            return "http://www.w3.org/1999/xhtml";
        }
      }
      function lb(a, b) {
        return null == a || "http://www.w3.org/1999/xhtml" === a ? kb(b) : "http://www.w3.org/2000/svg" === a && "foreignObject" === b ? "http://www.w3.org/1999/xhtml" : a;
      }
      var mb;
      var nb = (function(a) {
        return "undefined" !== typeof MSApp && MSApp.execUnsafeLocalFunction ? function(b, c, d, e) {
          MSApp.execUnsafeLocalFunction(function() {
            return a(b, c, d, e);
          });
        } : a;
      })(function(a, b) {
        if ("http://www.w3.org/2000/svg" !== a.namespaceURI || "innerHTML" in a) a.innerHTML = b;
        else {
          mb = mb || document.createElement("div");
          mb.innerHTML = "<svg>" + b.valueOf().toString() + "</svg>";
          for (b = mb.firstChild; a.firstChild; ) a.removeChild(a.firstChild);
          for (; b.firstChild; ) a.appendChild(b.firstChild);
        }
      });
      function ob(a, b) {
        if (b) {
          var c = a.firstChild;
          if (c && c === a.lastChild && 3 === c.nodeType) {
            c.nodeValue = b;
            return;
          }
        }
        a.textContent = b;
      }
      var pb = {
        animationIterationCount: true,
        aspectRatio: true,
        borderImageOutset: true,
        borderImageSlice: true,
        borderImageWidth: true,
        boxFlex: true,
        boxFlexGroup: true,
        boxOrdinalGroup: true,
        columnCount: true,
        columns: true,
        flex: true,
        flexGrow: true,
        flexPositive: true,
        flexShrink: true,
        flexNegative: true,
        flexOrder: true,
        gridArea: true,
        gridRow: true,
        gridRowEnd: true,
        gridRowSpan: true,
        gridRowStart: true,
        gridColumn: true,
        gridColumnEnd: true,
        gridColumnSpan: true,
        gridColumnStart: true,
        fontWeight: true,
        lineClamp: true,
        lineHeight: true,
        opacity: true,
        order: true,
        orphans: true,
        tabSize: true,
        widows: true,
        zIndex: true,
        zoom: true,
        fillOpacity: true,
        floodOpacity: true,
        stopOpacity: true,
        strokeDasharray: true,
        strokeDashoffset: true,
        strokeMiterlimit: true,
        strokeOpacity: true,
        strokeWidth: true
      };
      var qb = ["Webkit", "ms", "Moz", "O"];
      Object.keys(pb).forEach(function(a) {
        qb.forEach(function(b) {
          b = b + a.charAt(0).toUpperCase() + a.substring(1);
          pb[b] = pb[a];
        });
      });
      function rb(a, b, c) {
        return null == b || "boolean" === typeof b || "" === b ? "" : c || "number" !== typeof b || 0 === b || pb.hasOwnProperty(a) && pb[a] ? ("" + b).trim() : b + "px";
      }
      function sb(a, b) {
        a = a.style;
        for (var c in b) if (b.hasOwnProperty(c)) {
          var d = 0 === c.indexOf("--"), e = rb(c, b[c], d);
          "float" === c && (c = "cssFloat");
          d ? a.setProperty(c, e) : a[c] = e;
        }
      }
      var tb = A({ menuitem: true }, { area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, keygen: true, link: true, meta: true, param: true, source: true, track: true, wbr: true });
      function ub(a, b) {
        if (b) {
          if (tb[a] && (null != b.children || null != b.dangerouslySetInnerHTML)) throw Error(p(137, a));
          if (null != b.dangerouslySetInnerHTML) {
            if (null != b.children) throw Error(p(60));
            if ("object" !== typeof b.dangerouslySetInnerHTML || !("__html" in b.dangerouslySetInnerHTML)) throw Error(p(61));
          }
          if (null != b.style && "object" !== typeof b.style) throw Error(p(62));
        }
      }
      function vb(a, b) {
        if (-1 === a.indexOf("-")) return "string" === typeof b.is;
        switch (a) {
          case "annotation-xml":
          case "color-profile":
          case "font-face":
          case "font-face-src":
          case "font-face-uri":
          case "font-face-format":
          case "font-face-name":
          case "missing-glyph":
            return false;
          default:
            return true;
        }
      }
      var wb = null;
      function xb(a) {
        a = a.target || a.srcElement || window;
        a.correspondingUseElement && (a = a.correspondingUseElement);
        return 3 === a.nodeType ? a.parentNode : a;
      }
      var yb = null;
      var zb = null;
      var Ab = null;
      function Bb(a) {
        if (a = Cb(a)) {
          if ("function" !== typeof yb) throw Error(p(280));
          var b = a.stateNode;
          b && (b = Db(b), yb(a.stateNode, a.type, b));
        }
      }
      function Eb(a) {
        zb ? Ab ? Ab.push(a) : Ab = [a] : zb = a;
      }
      function Fb() {
        if (zb) {
          var a = zb, b = Ab;
          Ab = zb = null;
          Bb(a);
          if (b) for (a = 0; a < b.length; a++) Bb(b[a]);
        }
      }
      function Gb(a, b) {
        return a(b);
      }
      function Hb() {
      }
      var Ib = false;
      function Jb(a, b, c) {
        if (Ib) return a(b, c);
        Ib = true;
        try {
          return Gb(a, b, c);
        } finally {
          if (Ib = false, null !== zb || null !== Ab) Hb(), Fb();
        }
      }
      function Kb(a, b) {
        var c = a.stateNode;
        if (null === c) return null;
        var d = Db(c);
        if (null === d) return null;
        c = d[b];
        a: switch (b) {
          case "onClick":
          case "onClickCapture":
          case "onDoubleClick":
          case "onDoubleClickCapture":
          case "onMouseDown":
          case "onMouseDownCapture":
          case "onMouseMove":
          case "onMouseMoveCapture":
          case "onMouseUp":
          case "onMouseUpCapture":
          case "onMouseEnter":
            (d = !d.disabled) || (a = a.type, d = !("button" === a || "input" === a || "select" === a || "textarea" === a));
            a = !d;
            break a;
          default:
            a = false;
        }
        if (a) return null;
        if (c && "function" !== typeof c) throw Error(p(231, b, typeof c));
        return c;
      }
      var Lb = false;
      if (ia) try {
        Mb = {};
        Object.defineProperty(Mb, "passive", { get: function() {
          Lb = true;
        } });
        window.addEventListener("test", Mb, Mb);
        window.removeEventListener("test", Mb, Mb);
      } catch (a) {
        Lb = false;
      }
      var Mb;
      function Nb(a, b, c, d, e, f, g, h2, k) {
        var l = Array.prototype.slice.call(arguments, 3);
        try {
          b.apply(c, l);
        } catch (m) {
          this.onError(m);
        }
      }
      var Ob = false;
      var Pb = null;
      var Qb = false;
      var Rb = null;
      var Sb = { onError: function(a) {
        Ob = true;
        Pb = a;
      } };
      function Tb(a, b, c, d, e, f, g, h2, k) {
        Ob = false;
        Pb = null;
        Nb.apply(Sb, arguments);
      }
      function Ub(a, b, c, d, e, f, g, h2, k) {
        Tb.apply(this, arguments);
        if (Ob) {
          if (Ob) {
            var l = Pb;
            Ob = false;
            Pb = null;
          } else throw Error(p(198));
          Qb || (Qb = true, Rb = l);
        }
      }
      function Vb(a) {
        var b = a, c = a;
        if (a.alternate) for (; b.return; ) b = b.return;
        else {
          a = b;
          do
            b = a, 0 !== (b.flags & 4098) && (c = b.return), a = b.return;
          while (a);
        }
        return 3 === b.tag ? c : null;
      }
      function Wb(a) {
        if (13 === a.tag) {
          var b = a.memoizedState;
          null === b && (a = a.alternate, null !== a && (b = a.memoizedState));
          if (null !== b) return b.dehydrated;
        }
        return null;
      }
      function Xb(a) {
        if (Vb(a) !== a) throw Error(p(188));
      }
      function Yb(a) {
        var b = a.alternate;
        if (!b) {
          b = Vb(a);
          if (null === b) throw Error(p(188));
          return b !== a ? null : a;
        }
        for (var c = a, d = b; ; ) {
          var e = c.return;
          if (null === e) break;
          var f = e.alternate;
          if (null === f) {
            d = e.return;
            if (null !== d) {
              c = d;
              continue;
            }
            break;
          }
          if (e.child === f.child) {
            for (f = e.child; f; ) {
              if (f === c) return Xb(e), a;
              if (f === d) return Xb(e), b;
              f = f.sibling;
            }
            throw Error(p(188));
          }
          if (c.return !== d.return) c = e, d = f;
          else {
            for (var g = false, h2 = e.child; h2; ) {
              if (h2 === c) {
                g = true;
                c = e;
                d = f;
                break;
              }
              if (h2 === d) {
                g = true;
                d = e;
                c = f;
                break;
              }
              h2 = h2.sibling;
            }
            if (!g) {
              for (h2 = f.child; h2; ) {
                if (h2 === c) {
                  g = true;
                  c = f;
                  d = e;
                  break;
                }
                if (h2 === d) {
                  g = true;
                  d = f;
                  c = e;
                  break;
                }
                h2 = h2.sibling;
              }
              if (!g) throw Error(p(189));
            }
          }
          if (c.alternate !== d) throw Error(p(190));
        }
        if (3 !== c.tag) throw Error(p(188));
        return c.stateNode.current === c ? a : b;
      }
      function Zb(a) {
        a = Yb(a);
        return null !== a ? $b(a) : null;
      }
      function $b(a) {
        if (5 === a.tag || 6 === a.tag) return a;
        for (a = a.child; null !== a; ) {
          var b = $b(a);
          if (null !== b) return b;
          a = a.sibling;
        }
        return null;
      }
      var ac = ca.unstable_scheduleCallback;
      var bc = ca.unstable_cancelCallback;
      var cc = ca.unstable_shouldYield;
      var dc = ca.unstable_requestPaint;
      var B = ca.unstable_now;
      var ec = ca.unstable_getCurrentPriorityLevel;
      var fc = ca.unstable_ImmediatePriority;
      var gc = ca.unstable_UserBlockingPriority;
      var hc = ca.unstable_NormalPriority;
      var ic = ca.unstable_LowPriority;
      var jc = ca.unstable_IdlePriority;
      var kc = null;
      var lc = null;
      function mc(a) {
        if (lc && "function" === typeof lc.onCommitFiberRoot) try {
          lc.onCommitFiberRoot(kc, a, void 0, 128 === (a.current.flags & 128));
        } catch (b) {
        }
      }
      var oc = Math.clz32 ? Math.clz32 : nc;
      var pc = Math.log;
      var qc = Math.LN2;
      function nc(a) {
        a >>>= 0;
        return 0 === a ? 32 : 31 - (pc(a) / qc | 0) | 0;
      }
      var rc = 64;
      var sc = 4194304;
      function tc(a) {
        switch (a & -a) {
          case 1:
            return 1;
          case 2:
            return 2;
          case 4:
            return 4;
          case 8:
            return 8;
          case 16:
            return 16;
          case 32:
            return 32;
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
            return a & 4194240;
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            return a & 130023424;
          case 134217728:
            return 134217728;
          case 268435456:
            return 268435456;
          case 536870912:
            return 536870912;
          case 1073741824:
            return 1073741824;
          default:
            return a;
        }
      }
      function uc(a, b) {
        var c = a.pendingLanes;
        if (0 === c) return 0;
        var d = 0, e = a.suspendedLanes, f = a.pingedLanes, g = c & 268435455;
        if (0 !== g) {
          var h2 = g & ~e;
          0 !== h2 ? d = tc(h2) : (f &= g, 0 !== f && (d = tc(f)));
        } else g = c & ~e, 0 !== g ? d = tc(g) : 0 !== f && (d = tc(f));
        if (0 === d) return 0;
        if (0 !== b && b !== d && 0 === (b & e) && (e = d & -d, f = b & -b, e >= f || 16 === e && 0 !== (f & 4194240))) return b;
        0 !== (d & 4) && (d |= c & 16);
        b = a.entangledLanes;
        if (0 !== b) for (a = a.entanglements, b &= d; 0 < b; ) c = 31 - oc(b), e = 1 << c, d |= a[c], b &= ~e;
        return d;
      }
      function vc(a, b) {
        switch (a) {
          case 1:
          case 2:
          case 4:
            return b + 250;
          case 8:
          case 16:
          case 32:
          case 64:
          case 128:
          case 256:
          case 512:
          case 1024:
          case 2048:
          case 4096:
          case 8192:
          case 16384:
          case 32768:
          case 65536:
          case 131072:
          case 262144:
          case 524288:
          case 1048576:
          case 2097152:
            return b + 5e3;
          case 4194304:
          case 8388608:
          case 16777216:
          case 33554432:
          case 67108864:
            return -1;
          case 134217728:
          case 268435456:
          case 536870912:
          case 1073741824:
            return -1;
          default:
            return -1;
        }
      }
      function wc(a, b) {
        for (var c = a.suspendedLanes, d = a.pingedLanes, e = a.expirationTimes, f = a.pendingLanes; 0 < f; ) {
          var g = 31 - oc(f), h2 = 1 << g, k = e[g];
          if (-1 === k) {
            if (0 === (h2 & c) || 0 !== (h2 & d)) e[g] = vc(h2, b);
          } else k <= b && (a.expiredLanes |= h2);
          f &= ~h2;
        }
      }
      function xc(a) {
        a = a.pendingLanes & -1073741825;
        return 0 !== a ? a : a & 1073741824 ? 1073741824 : 0;
      }
      function yc() {
        var a = rc;
        rc <<= 1;
        0 === (rc & 4194240) && (rc = 64);
        return a;
      }
      function zc(a) {
        for (var b = [], c = 0; 31 > c; c++) b.push(a);
        return b;
      }
      function Ac(a, b, c) {
        a.pendingLanes |= b;
        536870912 !== b && (a.suspendedLanes = 0, a.pingedLanes = 0);
        a = a.eventTimes;
        b = 31 - oc(b);
        a[b] = c;
      }
      function Bc(a, b) {
        var c = a.pendingLanes & ~b;
        a.pendingLanes = b;
        a.suspendedLanes = 0;
        a.pingedLanes = 0;
        a.expiredLanes &= b;
        a.mutableReadLanes &= b;
        a.entangledLanes &= b;
        b = a.entanglements;
        var d = a.eventTimes;
        for (a = a.expirationTimes; 0 < c; ) {
          var e = 31 - oc(c), f = 1 << e;
          b[e] = 0;
          d[e] = -1;
          a[e] = -1;
          c &= ~f;
        }
      }
      function Cc(a, b) {
        var c = a.entangledLanes |= b;
        for (a = a.entanglements; c; ) {
          var d = 31 - oc(c), e = 1 << d;
          e & b | a[d] & b && (a[d] |= b);
          c &= ~e;
        }
      }
      var C = 0;
      function Dc(a) {
        a &= -a;
        return 1 < a ? 4 < a ? 0 !== (a & 268435455) ? 16 : 536870912 : 4 : 1;
      }
      var Ec;
      var Fc;
      var Gc;
      var Hc;
      var Ic;
      var Jc = false;
      var Kc = [];
      var Lc = null;
      var Mc = null;
      var Nc = null;
      var Oc = /* @__PURE__ */ new Map();
      var Pc = /* @__PURE__ */ new Map();
      var Qc = [];
      var Rc = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
      function Sc(a, b) {
        switch (a) {
          case "focusin":
          case "focusout":
            Lc = null;
            break;
          case "dragenter":
          case "dragleave":
            Mc = null;
            break;
          case "mouseover":
          case "mouseout":
            Nc = null;
            break;
          case "pointerover":
          case "pointerout":
            Oc.delete(b.pointerId);
            break;
          case "gotpointercapture":
          case "lostpointercapture":
            Pc.delete(b.pointerId);
        }
      }
      function Tc(a, b, c, d, e, f) {
        if (null === a || a.nativeEvent !== f) return a = { blockedOn: b, domEventName: c, eventSystemFlags: d, nativeEvent: f, targetContainers: [e] }, null !== b && (b = Cb(b), null !== b && Fc(b)), a;
        a.eventSystemFlags |= d;
        b = a.targetContainers;
        null !== e && -1 === b.indexOf(e) && b.push(e);
        return a;
      }
      function Uc(a, b, c, d, e) {
        switch (b) {
          case "focusin":
            return Lc = Tc(Lc, a, b, c, d, e), true;
          case "dragenter":
            return Mc = Tc(Mc, a, b, c, d, e), true;
          case "mouseover":
            return Nc = Tc(Nc, a, b, c, d, e), true;
          case "pointerover":
            var f = e.pointerId;
            Oc.set(f, Tc(Oc.get(f) || null, a, b, c, d, e));
            return true;
          case "gotpointercapture":
            return f = e.pointerId, Pc.set(f, Tc(Pc.get(f) || null, a, b, c, d, e)), true;
        }
        return false;
      }
      function Vc(a) {
        var b = Wc(a.target);
        if (null !== b) {
          var c = Vb(b);
          if (null !== c) {
            if (b = c.tag, 13 === b) {
              if (b = Wb(c), null !== b) {
                a.blockedOn = b;
                Ic(a.priority, function() {
                  Gc(c);
                });
                return;
              }
            } else if (3 === b && c.stateNode.current.memoizedState.isDehydrated) {
              a.blockedOn = 3 === c.tag ? c.stateNode.containerInfo : null;
              return;
            }
          }
        }
        a.blockedOn = null;
      }
      function Xc(a) {
        if (null !== a.blockedOn) return false;
        for (var b = a.targetContainers; 0 < b.length; ) {
          var c = Yc(a.domEventName, a.eventSystemFlags, b[0], a.nativeEvent);
          if (null === c) {
            c = a.nativeEvent;
            var d = new c.constructor(c.type, c);
            wb = d;
            c.target.dispatchEvent(d);
            wb = null;
          } else return b = Cb(c), null !== b && Fc(b), a.blockedOn = c, false;
          b.shift();
        }
        return true;
      }
      function Zc(a, b, c) {
        Xc(a) && c.delete(b);
      }
      function $c() {
        Jc = false;
        null !== Lc && Xc(Lc) && (Lc = null);
        null !== Mc && Xc(Mc) && (Mc = null);
        null !== Nc && Xc(Nc) && (Nc = null);
        Oc.forEach(Zc);
        Pc.forEach(Zc);
      }
      function ad(a, b) {
        a.blockedOn === b && (a.blockedOn = null, Jc || (Jc = true, ca.unstable_scheduleCallback(ca.unstable_NormalPriority, $c)));
      }
      function bd(a) {
        function b(b2) {
          return ad(b2, a);
        }
        if (0 < Kc.length) {
          ad(Kc[0], a);
          for (var c = 1; c < Kc.length; c++) {
            var d = Kc[c];
            d.blockedOn === a && (d.blockedOn = null);
          }
        }
        null !== Lc && ad(Lc, a);
        null !== Mc && ad(Mc, a);
        null !== Nc && ad(Nc, a);
        Oc.forEach(b);
        Pc.forEach(b);
        for (c = 0; c < Qc.length; c++) d = Qc[c], d.blockedOn === a && (d.blockedOn = null);
        for (; 0 < Qc.length && (c = Qc[0], null === c.blockedOn); ) Vc(c), null === c.blockedOn && Qc.shift();
      }
      var cd = ua.ReactCurrentBatchConfig;
      var dd = true;
      function ed(a, b, c, d) {
        var e = C, f = cd.transition;
        cd.transition = null;
        try {
          C = 1, fd(a, b, c, d);
        } finally {
          C = e, cd.transition = f;
        }
      }
      function gd(a, b, c, d) {
        var e = C, f = cd.transition;
        cd.transition = null;
        try {
          C = 4, fd(a, b, c, d);
        } finally {
          C = e, cd.transition = f;
        }
      }
      function fd(a, b, c, d) {
        if (dd) {
          var e = Yc(a, b, c, d);
          if (null === e) hd(a, b, d, id, c), Sc(a, d);
          else if (Uc(e, a, b, c, d)) d.stopPropagation();
          else if (Sc(a, d), b & 4 && -1 < Rc.indexOf(a)) {
            for (; null !== e; ) {
              var f = Cb(e);
              null !== f && Ec(f);
              f = Yc(a, b, c, d);
              null === f && hd(a, b, d, id, c);
              if (f === e) break;
              e = f;
            }
            null !== e && d.stopPropagation();
          } else hd(a, b, d, null, c);
        }
      }
      var id = null;
      function Yc(a, b, c, d) {
        id = null;
        a = xb(d);
        a = Wc(a);
        if (null !== a) if (b = Vb(a), null === b) a = null;
        else if (c = b.tag, 13 === c) {
          a = Wb(b);
          if (null !== a) return a;
          a = null;
        } else if (3 === c) {
          if (b.stateNode.current.memoizedState.isDehydrated) return 3 === b.tag ? b.stateNode.containerInfo : null;
          a = null;
        } else b !== a && (a = null);
        id = a;
        return null;
      }
      function jd(a) {
        switch (a) {
          case "cancel":
          case "click":
          case "close":
          case "contextmenu":
          case "copy":
          case "cut":
          case "auxclick":
          case "dblclick":
          case "dragend":
          case "dragstart":
          case "drop":
          case "focusin":
          case "focusout":
          case "input":
          case "invalid":
          case "keydown":
          case "keypress":
          case "keyup":
          case "mousedown":
          case "mouseup":
          case "paste":
          case "pause":
          case "play":
          case "pointercancel":
          case "pointerdown":
          case "pointerup":
          case "ratechange":
          case "reset":
          case "resize":
          case "seeked":
          case "submit":
          case "touchcancel":
          case "touchend":
          case "touchstart":
          case "volumechange":
          case "change":
          case "selectionchange":
          case "textInput":
          case "compositionstart":
          case "compositionend":
          case "compositionupdate":
          case "beforeblur":
          case "afterblur":
          case "beforeinput":
          case "blur":
          case "fullscreenchange":
          case "focus":
          case "hashchange":
          case "popstate":
          case "select":
          case "selectstart":
            return 1;
          case "drag":
          case "dragenter":
          case "dragexit":
          case "dragleave":
          case "dragover":
          case "mousemove":
          case "mouseout":
          case "mouseover":
          case "pointermove":
          case "pointerout":
          case "pointerover":
          case "scroll":
          case "toggle":
          case "touchmove":
          case "wheel":
          case "mouseenter":
          case "mouseleave":
          case "pointerenter":
          case "pointerleave":
            return 4;
          case "message":
            switch (ec()) {
              case fc:
                return 1;
              case gc:
                return 4;
              case hc:
              case ic:
                return 16;
              case jc:
                return 536870912;
              default:
                return 16;
            }
          default:
            return 16;
        }
      }
      var kd = null;
      var ld = null;
      var md = null;
      function nd() {
        if (md) return md;
        var a, b = ld, c = b.length, d, e = "value" in kd ? kd.value : kd.textContent, f = e.length;
        for (a = 0; a < c && b[a] === e[a]; a++) ;
        var g = c - a;
        for (d = 1; d <= g && b[c - d] === e[f - d]; d++) ;
        return md = e.slice(a, 1 < d ? 1 - d : void 0);
      }
      function od(a) {
        var b = a.keyCode;
        "charCode" in a ? (a = a.charCode, 0 === a && 13 === b && (a = 13)) : a = b;
        10 === a && (a = 13);
        return 32 <= a || 13 === a ? a : 0;
      }
      function pd() {
        return true;
      }
      function qd() {
        return false;
      }
      function rd(a) {
        function b(b2, d, e, f, g) {
          this._reactName = b2;
          this._targetInst = e;
          this.type = d;
          this.nativeEvent = f;
          this.target = g;
          this.currentTarget = null;
          for (var c in a) a.hasOwnProperty(c) && (b2 = a[c], this[c] = b2 ? b2(f) : f[c]);
          this.isDefaultPrevented = (null != f.defaultPrevented ? f.defaultPrevented : false === f.returnValue) ? pd : qd;
          this.isPropagationStopped = qd;
          return this;
        }
        A(b.prototype, { preventDefault: function() {
          this.defaultPrevented = true;
          var a2 = this.nativeEvent;
          a2 && (a2.preventDefault ? a2.preventDefault() : "unknown" !== typeof a2.returnValue && (a2.returnValue = false), this.isDefaultPrevented = pd);
        }, stopPropagation: function() {
          var a2 = this.nativeEvent;
          a2 && (a2.stopPropagation ? a2.stopPropagation() : "unknown" !== typeof a2.cancelBubble && (a2.cancelBubble = true), this.isPropagationStopped = pd);
        }, persist: function() {
        }, isPersistent: pd });
        return b;
      }
      var sd = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(a) {
        return a.timeStamp || Date.now();
      }, defaultPrevented: 0, isTrusted: 0 };
      var td = rd(sd);
      var ud = A({}, sd, { view: 0, detail: 0 });
      var vd = rd(ud);
      var wd;
      var xd;
      var yd;
      var Ad = A({}, ud, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: zd, button: 0, buttons: 0, relatedTarget: function(a) {
        return void 0 === a.relatedTarget ? a.fromElement === a.srcElement ? a.toElement : a.fromElement : a.relatedTarget;
      }, movementX: function(a) {
        if ("movementX" in a) return a.movementX;
        a !== yd && (yd && "mousemove" === a.type ? (wd = a.screenX - yd.screenX, xd = a.screenY - yd.screenY) : xd = wd = 0, yd = a);
        return wd;
      }, movementY: function(a) {
        return "movementY" in a ? a.movementY : xd;
      } });
      var Bd = rd(Ad);
      var Cd = A({}, Ad, { dataTransfer: 0 });
      var Dd = rd(Cd);
      var Ed = A({}, ud, { relatedTarget: 0 });
      var Fd = rd(Ed);
      var Gd = A({}, sd, { animationName: 0, elapsedTime: 0, pseudoElement: 0 });
      var Hd = rd(Gd);
      var Id = A({}, sd, { clipboardData: function(a) {
        return "clipboardData" in a ? a.clipboardData : window.clipboardData;
      } });
      var Jd = rd(Id);
      var Kd = A({}, sd, { data: 0 });
      var Ld = rd(Kd);
      var Md = {
        Esc: "Escape",
        Spacebar: " ",
        Left: "ArrowLeft",
        Up: "ArrowUp",
        Right: "ArrowRight",
        Down: "ArrowDown",
        Del: "Delete",
        Win: "OS",
        Menu: "ContextMenu",
        Apps: "ContextMenu",
        Scroll: "ScrollLock",
        MozPrintableKey: "Unidentified"
      };
      var Nd = {
        8: "Backspace",
        9: "Tab",
        12: "Clear",
        13: "Enter",
        16: "Shift",
        17: "Control",
        18: "Alt",
        19: "Pause",
        20: "CapsLock",
        27: "Escape",
        32: " ",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "ArrowLeft",
        38: "ArrowUp",
        39: "ArrowRight",
        40: "ArrowDown",
        45: "Insert",
        46: "Delete",
        112: "F1",
        113: "F2",
        114: "F3",
        115: "F4",
        116: "F5",
        117: "F6",
        118: "F7",
        119: "F8",
        120: "F9",
        121: "F10",
        122: "F11",
        123: "F12",
        144: "NumLock",
        145: "ScrollLock",
        224: "Meta"
      };
      var Od = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
      function Pd(a) {
        var b = this.nativeEvent;
        return b.getModifierState ? b.getModifierState(a) : (a = Od[a]) ? !!b[a] : false;
      }
      function zd() {
        return Pd;
      }
      var Qd = A({}, ud, { key: function(a) {
        if (a.key) {
          var b = Md[a.key] || a.key;
          if ("Unidentified" !== b) return b;
        }
        return "keypress" === a.type ? (a = od(a), 13 === a ? "Enter" : String.fromCharCode(a)) : "keydown" === a.type || "keyup" === a.type ? Nd[a.keyCode] || "Unidentified" : "";
      }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: zd, charCode: function(a) {
        return "keypress" === a.type ? od(a) : 0;
      }, keyCode: function(a) {
        return "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
      }, which: function(a) {
        return "keypress" === a.type ? od(a) : "keydown" === a.type || "keyup" === a.type ? a.keyCode : 0;
      } });
      var Rd = rd(Qd);
      var Sd = A({}, Ad, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 });
      var Td = rd(Sd);
      var Ud = A({}, ud, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: zd });
      var Vd = rd(Ud);
      var Wd = A({}, sd, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 });
      var Xd = rd(Wd);
      var Yd = A({}, Ad, {
        deltaX: function(a) {
          return "deltaX" in a ? a.deltaX : "wheelDeltaX" in a ? -a.wheelDeltaX : 0;
        },
        deltaY: function(a) {
          return "deltaY" in a ? a.deltaY : "wheelDeltaY" in a ? -a.wheelDeltaY : "wheelDelta" in a ? -a.wheelDelta : 0;
        },
        deltaZ: 0,
        deltaMode: 0
      });
      var Zd = rd(Yd);
      var $d = [9, 13, 27, 32];
      var ae = ia && "CompositionEvent" in window;
      var be = null;
      ia && "documentMode" in document && (be = document.documentMode);
      var ce = ia && "TextEvent" in window && !be;
      var de = ia && (!ae || be && 8 < be && 11 >= be);
      var ee = String.fromCharCode(32);
      var fe = false;
      function ge(a, b) {
        switch (a) {
          case "keyup":
            return -1 !== $d.indexOf(b.keyCode);
          case "keydown":
            return 229 !== b.keyCode;
          case "keypress":
          case "mousedown":
          case "focusout":
            return true;
          default:
            return false;
        }
      }
      function he(a) {
        a = a.detail;
        return "object" === typeof a && "data" in a ? a.data : null;
      }
      var ie = false;
      function je(a, b) {
        switch (a) {
          case "compositionend":
            return he(b);
          case "keypress":
            if (32 !== b.which) return null;
            fe = true;
            return ee;
          case "textInput":
            return a = b.data, a === ee && fe ? null : a;
          default:
            return null;
        }
      }
      function ke(a, b) {
        if (ie) return "compositionend" === a || !ae && ge(a, b) ? (a = nd(), md = ld = kd = null, ie = false, a) : null;
        switch (a) {
          case "paste":
            return null;
          case "keypress":
            if (!(b.ctrlKey || b.altKey || b.metaKey) || b.ctrlKey && b.altKey) {
              if (b.char && 1 < b.char.length) return b.char;
              if (b.which) return String.fromCharCode(b.which);
            }
            return null;
          case "compositionend":
            return de && "ko" !== b.locale ? null : b.data;
          default:
            return null;
        }
      }
      var le = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
      function me(a) {
        var b = a && a.nodeName && a.nodeName.toLowerCase();
        return "input" === b ? !!le[a.type] : "textarea" === b ? true : false;
      }
      function ne(a, b, c, d) {
        Eb(d);
        b = oe(b, "onChange");
        0 < b.length && (c = new td("onChange", "change", null, c, d), a.push({ event: c, listeners: b }));
      }
      var pe = null;
      var qe = null;
      function re(a) {
        se(a, 0);
      }
      function te(a) {
        var b = ue(a);
        if (Wa(b)) return a;
      }
      function ve(a, b) {
        if ("change" === a) return b;
      }
      var we = false;
      if (ia) {
        if (ia) {
          ye = "oninput" in document;
          if (!ye) {
            ze = document.createElement("div");
            ze.setAttribute("oninput", "return;");
            ye = "function" === typeof ze.oninput;
          }
          xe = ye;
        } else xe = false;
        we = xe && (!document.documentMode || 9 < document.documentMode);
      }
      var xe;
      var ye;
      var ze;
      function Ae() {
        pe && (pe.detachEvent("onpropertychange", Be), qe = pe = null);
      }
      function Be(a) {
        if ("value" === a.propertyName && te(qe)) {
          var b = [];
          ne(b, qe, a, xb(a));
          Jb(re, b);
        }
      }
      function Ce(a, b, c) {
        "focusin" === a ? (Ae(), pe = b, qe = c, pe.attachEvent("onpropertychange", Be)) : "focusout" === a && Ae();
      }
      function De(a) {
        if ("selectionchange" === a || "keyup" === a || "keydown" === a) return te(qe);
      }
      function Ee(a, b) {
        if ("click" === a) return te(b);
      }
      function Fe(a, b) {
        if ("input" === a || "change" === a) return te(b);
      }
      function Ge(a, b) {
        return a === b && (0 !== a || 1 / a === 1 / b) || a !== a && b !== b;
      }
      var He = "function" === typeof Object.is ? Object.is : Ge;
      function Ie(a, b) {
        if (He(a, b)) return true;
        if ("object" !== typeof a || null === a || "object" !== typeof b || null === b) return false;
        var c = Object.keys(a), d = Object.keys(b);
        if (c.length !== d.length) return false;
        for (d = 0; d < c.length; d++) {
          var e = c[d];
          if (!ja.call(b, e) || !He(a[e], b[e])) return false;
        }
        return true;
      }
      function Je(a) {
        for (; a && a.firstChild; ) a = a.firstChild;
        return a;
      }
      function Ke(a, b) {
        var c = Je(a);
        a = 0;
        for (var d; c; ) {
          if (3 === c.nodeType) {
            d = a + c.textContent.length;
            if (a <= b && d >= b) return { node: c, offset: b - a };
            a = d;
          }
          a: {
            for (; c; ) {
              if (c.nextSibling) {
                c = c.nextSibling;
                break a;
              }
              c = c.parentNode;
            }
            c = void 0;
          }
          c = Je(c);
        }
      }
      function Le(a, b) {
        return a && b ? a === b ? true : a && 3 === a.nodeType ? false : b && 3 === b.nodeType ? Le(a, b.parentNode) : "contains" in a ? a.contains(b) : a.compareDocumentPosition ? !!(a.compareDocumentPosition(b) & 16) : false : false;
      }
      function Me() {
        for (var a = window, b = Xa(); b instanceof a.HTMLIFrameElement; ) {
          try {
            var c = "string" === typeof b.contentWindow.location.href;
          } catch (d) {
            c = false;
          }
          if (c) a = b.contentWindow;
          else break;
          b = Xa(a.document);
        }
        return b;
      }
      function Ne(a) {
        var b = a && a.nodeName && a.nodeName.toLowerCase();
        return b && ("input" === b && ("text" === a.type || "search" === a.type || "tel" === a.type || "url" === a.type || "password" === a.type) || "textarea" === b || "true" === a.contentEditable);
      }
      function Oe(a) {
        var b = Me(), c = a.focusedElem, d = a.selectionRange;
        if (b !== c && c && c.ownerDocument && Le(c.ownerDocument.documentElement, c)) {
          if (null !== d && Ne(c)) {
            if (b = d.start, a = d.end, void 0 === a && (a = b), "selectionStart" in c) c.selectionStart = b, c.selectionEnd = Math.min(a, c.value.length);
            else if (a = (b = c.ownerDocument || document) && b.defaultView || window, a.getSelection) {
              a = a.getSelection();
              var e = c.textContent.length, f = Math.min(d.start, e);
              d = void 0 === d.end ? f : Math.min(d.end, e);
              !a.extend && f > d && (e = d, d = f, f = e);
              e = Ke(c, f);
              var g = Ke(
                c,
                d
              );
              e && g && (1 !== a.rangeCount || a.anchorNode !== e.node || a.anchorOffset !== e.offset || a.focusNode !== g.node || a.focusOffset !== g.offset) && (b = b.createRange(), b.setStart(e.node, e.offset), a.removeAllRanges(), f > d ? (a.addRange(b), a.extend(g.node, g.offset)) : (b.setEnd(g.node, g.offset), a.addRange(b)));
            }
          }
          b = [];
          for (a = c; a = a.parentNode; ) 1 === a.nodeType && b.push({ element: a, left: a.scrollLeft, top: a.scrollTop });
          "function" === typeof c.focus && c.focus();
          for (c = 0; c < b.length; c++) a = b[c], a.element.scrollLeft = a.left, a.element.scrollTop = a.top;
        }
      }
      var Pe = ia && "documentMode" in document && 11 >= document.documentMode;
      var Qe = null;
      var Re = null;
      var Se = null;
      var Te = false;
      function Ue(a, b, c) {
        var d = c.window === c ? c.document : 9 === c.nodeType ? c : c.ownerDocument;
        Te || null == Qe || Qe !== Xa(d) || (d = Qe, "selectionStart" in d && Ne(d) ? d = { start: d.selectionStart, end: d.selectionEnd } : (d = (d.ownerDocument && d.ownerDocument.defaultView || window).getSelection(), d = { anchorNode: d.anchorNode, anchorOffset: d.anchorOffset, focusNode: d.focusNode, focusOffset: d.focusOffset }), Se && Ie(Se, d) || (Se = d, d = oe(Re, "onSelect"), 0 < d.length && (b = new td("onSelect", "select", null, b, c), a.push({ event: b, listeners: d }), b.target = Qe)));
      }
      function Ve(a, b) {
        var c = {};
        c[a.toLowerCase()] = b.toLowerCase();
        c["Webkit" + a] = "webkit" + b;
        c["Moz" + a] = "moz" + b;
        return c;
      }
      var We = { animationend: Ve("Animation", "AnimationEnd"), animationiteration: Ve("Animation", "AnimationIteration"), animationstart: Ve("Animation", "AnimationStart"), transitionend: Ve("Transition", "TransitionEnd") };
      var Xe = {};
      var Ye = {};
      ia && (Ye = document.createElement("div").style, "AnimationEvent" in window || (delete We.animationend.animation, delete We.animationiteration.animation, delete We.animationstart.animation), "TransitionEvent" in window || delete We.transitionend.transition);
      function Ze(a) {
        if (Xe[a]) return Xe[a];
        if (!We[a]) return a;
        var b = We[a], c;
        for (c in b) if (b.hasOwnProperty(c) && c in Ye) return Xe[a] = b[c];
        return a;
      }
      var $e = Ze("animationend");
      var af = Ze("animationiteration");
      var bf = Ze("animationstart");
      var cf = Ze("transitionend");
      var df = /* @__PURE__ */ new Map();
      var ef = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
      function ff(a, b) {
        df.set(a, b);
        fa(b, [a]);
      }
      for (gf = 0; gf < ef.length; gf++) {
        hf = ef[gf], jf = hf.toLowerCase(), kf = hf[0].toUpperCase() + hf.slice(1);
        ff(jf, "on" + kf);
      }
      var hf;
      var jf;
      var kf;
      var gf;
      ff($e, "onAnimationEnd");
      ff(af, "onAnimationIteration");
      ff(bf, "onAnimationStart");
      ff("dblclick", "onDoubleClick");
      ff("focusin", "onFocus");
      ff("focusout", "onBlur");
      ff(cf, "onTransitionEnd");
      ha("onMouseEnter", ["mouseout", "mouseover"]);
      ha("onMouseLeave", ["mouseout", "mouseover"]);
      ha("onPointerEnter", ["pointerout", "pointerover"]);
      ha("onPointerLeave", ["pointerout", "pointerover"]);
      fa("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
      fa("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
      fa("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
      fa("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
      fa("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
      fa("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
      var lf = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" ");
      var mf = new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));
      function nf(a, b, c) {
        var d = a.type || "unknown-event";
        a.currentTarget = c;
        Ub(d, b, void 0, a);
        a.currentTarget = null;
      }
      function se(a, b) {
        b = 0 !== (b & 4);
        for (var c = 0; c < a.length; c++) {
          var d = a[c], e = d.event;
          d = d.listeners;
          a: {
            var f = void 0;
            if (b) for (var g = d.length - 1; 0 <= g; g--) {
              var h2 = d[g], k = h2.instance, l = h2.currentTarget;
              h2 = h2.listener;
              if (k !== f && e.isPropagationStopped()) break a;
              nf(e, h2, l);
              f = k;
            }
            else for (g = 0; g < d.length; g++) {
              h2 = d[g];
              k = h2.instance;
              l = h2.currentTarget;
              h2 = h2.listener;
              if (k !== f && e.isPropagationStopped()) break a;
              nf(e, h2, l);
              f = k;
            }
          }
        }
        if (Qb) throw a = Rb, Qb = false, Rb = null, a;
      }
      function D(a, b) {
        var c = b[of];
        void 0 === c && (c = b[of] = /* @__PURE__ */ new Set());
        var d = a + "__bubble";
        c.has(d) || (pf(b, a, 2, false), c.add(d));
      }
      function qf(a, b, c) {
        var d = 0;
        b && (d |= 4);
        pf(c, a, d, b);
      }
      var rf = "_reactListening" + Math.random().toString(36).slice(2);
      function sf(a) {
        if (!a[rf]) {
          a[rf] = true;
          da.forEach(function(b2) {
            "selectionchange" !== b2 && (mf.has(b2) || qf(b2, false, a), qf(b2, true, a));
          });
          var b = 9 === a.nodeType ? a : a.ownerDocument;
          null === b || b[rf] || (b[rf] = true, qf("selectionchange", false, b));
        }
      }
      function pf(a, b, c, d) {
        switch (jd(b)) {
          case 1:
            var e = ed;
            break;
          case 4:
            e = gd;
            break;
          default:
            e = fd;
        }
        c = e.bind(null, b, c, a);
        e = void 0;
        !Lb || "touchstart" !== b && "touchmove" !== b && "wheel" !== b || (e = true);
        d ? void 0 !== e ? a.addEventListener(b, c, { capture: true, passive: e }) : a.addEventListener(b, c, true) : void 0 !== e ? a.addEventListener(b, c, { passive: e }) : a.addEventListener(b, c, false);
      }
      function hd(a, b, c, d, e) {
        var f = d;
        if (0 === (b & 1) && 0 === (b & 2) && null !== d) a: for (; ; ) {
          if (null === d) return;
          var g = d.tag;
          if (3 === g || 4 === g) {
            var h2 = d.stateNode.containerInfo;
            if (h2 === e || 8 === h2.nodeType && h2.parentNode === e) break;
            if (4 === g) for (g = d.return; null !== g; ) {
              var k = g.tag;
              if (3 === k || 4 === k) {
                if (k = g.stateNode.containerInfo, k === e || 8 === k.nodeType && k.parentNode === e) return;
              }
              g = g.return;
            }
            for (; null !== h2; ) {
              g = Wc(h2);
              if (null === g) return;
              k = g.tag;
              if (5 === k || 6 === k) {
                d = f = g;
                continue a;
              }
              h2 = h2.parentNode;
            }
          }
          d = d.return;
        }
        Jb(function() {
          var d2 = f, e2 = xb(c), g2 = [];
          a: {
            var h3 = df.get(a);
            if (void 0 !== h3) {
              var k2 = td, n = a;
              switch (a) {
                case "keypress":
                  if (0 === od(c)) break a;
                case "keydown":
                case "keyup":
                  k2 = Rd;
                  break;
                case "focusin":
                  n = "focus";
                  k2 = Fd;
                  break;
                case "focusout":
                  n = "blur";
                  k2 = Fd;
                  break;
                case "beforeblur":
                case "afterblur":
                  k2 = Fd;
                  break;
                case "click":
                  if (2 === c.button) break a;
                case "auxclick":
                case "dblclick":
                case "mousedown":
                case "mousemove":
                case "mouseup":
                case "mouseout":
                case "mouseover":
                case "contextmenu":
                  k2 = Bd;
                  break;
                case "drag":
                case "dragend":
                case "dragenter":
                case "dragexit":
                case "dragleave":
                case "dragover":
                case "dragstart":
                case "drop":
                  k2 = Dd;
                  break;
                case "touchcancel":
                case "touchend":
                case "touchmove":
                case "touchstart":
                  k2 = Vd;
                  break;
                case $e:
                case af:
                case bf:
                  k2 = Hd;
                  break;
                case cf:
                  k2 = Xd;
                  break;
                case "scroll":
                  k2 = vd;
                  break;
                case "wheel":
                  k2 = Zd;
                  break;
                case "copy":
                case "cut":
                case "paste":
                  k2 = Jd;
                  break;
                case "gotpointercapture":
                case "lostpointercapture":
                case "pointercancel":
                case "pointerdown":
                case "pointermove":
                case "pointerout":
                case "pointerover":
                case "pointerup":
                  k2 = Td;
              }
              var t = 0 !== (b & 4), J = !t && "scroll" === a, x = t ? null !== h3 ? h3 + "Capture" : null : h3;
              t = [];
              for (var w = d2, u; null !== w; ) {
                u = w;
                var F = u.stateNode;
                5 === u.tag && null !== F && (u = F, null !== x && (F = Kb(w, x), null != F && t.push(tf(w, F, u))));
                if (J) break;
                w = w.return;
              }
              0 < t.length && (h3 = new k2(h3, n, null, c, e2), g2.push({ event: h3, listeners: t }));
            }
          }
          if (0 === (b & 7)) {
            a: {
              h3 = "mouseover" === a || "pointerover" === a;
              k2 = "mouseout" === a || "pointerout" === a;
              if (h3 && c !== wb && (n = c.relatedTarget || c.fromElement) && (Wc(n) || n[uf])) break a;
              if (k2 || h3) {
                h3 = e2.window === e2 ? e2 : (h3 = e2.ownerDocument) ? h3.defaultView || h3.parentWindow : window;
                if (k2) {
                  if (n = c.relatedTarget || c.toElement, k2 = d2, n = n ? Wc(n) : null, null !== n && (J = Vb(n), n !== J || 5 !== n.tag && 6 !== n.tag)) n = null;
                } else k2 = null, n = d2;
                if (k2 !== n) {
                  t = Bd;
                  F = "onMouseLeave";
                  x = "onMouseEnter";
                  w = "mouse";
                  if ("pointerout" === a || "pointerover" === a) t = Td, F = "onPointerLeave", x = "onPointerEnter", w = "pointer";
                  J = null == k2 ? h3 : ue(k2);
                  u = null == n ? h3 : ue(n);
                  h3 = new t(F, w + "leave", k2, c, e2);
                  h3.target = J;
                  h3.relatedTarget = u;
                  F = null;
                  Wc(e2) === d2 && (t = new t(x, w + "enter", n, c, e2), t.target = u, t.relatedTarget = J, F = t);
                  J = F;
                  if (k2 && n) b: {
                    t = k2;
                    x = n;
                    w = 0;
                    for (u = t; u; u = vf(u)) w++;
                    u = 0;
                    for (F = x; F; F = vf(F)) u++;
                    for (; 0 < w - u; ) t = vf(t), w--;
                    for (; 0 < u - w; ) x = vf(x), u--;
                    for (; w--; ) {
                      if (t === x || null !== x && t === x.alternate) break b;
                      t = vf(t);
                      x = vf(x);
                    }
                    t = null;
                  }
                  else t = null;
                  null !== k2 && wf(g2, h3, k2, t, false);
                  null !== n && null !== J && wf(g2, J, n, t, true);
                }
              }
            }
            a: {
              h3 = d2 ? ue(d2) : window;
              k2 = h3.nodeName && h3.nodeName.toLowerCase();
              if ("select" === k2 || "input" === k2 && "file" === h3.type) var na = ve;
              else if (me(h3)) if (we) na = Fe;
              else {
                na = De;
                var xa = Ce;
              }
              else (k2 = h3.nodeName) && "input" === k2.toLowerCase() && ("checkbox" === h3.type || "radio" === h3.type) && (na = Ee);
              if (na && (na = na(a, d2))) {
                ne(g2, na, c, e2);
                break a;
              }
              xa && xa(a, h3, d2);
              "focusout" === a && (xa = h3._wrapperState) && xa.controlled && "number" === h3.type && cb(h3, "number", h3.value);
            }
            xa = d2 ? ue(d2) : window;
            switch (a) {
              case "focusin":
                if (me(xa) || "true" === xa.contentEditable) Qe = xa, Re = d2, Se = null;
                break;
              case "focusout":
                Se = Re = Qe = null;
                break;
              case "mousedown":
                Te = true;
                break;
              case "contextmenu":
              case "mouseup":
              case "dragend":
                Te = false;
                Ue(g2, c, e2);
                break;
              case "selectionchange":
                if (Pe) break;
              case "keydown":
              case "keyup":
                Ue(g2, c, e2);
            }
            var $a;
            if (ae) b: {
              switch (a) {
                case "compositionstart":
                  var ba = "onCompositionStart";
                  break b;
                case "compositionend":
                  ba = "onCompositionEnd";
                  break b;
                case "compositionupdate":
                  ba = "onCompositionUpdate";
                  break b;
              }
              ba = void 0;
            }
            else ie ? ge(a, c) && (ba = "onCompositionEnd") : "keydown" === a && 229 === c.keyCode && (ba = "onCompositionStart");
            ba && (de && "ko" !== c.locale && (ie || "onCompositionStart" !== ba ? "onCompositionEnd" === ba && ie && ($a = nd()) : (kd = e2, ld = "value" in kd ? kd.value : kd.textContent, ie = true)), xa = oe(d2, ba), 0 < xa.length && (ba = new Ld(ba, a, null, c, e2), g2.push({ event: ba, listeners: xa }), $a ? ba.data = $a : ($a = he(c), null !== $a && (ba.data = $a))));
            if ($a = ce ? je(a, c) : ke(a, c)) d2 = oe(d2, "onBeforeInput"), 0 < d2.length && (e2 = new Ld("onBeforeInput", "beforeinput", null, c, e2), g2.push({ event: e2, listeners: d2 }), e2.data = $a);
          }
          se(g2, b);
        });
      }
      function tf(a, b, c) {
        return { instance: a, listener: b, currentTarget: c };
      }
      function oe(a, b) {
        for (var c = b + "Capture", d = []; null !== a; ) {
          var e = a, f = e.stateNode;
          5 === e.tag && null !== f && (e = f, f = Kb(a, c), null != f && d.unshift(tf(a, f, e)), f = Kb(a, b), null != f && d.push(tf(a, f, e)));
          a = a.return;
        }
        return d;
      }
      function vf(a) {
        if (null === a) return null;
        do
          a = a.return;
        while (a && 5 !== a.tag);
        return a ? a : null;
      }
      function wf(a, b, c, d, e) {
        for (var f = b._reactName, g = []; null !== c && c !== d; ) {
          var h2 = c, k = h2.alternate, l = h2.stateNode;
          if (null !== k && k === d) break;
          5 === h2.tag && null !== l && (h2 = l, e ? (k = Kb(c, f), null != k && g.unshift(tf(c, k, h2))) : e || (k = Kb(c, f), null != k && g.push(tf(c, k, h2))));
          c = c.return;
        }
        0 !== g.length && a.push({ event: b, listeners: g });
      }
      var xf = /\r\n?/g;
      var yf = /\u0000|\uFFFD/g;
      function zf(a) {
        return ("string" === typeof a ? a : "" + a).replace(xf, "\n").replace(yf, "");
      }
      function Af(a, b, c) {
        b = zf(b);
        if (zf(a) !== b && c) throw Error(p(425));
      }
      function Bf() {
      }
      var Cf = null;
      var Df = null;
      function Ef(a, b) {
        return "textarea" === a || "noscript" === a || "string" === typeof b.children || "number" === typeof b.children || "object" === typeof b.dangerouslySetInnerHTML && null !== b.dangerouslySetInnerHTML && null != b.dangerouslySetInnerHTML.__html;
      }
      var Ff = "function" === typeof setTimeout ? setTimeout : void 0;
      var Gf = "function" === typeof clearTimeout ? clearTimeout : void 0;
      var Hf = "function" === typeof Promise ? Promise : void 0;
      var Jf = "function" === typeof queueMicrotask ? queueMicrotask : "undefined" !== typeof Hf ? function(a) {
        return Hf.resolve(null).then(a).catch(If);
      } : Ff;
      function If(a) {
        setTimeout(function() {
          throw a;
        });
      }
      function Kf(a, b) {
        var c = b, d = 0;
        do {
          var e = c.nextSibling;
          a.removeChild(c);
          if (e && 8 === e.nodeType) if (c = e.data, "/$" === c) {
            if (0 === d) {
              a.removeChild(e);
              bd(b);
              return;
            }
            d--;
          } else "$" !== c && "$?" !== c && "$!" !== c || d++;
          c = e;
        } while (c);
        bd(b);
      }
      function Lf(a) {
        for (; null != a; a = a.nextSibling) {
          var b = a.nodeType;
          if (1 === b || 3 === b) break;
          if (8 === b) {
            b = a.data;
            if ("$" === b || "$!" === b || "$?" === b) break;
            if ("/$" === b) return null;
          }
        }
        return a;
      }
      function Mf(a) {
        a = a.previousSibling;
        for (var b = 0; a; ) {
          if (8 === a.nodeType) {
            var c = a.data;
            if ("$" === c || "$!" === c || "$?" === c) {
              if (0 === b) return a;
              b--;
            } else "/$" === c && b++;
          }
          a = a.previousSibling;
        }
        return null;
      }
      var Nf = Math.random().toString(36).slice(2);
      var Of = "__reactFiber$" + Nf;
      var Pf = "__reactProps$" + Nf;
      var uf = "__reactContainer$" + Nf;
      var of = "__reactEvents$" + Nf;
      var Qf = "__reactListeners$" + Nf;
      var Rf = "__reactHandles$" + Nf;
      function Wc(a) {
        var b = a[Of];
        if (b) return b;
        for (var c = a.parentNode; c; ) {
          if (b = c[uf] || c[Of]) {
            c = b.alternate;
            if (null !== b.child || null !== c && null !== c.child) for (a = Mf(a); null !== a; ) {
              if (c = a[Of]) return c;
              a = Mf(a);
            }
            return b;
          }
          a = c;
          c = a.parentNode;
        }
        return null;
      }
      function Cb(a) {
        a = a[Of] || a[uf];
        return !a || 5 !== a.tag && 6 !== a.tag && 13 !== a.tag && 3 !== a.tag ? null : a;
      }
      function ue(a) {
        if (5 === a.tag || 6 === a.tag) return a.stateNode;
        throw Error(p(33));
      }
      function Db(a) {
        return a[Pf] || null;
      }
      var Sf = [];
      var Tf = -1;
      function Uf(a) {
        return { current: a };
      }
      function E(a) {
        0 > Tf || (a.current = Sf[Tf], Sf[Tf] = null, Tf--);
      }
      function G(a, b) {
        Tf++;
        Sf[Tf] = a.current;
        a.current = b;
      }
      var Vf = {};
      var H = Uf(Vf);
      var Wf = Uf(false);
      var Xf = Vf;
      function Yf(a, b) {
        var c = a.type.contextTypes;
        if (!c) return Vf;
        var d = a.stateNode;
        if (d && d.__reactInternalMemoizedUnmaskedChildContext === b) return d.__reactInternalMemoizedMaskedChildContext;
        var e = {}, f;
        for (f in c) e[f] = b[f];
        d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = b, a.__reactInternalMemoizedMaskedChildContext = e);
        return e;
      }
      function Zf(a) {
        a = a.childContextTypes;
        return null !== a && void 0 !== a;
      }
      function $f() {
        E(Wf);
        E(H);
      }
      function ag(a, b, c) {
        if (H.current !== Vf) throw Error(p(168));
        G(H, b);
        G(Wf, c);
      }
      function bg(a, b, c) {
        var d = a.stateNode;
        b = b.childContextTypes;
        if ("function" !== typeof d.getChildContext) return c;
        d = d.getChildContext();
        for (var e in d) if (!(e in b)) throw Error(p(108, Ra(a) || "Unknown", e));
        return A({}, c, d);
      }
      function cg(a) {
        a = (a = a.stateNode) && a.__reactInternalMemoizedMergedChildContext || Vf;
        Xf = H.current;
        G(H, a);
        G(Wf, Wf.current);
        return true;
      }
      function dg(a, b, c) {
        var d = a.stateNode;
        if (!d) throw Error(p(169));
        c ? (a = bg(a, b, Xf), d.__reactInternalMemoizedMergedChildContext = a, E(Wf), E(H), G(H, a)) : E(Wf);
        G(Wf, c);
      }
      var eg = null;
      var fg = false;
      var gg = false;
      function hg(a) {
        null === eg ? eg = [a] : eg.push(a);
      }
      function ig(a) {
        fg = true;
        hg(a);
      }
      function jg() {
        if (!gg && null !== eg) {
          gg = true;
          var a = 0, b = C;
          try {
            var c = eg;
            for (C = 1; a < c.length; a++) {
              var d = c[a];
              do
                d = d(true);
              while (null !== d);
            }
            eg = null;
            fg = false;
          } catch (e) {
            throw null !== eg && (eg = eg.slice(a + 1)), ac(fc, jg), e;
          } finally {
            C = b, gg = false;
          }
        }
        return null;
      }
      var kg = [];
      var lg = 0;
      var mg = null;
      var ng = 0;
      var og = [];
      var pg = 0;
      var qg = null;
      var rg = 1;
      var sg = "";
      function tg(a, b) {
        kg[lg++] = ng;
        kg[lg++] = mg;
        mg = a;
        ng = b;
      }
      function ug(a, b, c) {
        og[pg++] = rg;
        og[pg++] = sg;
        og[pg++] = qg;
        qg = a;
        var d = rg;
        a = sg;
        var e = 32 - oc(d) - 1;
        d &= ~(1 << e);
        c += 1;
        var f = 32 - oc(b) + e;
        if (30 < f) {
          var g = e - e % 5;
          f = (d & (1 << g) - 1).toString(32);
          d >>= g;
          e -= g;
          rg = 1 << 32 - oc(b) + e | c << e | d;
          sg = f + a;
        } else rg = 1 << f | c << e | d, sg = a;
      }
      function vg(a) {
        null !== a.return && (tg(a, 1), ug(a, 1, 0));
      }
      function wg(a) {
        for (; a === mg; ) mg = kg[--lg], kg[lg] = null, ng = kg[--lg], kg[lg] = null;
        for (; a === qg; ) qg = og[--pg], og[pg] = null, sg = og[--pg], og[pg] = null, rg = og[--pg], og[pg] = null;
      }
      var xg = null;
      var yg = null;
      var I = false;
      var zg = null;
      function Ag(a, b) {
        var c = Bg(5, null, null, 0);
        c.elementType = "DELETED";
        c.stateNode = b;
        c.return = a;
        b = a.deletions;
        null === b ? (a.deletions = [c], a.flags |= 16) : b.push(c);
      }
      function Cg(a, b) {
        switch (a.tag) {
          case 5:
            var c = a.type;
            b = 1 !== b.nodeType || c.toLowerCase() !== b.nodeName.toLowerCase() ? null : b;
            return null !== b ? (a.stateNode = b, xg = a, yg = Lf(b.firstChild), true) : false;
          case 6:
            return b = "" === a.pendingProps || 3 !== b.nodeType ? null : b, null !== b ? (a.stateNode = b, xg = a, yg = null, true) : false;
          case 13:
            return b = 8 !== b.nodeType ? null : b, null !== b ? (c = null !== qg ? { id: rg, overflow: sg } : null, a.memoizedState = { dehydrated: b, treeContext: c, retryLane: 1073741824 }, c = Bg(18, null, null, 0), c.stateNode = b, c.return = a, a.child = c, xg = a, yg = null, true) : false;
          default:
            return false;
        }
      }
      function Dg(a) {
        return 0 !== (a.mode & 1) && 0 === (a.flags & 128);
      }
      function Eg(a) {
        if (I) {
          var b = yg;
          if (b) {
            var c = b;
            if (!Cg(a, b)) {
              if (Dg(a)) throw Error(p(418));
              b = Lf(c.nextSibling);
              var d = xg;
              b && Cg(a, b) ? Ag(d, c) : (a.flags = a.flags & -4097 | 2, I = false, xg = a);
            }
          } else {
            if (Dg(a)) throw Error(p(418));
            a.flags = a.flags & -4097 | 2;
            I = false;
            xg = a;
          }
        }
      }
      function Fg(a) {
        for (a = a.return; null !== a && 5 !== a.tag && 3 !== a.tag && 13 !== a.tag; ) a = a.return;
        xg = a;
      }
      function Gg(a) {
        if (a !== xg) return false;
        if (!I) return Fg(a), I = true, false;
        var b;
        (b = 3 !== a.tag) && !(b = 5 !== a.tag) && (b = a.type, b = "head" !== b && "body" !== b && !Ef(a.type, a.memoizedProps));
        if (b && (b = yg)) {
          if (Dg(a)) throw Hg(), Error(p(418));
          for (; b; ) Ag(a, b), b = Lf(b.nextSibling);
        }
        Fg(a);
        if (13 === a.tag) {
          a = a.memoizedState;
          a = null !== a ? a.dehydrated : null;
          if (!a) throw Error(p(317));
          a: {
            a = a.nextSibling;
            for (b = 0; a; ) {
              if (8 === a.nodeType) {
                var c = a.data;
                if ("/$" === c) {
                  if (0 === b) {
                    yg = Lf(a.nextSibling);
                    break a;
                  }
                  b--;
                } else "$" !== c && "$!" !== c && "$?" !== c || b++;
              }
              a = a.nextSibling;
            }
            yg = null;
          }
        } else yg = xg ? Lf(a.stateNode.nextSibling) : null;
        return true;
      }
      function Hg() {
        for (var a = yg; a; ) a = Lf(a.nextSibling);
      }
      function Ig() {
        yg = xg = null;
        I = false;
      }
      function Jg(a) {
        null === zg ? zg = [a] : zg.push(a);
      }
      var Kg = ua.ReactCurrentBatchConfig;
      function Lg(a, b, c) {
        a = c.ref;
        if (null !== a && "function" !== typeof a && "object" !== typeof a) {
          if (c._owner) {
            c = c._owner;
            if (c) {
              if (1 !== c.tag) throw Error(p(309));
              var d = c.stateNode;
            }
            if (!d) throw Error(p(147, a));
            var e = d, f = "" + a;
            if (null !== b && null !== b.ref && "function" === typeof b.ref && b.ref._stringRef === f) return b.ref;
            b = function(a2) {
              var b2 = e.refs;
              null === a2 ? delete b2[f] : b2[f] = a2;
            };
            b._stringRef = f;
            return b;
          }
          if ("string" !== typeof a) throw Error(p(284));
          if (!c._owner) throw Error(p(290, a));
        }
        return a;
      }
      function Mg(a, b) {
        a = Object.prototype.toString.call(b);
        throw Error(p(31, "[object Object]" === a ? "object with keys {" + Object.keys(b).join(", ") + "}" : a));
      }
      function Ng(a) {
        var b = a._init;
        return b(a._payload);
      }
      function Og(a) {
        function b(b2, c2) {
          if (a) {
            var d2 = b2.deletions;
            null === d2 ? (b2.deletions = [c2], b2.flags |= 16) : d2.push(c2);
          }
        }
        function c(c2, d2) {
          if (!a) return null;
          for (; null !== d2; ) b(c2, d2), d2 = d2.sibling;
          return null;
        }
        function d(a2, b2) {
          for (a2 = /* @__PURE__ */ new Map(); null !== b2; ) null !== b2.key ? a2.set(b2.key, b2) : a2.set(b2.index, b2), b2 = b2.sibling;
          return a2;
        }
        function e(a2, b2) {
          a2 = Pg(a2, b2);
          a2.index = 0;
          a2.sibling = null;
          return a2;
        }
        function f(b2, c2, d2) {
          b2.index = d2;
          if (!a) return b2.flags |= 1048576, c2;
          d2 = b2.alternate;
          if (null !== d2) return d2 = d2.index, d2 < c2 ? (b2.flags |= 2, c2) : d2;
          b2.flags |= 2;
          return c2;
        }
        function g(b2) {
          a && null === b2.alternate && (b2.flags |= 2);
          return b2;
        }
        function h2(a2, b2, c2, d2) {
          if (null === b2 || 6 !== b2.tag) return b2 = Qg(c2, a2.mode, d2), b2.return = a2, b2;
          b2 = e(b2, c2);
          b2.return = a2;
          return b2;
        }
        function k(a2, b2, c2, d2) {
          var f2 = c2.type;
          if (f2 === ya) return m(a2, b2, c2.props.children, d2, c2.key);
          if (null !== b2 && (b2.elementType === f2 || "object" === typeof f2 && null !== f2 && f2.$$typeof === Ha && Ng(f2) === b2.type)) return d2 = e(b2, c2.props), d2.ref = Lg(a2, b2, c2), d2.return = a2, d2;
          d2 = Rg(c2.type, c2.key, c2.props, null, a2.mode, d2);
          d2.ref = Lg(a2, b2, c2);
          d2.return = a2;
          return d2;
        }
        function l(a2, b2, c2, d2) {
          if (null === b2 || 4 !== b2.tag || b2.stateNode.containerInfo !== c2.containerInfo || b2.stateNode.implementation !== c2.implementation) return b2 = Sg(c2, a2.mode, d2), b2.return = a2, b2;
          b2 = e(b2, c2.children || []);
          b2.return = a2;
          return b2;
        }
        function m(a2, b2, c2, d2, f2) {
          if (null === b2 || 7 !== b2.tag) return b2 = Tg(c2, a2.mode, d2, f2), b2.return = a2, b2;
          b2 = e(b2, c2);
          b2.return = a2;
          return b2;
        }
        function q(a2, b2, c2) {
          if ("string" === typeof b2 && "" !== b2 || "number" === typeof b2) return b2 = Qg("" + b2, a2.mode, c2), b2.return = a2, b2;
          if ("object" === typeof b2 && null !== b2) {
            switch (b2.$$typeof) {
              case va:
                return c2 = Rg(b2.type, b2.key, b2.props, null, a2.mode, c2), c2.ref = Lg(a2, null, b2), c2.return = a2, c2;
              case wa:
                return b2 = Sg(b2, a2.mode, c2), b2.return = a2, b2;
              case Ha:
                var d2 = b2._init;
                return q(a2, d2(b2._payload), c2);
            }
            if (eb(b2) || Ka(b2)) return b2 = Tg(b2, a2.mode, c2, null), b2.return = a2, b2;
            Mg(a2, b2);
          }
          return null;
        }
        function r(a2, b2, c2, d2) {
          var e2 = null !== b2 ? b2.key : null;
          if ("string" === typeof c2 && "" !== c2 || "number" === typeof c2) return null !== e2 ? null : h2(a2, b2, "" + c2, d2);
          if ("object" === typeof c2 && null !== c2) {
            switch (c2.$$typeof) {
              case va:
                return c2.key === e2 ? k(a2, b2, c2, d2) : null;
              case wa:
                return c2.key === e2 ? l(a2, b2, c2, d2) : null;
              case Ha:
                return e2 = c2._init, r(
                  a2,
                  b2,
                  e2(c2._payload),
                  d2
                );
            }
            if (eb(c2) || Ka(c2)) return null !== e2 ? null : m(a2, b2, c2, d2, null);
            Mg(a2, c2);
          }
          return null;
        }
        function y(a2, b2, c2, d2, e2) {
          if ("string" === typeof d2 && "" !== d2 || "number" === typeof d2) return a2 = a2.get(c2) || null, h2(b2, a2, "" + d2, e2);
          if ("object" === typeof d2 && null !== d2) {
            switch (d2.$$typeof) {
              case va:
                return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, k(b2, a2, d2, e2);
              case wa:
                return a2 = a2.get(null === d2.key ? c2 : d2.key) || null, l(b2, a2, d2, e2);
              case Ha:
                var f2 = d2._init;
                return y(a2, b2, c2, f2(d2._payload), e2);
            }
            if (eb(d2) || Ka(d2)) return a2 = a2.get(c2) || null, m(b2, a2, d2, e2, null);
            Mg(b2, d2);
          }
          return null;
        }
        function n(e2, g2, h3, k2) {
          for (var l2 = null, m2 = null, u = g2, w = g2 = 0, x = null; null !== u && w < h3.length; w++) {
            u.index > w ? (x = u, u = null) : x = u.sibling;
            var n2 = r(e2, u, h3[w], k2);
            if (null === n2) {
              null === u && (u = x);
              break;
            }
            a && u && null === n2.alternate && b(e2, u);
            g2 = f(n2, g2, w);
            null === m2 ? l2 = n2 : m2.sibling = n2;
            m2 = n2;
            u = x;
          }
          if (w === h3.length) return c(e2, u), I && tg(e2, w), l2;
          if (null === u) {
            for (; w < h3.length; w++) u = q(e2, h3[w], k2), null !== u && (g2 = f(u, g2, w), null === m2 ? l2 = u : m2.sibling = u, m2 = u);
            I && tg(e2, w);
            return l2;
          }
          for (u = d(e2, u); w < h3.length; w++) x = y(u, e2, w, h3[w], k2), null !== x && (a && null !== x.alternate && u.delete(null === x.key ? w : x.key), g2 = f(x, g2, w), null === m2 ? l2 = x : m2.sibling = x, m2 = x);
          a && u.forEach(function(a2) {
            return b(e2, a2);
          });
          I && tg(e2, w);
          return l2;
        }
        function t(e2, g2, h3, k2) {
          var l2 = Ka(h3);
          if ("function" !== typeof l2) throw Error(p(150));
          h3 = l2.call(h3);
          if (null == h3) throw Error(p(151));
          for (var u = l2 = null, m2 = g2, w = g2 = 0, x = null, n2 = h3.next(); null !== m2 && !n2.done; w++, n2 = h3.next()) {
            m2.index > w ? (x = m2, m2 = null) : x = m2.sibling;
            var t2 = r(e2, m2, n2.value, k2);
            if (null === t2) {
              null === m2 && (m2 = x);
              break;
            }
            a && m2 && null === t2.alternate && b(e2, m2);
            g2 = f(t2, g2, w);
            null === u ? l2 = t2 : u.sibling = t2;
            u = t2;
            m2 = x;
          }
          if (n2.done) return c(
            e2,
            m2
          ), I && tg(e2, w), l2;
          if (null === m2) {
            for (; !n2.done; w++, n2 = h3.next()) n2 = q(e2, n2.value, k2), null !== n2 && (g2 = f(n2, g2, w), null === u ? l2 = n2 : u.sibling = n2, u = n2);
            I && tg(e2, w);
            return l2;
          }
          for (m2 = d(e2, m2); !n2.done; w++, n2 = h3.next()) n2 = y(m2, e2, w, n2.value, k2), null !== n2 && (a && null !== n2.alternate && m2.delete(null === n2.key ? w : n2.key), g2 = f(n2, g2, w), null === u ? l2 = n2 : u.sibling = n2, u = n2);
          a && m2.forEach(function(a2) {
            return b(e2, a2);
          });
          I && tg(e2, w);
          return l2;
        }
        function J(a2, d2, f2, h3) {
          "object" === typeof f2 && null !== f2 && f2.type === ya && null === f2.key && (f2 = f2.props.children);
          if ("object" === typeof f2 && null !== f2) {
            switch (f2.$$typeof) {
              case va:
                a: {
                  for (var k2 = f2.key, l2 = d2; null !== l2; ) {
                    if (l2.key === k2) {
                      k2 = f2.type;
                      if (k2 === ya) {
                        if (7 === l2.tag) {
                          c(a2, l2.sibling);
                          d2 = e(l2, f2.props.children);
                          d2.return = a2;
                          a2 = d2;
                          break a;
                        }
                      } else if (l2.elementType === k2 || "object" === typeof k2 && null !== k2 && k2.$$typeof === Ha && Ng(k2) === l2.type) {
                        c(a2, l2.sibling);
                        d2 = e(l2, f2.props);
                        d2.ref = Lg(a2, l2, f2);
                        d2.return = a2;
                        a2 = d2;
                        break a;
                      }
                      c(a2, l2);
                      break;
                    } else b(a2, l2);
                    l2 = l2.sibling;
                  }
                  f2.type === ya ? (d2 = Tg(f2.props.children, a2.mode, h3, f2.key), d2.return = a2, a2 = d2) : (h3 = Rg(f2.type, f2.key, f2.props, null, a2.mode, h3), h3.ref = Lg(a2, d2, f2), h3.return = a2, a2 = h3);
                }
                return g(a2);
              case wa:
                a: {
                  for (l2 = f2.key; null !== d2; ) {
                    if (d2.key === l2) if (4 === d2.tag && d2.stateNode.containerInfo === f2.containerInfo && d2.stateNode.implementation === f2.implementation) {
                      c(a2, d2.sibling);
                      d2 = e(d2, f2.children || []);
                      d2.return = a2;
                      a2 = d2;
                      break a;
                    } else {
                      c(a2, d2);
                      break;
                    }
                    else b(a2, d2);
                    d2 = d2.sibling;
                  }
                  d2 = Sg(f2, a2.mode, h3);
                  d2.return = a2;
                  a2 = d2;
                }
                return g(a2);
              case Ha:
                return l2 = f2._init, J(a2, d2, l2(f2._payload), h3);
            }
            if (eb(f2)) return n(a2, d2, f2, h3);
            if (Ka(f2)) return t(a2, d2, f2, h3);
            Mg(a2, f2);
          }
          return "string" === typeof f2 && "" !== f2 || "number" === typeof f2 ? (f2 = "" + f2, null !== d2 && 6 === d2.tag ? (c(a2, d2.sibling), d2 = e(d2, f2), d2.return = a2, a2 = d2) : (c(a2, d2), d2 = Qg(f2, a2.mode, h3), d2.return = a2, a2 = d2), g(a2)) : c(a2, d2);
        }
        return J;
      }
      var Ug = Og(true);
      var Vg = Og(false);
      var Wg = Uf(null);
      var Xg = null;
      var Yg = null;
      var Zg = null;
      function $g() {
        Zg = Yg = Xg = null;
      }
      function ah(a) {
        var b = Wg.current;
        E(Wg);
        a._currentValue = b;
      }
      function bh(a, b, c) {
        for (; null !== a; ) {
          var d = a.alternate;
          (a.childLanes & b) !== b ? (a.childLanes |= b, null !== d && (d.childLanes |= b)) : null !== d && (d.childLanes & b) !== b && (d.childLanes |= b);
          if (a === c) break;
          a = a.return;
        }
      }
      function ch(a, b) {
        Xg = a;
        Zg = Yg = null;
        a = a.dependencies;
        null !== a && null !== a.firstContext && (0 !== (a.lanes & b) && (dh = true), a.firstContext = null);
      }
      function eh(a) {
        var b = a._currentValue;
        if (Zg !== a) if (a = { context: a, memoizedValue: b, next: null }, null === Yg) {
          if (null === Xg) throw Error(p(308));
          Yg = a;
          Xg.dependencies = { lanes: 0, firstContext: a };
        } else Yg = Yg.next = a;
        return b;
      }
      var fh = null;
      function gh(a) {
        null === fh ? fh = [a] : fh.push(a);
      }
      function hh(a, b, c, d) {
        var e = b.interleaved;
        null === e ? (c.next = c, gh(b)) : (c.next = e.next, e.next = c);
        b.interleaved = c;
        return ih(a, d);
      }
      function ih(a, b) {
        a.lanes |= b;
        var c = a.alternate;
        null !== c && (c.lanes |= b);
        c = a;
        for (a = a.return; null !== a; ) a.childLanes |= b, c = a.alternate, null !== c && (c.childLanes |= b), c = a, a = a.return;
        return 3 === c.tag ? c.stateNode : null;
      }
      var jh = false;
      function kh(a) {
        a.updateQueue = { baseState: a.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
      }
      function lh(a, b) {
        a = a.updateQueue;
        b.updateQueue === a && (b.updateQueue = { baseState: a.baseState, firstBaseUpdate: a.firstBaseUpdate, lastBaseUpdate: a.lastBaseUpdate, shared: a.shared, effects: a.effects });
      }
      function mh(a, b) {
        return { eventTime: a, lane: b, tag: 0, payload: null, callback: null, next: null };
      }
      function nh(a, b, c) {
        var d = a.updateQueue;
        if (null === d) return null;
        d = d.shared;
        if (0 !== (K & 2)) {
          var e = d.pending;
          null === e ? b.next = b : (b.next = e.next, e.next = b);
          d.pending = b;
          return ih(a, c);
        }
        e = d.interleaved;
        null === e ? (b.next = b, gh(d)) : (b.next = e.next, e.next = b);
        d.interleaved = b;
        return ih(a, c);
      }
      function oh(a, b, c) {
        b = b.updateQueue;
        if (null !== b && (b = b.shared, 0 !== (c & 4194240))) {
          var d = b.lanes;
          d &= a.pendingLanes;
          c |= d;
          b.lanes = c;
          Cc(a, c);
        }
      }
      function ph(a, b) {
        var c = a.updateQueue, d = a.alternate;
        if (null !== d && (d = d.updateQueue, c === d)) {
          var e = null, f = null;
          c = c.firstBaseUpdate;
          if (null !== c) {
            do {
              var g = { eventTime: c.eventTime, lane: c.lane, tag: c.tag, payload: c.payload, callback: c.callback, next: null };
              null === f ? e = f = g : f = f.next = g;
              c = c.next;
            } while (null !== c);
            null === f ? e = f = b : f = f.next = b;
          } else e = f = b;
          c = { baseState: d.baseState, firstBaseUpdate: e, lastBaseUpdate: f, shared: d.shared, effects: d.effects };
          a.updateQueue = c;
          return;
        }
        a = c.lastBaseUpdate;
        null === a ? c.firstBaseUpdate = b : a.next = b;
        c.lastBaseUpdate = b;
      }
      function qh(a, b, c, d) {
        var e = a.updateQueue;
        jh = false;
        var f = e.firstBaseUpdate, g = e.lastBaseUpdate, h2 = e.shared.pending;
        if (null !== h2) {
          e.shared.pending = null;
          var k = h2, l = k.next;
          k.next = null;
          null === g ? f = l : g.next = l;
          g = k;
          var m = a.alternate;
          null !== m && (m = m.updateQueue, h2 = m.lastBaseUpdate, h2 !== g && (null === h2 ? m.firstBaseUpdate = l : h2.next = l, m.lastBaseUpdate = k));
        }
        if (null !== f) {
          var q = e.baseState;
          g = 0;
          m = l = k = null;
          h2 = f;
          do {
            var r = h2.lane, y = h2.eventTime;
            if ((d & r) === r) {
              null !== m && (m = m.next = {
                eventTime: y,
                lane: 0,
                tag: h2.tag,
                payload: h2.payload,
                callback: h2.callback,
                next: null
              });
              a: {
                var n = a, t = h2;
                r = b;
                y = c;
                switch (t.tag) {
                  case 1:
                    n = t.payload;
                    if ("function" === typeof n) {
                      q = n.call(y, q, r);
                      break a;
                    }
                    q = n;
                    break a;
                  case 3:
                    n.flags = n.flags & -65537 | 128;
                  case 0:
                    n = t.payload;
                    r = "function" === typeof n ? n.call(y, q, r) : n;
                    if (null === r || void 0 === r) break a;
                    q = A({}, q, r);
                    break a;
                  case 2:
                    jh = true;
                }
              }
              null !== h2.callback && 0 !== h2.lane && (a.flags |= 64, r = e.effects, null === r ? e.effects = [h2] : r.push(h2));
            } else y = { eventTime: y, lane: r, tag: h2.tag, payload: h2.payload, callback: h2.callback, next: null }, null === m ? (l = m = y, k = q) : m = m.next = y, g |= r;
            h2 = h2.next;
            if (null === h2) if (h2 = e.shared.pending, null === h2) break;
            else r = h2, h2 = r.next, r.next = null, e.lastBaseUpdate = r, e.shared.pending = null;
          } while (1);
          null === m && (k = q);
          e.baseState = k;
          e.firstBaseUpdate = l;
          e.lastBaseUpdate = m;
          b = e.shared.interleaved;
          if (null !== b) {
            e = b;
            do
              g |= e.lane, e = e.next;
            while (e !== b);
          } else null === f && (e.shared.lanes = 0);
          rh |= g;
          a.lanes = g;
          a.memoizedState = q;
        }
      }
      function sh(a, b, c) {
        a = b.effects;
        b.effects = null;
        if (null !== a) for (b = 0; b < a.length; b++) {
          var d = a[b], e = d.callback;
          if (null !== e) {
            d.callback = null;
            d = c;
            if ("function" !== typeof e) throw Error(p(191, e));
            e.call(d);
          }
        }
      }
      var th = {};
      var uh = Uf(th);
      var vh = Uf(th);
      var wh = Uf(th);
      function xh(a) {
        if (a === th) throw Error(p(174));
        return a;
      }
      function yh(a, b) {
        G(wh, b);
        G(vh, a);
        G(uh, th);
        a = b.nodeType;
        switch (a) {
          case 9:
          case 11:
            b = (b = b.documentElement) ? b.namespaceURI : lb(null, "");
            break;
          default:
            a = 8 === a ? b.parentNode : b, b = a.namespaceURI || null, a = a.tagName, b = lb(b, a);
        }
        E(uh);
        G(uh, b);
      }
      function zh() {
        E(uh);
        E(vh);
        E(wh);
      }
      function Ah(a) {
        xh(wh.current);
        var b = xh(uh.current);
        var c = lb(b, a.type);
        b !== c && (G(vh, a), G(uh, c));
      }
      function Bh(a) {
        vh.current === a && (E(uh), E(vh));
      }
      var L = Uf(0);
      function Ch(a) {
        for (var b = a; null !== b; ) {
          if (13 === b.tag) {
            var c = b.memoizedState;
            if (null !== c && (c = c.dehydrated, null === c || "$?" === c.data || "$!" === c.data)) return b;
          } else if (19 === b.tag && void 0 !== b.memoizedProps.revealOrder) {
            if (0 !== (b.flags & 128)) return b;
          } else if (null !== b.child) {
            b.child.return = b;
            b = b.child;
            continue;
          }
          if (b === a) break;
          for (; null === b.sibling; ) {
            if (null === b.return || b.return === a) return null;
            b = b.return;
          }
          b.sibling.return = b.return;
          b = b.sibling;
        }
        return null;
      }
      var Dh = [];
      function Eh() {
        for (var a = 0; a < Dh.length; a++) Dh[a]._workInProgressVersionPrimary = null;
        Dh.length = 0;
      }
      var Fh = ua.ReactCurrentDispatcher;
      var Gh = ua.ReactCurrentBatchConfig;
      var Hh = 0;
      var M = null;
      var N = null;
      var O = null;
      var Ih = false;
      var Jh = false;
      var Kh = 0;
      var Lh = 0;
      function P() {
        throw Error(p(321));
      }
      function Mh(a, b) {
        if (null === b) return false;
        for (var c = 0; c < b.length && c < a.length; c++) if (!He(a[c], b[c])) return false;
        return true;
      }
      function Nh(a, b, c, d, e, f) {
        Hh = f;
        M = b;
        b.memoizedState = null;
        b.updateQueue = null;
        b.lanes = 0;
        Fh.current = null === a || null === a.memoizedState ? Oh : Ph;
        a = c(d, e);
        if (Jh) {
          f = 0;
          do {
            Jh = false;
            Kh = 0;
            if (25 <= f) throw Error(p(301));
            f += 1;
            O = N = null;
            b.updateQueue = null;
            Fh.current = Qh;
            a = c(d, e);
          } while (Jh);
        }
        Fh.current = Rh;
        b = null !== N && null !== N.next;
        Hh = 0;
        O = N = M = null;
        Ih = false;
        if (b) throw Error(p(300));
        return a;
      }
      function Sh() {
        var a = 0 !== Kh;
        Kh = 0;
        return a;
      }
      function Th() {
        var a = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
        null === O ? M.memoizedState = O = a : O = O.next = a;
        return O;
      }
      function Uh() {
        if (null === N) {
          var a = M.alternate;
          a = null !== a ? a.memoizedState : null;
        } else a = N.next;
        var b = null === O ? M.memoizedState : O.next;
        if (null !== b) O = b, N = a;
        else {
          if (null === a) throw Error(p(310));
          N = a;
          a = { memoizedState: N.memoizedState, baseState: N.baseState, baseQueue: N.baseQueue, queue: N.queue, next: null };
          null === O ? M.memoizedState = O = a : O = O.next = a;
        }
        return O;
      }
      function Vh(a, b) {
        return "function" === typeof b ? b(a) : b;
      }
      function Wh(a) {
        var b = Uh(), c = b.queue;
        if (null === c) throw Error(p(311));
        c.lastRenderedReducer = a;
        var d = N, e = d.baseQueue, f = c.pending;
        if (null !== f) {
          if (null !== e) {
            var g = e.next;
            e.next = f.next;
            f.next = g;
          }
          d.baseQueue = e = f;
          c.pending = null;
        }
        if (null !== e) {
          f = e.next;
          d = d.baseState;
          var h2 = g = null, k = null, l = f;
          do {
            var m = l.lane;
            if ((Hh & m) === m) null !== k && (k = k.next = { lane: 0, action: l.action, hasEagerState: l.hasEagerState, eagerState: l.eagerState, next: null }), d = l.hasEagerState ? l.eagerState : a(d, l.action);
            else {
              var q = {
                lane: m,
                action: l.action,
                hasEagerState: l.hasEagerState,
                eagerState: l.eagerState,
                next: null
              };
              null === k ? (h2 = k = q, g = d) : k = k.next = q;
              M.lanes |= m;
              rh |= m;
            }
            l = l.next;
          } while (null !== l && l !== f);
          null === k ? g = d : k.next = h2;
          He(d, b.memoizedState) || (dh = true);
          b.memoizedState = d;
          b.baseState = g;
          b.baseQueue = k;
          c.lastRenderedState = d;
        }
        a = c.interleaved;
        if (null !== a) {
          e = a;
          do
            f = e.lane, M.lanes |= f, rh |= f, e = e.next;
          while (e !== a);
        } else null === e && (c.lanes = 0);
        return [b.memoizedState, c.dispatch];
      }
      function Xh(a) {
        var b = Uh(), c = b.queue;
        if (null === c) throw Error(p(311));
        c.lastRenderedReducer = a;
        var d = c.dispatch, e = c.pending, f = b.memoizedState;
        if (null !== e) {
          c.pending = null;
          var g = e = e.next;
          do
            f = a(f, g.action), g = g.next;
          while (g !== e);
          He(f, b.memoizedState) || (dh = true);
          b.memoizedState = f;
          null === b.baseQueue && (b.baseState = f);
          c.lastRenderedState = f;
        }
        return [f, d];
      }
      function Yh() {
      }
      function Zh(a, b) {
        var c = M, d = Uh(), e = b(), f = !He(d.memoizedState, e);
        f && (d.memoizedState = e, dh = true);
        d = d.queue;
        $h(ai.bind(null, c, d, a), [a]);
        if (d.getSnapshot !== b || f || null !== O && O.memoizedState.tag & 1) {
          c.flags |= 2048;
          bi(9, ci.bind(null, c, d, e, b), void 0, null);
          if (null === Q) throw Error(p(349));
          0 !== (Hh & 30) || di(c, b, e);
        }
        return e;
      }
      function di(a, b, c) {
        a.flags |= 16384;
        a = { getSnapshot: b, value: c };
        b = M.updateQueue;
        null === b ? (b = { lastEffect: null, stores: null }, M.updateQueue = b, b.stores = [a]) : (c = b.stores, null === c ? b.stores = [a] : c.push(a));
      }
      function ci(a, b, c, d) {
        b.value = c;
        b.getSnapshot = d;
        ei(b) && fi(a);
      }
      function ai(a, b, c) {
        return c(function() {
          ei(b) && fi(a);
        });
      }
      function ei(a) {
        var b = a.getSnapshot;
        a = a.value;
        try {
          var c = b();
          return !He(a, c);
        } catch (d) {
          return true;
        }
      }
      function fi(a) {
        var b = ih(a, 1);
        null !== b && gi(b, a, 1, -1);
      }
      function hi(a) {
        var b = Th();
        "function" === typeof a && (a = a());
        b.memoizedState = b.baseState = a;
        a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: Vh, lastRenderedState: a };
        b.queue = a;
        a = a.dispatch = ii.bind(null, M, a);
        return [b.memoizedState, a];
      }
      function bi(a, b, c, d) {
        a = { tag: a, create: b, destroy: c, deps: d, next: null };
        b = M.updateQueue;
        null === b ? (b = { lastEffect: null, stores: null }, M.updateQueue = b, b.lastEffect = a.next = a) : (c = b.lastEffect, null === c ? b.lastEffect = a.next = a : (d = c.next, c.next = a, a.next = d, b.lastEffect = a));
        return a;
      }
      function ji() {
        return Uh().memoizedState;
      }
      function ki(a, b, c, d) {
        var e = Th();
        M.flags |= a;
        e.memoizedState = bi(1 | b, c, void 0, void 0 === d ? null : d);
      }
      function li(a, b, c, d) {
        var e = Uh();
        d = void 0 === d ? null : d;
        var f = void 0;
        if (null !== N) {
          var g = N.memoizedState;
          f = g.destroy;
          if (null !== d && Mh(d, g.deps)) {
            e.memoizedState = bi(b, c, f, d);
            return;
          }
        }
        M.flags |= a;
        e.memoizedState = bi(1 | b, c, f, d);
      }
      function mi(a, b) {
        return ki(8390656, 8, a, b);
      }
      function $h(a, b) {
        return li(2048, 8, a, b);
      }
      function ni(a, b) {
        return li(4, 2, a, b);
      }
      function oi(a, b) {
        return li(4, 4, a, b);
      }
      function pi(a, b) {
        if ("function" === typeof b) return a = a(), b(a), function() {
          b(null);
        };
        if (null !== b && void 0 !== b) return a = a(), b.current = a, function() {
          b.current = null;
        };
      }
      function qi(a, b, c) {
        c = null !== c && void 0 !== c ? c.concat([a]) : null;
        return li(4, 4, pi.bind(null, b, a), c);
      }
      function ri() {
      }
      function si(a, b) {
        var c = Uh();
        b = void 0 === b ? null : b;
        var d = c.memoizedState;
        if (null !== d && null !== b && Mh(b, d[1])) return d[0];
        c.memoizedState = [a, b];
        return a;
      }
      function ti(a, b) {
        var c = Uh();
        b = void 0 === b ? null : b;
        var d = c.memoizedState;
        if (null !== d && null !== b && Mh(b, d[1])) return d[0];
        a = a();
        c.memoizedState = [a, b];
        return a;
      }
      function ui(a, b, c) {
        if (0 === (Hh & 21)) return a.baseState && (a.baseState = false, dh = true), a.memoizedState = c;
        He(c, b) || (c = yc(), M.lanes |= c, rh |= c, a.baseState = true);
        return b;
      }
      function vi(a, b) {
        var c = C;
        C = 0 !== c && 4 > c ? c : 4;
        a(true);
        var d = Gh.transition;
        Gh.transition = {};
        try {
          a(false), b();
        } finally {
          C = c, Gh.transition = d;
        }
      }
      function wi() {
        return Uh().memoizedState;
      }
      function xi(a, b, c) {
        var d = yi(a);
        c = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
        if (zi(a)) Ai(b, c);
        else if (c = hh(a, b, c, d), null !== c) {
          var e = R();
          gi(c, a, d, e);
          Bi(c, b, d);
        }
      }
      function ii(a, b, c) {
        var d = yi(a), e = { lane: d, action: c, hasEagerState: false, eagerState: null, next: null };
        if (zi(a)) Ai(b, e);
        else {
          var f = a.alternate;
          if (0 === a.lanes && (null === f || 0 === f.lanes) && (f = b.lastRenderedReducer, null !== f)) try {
            var g = b.lastRenderedState, h2 = f(g, c);
            e.hasEagerState = true;
            e.eagerState = h2;
            if (He(h2, g)) {
              var k = b.interleaved;
              null === k ? (e.next = e, gh(b)) : (e.next = k.next, k.next = e);
              b.interleaved = e;
              return;
            }
          } catch (l) {
          } finally {
          }
          c = hh(a, b, e, d);
          null !== c && (e = R(), gi(c, a, d, e), Bi(c, b, d));
        }
      }
      function zi(a) {
        var b = a.alternate;
        return a === M || null !== b && b === M;
      }
      function Ai(a, b) {
        Jh = Ih = true;
        var c = a.pending;
        null === c ? b.next = b : (b.next = c.next, c.next = b);
        a.pending = b;
      }
      function Bi(a, b, c) {
        if (0 !== (c & 4194240)) {
          var d = b.lanes;
          d &= a.pendingLanes;
          c |= d;
          b.lanes = c;
          Cc(a, c);
        }
      }
      var Rh = { readContext: eh, useCallback: P, useContext: P, useEffect: P, useImperativeHandle: P, useInsertionEffect: P, useLayoutEffect: P, useMemo: P, useReducer: P, useRef: P, useState: P, useDebugValue: P, useDeferredValue: P, useTransition: P, useMutableSource: P, useSyncExternalStore: P, useId: P, unstable_isNewReconciler: false };
      var Oh = { readContext: eh, useCallback: function(a, b) {
        Th().memoizedState = [a, void 0 === b ? null : b];
        return a;
      }, useContext: eh, useEffect: mi, useImperativeHandle: function(a, b, c) {
        c = null !== c && void 0 !== c ? c.concat([a]) : null;
        return ki(
          4194308,
          4,
          pi.bind(null, b, a),
          c
        );
      }, useLayoutEffect: function(a, b) {
        return ki(4194308, 4, a, b);
      }, useInsertionEffect: function(a, b) {
        return ki(4, 2, a, b);
      }, useMemo: function(a, b) {
        var c = Th();
        b = void 0 === b ? null : b;
        a = a();
        c.memoizedState = [a, b];
        return a;
      }, useReducer: function(a, b, c) {
        var d = Th();
        b = void 0 !== c ? c(b) : b;
        d.memoizedState = d.baseState = b;
        a = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: a, lastRenderedState: b };
        d.queue = a;
        a = a.dispatch = xi.bind(null, M, a);
        return [d.memoizedState, a];
      }, useRef: function(a) {
        var b = Th();
        a = { current: a };
        return b.memoizedState = a;
      }, useState: hi, useDebugValue: ri, useDeferredValue: function(a) {
        return Th().memoizedState = a;
      }, useTransition: function() {
        var a = hi(false), b = a[0];
        a = vi.bind(null, a[1]);
        Th().memoizedState = a;
        return [b, a];
      }, useMutableSource: function() {
      }, useSyncExternalStore: function(a, b, c) {
        var d = M, e = Th();
        if (I) {
          if (void 0 === c) throw Error(p(407));
          c = c();
        } else {
          c = b();
          if (null === Q) throw Error(p(349));
          0 !== (Hh & 30) || di(d, b, c);
        }
        e.memoizedState = c;
        var f = { value: c, getSnapshot: b };
        e.queue = f;
        mi(ai.bind(
          null,
          d,
          f,
          a
        ), [a]);
        d.flags |= 2048;
        bi(9, ci.bind(null, d, f, c, b), void 0, null);
        return c;
      }, useId: function() {
        var a = Th(), b = Q.identifierPrefix;
        if (I) {
          var c = sg;
          var d = rg;
          c = (d & ~(1 << 32 - oc(d) - 1)).toString(32) + c;
          b = ":" + b + "R" + c;
          c = Kh++;
          0 < c && (b += "H" + c.toString(32));
          b += ":";
        } else c = Lh++, b = ":" + b + "r" + c.toString(32) + ":";
        return a.memoizedState = b;
      }, unstable_isNewReconciler: false };
      var Ph = {
        readContext: eh,
        useCallback: si,
        useContext: eh,
        useEffect: $h,
        useImperativeHandle: qi,
        useInsertionEffect: ni,
        useLayoutEffect: oi,
        useMemo: ti,
        useReducer: Wh,
        useRef: ji,
        useState: function() {
          return Wh(Vh);
        },
        useDebugValue: ri,
        useDeferredValue: function(a) {
          var b = Uh();
          return ui(b, N.memoizedState, a);
        },
        useTransition: function() {
          var a = Wh(Vh)[0], b = Uh().memoizedState;
          return [a, b];
        },
        useMutableSource: Yh,
        useSyncExternalStore: Zh,
        useId: wi,
        unstable_isNewReconciler: false
      };
      var Qh = { readContext: eh, useCallback: si, useContext: eh, useEffect: $h, useImperativeHandle: qi, useInsertionEffect: ni, useLayoutEffect: oi, useMemo: ti, useReducer: Xh, useRef: ji, useState: function() {
        return Xh(Vh);
      }, useDebugValue: ri, useDeferredValue: function(a) {
        var b = Uh();
        return null === N ? b.memoizedState = a : ui(b, N.memoizedState, a);
      }, useTransition: function() {
        var a = Xh(Vh)[0], b = Uh().memoizedState;
        return [a, b];
      }, useMutableSource: Yh, useSyncExternalStore: Zh, useId: wi, unstable_isNewReconciler: false };
      function Ci(a, b) {
        if (a && a.defaultProps) {
          b = A({}, b);
          a = a.defaultProps;
          for (var c in a) void 0 === b[c] && (b[c] = a[c]);
          return b;
        }
        return b;
      }
      function Di(a, b, c, d) {
        b = a.memoizedState;
        c = c(d, b);
        c = null === c || void 0 === c ? b : A({}, b, c);
        a.memoizedState = c;
        0 === a.lanes && (a.updateQueue.baseState = c);
      }
      var Ei = { isMounted: function(a) {
        return (a = a._reactInternals) ? Vb(a) === a : false;
      }, enqueueSetState: function(a, b, c) {
        a = a._reactInternals;
        var d = R(), e = yi(a), f = mh(d, e);
        f.payload = b;
        void 0 !== c && null !== c && (f.callback = c);
        b = nh(a, f, e);
        null !== b && (gi(b, a, e, d), oh(b, a, e));
      }, enqueueReplaceState: function(a, b, c) {
        a = a._reactInternals;
        var d = R(), e = yi(a), f = mh(d, e);
        f.tag = 1;
        f.payload = b;
        void 0 !== c && null !== c && (f.callback = c);
        b = nh(a, f, e);
        null !== b && (gi(b, a, e, d), oh(b, a, e));
      }, enqueueForceUpdate: function(a, b) {
        a = a._reactInternals;
        var c = R(), d = yi(a), e = mh(c, d);
        e.tag = 2;
        void 0 !== b && null !== b && (e.callback = b);
        b = nh(a, e, d);
        null !== b && (gi(b, a, d, c), oh(b, a, d));
      } };
      function Fi(a, b, c, d, e, f, g) {
        a = a.stateNode;
        return "function" === typeof a.shouldComponentUpdate ? a.shouldComponentUpdate(d, f, g) : b.prototype && b.prototype.isPureReactComponent ? !Ie(c, d) || !Ie(e, f) : true;
      }
      function Gi(a, b, c) {
        var d = false, e = Vf;
        var f = b.contextType;
        "object" === typeof f && null !== f ? f = eh(f) : (e = Zf(b) ? Xf : H.current, d = b.contextTypes, f = (d = null !== d && void 0 !== d) ? Yf(a, e) : Vf);
        b = new b(c, f);
        a.memoizedState = null !== b.state && void 0 !== b.state ? b.state : null;
        b.updater = Ei;
        a.stateNode = b;
        b._reactInternals = a;
        d && (a = a.stateNode, a.__reactInternalMemoizedUnmaskedChildContext = e, a.__reactInternalMemoizedMaskedChildContext = f);
        return b;
      }
      function Hi(a, b, c, d) {
        a = b.state;
        "function" === typeof b.componentWillReceiveProps && b.componentWillReceiveProps(c, d);
        "function" === typeof b.UNSAFE_componentWillReceiveProps && b.UNSAFE_componentWillReceiveProps(c, d);
        b.state !== a && Ei.enqueueReplaceState(b, b.state, null);
      }
      function Ii(a, b, c, d) {
        var e = a.stateNode;
        e.props = c;
        e.state = a.memoizedState;
        e.refs = {};
        kh(a);
        var f = b.contextType;
        "object" === typeof f && null !== f ? e.context = eh(f) : (f = Zf(b) ? Xf : H.current, e.context = Yf(a, f));
        e.state = a.memoizedState;
        f = b.getDerivedStateFromProps;
        "function" === typeof f && (Di(a, b, f, c), e.state = a.memoizedState);
        "function" === typeof b.getDerivedStateFromProps || "function" === typeof e.getSnapshotBeforeUpdate || "function" !== typeof e.UNSAFE_componentWillMount && "function" !== typeof e.componentWillMount || (b = e.state, "function" === typeof e.componentWillMount && e.componentWillMount(), "function" === typeof e.UNSAFE_componentWillMount && e.UNSAFE_componentWillMount(), b !== e.state && Ei.enqueueReplaceState(e, e.state, null), qh(a, c, e, d), e.state = a.memoizedState);
        "function" === typeof e.componentDidMount && (a.flags |= 4194308);
      }
      function Ji(a, b) {
        try {
          var c = "", d = b;
          do
            c += Pa(d), d = d.return;
          while (d);
          var e = c;
        } catch (f) {
          e = "\nError generating stack: " + f.message + "\n" + f.stack;
        }
        return { value: a, source: b, stack: e, digest: null };
      }
      function Ki(a, b, c) {
        return { value: a, source: null, stack: null != c ? c : null, digest: null != b ? b : null };
      }
      function Li(a, b) {
        try {
          console.error(b.value);
        } catch (c) {
          setTimeout(function() {
            throw c;
          });
        }
      }
      var Mi = "function" === typeof WeakMap ? WeakMap : Map;
      function Ni(a, b, c) {
        c = mh(-1, c);
        c.tag = 3;
        c.payload = { element: null };
        var d = b.value;
        c.callback = function() {
          Oi || (Oi = true, Pi = d);
          Li(a, b);
        };
        return c;
      }
      function Qi(a, b, c) {
        c = mh(-1, c);
        c.tag = 3;
        var d = a.type.getDerivedStateFromError;
        if ("function" === typeof d) {
          var e = b.value;
          c.payload = function() {
            return d(e);
          };
          c.callback = function() {
            Li(a, b);
          };
        }
        var f = a.stateNode;
        null !== f && "function" === typeof f.componentDidCatch && (c.callback = function() {
          Li(a, b);
          "function" !== typeof d && (null === Ri ? Ri = /* @__PURE__ */ new Set([this]) : Ri.add(this));
          var c2 = b.stack;
          this.componentDidCatch(b.value, { componentStack: null !== c2 ? c2 : "" });
        });
        return c;
      }
      function Si(a, b, c) {
        var d = a.pingCache;
        if (null === d) {
          d = a.pingCache = new Mi();
          var e = /* @__PURE__ */ new Set();
          d.set(b, e);
        } else e = d.get(b), void 0 === e && (e = /* @__PURE__ */ new Set(), d.set(b, e));
        e.has(c) || (e.add(c), a = Ti.bind(null, a, b, c), b.then(a, a));
      }
      function Ui(a) {
        do {
          var b;
          if (b = 13 === a.tag) b = a.memoizedState, b = null !== b ? null !== b.dehydrated ? true : false : true;
          if (b) return a;
          a = a.return;
        } while (null !== a);
        return null;
      }
      function Vi(a, b, c, d, e) {
        if (0 === (a.mode & 1)) return a === b ? a.flags |= 65536 : (a.flags |= 128, c.flags |= 131072, c.flags &= -52805, 1 === c.tag && (null === c.alternate ? c.tag = 17 : (b = mh(-1, 1), b.tag = 2, nh(c, b, 1))), c.lanes |= 1), a;
        a.flags |= 65536;
        a.lanes = e;
        return a;
      }
      var Wi = ua.ReactCurrentOwner;
      var dh = false;
      function Xi(a, b, c, d) {
        b.child = null === a ? Vg(b, null, c, d) : Ug(b, a.child, c, d);
      }
      function Yi(a, b, c, d, e) {
        c = c.render;
        var f = b.ref;
        ch(b, e);
        d = Nh(a, b, c, d, f, e);
        c = Sh();
        if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
        I && c && vg(b);
        b.flags |= 1;
        Xi(a, b, d, e);
        return b.child;
      }
      function $i(a, b, c, d, e) {
        if (null === a) {
          var f = c.type;
          if ("function" === typeof f && !aj(f) && void 0 === f.defaultProps && null === c.compare && void 0 === c.defaultProps) return b.tag = 15, b.type = f, bj(a, b, f, d, e);
          a = Rg(c.type, null, d, b, b.mode, e);
          a.ref = b.ref;
          a.return = b;
          return b.child = a;
        }
        f = a.child;
        if (0 === (a.lanes & e)) {
          var g = f.memoizedProps;
          c = c.compare;
          c = null !== c ? c : Ie;
          if (c(g, d) && a.ref === b.ref) return Zi(a, b, e);
        }
        b.flags |= 1;
        a = Pg(f, d);
        a.ref = b.ref;
        a.return = b;
        return b.child = a;
      }
      function bj(a, b, c, d, e) {
        if (null !== a) {
          var f = a.memoizedProps;
          if (Ie(f, d) && a.ref === b.ref) if (dh = false, b.pendingProps = d = f, 0 !== (a.lanes & e)) 0 !== (a.flags & 131072) && (dh = true);
          else return b.lanes = a.lanes, Zi(a, b, e);
        }
        return cj(a, b, c, d, e);
      }
      function dj(a, b, c) {
        var d = b.pendingProps, e = d.children, f = null !== a ? a.memoizedState : null;
        if ("hidden" === d.mode) if (0 === (b.mode & 1)) b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, G(ej, fj), fj |= c;
        else {
          if (0 === (c & 1073741824)) return a = null !== f ? f.baseLanes | c : c, b.lanes = b.childLanes = 1073741824, b.memoizedState = { baseLanes: a, cachePool: null, transitions: null }, b.updateQueue = null, G(ej, fj), fj |= a, null;
          b.memoizedState = { baseLanes: 0, cachePool: null, transitions: null };
          d = null !== f ? f.baseLanes : c;
          G(ej, fj);
          fj |= d;
        }
        else null !== f ? (d = f.baseLanes | c, b.memoizedState = null) : d = c, G(ej, fj), fj |= d;
        Xi(a, b, e, c);
        return b.child;
      }
      function gj(a, b) {
        var c = b.ref;
        if (null === a && null !== c || null !== a && a.ref !== c) b.flags |= 512, b.flags |= 2097152;
      }
      function cj(a, b, c, d, e) {
        var f = Zf(c) ? Xf : H.current;
        f = Yf(b, f);
        ch(b, e);
        c = Nh(a, b, c, d, f, e);
        d = Sh();
        if (null !== a && !dh) return b.updateQueue = a.updateQueue, b.flags &= -2053, a.lanes &= ~e, Zi(a, b, e);
        I && d && vg(b);
        b.flags |= 1;
        Xi(a, b, c, e);
        return b.child;
      }
      function hj(a, b, c, d, e) {
        if (Zf(c)) {
          var f = true;
          cg(b);
        } else f = false;
        ch(b, e);
        if (null === b.stateNode) ij(a, b), Gi(b, c, d), Ii(b, c, d, e), d = true;
        else if (null === a) {
          var g = b.stateNode, h2 = b.memoizedProps;
          g.props = h2;
          var k = g.context, l = c.contextType;
          "object" === typeof l && null !== l ? l = eh(l) : (l = Zf(c) ? Xf : H.current, l = Yf(b, l));
          var m = c.getDerivedStateFromProps, q = "function" === typeof m || "function" === typeof g.getSnapshotBeforeUpdate;
          q || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h2 !== d || k !== l) && Hi(b, g, d, l);
          jh = false;
          var r = b.memoizedState;
          g.state = r;
          qh(b, d, g, e);
          k = b.memoizedState;
          h2 !== d || r !== k || Wf.current || jh ? ("function" === typeof m && (Di(b, c, m, d), k = b.memoizedState), (h2 = jh || Fi(b, c, h2, d, r, k, l)) ? (q || "function" !== typeof g.UNSAFE_componentWillMount && "function" !== typeof g.componentWillMount || ("function" === typeof g.componentWillMount && g.componentWillMount(), "function" === typeof g.UNSAFE_componentWillMount && g.UNSAFE_componentWillMount()), "function" === typeof g.componentDidMount && (b.flags |= 4194308)) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), b.memoizedProps = d, b.memoizedState = k), g.props = d, g.state = k, g.context = l, d = h2) : ("function" === typeof g.componentDidMount && (b.flags |= 4194308), d = false);
        } else {
          g = b.stateNode;
          lh(a, b);
          h2 = b.memoizedProps;
          l = b.type === b.elementType ? h2 : Ci(b.type, h2);
          g.props = l;
          q = b.pendingProps;
          r = g.context;
          k = c.contextType;
          "object" === typeof k && null !== k ? k = eh(k) : (k = Zf(c) ? Xf : H.current, k = Yf(b, k));
          var y = c.getDerivedStateFromProps;
          (m = "function" === typeof y || "function" === typeof g.getSnapshotBeforeUpdate) || "function" !== typeof g.UNSAFE_componentWillReceiveProps && "function" !== typeof g.componentWillReceiveProps || (h2 !== q || r !== k) && Hi(b, g, d, k);
          jh = false;
          r = b.memoizedState;
          g.state = r;
          qh(b, d, g, e);
          var n = b.memoizedState;
          h2 !== q || r !== n || Wf.current || jh ? ("function" === typeof y && (Di(b, c, y, d), n = b.memoizedState), (l = jh || Fi(b, c, l, d, r, n, k) || false) ? (m || "function" !== typeof g.UNSAFE_componentWillUpdate && "function" !== typeof g.componentWillUpdate || ("function" === typeof g.componentWillUpdate && g.componentWillUpdate(d, n, k), "function" === typeof g.UNSAFE_componentWillUpdate && g.UNSAFE_componentWillUpdate(d, n, k)), "function" === typeof g.componentDidUpdate && (b.flags |= 4), "function" === typeof g.getSnapshotBeforeUpdate && (b.flags |= 1024)) : ("function" !== typeof g.componentDidUpdate || h2 === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h2 === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), b.memoizedProps = d, b.memoizedState = n), g.props = d, g.state = n, g.context = k, d = l) : ("function" !== typeof g.componentDidUpdate || h2 === a.memoizedProps && r === a.memoizedState || (b.flags |= 4), "function" !== typeof g.getSnapshotBeforeUpdate || h2 === a.memoizedProps && r === a.memoizedState || (b.flags |= 1024), d = false);
        }
        return jj(a, b, c, d, f, e);
      }
      function jj(a, b, c, d, e, f) {
        gj(a, b);
        var g = 0 !== (b.flags & 128);
        if (!d && !g) return e && dg(b, c, false), Zi(a, b, f);
        d = b.stateNode;
        Wi.current = b;
        var h2 = g && "function" !== typeof c.getDerivedStateFromError ? null : d.render();
        b.flags |= 1;
        null !== a && g ? (b.child = Ug(b, a.child, null, f), b.child = Ug(b, null, h2, f)) : Xi(a, b, h2, f);
        b.memoizedState = d.state;
        e && dg(b, c, true);
        return b.child;
      }
      function kj(a) {
        var b = a.stateNode;
        b.pendingContext ? ag(a, b.pendingContext, b.pendingContext !== b.context) : b.context && ag(a, b.context, false);
        yh(a, b.containerInfo);
      }
      function lj(a, b, c, d, e) {
        Ig();
        Jg(e);
        b.flags |= 256;
        Xi(a, b, c, d);
        return b.child;
      }
      var mj = { dehydrated: null, treeContext: null, retryLane: 0 };
      function nj(a) {
        return { baseLanes: a, cachePool: null, transitions: null };
      }
      function oj(a, b, c) {
        var d = b.pendingProps, e = L.current, f = false, g = 0 !== (b.flags & 128), h2;
        (h2 = g) || (h2 = null !== a && null === a.memoizedState ? false : 0 !== (e & 2));
        if (h2) f = true, b.flags &= -129;
        else if (null === a || null !== a.memoizedState) e |= 1;
        G(L, e & 1);
        if (null === a) {
          Eg(b);
          a = b.memoizedState;
          if (null !== a && (a = a.dehydrated, null !== a)) return 0 === (b.mode & 1) ? b.lanes = 1 : "$!" === a.data ? b.lanes = 8 : b.lanes = 1073741824, null;
          g = d.children;
          a = d.fallback;
          return f ? (d = b.mode, f = b.child, g = { mode: "hidden", children: g }, 0 === (d & 1) && null !== f ? (f.childLanes = 0, f.pendingProps = g) : f = pj(g, d, 0, null), a = Tg(a, d, c, null), f.return = b, a.return = b, f.sibling = a, b.child = f, b.child.memoizedState = nj(c), b.memoizedState = mj, a) : qj(b, g);
        }
        e = a.memoizedState;
        if (null !== e && (h2 = e.dehydrated, null !== h2)) return rj(a, b, g, d, h2, e, c);
        if (f) {
          f = d.fallback;
          g = b.mode;
          e = a.child;
          h2 = e.sibling;
          var k = { mode: "hidden", children: d.children };
          0 === (g & 1) && b.child !== e ? (d = b.child, d.childLanes = 0, d.pendingProps = k, b.deletions = null) : (d = Pg(e, k), d.subtreeFlags = e.subtreeFlags & 14680064);
          null !== h2 ? f = Pg(h2, f) : (f = Tg(f, g, c, null), f.flags |= 2);
          f.return = b;
          d.return = b;
          d.sibling = f;
          b.child = d;
          d = f;
          f = b.child;
          g = a.child.memoizedState;
          g = null === g ? nj(c) : { baseLanes: g.baseLanes | c, cachePool: null, transitions: g.transitions };
          f.memoizedState = g;
          f.childLanes = a.childLanes & ~c;
          b.memoizedState = mj;
          return d;
        }
        f = a.child;
        a = f.sibling;
        d = Pg(f, { mode: "visible", children: d.children });
        0 === (b.mode & 1) && (d.lanes = c);
        d.return = b;
        d.sibling = null;
        null !== a && (c = b.deletions, null === c ? (b.deletions = [a], b.flags |= 16) : c.push(a));
        b.child = d;
        b.memoizedState = null;
        return d;
      }
      function qj(a, b) {
        b = pj({ mode: "visible", children: b }, a.mode, 0, null);
        b.return = a;
        return a.child = b;
      }
      function sj(a, b, c, d) {
        null !== d && Jg(d);
        Ug(b, a.child, null, c);
        a = qj(b, b.pendingProps.children);
        a.flags |= 2;
        b.memoizedState = null;
        return a;
      }
      function rj(a, b, c, d, e, f, g) {
        if (c) {
          if (b.flags & 256) return b.flags &= -257, d = Ki(Error(p(422))), sj(a, b, g, d);
          if (null !== b.memoizedState) return b.child = a.child, b.flags |= 128, null;
          f = d.fallback;
          e = b.mode;
          d = pj({ mode: "visible", children: d.children }, e, 0, null);
          f = Tg(f, e, g, null);
          f.flags |= 2;
          d.return = b;
          f.return = b;
          d.sibling = f;
          b.child = d;
          0 !== (b.mode & 1) && Ug(b, a.child, null, g);
          b.child.memoizedState = nj(g);
          b.memoizedState = mj;
          return f;
        }
        if (0 === (b.mode & 1)) return sj(a, b, g, null);
        if ("$!" === e.data) {
          d = e.nextSibling && e.nextSibling.dataset;
          if (d) var h2 = d.dgst;
          d = h2;
          f = Error(p(419));
          d = Ki(f, d, void 0);
          return sj(a, b, g, d);
        }
        h2 = 0 !== (g & a.childLanes);
        if (dh || h2) {
          d = Q;
          if (null !== d) {
            switch (g & -g) {
              case 4:
                e = 2;
                break;
              case 16:
                e = 8;
                break;
              case 64:
              case 128:
              case 256:
              case 512:
              case 1024:
              case 2048:
              case 4096:
              case 8192:
              case 16384:
              case 32768:
              case 65536:
              case 131072:
              case 262144:
              case 524288:
              case 1048576:
              case 2097152:
              case 4194304:
              case 8388608:
              case 16777216:
              case 33554432:
              case 67108864:
                e = 32;
                break;
              case 536870912:
                e = 268435456;
                break;
              default:
                e = 0;
            }
            e = 0 !== (e & (d.suspendedLanes | g)) ? 0 : e;
            0 !== e && e !== f.retryLane && (f.retryLane = e, ih(a, e), gi(d, a, e, -1));
          }
          tj();
          d = Ki(Error(p(421)));
          return sj(a, b, g, d);
        }
        if ("$?" === e.data) return b.flags |= 128, b.child = a.child, b = uj.bind(null, a), e._reactRetry = b, null;
        a = f.treeContext;
        yg = Lf(e.nextSibling);
        xg = b;
        I = true;
        zg = null;
        null !== a && (og[pg++] = rg, og[pg++] = sg, og[pg++] = qg, rg = a.id, sg = a.overflow, qg = b);
        b = qj(b, d.children);
        b.flags |= 4096;
        return b;
      }
      function vj(a, b, c) {
        a.lanes |= b;
        var d = a.alternate;
        null !== d && (d.lanes |= b);
        bh(a.return, b, c);
      }
      function wj(a, b, c, d, e) {
        var f = a.memoizedState;
        null === f ? a.memoizedState = { isBackwards: b, rendering: null, renderingStartTime: 0, last: d, tail: c, tailMode: e } : (f.isBackwards = b, f.rendering = null, f.renderingStartTime = 0, f.last = d, f.tail = c, f.tailMode = e);
      }
      function xj(a, b, c) {
        var d = b.pendingProps, e = d.revealOrder, f = d.tail;
        Xi(a, b, d.children, c);
        d = L.current;
        if (0 !== (d & 2)) d = d & 1 | 2, b.flags |= 128;
        else {
          if (null !== a && 0 !== (a.flags & 128)) a: for (a = b.child; null !== a; ) {
            if (13 === a.tag) null !== a.memoizedState && vj(a, c, b);
            else if (19 === a.tag) vj(a, c, b);
            else if (null !== a.child) {
              a.child.return = a;
              a = a.child;
              continue;
            }
            if (a === b) break a;
            for (; null === a.sibling; ) {
              if (null === a.return || a.return === b) break a;
              a = a.return;
            }
            a.sibling.return = a.return;
            a = a.sibling;
          }
          d &= 1;
        }
        G(L, d);
        if (0 === (b.mode & 1)) b.memoizedState = null;
        else switch (e) {
          case "forwards":
            c = b.child;
            for (e = null; null !== c; ) a = c.alternate, null !== a && null === Ch(a) && (e = c), c = c.sibling;
            c = e;
            null === c ? (e = b.child, b.child = null) : (e = c.sibling, c.sibling = null);
            wj(b, false, e, c, f);
            break;
          case "backwards":
            c = null;
            e = b.child;
            for (b.child = null; null !== e; ) {
              a = e.alternate;
              if (null !== a && null === Ch(a)) {
                b.child = e;
                break;
              }
              a = e.sibling;
              e.sibling = c;
              c = e;
              e = a;
            }
            wj(b, true, c, null, f);
            break;
          case "together":
            wj(b, false, null, null, void 0);
            break;
          default:
            b.memoizedState = null;
        }
        return b.child;
      }
      function ij(a, b) {
        0 === (b.mode & 1) && null !== a && (a.alternate = null, b.alternate = null, b.flags |= 2);
      }
      function Zi(a, b, c) {
        null !== a && (b.dependencies = a.dependencies);
        rh |= b.lanes;
        if (0 === (c & b.childLanes)) return null;
        if (null !== a && b.child !== a.child) throw Error(p(153));
        if (null !== b.child) {
          a = b.child;
          c = Pg(a, a.pendingProps);
          b.child = c;
          for (c.return = b; null !== a.sibling; ) a = a.sibling, c = c.sibling = Pg(a, a.pendingProps), c.return = b;
          c.sibling = null;
        }
        return b.child;
      }
      function yj(a, b, c) {
        switch (b.tag) {
          case 3:
            kj(b);
            Ig();
            break;
          case 5:
            Ah(b);
            break;
          case 1:
            Zf(b.type) && cg(b);
            break;
          case 4:
            yh(b, b.stateNode.containerInfo);
            break;
          case 10:
            var d = b.type._context, e = b.memoizedProps.value;
            G(Wg, d._currentValue);
            d._currentValue = e;
            break;
          case 13:
            d = b.memoizedState;
            if (null !== d) {
              if (null !== d.dehydrated) return G(L, L.current & 1), b.flags |= 128, null;
              if (0 !== (c & b.child.childLanes)) return oj(a, b, c);
              G(L, L.current & 1);
              a = Zi(a, b, c);
              return null !== a ? a.sibling : null;
            }
            G(L, L.current & 1);
            break;
          case 19:
            d = 0 !== (c & b.childLanes);
            if (0 !== (a.flags & 128)) {
              if (d) return xj(a, b, c);
              b.flags |= 128;
            }
            e = b.memoizedState;
            null !== e && (e.rendering = null, e.tail = null, e.lastEffect = null);
            G(L, L.current);
            if (d) break;
            else return null;
          case 22:
          case 23:
            return b.lanes = 0, dj(a, b, c);
        }
        return Zi(a, b, c);
      }
      var zj;
      var Aj;
      var Bj;
      var Cj;
      zj = function(a, b) {
        for (var c = b.child; null !== c; ) {
          if (5 === c.tag || 6 === c.tag) a.appendChild(c.stateNode);
          else if (4 !== c.tag && null !== c.child) {
            c.child.return = c;
            c = c.child;
            continue;
          }
          if (c === b) break;
          for (; null === c.sibling; ) {
            if (null === c.return || c.return === b) return;
            c = c.return;
          }
          c.sibling.return = c.return;
          c = c.sibling;
        }
      };
      Aj = function() {
      };
      Bj = function(a, b, c, d) {
        var e = a.memoizedProps;
        if (e !== d) {
          a = b.stateNode;
          xh(uh.current);
          var f = null;
          switch (c) {
            case "input":
              e = Ya(a, e);
              d = Ya(a, d);
              f = [];
              break;
            case "select":
              e = A({}, e, { value: void 0 });
              d = A({}, d, { value: void 0 });
              f = [];
              break;
            case "textarea":
              e = gb(a, e);
              d = gb(a, d);
              f = [];
              break;
            default:
              "function" !== typeof e.onClick && "function" === typeof d.onClick && (a.onclick = Bf);
          }
          ub(c, d);
          var g;
          c = null;
          for (l in e) if (!d.hasOwnProperty(l) && e.hasOwnProperty(l) && null != e[l]) if ("style" === l) {
            var h2 = e[l];
            for (g in h2) h2.hasOwnProperty(g) && (c || (c = {}), c[g] = "");
          } else "dangerouslySetInnerHTML" !== l && "children" !== l && "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && "autoFocus" !== l && (ea.hasOwnProperty(l) ? f || (f = []) : (f = f || []).push(l, null));
          for (l in d) {
            var k = d[l];
            h2 = null != e ? e[l] : void 0;
            if (d.hasOwnProperty(l) && k !== h2 && (null != k || null != h2)) if ("style" === l) if (h2) {
              for (g in h2) !h2.hasOwnProperty(g) || k && k.hasOwnProperty(g) || (c || (c = {}), c[g] = "");
              for (g in k) k.hasOwnProperty(g) && h2[g] !== k[g] && (c || (c = {}), c[g] = k[g]);
            } else c || (f || (f = []), f.push(
              l,
              c
            )), c = k;
            else "dangerouslySetInnerHTML" === l ? (k = k ? k.__html : void 0, h2 = h2 ? h2.__html : void 0, null != k && h2 !== k && (f = f || []).push(l, k)) : "children" === l ? "string" !== typeof k && "number" !== typeof k || (f = f || []).push(l, "" + k) : "suppressContentEditableWarning" !== l && "suppressHydrationWarning" !== l && (ea.hasOwnProperty(l) ? (null != k && "onScroll" === l && D("scroll", a), f || h2 === k || (f = [])) : (f = f || []).push(l, k));
          }
          c && (f = f || []).push("style", c);
          var l = f;
          if (b.updateQueue = l) b.flags |= 4;
        }
      };
      Cj = function(a, b, c, d) {
        c !== d && (b.flags |= 4);
      };
      function Dj(a, b) {
        if (!I) switch (a.tailMode) {
          case "hidden":
            b = a.tail;
            for (var c = null; null !== b; ) null !== b.alternate && (c = b), b = b.sibling;
            null === c ? a.tail = null : c.sibling = null;
            break;
          case "collapsed":
            c = a.tail;
            for (var d = null; null !== c; ) null !== c.alternate && (d = c), c = c.sibling;
            null === d ? b || null === a.tail ? a.tail = null : a.tail.sibling = null : d.sibling = null;
        }
      }
      function S(a) {
        var b = null !== a.alternate && a.alternate.child === a.child, c = 0, d = 0;
        if (b) for (var e = a.child; null !== e; ) c |= e.lanes | e.childLanes, d |= e.subtreeFlags & 14680064, d |= e.flags & 14680064, e.return = a, e = e.sibling;
        else for (e = a.child; null !== e; ) c |= e.lanes | e.childLanes, d |= e.subtreeFlags, d |= e.flags, e.return = a, e = e.sibling;
        a.subtreeFlags |= d;
        a.childLanes = c;
        return b;
      }
      function Ej(a, b, c) {
        var d = b.pendingProps;
        wg(b);
        switch (b.tag) {
          case 2:
          case 16:
          case 15:
          case 0:
          case 11:
          case 7:
          case 8:
          case 12:
          case 9:
          case 14:
            return S(b), null;
          case 1:
            return Zf(b.type) && $f(), S(b), null;
          case 3:
            d = b.stateNode;
            zh();
            E(Wf);
            E(H);
            Eh();
            d.pendingContext && (d.context = d.pendingContext, d.pendingContext = null);
            if (null === a || null === a.child) Gg(b) ? b.flags |= 4 : null === a || a.memoizedState.isDehydrated && 0 === (b.flags & 256) || (b.flags |= 1024, null !== zg && (Fj(zg), zg = null));
            Aj(a, b);
            S(b);
            return null;
          case 5:
            Bh(b);
            var e = xh(wh.current);
            c = b.type;
            if (null !== a && null != b.stateNode) Bj(a, b, c, d, e), a.ref !== b.ref && (b.flags |= 512, b.flags |= 2097152);
            else {
              if (!d) {
                if (null === b.stateNode) throw Error(p(166));
                S(b);
                return null;
              }
              a = xh(uh.current);
              if (Gg(b)) {
                d = b.stateNode;
                c = b.type;
                var f = b.memoizedProps;
                d[Of] = b;
                d[Pf] = f;
                a = 0 !== (b.mode & 1);
                switch (c) {
                  case "dialog":
                    D("cancel", d);
                    D("close", d);
                    break;
                  case "iframe":
                  case "object":
                  case "embed":
                    D("load", d);
                    break;
                  case "video":
                  case "audio":
                    for (e = 0; e < lf.length; e++) D(lf[e], d);
                    break;
                  case "source":
                    D("error", d);
                    break;
                  case "img":
                  case "image":
                  case "link":
                    D(
                      "error",
                      d
                    );
                    D("load", d);
                    break;
                  case "details":
                    D("toggle", d);
                    break;
                  case "input":
                    Za(d, f);
                    D("invalid", d);
                    break;
                  case "select":
                    d._wrapperState = { wasMultiple: !!f.multiple };
                    D("invalid", d);
                    break;
                  case "textarea":
                    hb(d, f), D("invalid", d);
                }
                ub(c, f);
                e = null;
                for (var g in f) if (f.hasOwnProperty(g)) {
                  var h2 = f[g];
                  "children" === g ? "string" === typeof h2 ? d.textContent !== h2 && (true !== f.suppressHydrationWarning && Af(d.textContent, h2, a), e = ["children", h2]) : "number" === typeof h2 && d.textContent !== "" + h2 && (true !== f.suppressHydrationWarning && Af(
                    d.textContent,
                    h2,
                    a
                  ), e = ["children", "" + h2]) : ea.hasOwnProperty(g) && null != h2 && "onScroll" === g && D("scroll", d);
                }
                switch (c) {
                  case "input":
                    Va(d);
                    db(d, f, true);
                    break;
                  case "textarea":
                    Va(d);
                    jb(d);
                    break;
                  case "select":
                  case "option":
                    break;
                  default:
                    "function" === typeof f.onClick && (d.onclick = Bf);
                }
                d = e;
                b.updateQueue = d;
                null !== d && (b.flags |= 4);
              } else {
                g = 9 === e.nodeType ? e : e.ownerDocument;
                "http://www.w3.org/1999/xhtml" === a && (a = kb(c));
                "http://www.w3.org/1999/xhtml" === a ? "script" === c ? (a = g.createElement("div"), a.innerHTML = "<script><\/script>", a = a.removeChild(a.firstChild)) : "string" === typeof d.is ? a = g.createElement(c, { is: d.is }) : (a = g.createElement(c), "select" === c && (g = a, d.multiple ? g.multiple = true : d.size && (g.size = d.size))) : a = g.createElementNS(a, c);
                a[Of] = b;
                a[Pf] = d;
                zj(a, b, false, false);
                b.stateNode = a;
                a: {
                  g = vb(c, d);
                  switch (c) {
                    case "dialog":
                      D("cancel", a);
                      D("close", a);
                      e = d;
                      break;
                    case "iframe":
                    case "object":
                    case "embed":
                      D("load", a);
                      e = d;
                      break;
                    case "video":
                    case "audio":
                      for (e = 0; e < lf.length; e++) D(lf[e], a);
                      e = d;
                      break;
                    case "source":
                      D("error", a);
                      e = d;
                      break;
                    case "img":
                    case "image":
                    case "link":
                      D(
                        "error",
                        a
                      );
                      D("load", a);
                      e = d;
                      break;
                    case "details":
                      D("toggle", a);
                      e = d;
                      break;
                    case "input":
                      Za(a, d);
                      e = Ya(a, d);
                      D("invalid", a);
                      break;
                    case "option":
                      e = d;
                      break;
                    case "select":
                      a._wrapperState = { wasMultiple: !!d.multiple };
                      e = A({}, d, { value: void 0 });
                      D("invalid", a);
                      break;
                    case "textarea":
                      hb(a, d);
                      e = gb(a, d);
                      D("invalid", a);
                      break;
                    default:
                      e = d;
                  }
                  ub(c, e);
                  h2 = e;
                  for (f in h2) if (h2.hasOwnProperty(f)) {
                    var k = h2[f];
                    "style" === f ? sb(a, k) : "dangerouslySetInnerHTML" === f ? (k = k ? k.__html : void 0, null != k && nb(a, k)) : "children" === f ? "string" === typeof k ? ("textarea" !== c || "" !== k) && ob(a, k) : "number" === typeof k && ob(a, "" + k) : "suppressContentEditableWarning" !== f && "suppressHydrationWarning" !== f && "autoFocus" !== f && (ea.hasOwnProperty(f) ? null != k && "onScroll" === f && D("scroll", a) : null != k && ta(a, f, k, g));
                  }
                  switch (c) {
                    case "input":
                      Va(a);
                      db(a, d, false);
                      break;
                    case "textarea":
                      Va(a);
                      jb(a);
                      break;
                    case "option":
                      null != d.value && a.setAttribute("value", "" + Sa(d.value));
                      break;
                    case "select":
                      a.multiple = !!d.multiple;
                      f = d.value;
                      null != f ? fb(a, !!d.multiple, f, false) : null != d.defaultValue && fb(
                        a,
                        !!d.multiple,
                        d.defaultValue,
                        true
                      );
                      break;
                    default:
                      "function" === typeof e.onClick && (a.onclick = Bf);
                  }
                  switch (c) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      d = !!d.autoFocus;
                      break a;
                    case "img":
                      d = true;
                      break a;
                    default:
                      d = false;
                  }
                }
                d && (b.flags |= 4);
              }
              null !== b.ref && (b.flags |= 512, b.flags |= 2097152);
            }
            S(b);
            return null;
          case 6:
            if (a && null != b.stateNode) Cj(a, b, a.memoizedProps, d);
            else {
              if ("string" !== typeof d && null === b.stateNode) throw Error(p(166));
              c = xh(wh.current);
              xh(uh.current);
              if (Gg(b)) {
                d = b.stateNode;
                c = b.memoizedProps;
                d[Of] = b;
                if (f = d.nodeValue !== c) {
                  if (a = xg, null !== a) switch (a.tag) {
                    case 3:
                      Af(d.nodeValue, c, 0 !== (a.mode & 1));
                      break;
                    case 5:
                      true !== a.memoizedProps.suppressHydrationWarning && Af(d.nodeValue, c, 0 !== (a.mode & 1));
                  }
                }
                f && (b.flags |= 4);
              } else d = (9 === c.nodeType ? c : c.ownerDocument).createTextNode(d), d[Of] = b, b.stateNode = d;
            }
            S(b);
            return null;
          case 13:
            E(L);
            d = b.memoizedState;
            if (null === a || null !== a.memoizedState && null !== a.memoizedState.dehydrated) {
              if (I && null !== yg && 0 !== (b.mode & 1) && 0 === (b.flags & 128)) Hg(), Ig(), b.flags |= 98560, f = false;
              else if (f = Gg(b), null !== d && null !== d.dehydrated) {
                if (null === a) {
                  if (!f) throw Error(p(318));
                  f = b.memoizedState;
                  f = null !== f ? f.dehydrated : null;
                  if (!f) throw Error(p(317));
                  f[Of] = b;
                } else Ig(), 0 === (b.flags & 128) && (b.memoizedState = null), b.flags |= 4;
                S(b);
                f = false;
              } else null !== zg && (Fj(zg), zg = null), f = true;
              if (!f) return b.flags & 65536 ? b : null;
            }
            if (0 !== (b.flags & 128)) return b.lanes = c, b;
            d = null !== d;
            d !== (null !== a && null !== a.memoizedState) && d && (b.child.flags |= 8192, 0 !== (b.mode & 1) && (null === a || 0 !== (L.current & 1) ? 0 === T && (T = 3) : tj()));
            null !== b.updateQueue && (b.flags |= 4);
            S(b);
            return null;
          case 4:
            return zh(), Aj(a, b), null === a && sf(b.stateNode.containerInfo), S(b), null;
          case 10:
            return ah(b.type._context), S(b), null;
          case 17:
            return Zf(b.type) && $f(), S(b), null;
          case 19:
            E(L);
            f = b.memoizedState;
            if (null === f) return S(b), null;
            d = 0 !== (b.flags & 128);
            g = f.rendering;
            if (null === g) if (d) Dj(f, false);
            else {
              if (0 !== T || null !== a && 0 !== (a.flags & 128)) for (a = b.child; null !== a; ) {
                g = Ch(a);
                if (null !== g) {
                  b.flags |= 128;
                  Dj(f, false);
                  d = g.updateQueue;
                  null !== d && (b.updateQueue = d, b.flags |= 4);
                  b.subtreeFlags = 0;
                  d = c;
                  for (c = b.child; null !== c; ) f = c, a = d, f.flags &= 14680066, g = f.alternate, null === g ? (f.childLanes = 0, f.lanes = a, f.child = null, f.subtreeFlags = 0, f.memoizedProps = null, f.memoizedState = null, f.updateQueue = null, f.dependencies = null, f.stateNode = null) : (f.childLanes = g.childLanes, f.lanes = g.lanes, f.child = g.child, f.subtreeFlags = 0, f.deletions = null, f.memoizedProps = g.memoizedProps, f.memoizedState = g.memoizedState, f.updateQueue = g.updateQueue, f.type = g.type, a = g.dependencies, f.dependencies = null === a ? null : { lanes: a.lanes, firstContext: a.firstContext }), c = c.sibling;
                  G(L, L.current & 1 | 2);
                  return b.child;
                }
                a = a.sibling;
              }
              null !== f.tail && B() > Gj && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
            }
            else {
              if (!d) if (a = Ch(g), null !== a) {
                if (b.flags |= 128, d = true, c = a.updateQueue, null !== c && (b.updateQueue = c, b.flags |= 4), Dj(f, true), null === f.tail && "hidden" === f.tailMode && !g.alternate && !I) return S(b), null;
              } else 2 * B() - f.renderingStartTime > Gj && 1073741824 !== c && (b.flags |= 128, d = true, Dj(f, false), b.lanes = 4194304);
              f.isBackwards ? (g.sibling = b.child, b.child = g) : (c = f.last, null !== c ? c.sibling = g : b.child = g, f.last = g);
            }
            if (null !== f.tail) return b = f.tail, f.rendering = b, f.tail = b.sibling, f.renderingStartTime = B(), b.sibling = null, c = L.current, G(L, d ? c & 1 | 2 : c & 1), b;
            S(b);
            return null;
          case 22:
          case 23:
            return Hj(), d = null !== b.memoizedState, null !== a && null !== a.memoizedState !== d && (b.flags |= 8192), d && 0 !== (b.mode & 1) ? 0 !== (fj & 1073741824) && (S(b), b.subtreeFlags & 6 && (b.flags |= 8192)) : S(b), null;
          case 24:
            return null;
          case 25:
            return null;
        }
        throw Error(p(156, b.tag));
      }
      function Ij(a, b) {
        wg(b);
        switch (b.tag) {
          case 1:
            return Zf(b.type) && $f(), a = b.flags, a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
          case 3:
            return zh(), E(Wf), E(H), Eh(), a = b.flags, 0 !== (a & 65536) && 0 === (a & 128) ? (b.flags = a & -65537 | 128, b) : null;
          case 5:
            return Bh(b), null;
          case 13:
            E(L);
            a = b.memoizedState;
            if (null !== a && null !== a.dehydrated) {
              if (null === b.alternate) throw Error(p(340));
              Ig();
            }
            a = b.flags;
            return a & 65536 ? (b.flags = a & -65537 | 128, b) : null;
          case 19:
            return E(L), null;
          case 4:
            return zh(), null;
          case 10:
            return ah(b.type._context), null;
          case 22:
          case 23:
            return Hj(), null;
          case 24:
            return null;
          default:
            return null;
        }
      }
      var Jj = false;
      var U = false;
      var Kj = "function" === typeof WeakSet ? WeakSet : Set;
      var V = null;
      function Lj(a, b) {
        var c = a.ref;
        if (null !== c) if ("function" === typeof c) try {
          c(null);
        } catch (d) {
          W(a, b, d);
        }
        else c.current = null;
      }
      function Mj(a, b, c) {
        try {
          c();
        } catch (d) {
          W(a, b, d);
        }
      }
      var Nj = false;
      function Oj(a, b) {
        Cf = dd;
        a = Me();
        if (Ne(a)) {
          if ("selectionStart" in a) var c = { start: a.selectionStart, end: a.selectionEnd };
          else a: {
            c = (c = a.ownerDocument) && c.defaultView || window;
            var d = c.getSelection && c.getSelection();
            if (d && 0 !== d.rangeCount) {
              c = d.anchorNode;
              var e = d.anchorOffset, f = d.focusNode;
              d = d.focusOffset;
              try {
                c.nodeType, f.nodeType;
              } catch (F) {
                c = null;
                break a;
              }
              var g = 0, h2 = -1, k = -1, l = 0, m = 0, q = a, r = null;
              b: for (; ; ) {
                for (var y; ; ) {
                  q !== c || 0 !== e && 3 !== q.nodeType || (h2 = g + e);
                  q !== f || 0 !== d && 3 !== q.nodeType || (k = g + d);
                  3 === q.nodeType && (g += q.nodeValue.length);
                  if (null === (y = q.firstChild)) break;
                  r = q;
                  q = y;
                }
                for (; ; ) {
                  if (q === a) break b;
                  r === c && ++l === e && (h2 = g);
                  r === f && ++m === d && (k = g);
                  if (null !== (y = q.nextSibling)) break;
                  q = r;
                  r = q.parentNode;
                }
                q = y;
              }
              c = -1 === h2 || -1 === k ? null : { start: h2, end: k };
            } else c = null;
          }
          c = c || { start: 0, end: 0 };
        } else c = null;
        Df = { focusedElem: a, selectionRange: c };
        dd = false;
        for (V = b; null !== V; ) if (b = V, a = b.child, 0 !== (b.subtreeFlags & 1028) && null !== a) a.return = b, V = a;
        else for (; null !== V; ) {
          b = V;
          try {
            var n = b.alternate;
            if (0 !== (b.flags & 1024)) switch (b.tag) {
              case 0:
              case 11:
              case 15:
                break;
              case 1:
                if (null !== n) {
                  var t = n.memoizedProps, J = n.memoizedState, x = b.stateNode, w = x.getSnapshotBeforeUpdate(b.elementType === b.type ? t : Ci(b.type, t), J);
                  x.__reactInternalSnapshotBeforeUpdate = w;
                }
                break;
              case 3:
                var u = b.stateNode.containerInfo;
                1 === u.nodeType ? u.textContent = "" : 9 === u.nodeType && u.documentElement && u.removeChild(u.documentElement);
                break;
              case 5:
              case 6:
              case 4:
              case 17:
                break;
              default:
                throw Error(p(163));
            }
          } catch (F) {
            W(b, b.return, F);
          }
          a = b.sibling;
          if (null !== a) {
            a.return = b.return;
            V = a;
            break;
          }
          V = b.return;
        }
        n = Nj;
        Nj = false;
        return n;
      }
      function Pj(a, b, c) {
        var d = b.updateQueue;
        d = null !== d ? d.lastEffect : null;
        if (null !== d) {
          var e = d = d.next;
          do {
            if ((e.tag & a) === a) {
              var f = e.destroy;
              e.destroy = void 0;
              void 0 !== f && Mj(b, c, f);
            }
            e = e.next;
          } while (e !== d);
        }
      }
      function Qj(a, b) {
        b = b.updateQueue;
        b = null !== b ? b.lastEffect : null;
        if (null !== b) {
          var c = b = b.next;
          do {
            if ((c.tag & a) === a) {
              var d = c.create;
              c.destroy = d();
            }
            c = c.next;
          } while (c !== b);
        }
      }
      function Rj(a) {
        var b = a.ref;
        if (null !== b) {
          var c = a.stateNode;
          switch (a.tag) {
            case 5:
              a = c;
              break;
            default:
              a = c;
          }
          "function" === typeof b ? b(a) : b.current = a;
        }
      }
      function Sj(a) {
        var b = a.alternate;
        null !== b && (a.alternate = null, Sj(b));
        a.child = null;
        a.deletions = null;
        a.sibling = null;
        5 === a.tag && (b = a.stateNode, null !== b && (delete b[Of], delete b[Pf], delete b[of], delete b[Qf], delete b[Rf]));
        a.stateNode = null;
        a.return = null;
        a.dependencies = null;
        a.memoizedProps = null;
        a.memoizedState = null;
        a.pendingProps = null;
        a.stateNode = null;
        a.updateQueue = null;
      }
      function Tj(a) {
        return 5 === a.tag || 3 === a.tag || 4 === a.tag;
      }
      function Uj(a) {
        a: for (; ; ) {
          for (; null === a.sibling; ) {
            if (null === a.return || Tj(a.return)) return null;
            a = a.return;
          }
          a.sibling.return = a.return;
          for (a = a.sibling; 5 !== a.tag && 6 !== a.tag && 18 !== a.tag; ) {
            if (a.flags & 2) continue a;
            if (null === a.child || 4 === a.tag) continue a;
            else a.child.return = a, a = a.child;
          }
          if (!(a.flags & 2)) return a.stateNode;
        }
      }
      function Vj(a, b, c) {
        var d = a.tag;
        if (5 === d || 6 === d) a = a.stateNode, b ? 8 === c.nodeType ? c.parentNode.insertBefore(a, b) : c.insertBefore(a, b) : (8 === c.nodeType ? (b = c.parentNode, b.insertBefore(a, c)) : (b = c, b.appendChild(a)), c = c._reactRootContainer, null !== c && void 0 !== c || null !== b.onclick || (b.onclick = Bf));
        else if (4 !== d && (a = a.child, null !== a)) for (Vj(a, b, c), a = a.sibling; null !== a; ) Vj(a, b, c), a = a.sibling;
      }
      function Wj(a, b, c) {
        var d = a.tag;
        if (5 === d || 6 === d) a = a.stateNode, b ? c.insertBefore(a, b) : c.appendChild(a);
        else if (4 !== d && (a = a.child, null !== a)) for (Wj(a, b, c), a = a.sibling; null !== a; ) Wj(a, b, c), a = a.sibling;
      }
      var X = null;
      var Xj = false;
      function Yj(a, b, c) {
        for (c = c.child; null !== c; ) Zj(a, b, c), c = c.sibling;
      }
      function Zj(a, b, c) {
        if (lc && "function" === typeof lc.onCommitFiberUnmount) try {
          lc.onCommitFiberUnmount(kc, c);
        } catch (h2) {
        }
        switch (c.tag) {
          case 5:
            U || Lj(c, b);
          case 6:
            var d = X, e = Xj;
            X = null;
            Yj(a, b, c);
            X = d;
            Xj = e;
            null !== X && (Xj ? (a = X, c = c.stateNode, 8 === a.nodeType ? a.parentNode.removeChild(c) : a.removeChild(c)) : X.removeChild(c.stateNode));
            break;
          case 18:
            null !== X && (Xj ? (a = X, c = c.stateNode, 8 === a.nodeType ? Kf(a.parentNode, c) : 1 === a.nodeType && Kf(a, c), bd(a)) : Kf(X, c.stateNode));
            break;
          case 4:
            d = X;
            e = Xj;
            X = c.stateNode.containerInfo;
            Xj = true;
            Yj(a, b, c);
            X = d;
            Xj = e;
            break;
          case 0:
          case 11:
          case 14:
          case 15:
            if (!U && (d = c.updateQueue, null !== d && (d = d.lastEffect, null !== d))) {
              e = d = d.next;
              do {
                var f = e, g = f.destroy;
                f = f.tag;
                void 0 !== g && (0 !== (f & 2) ? Mj(c, b, g) : 0 !== (f & 4) && Mj(c, b, g));
                e = e.next;
              } while (e !== d);
            }
            Yj(a, b, c);
            break;
          case 1:
            if (!U && (Lj(c, b), d = c.stateNode, "function" === typeof d.componentWillUnmount)) try {
              d.props = c.memoizedProps, d.state = c.memoizedState, d.componentWillUnmount();
            } catch (h2) {
              W(c, b, h2);
            }
            Yj(a, b, c);
            break;
          case 21:
            Yj(a, b, c);
            break;
          case 22:
            c.mode & 1 ? (U = (d = U) || null !== c.memoizedState, Yj(a, b, c), U = d) : Yj(a, b, c);
            break;
          default:
            Yj(a, b, c);
        }
      }
      function ak(a) {
        var b = a.updateQueue;
        if (null !== b) {
          a.updateQueue = null;
          var c = a.stateNode;
          null === c && (c = a.stateNode = new Kj());
          b.forEach(function(b2) {
            var d = bk.bind(null, a, b2);
            c.has(b2) || (c.add(b2), b2.then(d, d));
          });
        }
      }
      function ck(a, b) {
        var c = b.deletions;
        if (null !== c) for (var d = 0; d < c.length; d++) {
          var e = c[d];
          try {
            var f = a, g = b, h2 = g;
            a: for (; null !== h2; ) {
              switch (h2.tag) {
                case 5:
                  X = h2.stateNode;
                  Xj = false;
                  break a;
                case 3:
                  X = h2.stateNode.containerInfo;
                  Xj = true;
                  break a;
                case 4:
                  X = h2.stateNode.containerInfo;
                  Xj = true;
                  break a;
              }
              h2 = h2.return;
            }
            if (null === X) throw Error(p(160));
            Zj(f, g, e);
            X = null;
            Xj = false;
            var k = e.alternate;
            null !== k && (k.return = null);
            e.return = null;
          } catch (l) {
            W(e, b, l);
          }
        }
        if (b.subtreeFlags & 12854) for (b = b.child; null !== b; ) dk(b, a), b = b.sibling;
      }
      function dk(a, b) {
        var c = a.alternate, d = a.flags;
        switch (a.tag) {
          case 0:
          case 11:
          case 14:
          case 15:
            ck(b, a);
            ek(a);
            if (d & 4) {
              try {
                Pj(3, a, a.return), Qj(3, a);
              } catch (t) {
                W(a, a.return, t);
              }
              try {
                Pj(5, a, a.return);
              } catch (t) {
                W(a, a.return, t);
              }
            }
            break;
          case 1:
            ck(b, a);
            ek(a);
            d & 512 && null !== c && Lj(c, c.return);
            break;
          case 5:
            ck(b, a);
            ek(a);
            d & 512 && null !== c && Lj(c, c.return);
            if (a.flags & 32) {
              var e = a.stateNode;
              try {
                ob(e, "");
              } catch (t) {
                W(a, a.return, t);
              }
            }
            if (d & 4 && (e = a.stateNode, null != e)) {
              var f = a.memoizedProps, g = null !== c ? c.memoizedProps : f, h2 = a.type, k = a.updateQueue;
              a.updateQueue = null;
              if (null !== k) try {
                "input" === h2 && "radio" === f.type && null != f.name && ab(e, f);
                vb(h2, g);
                var l = vb(h2, f);
                for (g = 0; g < k.length; g += 2) {
                  var m = k[g], q = k[g + 1];
                  "style" === m ? sb(e, q) : "dangerouslySetInnerHTML" === m ? nb(e, q) : "children" === m ? ob(e, q) : ta(e, m, q, l);
                }
                switch (h2) {
                  case "input":
                    bb(e, f);
                    break;
                  case "textarea":
                    ib(e, f);
                    break;
                  case "select":
                    var r = e._wrapperState.wasMultiple;
                    e._wrapperState.wasMultiple = !!f.multiple;
                    var y = f.value;
                    null != y ? fb(e, !!f.multiple, y, false) : r !== !!f.multiple && (null != f.defaultValue ? fb(
                      e,
                      !!f.multiple,
                      f.defaultValue,
                      true
                    ) : fb(e, !!f.multiple, f.multiple ? [] : "", false));
                }
                e[Pf] = f;
              } catch (t) {
                W(a, a.return, t);
              }
            }
            break;
          case 6:
            ck(b, a);
            ek(a);
            if (d & 4) {
              if (null === a.stateNode) throw Error(p(162));
              e = a.stateNode;
              f = a.memoizedProps;
              try {
                e.nodeValue = f;
              } catch (t) {
                W(a, a.return, t);
              }
            }
            break;
          case 3:
            ck(b, a);
            ek(a);
            if (d & 4 && null !== c && c.memoizedState.isDehydrated) try {
              bd(b.containerInfo);
            } catch (t) {
              W(a, a.return, t);
            }
            break;
          case 4:
            ck(b, a);
            ek(a);
            break;
          case 13:
            ck(b, a);
            ek(a);
            e = a.child;
            e.flags & 8192 && (f = null !== e.memoizedState, e.stateNode.isHidden = f, !f || null !== e.alternate && null !== e.alternate.memoizedState || (fk = B()));
            d & 4 && ak(a);
            break;
          case 22:
            m = null !== c && null !== c.memoizedState;
            a.mode & 1 ? (U = (l = U) || m, ck(b, a), U = l) : ck(b, a);
            ek(a);
            if (d & 8192) {
              l = null !== a.memoizedState;
              if ((a.stateNode.isHidden = l) && !m && 0 !== (a.mode & 1)) for (V = a, m = a.child; null !== m; ) {
                for (q = V = m; null !== V; ) {
                  r = V;
                  y = r.child;
                  switch (r.tag) {
                    case 0:
                    case 11:
                    case 14:
                    case 15:
                      Pj(4, r, r.return);
                      break;
                    case 1:
                      Lj(r, r.return);
                      var n = r.stateNode;
                      if ("function" === typeof n.componentWillUnmount) {
                        d = r;
                        c = r.return;
                        try {
                          b = d, n.props = b.memoizedProps, n.state = b.memoizedState, n.componentWillUnmount();
                        } catch (t) {
                          W(d, c, t);
                        }
                      }
                      break;
                    case 5:
                      Lj(r, r.return);
                      break;
                    case 22:
                      if (null !== r.memoizedState) {
                        gk(q);
                        continue;
                      }
                  }
                  null !== y ? (y.return = r, V = y) : gk(q);
                }
                m = m.sibling;
              }
              a: for (m = null, q = a; ; ) {
                if (5 === q.tag) {
                  if (null === m) {
                    m = q;
                    try {
                      e = q.stateNode, l ? (f = e.style, "function" === typeof f.setProperty ? f.setProperty("display", "none", "important") : f.display = "none") : (h2 = q.stateNode, k = q.memoizedProps.style, g = void 0 !== k && null !== k && k.hasOwnProperty("display") ? k.display : null, h2.style.display = rb("display", g));
                    } catch (t) {
                      W(a, a.return, t);
                    }
                  }
                } else if (6 === q.tag) {
                  if (null === m) try {
                    q.stateNode.nodeValue = l ? "" : q.memoizedProps;
                  } catch (t) {
                    W(a, a.return, t);
                  }
                } else if ((22 !== q.tag && 23 !== q.tag || null === q.memoizedState || q === a) && null !== q.child) {
                  q.child.return = q;
                  q = q.child;
                  continue;
                }
                if (q === a) break a;
                for (; null === q.sibling; ) {
                  if (null === q.return || q.return === a) break a;
                  m === q && (m = null);
                  q = q.return;
                }
                m === q && (m = null);
                q.sibling.return = q.return;
                q = q.sibling;
              }
            }
            break;
          case 19:
            ck(b, a);
            ek(a);
            d & 4 && ak(a);
            break;
          case 21:
            break;
          default:
            ck(
              b,
              a
            ), ek(a);
        }
      }
      function ek(a) {
        var b = a.flags;
        if (b & 2) {
          try {
            a: {
              for (var c = a.return; null !== c; ) {
                if (Tj(c)) {
                  var d = c;
                  break a;
                }
                c = c.return;
              }
              throw Error(p(160));
            }
            switch (d.tag) {
              case 5:
                var e = d.stateNode;
                d.flags & 32 && (ob(e, ""), d.flags &= -33);
                var f = Uj(a);
                Wj(a, f, e);
                break;
              case 3:
              case 4:
                var g = d.stateNode.containerInfo, h2 = Uj(a);
                Vj(a, h2, g);
                break;
              default:
                throw Error(p(161));
            }
          } catch (k) {
            W(a, a.return, k);
          }
          a.flags &= -3;
        }
        b & 4096 && (a.flags &= -4097);
      }
      function hk(a, b, c) {
        V = a;
        ik(a, b, c);
      }
      function ik(a, b, c) {
        for (var d = 0 !== (a.mode & 1); null !== V; ) {
          var e = V, f = e.child;
          if (22 === e.tag && d) {
            var g = null !== e.memoizedState || Jj;
            if (!g) {
              var h2 = e.alternate, k = null !== h2 && null !== h2.memoizedState || U;
              h2 = Jj;
              var l = U;
              Jj = g;
              if ((U = k) && !l) for (V = e; null !== V; ) g = V, k = g.child, 22 === g.tag && null !== g.memoizedState ? jk(e) : null !== k ? (k.return = g, V = k) : jk(e);
              for (; null !== f; ) V = f, ik(f, b, c), f = f.sibling;
              V = e;
              Jj = h2;
              U = l;
            }
            kk(a, b, c);
          } else 0 !== (e.subtreeFlags & 8772) && null !== f ? (f.return = e, V = f) : kk(a, b, c);
        }
      }
      function kk(a) {
        for (; null !== V; ) {
          var b = V;
          if (0 !== (b.flags & 8772)) {
            var c = b.alternate;
            try {
              if (0 !== (b.flags & 8772)) switch (b.tag) {
                case 0:
                case 11:
                case 15:
                  U || Qj(5, b);
                  break;
                case 1:
                  var d = b.stateNode;
                  if (b.flags & 4 && !U) if (null === c) d.componentDidMount();
                  else {
                    var e = b.elementType === b.type ? c.memoizedProps : Ci(b.type, c.memoizedProps);
                    d.componentDidUpdate(e, c.memoizedState, d.__reactInternalSnapshotBeforeUpdate);
                  }
                  var f = b.updateQueue;
                  null !== f && sh(b, f, d);
                  break;
                case 3:
                  var g = b.updateQueue;
                  if (null !== g) {
                    c = null;
                    if (null !== b.child) switch (b.child.tag) {
                      case 5:
                        c = b.child.stateNode;
                        break;
                      case 1:
                        c = b.child.stateNode;
                    }
                    sh(b, g, c);
                  }
                  break;
                case 5:
                  var h2 = b.stateNode;
                  if (null === c && b.flags & 4) {
                    c = h2;
                    var k = b.memoizedProps;
                    switch (b.type) {
                      case "button":
                      case "input":
                      case "select":
                      case "textarea":
                        k.autoFocus && c.focus();
                        break;
                      case "img":
                        k.src && (c.src = k.src);
                    }
                  }
                  break;
                case 6:
                  break;
                case 4:
                  break;
                case 12:
                  break;
                case 13:
                  if (null === b.memoizedState) {
                    var l = b.alternate;
                    if (null !== l) {
                      var m = l.memoizedState;
                      if (null !== m) {
                        var q = m.dehydrated;
                        null !== q && bd(q);
                      }
                    }
                  }
                  break;
                case 19:
                case 17:
                case 21:
                case 22:
                case 23:
                case 25:
                  break;
                default:
                  throw Error(p(163));
              }
              U || b.flags & 512 && Rj(b);
            } catch (r) {
              W(b, b.return, r);
            }
          }
          if (b === a) {
            V = null;
            break;
          }
          c = b.sibling;
          if (null !== c) {
            c.return = b.return;
            V = c;
            break;
          }
          V = b.return;
        }
      }
      function gk(a) {
        for (; null !== V; ) {
          var b = V;
          if (b === a) {
            V = null;
            break;
          }
          var c = b.sibling;
          if (null !== c) {
            c.return = b.return;
            V = c;
            break;
          }
          V = b.return;
        }
      }
      function jk(a) {
        for (; null !== V; ) {
          var b = V;
          try {
            switch (b.tag) {
              case 0:
              case 11:
              case 15:
                var c = b.return;
                try {
                  Qj(4, b);
                } catch (k) {
                  W(b, c, k);
                }
                break;
              case 1:
                var d = b.stateNode;
                if ("function" === typeof d.componentDidMount) {
                  var e = b.return;
                  try {
                    d.componentDidMount();
                  } catch (k) {
                    W(b, e, k);
                  }
                }
                var f = b.return;
                try {
                  Rj(b);
                } catch (k) {
                  W(b, f, k);
                }
                break;
              case 5:
                var g = b.return;
                try {
                  Rj(b);
                } catch (k) {
                  W(b, g, k);
                }
            }
          } catch (k) {
            W(b, b.return, k);
          }
          if (b === a) {
            V = null;
            break;
          }
          var h2 = b.sibling;
          if (null !== h2) {
            h2.return = b.return;
            V = h2;
            break;
          }
          V = b.return;
        }
      }
      var lk = Math.ceil;
      var mk = ua.ReactCurrentDispatcher;
      var nk = ua.ReactCurrentOwner;
      var ok = ua.ReactCurrentBatchConfig;
      var K = 0;
      var Q = null;
      var Y = null;
      var Z = 0;
      var fj = 0;
      var ej = Uf(0);
      var T = 0;
      var pk = null;
      var rh = 0;
      var qk = 0;
      var rk = 0;
      var sk = null;
      var tk = null;
      var fk = 0;
      var Gj = Infinity;
      var uk = null;
      var Oi = false;
      var Pi = null;
      var Ri = null;
      var vk = false;
      var wk = null;
      var xk = 0;
      var yk = 0;
      var zk = null;
      var Ak = -1;
      var Bk = 0;
      function R() {
        return 0 !== (K & 6) ? B() : -1 !== Ak ? Ak : Ak = B();
      }
      function yi(a) {
        if (0 === (a.mode & 1)) return 1;
        if (0 !== (K & 2) && 0 !== Z) return Z & -Z;
        if (null !== Kg.transition) return 0 === Bk && (Bk = yc()), Bk;
        a = C;
        if (0 !== a) return a;
        a = window.event;
        a = void 0 === a ? 16 : jd(a.type);
        return a;
      }
      function gi(a, b, c, d) {
        if (50 < yk) throw yk = 0, zk = null, Error(p(185));
        Ac(a, c, d);
        if (0 === (K & 2) || a !== Q) a === Q && (0 === (K & 2) && (qk |= c), 4 === T && Ck(a, Z)), Dk(a, d), 1 === c && 0 === K && 0 === (b.mode & 1) && (Gj = B() + 500, fg && jg());
      }
      function Dk(a, b) {
        var c = a.callbackNode;
        wc(a, b);
        var d = uc(a, a === Q ? Z : 0);
        if (0 === d) null !== c && bc(c), a.callbackNode = null, a.callbackPriority = 0;
        else if (b = d & -d, a.callbackPriority !== b) {
          null != c && bc(c);
          if (1 === b) 0 === a.tag ? ig(Ek.bind(null, a)) : hg(Ek.bind(null, a)), Jf(function() {
            0 === (K & 6) && jg();
          }), c = null;
          else {
            switch (Dc(d)) {
              case 1:
                c = fc;
                break;
              case 4:
                c = gc;
                break;
              case 16:
                c = hc;
                break;
              case 536870912:
                c = jc;
                break;
              default:
                c = hc;
            }
            c = Fk(c, Gk.bind(null, a));
          }
          a.callbackPriority = b;
          a.callbackNode = c;
        }
      }
      function Gk(a, b) {
        Ak = -1;
        Bk = 0;
        if (0 !== (K & 6)) throw Error(p(327));
        var c = a.callbackNode;
        if (Hk() && a.callbackNode !== c) return null;
        var d = uc(a, a === Q ? Z : 0);
        if (0 === d) return null;
        if (0 !== (d & 30) || 0 !== (d & a.expiredLanes) || b) b = Ik(a, d);
        else {
          b = d;
          var e = K;
          K |= 2;
          var f = Jk();
          if (Q !== a || Z !== b) uk = null, Gj = B() + 500, Kk(a, b);
          do
            try {
              Lk();
              break;
            } catch (h2) {
              Mk(a, h2);
            }
          while (1);
          $g();
          mk.current = f;
          K = e;
          null !== Y ? b = 0 : (Q = null, Z = 0, b = T);
        }
        if (0 !== b) {
          2 === b && (e = xc(a), 0 !== e && (d = e, b = Nk(a, e)));
          if (1 === b) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B()), c;
          if (6 === b) Ck(a, d);
          else {
            e = a.current.alternate;
            if (0 === (d & 30) && !Ok(e) && (b = Ik(a, d), 2 === b && (f = xc(a), 0 !== f && (d = f, b = Nk(a, f))), 1 === b)) throw c = pk, Kk(a, 0), Ck(a, d), Dk(a, B()), c;
            a.finishedWork = e;
            a.finishedLanes = d;
            switch (b) {
              case 0:
              case 1:
                throw Error(p(345));
              case 2:
                Pk(a, tk, uk);
                break;
              case 3:
                Ck(a, d);
                if ((d & 130023424) === d && (b = fk + 500 - B(), 10 < b)) {
                  if (0 !== uc(a, 0)) break;
                  e = a.suspendedLanes;
                  if ((e & d) !== d) {
                    R();
                    a.pingedLanes |= a.suspendedLanes & e;
                    break;
                  }
                  a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), b);
                  break;
                }
                Pk(a, tk, uk);
                break;
              case 4:
                Ck(a, d);
                if ((d & 4194240) === d) break;
                b = a.eventTimes;
                for (e = -1; 0 < d; ) {
                  var g = 31 - oc(d);
                  f = 1 << g;
                  g = b[g];
                  g > e && (e = g);
                  d &= ~f;
                }
                d = e;
                d = B() - d;
                d = (120 > d ? 120 : 480 > d ? 480 : 1080 > d ? 1080 : 1920 > d ? 1920 : 3e3 > d ? 3e3 : 4320 > d ? 4320 : 1960 * lk(d / 1960)) - d;
                if (10 < d) {
                  a.timeoutHandle = Ff(Pk.bind(null, a, tk, uk), d);
                  break;
                }
                Pk(a, tk, uk);
                break;
              case 5:
                Pk(a, tk, uk);
                break;
              default:
                throw Error(p(329));
            }
          }
        }
        Dk(a, B());
        return a.callbackNode === c ? Gk.bind(null, a) : null;
      }
      function Nk(a, b) {
        var c = sk;
        a.current.memoizedState.isDehydrated && (Kk(a, b).flags |= 256);
        a = Ik(a, b);
        2 !== a && (b = tk, tk = c, null !== b && Fj(b));
        return a;
      }
      function Fj(a) {
        null === tk ? tk = a : tk.push.apply(tk, a);
      }
      function Ok(a) {
        for (var b = a; ; ) {
          if (b.flags & 16384) {
            var c = b.updateQueue;
            if (null !== c && (c = c.stores, null !== c)) for (var d = 0; d < c.length; d++) {
              var e = c[d], f = e.getSnapshot;
              e = e.value;
              try {
                if (!He(f(), e)) return false;
              } catch (g) {
                return false;
              }
            }
          }
          c = b.child;
          if (b.subtreeFlags & 16384 && null !== c) c.return = b, b = c;
          else {
            if (b === a) break;
            for (; null === b.sibling; ) {
              if (null === b.return || b.return === a) return true;
              b = b.return;
            }
            b.sibling.return = b.return;
            b = b.sibling;
          }
        }
        return true;
      }
      function Ck(a, b) {
        b &= ~rk;
        b &= ~qk;
        a.suspendedLanes |= b;
        a.pingedLanes &= ~b;
        for (a = a.expirationTimes; 0 < b; ) {
          var c = 31 - oc(b), d = 1 << c;
          a[c] = -1;
          b &= ~d;
        }
      }
      function Ek(a) {
        if (0 !== (K & 6)) throw Error(p(327));
        Hk();
        var b = uc(a, 0);
        if (0 === (b & 1)) return Dk(a, B()), null;
        var c = Ik(a, b);
        if (0 !== a.tag && 2 === c) {
          var d = xc(a);
          0 !== d && (b = d, c = Nk(a, d));
        }
        if (1 === c) throw c = pk, Kk(a, 0), Ck(a, b), Dk(a, B()), c;
        if (6 === c) throw Error(p(345));
        a.finishedWork = a.current.alternate;
        a.finishedLanes = b;
        Pk(a, tk, uk);
        Dk(a, B());
        return null;
      }
      function Qk(a, b) {
        var c = K;
        K |= 1;
        try {
          return a(b);
        } finally {
          K = c, 0 === K && (Gj = B() + 500, fg && jg());
        }
      }
      function Rk(a) {
        null !== wk && 0 === wk.tag && 0 === (K & 6) && Hk();
        var b = K;
        K |= 1;
        var c = ok.transition, d = C;
        try {
          if (ok.transition = null, C = 1, a) return a();
        } finally {
          C = d, ok.transition = c, K = b, 0 === (K & 6) && jg();
        }
      }
      function Hj() {
        fj = ej.current;
        E(ej);
      }
      function Kk(a, b) {
        a.finishedWork = null;
        a.finishedLanes = 0;
        var c = a.timeoutHandle;
        -1 !== c && (a.timeoutHandle = -1, Gf(c));
        if (null !== Y) for (c = Y.return; null !== c; ) {
          var d = c;
          wg(d);
          switch (d.tag) {
            case 1:
              d = d.type.childContextTypes;
              null !== d && void 0 !== d && $f();
              break;
            case 3:
              zh();
              E(Wf);
              E(H);
              Eh();
              break;
            case 5:
              Bh(d);
              break;
            case 4:
              zh();
              break;
            case 13:
              E(L);
              break;
            case 19:
              E(L);
              break;
            case 10:
              ah(d.type._context);
              break;
            case 22:
            case 23:
              Hj();
          }
          c = c.return;
        }
        Q = a;
        Y = a = Pg(a.current, null);
        Z = fj = b;
        T = 0;
        pk = null;
        rk = qk = rh = 0;
        tk = sk = null;
        if (null !== fh) {
          for (b = 0; b < fh.length; b++) if (c = fh[b], d = c.interleaved, null !== d) {
            c.interleaved = null;
            var e = d.next, f = c.pending;
            if (null !== f) {
              var g = f.next;
              f.next = e;
              d.next = g;
            }
            c.pending = d;
          }
          fh = null;
        }
        return a;
      }
      function Mk(a, b) {
        do {
          var c = Y;
          try {
            $g();
            Fh.current = Rh;
            if (Ih) {
              for (var d = M.memoizedState; null !== d; ) {
                var e = d.queue;
                null !== e && (e.pending = null);
                d = d.next;
              }
              Ih = false;
            }
            Hh = 0;
            O = N = M = null;
            Jh = false;
            Kh = 0;
            nk.current = null;
            if (null === c || null === c.return) {
              T = 1;
              pk = b;
              Y = null;
              break;
            }
            a: {
              var f = a, g = c.return, h2 = c, k = b;
              b = Z;
              h2.flags |= 32768;
              if (null !== k && "object" === typeof k && "function" === typeof k.then) {
                var l = k, m = h2, q = m.tag;
                if (0 === (m.mode & 1) && (0 === q || 11 === q || 15 === q)) {
                  var r = m.alternate;
                  r ? (m.updateQueue = r.updateQueue, m.memoizedState = r.memoizedState, m.lanes = r.lanes) : (m.updateQueue = null, m.memoizedState = null);
                }
                var y = Ui(g);
                if (null !== y) {
                  y.flags &= -257;
                  Vi(y, g, h2, f, b);
                  y.mode & 1 && Si(f, l, b);
                  b = y;
                  k = l;
                  var n = b.updateQueue;
                  if (null === n) {
                    var t = /* @__PURE__ */ new Set();
                    t.add(k);
                    b.updateQueue = t;
                  } else n.add(k);
                  break a;
                } else {
                  if (0 === (b & 1)) {
                    Si(f, l, b);
                    tj();
                    break a;
                  }
                  k = Error(p(426));
                }
              } else if (I && h2.mode & 1) {
                var J = Ui(g);
                if (null !== J) {
                  0 === (J.flags & 65536) && (J.flags |= 256);
                  Vi(J, g, h2, f, b);
                  Jg(Ji(k, h2));
                  break a;
                }
              }
              f = k = Ji(k, h2);
              4 !== T && (T = 2);
              null === sk ? sk = [f] : sk.push(f);
              f = g;
              do {
                switch (f.tag) {
                  case 3:
                    f.flags |= 65536;
                    b &= -b;
                    f.lanes |= b;
                    var x = Ni(f, k, b);
                    ph(f, x);
                    break a;
                  case 1:
                    h2 = k;
                    var w = f.type, u = f.stateNode;
                    if (0 === (f.flags & 128) && ("function" === typeof w.getDerivedStateFromError || null !== u && "function" === typeof u.componentDidCatch && (null === Ri || !Ri.has(u)))) {
                      f.flags |= 65536;
                      b &= -b;
                      f.lanes |= b;
                      var F = Qi(f, h2, b);
                      ph(f, F);
                      break a;
                    }
                }
                f = f.return;
              } while (null !== f);
            }
            Sk(c);
          } catch (na) {
            b = na;
            Y === c && null !== c && (Y = c = c.return);
            continue;
          }
          break;
        } while (1);
      }
      function Jk() {
        var a = mk.current;
        mk.current = Rh;
        return null === a ? Rh : a;
      }
      function tj() {
        if (0 === T || 3 === T || 2 === T) T = 4;
        null === Q || 0 === (rh & 268435455) && 0 === (qk & 268435455) || Ck(Q, Z);
      }
      function Ik(a, b) {
        var c = K;
        K |= 2;
        var d = Jk();
        if (Q !== a || Z !== b) uk = null, Kk(a, b);
        do
          try {
            Tk();
            break;
          } catch (e) {
            Mk(a, e);
          }
        while (1);
        $g();
        K = c;
        mk.current = d;
        if (null !== Y) throw Error(p(261));
        Q = null;
        Z = 0;
        return T;
      }
      function Tk() {
        for (; null !== Y; ) Uk(Y);
      }
      function Lk() {
        for (; null !== Y && !cc(); ) Uk(Y);
      }
      function Uk(a) {
        var b = Vk(a.alternate, a, fj);
        a.memoizedProps = a.pendingProps;
        null === b ? Sk(a) : Y = b;
        nk.current = null;
      }
      function Sk(a) {
        var b = a;
        do {
          var c = b.alternate;
          a = b.return;
          if (0 === (b.flags & 32768)) {
            if (c = Ej(c, b, fj), null !== c) {
              Y = c;
              return;
            }
          } else {
            c = Ij(c, b);
            if (null !== c) {
              c.flags &= 32767;
              Y = c;
              return;
            }
            if (null !== a) a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null;
            else {
              T = 6;
              Y = null;
              return;
            }
          }
          b = b.sibling;
          if (null !== b) {
            Y = b;
            return;
          }
          Y = b = a;
        } while (null !== b);
        0 === T && (T = 5);
      }
      function Pk(a, b, c) {
        var d = C, e = ok.transition;
        try {
          ok.transition = null, C = 1, Wk(a, b, c, d);
        } finally {
          ok.transition = e, C = d;
        }
        return null;
      }
      function Wk(a, b, c, d) {
        do
          Hk();
        while (null !== wk);
        if (0 !== (K & 6)) throw Error(p(327));
        c = a.finishedWork;
        var e = a.finishedLanes;
        if (null === c) return null;
        a.finishedWork = null;
        a.finishedLanes = 0;
        if (c === a.current) throw Error(p(177));
        a.callbackNode = null;
        a.callbackPriority = 0;
        var f = c.lanes | c.childLanes;
        Bc(a, f);
        a === Q && (Y = Q = null, Z = 0);
        0 === (c.subtreeFlags & 2064) && 0 === (c.flags & 2064) || vk || (vk = true, Fk(hc, function() {
          Hk();
          return null;
        }));
        f = 0 !== (c.flags & 15990);
        if (0 !== (c.subtreeFlags & 15990) || f) {
          f = ok.transition;
          ok.transition = null;
          var g = C;
          C = 1;
          var h2 = K;
          K |= 4;
          nk.current = null;
          Oj(a, c);
          dk(c, a);
          Oe(Df);
          dd = !!Cf;
          Df = Cf = null;
          a.current = c;
          hk(c, a, e);
          dc();
          K = h2;
          C = g;
          ok.transition = f;
        } else a.current = c;
        vk && (vk = false, wk = a, xk = e);
        f = a.pendingLanes;
        0 === f && (Ri = null);
        mc(c.stateNode, d);
        Dk(a, B());
        if (null !== b) for (d = a.onRecoverableError, c = 0; c < b.length; c++) e = b[c], d(e.value, { componentStack: e.stack, digest: e.digest });
        if (Oi) throw Oi = false, a = Pi, Pi = null, a;
        0 !== (xk & 1) && 0 !== a.tag && Hk();
        f = a.pendingLanes;
        0 !== (f & 1) ? a === zk ? yk++ : (yk = 0, zk = a) : yk = 0;
        jg();
        return null;
      }
      function Hk() {
        if (null !== wk) {
          var a = Dc(xk), b = ok.transition, c = C;
          try {
            ok.transition = null;
            C = 16 > a ? 16 : a;
            if (null === wk) var d = false;
            else {
              a = wk;
              wk = null;
              xk = 0;
              if (0 !== (K & 6)) throw Error(p(331));
              var e = K;
              K |= 4;
              for (V = a.current; null !== V; ) {
                var f = V, g = f.child;
                if (0 !== (V.flags & 16)) {
                  var h2 = f.deletions;
                  if (null !== h2) {
                    for (var k = 0; k < h2.length; k++) {
                      var l = h2[k];
                      for (V = l; null !== V; ) {
                        var m = V;
                        switch (m.tag) {
                          case 0:
                          case 11:
                          case 15:
                            Pj(8, m, f);
                        }
                        var q = m.child;
                        if (null !== q) q.return = m, V = q;
                        else for (; null !== V; ) {
                          m = V;
                          var r = m.sibling, y = m.return;
                          Sj(m);
                          if (m === l) {
                            V = null;
                            break;
                          }
                          if (null !== r) {
                            r.return = y;
                            V = r;
                            break;
                          }
                          V = y;
                        }
                      }
                    }
                    var n = f.alternate;
                    if (null !== n) {
                      var t = n.child;
                      if (null !== t) {
                        n.child = null;
                        do {
                          var J = t.sibling;
                          t.sibling = null;
                          t = J;
                        } while (null !== t);
                      }
                    }
                    V = f;
                  }
                }
                if (0 !== (f.subtreeFlags & 2064) && null !== g) g.return = f, V = g;
                else b: for (; null !== V; ) {
                  f = V;
                  if (0 !== (f.flags & 2048)) switch (f.tag) {
                    case 0:
                    case 11:
                    case 15:
                      Pj(9, f, f.return);
                  }
                  var x = f.sibling;
                  if (null !== x) {
                    x.return = f.return;
                    V = x;
                    break b;
                  }
                  V = f.return;
                }
              }
              var w = a.current;
              for (V = w; null !== V; ) {
                g = V;
                var u = g.child;
                if (0 !== (g.subtreeFlags & 2064) && null !== u) u.return = g, V = u;
                else b: for (g = w; null !== V; ) {
                  h2 = V;
                  if (0 !== (h2.flags & 2048)) try {
                    switch (h2.tag) {
                      case 0:
                      case 11:
                      case 15:
                        Qj(9, h2);
                    }
                  } catch (na) {
                    W(h2, h2.return, na);
                  }
                  if (h2 === g) {
                    V = null;
                    break b;
                  }
                  var F = h2.sibling;
                  if (null !== F) {
                    F.return = h2.return;
                    V = F;
                    break b;
                  }
                  V = h2.return;
                }
              }
              K = e;
              jg();
              if (lc && "function" === typeof lc.onPostCommitFiberRoot) try {
                lc.onPostCommitFiberRoot(kc, a);
              } catch (na) {
              }
              d = true;
            }
            return d;
          } finally {
            C = c, ok.transition = b;
          }
        }
        return false;
      }
      function Xk(a, b, c) {
        b = Ji(c, b);
        b = Ni(a, b, 1);
        a = nh(a, b, 1);
        b = R();
        null !== a && (Ac(a, 1, b), Dk(a, b));
      }
      function W(a, b, c) {
        if (3 === a.tag) Xk(a, a, c);
        else for (; null !== b; ) {
          if (3 === b.tag) {
            Xk(b, a, c);
            break;
          } else if (1 === b.tag) {
            var d = b.stateNode;
            if ("function" === typeof b.type.getDerivedStateFromError || "function" === typeof d.componentDidCatch && (null === Ri || !Ri.has(d))) {
              a = Ji(c, a);
              a = Qi(b, a, 1);
              b = nh(b, a, 1);
              a = R();
              null !== b && (Ac(b, 1, a), Dk(b, a));
              break;
            }
          }
          b = b.return;
        }
      }
      function Ti(a, b, c) {
        var d = a.pingCache;
        null !== d && d.delete(b);
        b = R();
        a.pingedLanes |= a.suspendedLanes & c;
        Q === a && (Z & c) === c && (4 === T || 3 === T && (Z & 130023424) === Z && 500 > B() - fk ? Kk(a, 0) : rk |= c);
        Dk(a, b);
      }
      function Yk(a, b) {
        0 === b && (0 === (a.mode & 1) ? b = 1 : (b = sc, sc <<= 1, 0 === (sc & 130023424) && (sc = 4194304)));
        var c = R();
        a = ih(a, b);
        null !== a && (Ac(a, b, c), Dk(a, c));
      }
      function uj(a) {
        var b = a.memoizedState, c = 0;
        null !== b && (c = b.retryLane);
        Yk(a, c);
      }
      function bk(a, b) {
        var c = 0;
        switch (a.tag) {
          case 13:
            var d = a.stateNode;
            var e = a.memoizedState;
            null !== e && (c = e.retryLane);
            break;
          case 19:
            d = a.stateNode;
            break;
          default:
            throw Error(p(314));
        }
        null !== d && d.delete(b);
        Yk(a, c);
      }
      var Vk;
      Vk = function(a, b, c) {
        if (null !== a) if (a.memoizedProps !== b.pendingProps || Wf.current) dh = true;
        else {
          if (0 === (a.lanes & c) && 0 === (b.flags & 128)) return dh = false, yj(a, b, c);
          dh = 0 !== (a.flags & 131072) ? true : false;
        }
        else dh = false, I && 0 !== (b.flags & 1048576) && ug(b, ng, b.index);
        b.lanes = 0;
        switch (b.tag) {
          case 2:
            var d = b.type;
            ij(a, b);
            a = b.pendingProps;
            var e = Yf(b, H.current);
            ch(b, c);
            e = Nh(null, b, d, a, e, c);
            var f = Sh();
            b.flags |= 1;
            "object" === typeof e && null !== e && "function" === typeof e.render && void 0 === e.$$typeof ? (b.tag = 1, b.memoizedState = null, b.updateQueue = null, Zf(d) ? (f = true, cg(b)) : f = false, b.memoizedState = null !== e.state && void 0 !== e.state ? e.state : null, kh(b), e.updater = Ei, b.stateNode = e, e._reactInternals = b, Ii(b, d, a, c), b = jj(null, b, d, true, f, c)) : (b.tag = 0, I && f && vg(b), Xi(null, b, e, c), b = b.child);
            return b;
          case 16:
            d = b.elementType;
            a: {
              ij(a, b);
              a = b.pendingProps;
              e = d._init;
              d = e(d._payload);
              b.type = d;
              e = b.tag = Zk(d);
              a = Ci(d, a);
              switch (e) {
                case 0:
                  b = cj(null, b, d, a, c);
                  break a;
                case 1:
                  b = hj(null, b, d, a, c);
                  break a;
                case 11:
                  b = Yi(null, b, d, a, c);
                  break a;
                case 14:
                  b = $i(null, b, d, Ci(d.type, a), c);
                  break a;
              }
              throw Error(p(
                306,
                d,
                ""
              ));
            }
            return b;
          case 0:
            return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), cj(a, b, d, e, c);
          case 1:
            return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), hj(a, b, d, e, c);
          case 3:
            a: {
              kj(b);
              if (null === a) throw Error(p(387));
              d = b.pendingProps;
              f = b.memoizedState;
              e = f.element;
              lh(a, b);
              qh(b, d, null, c);
              var g = b.memoizedState;
              d = g.element;
              if (f.isDehydrated) if (f = { element: d, isDehydrated: false, cache: g.cache, pendingSuspenseBoundaries: g.pendingSuspenseBoundaries, transitions: g.transitions }, b.updateQueue.baseState = f, b.memoizedState = f, b.flags & 256) {
                e = Ji(Error(p(423)), b);
                b = lj(a, b, d, c, e);
                break a;
              } else if (d !== e) {
                e = Ji(Error(p(424)), b);
                b = lj(a, b, d, c, e);
                break a;
              } else for (yg = Lf(b.stateNode.containerInfo.firstChild), xg = b, I = true, zg = null, c = Vg(b, null, d, c), b.child = c; c; ) c.flags = c.flags & -3 | 4096, c = c.sibling;
              else {
                Ig();
                if (d === e) {
                  b = Zi(a, b, c);
                  break a;
                }
                Xi(a, b, d, c);
              }
              b = b.child;
            }
            return b;
          case 5:
            return Ah(b), null === a && Eg(b), d = b.type, e = b.pendingProps, f = null !== a ? a.memoizedProps : null, g = e.children, Ef(d, e) ? g = null : null !== f && Ef(d, f) && (b.flags |= 32), gj(a, b), Xi(a, b, g, c), b.child;
          case 6:
            return null === a && Eg(b), null;
          case 13:
            return oj(a, b, c);
          case 4:
            return yh(b, b.stateNode.containerInfo), d = b.pendingProps, null === a ? b.child = Ug(b, null, d, c) : Xi(a, b, d, c), b.child;
          case 11:
            return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), Yi(a, b, d, e, c);
          case 7:
            return Xi(a, b, b.pendingProps, c), b.child;
          case 8:
            return Xi(a, b, b.pendingProps.children, c), b.child;
          case 12:
            return Xi(a, b, b.pendingProps.children, c), b.child;
          case 10:
            a: {
              d = b.type._context;
              e = b.pendingProps;
              f = b.memoizedProps;
              g = e.value;
              G(Wg, d._currentValue);
              d._currentValue = g;
              if (null !== f) if (He(f.value, g)) {
                if (f.children === e.children && !Wf.current) {
                  b = Zi(a, b, c);
                  break a;
                }
              } else for (f = b.child, null !== f && (f.return = b); null !== f; ) {
                var h2 = f.dependencies;
                if (null !== h2) {
                  g = f.child;
                  for (var k = h2.firstContext; null !== k; ) {
                    if (k.context === d) {
                      if (1 === f.tag) {
                        k = mh(-1, c & -c);
                        k.tag = 2;
                        var l = f.updateQueue;
                        if (null !== l) {
                          l = l.shared;
                          var m = l.pending;
                          null === m ? k.next = k : (k.next = m.next, m.next = k);
                          l.pending = k;
                        }
                      }
                      f.lanes |= c;
                      k = f.alternate;
                      null !== k && (k.lanes |= c);
                      bh(
                        f.return,
                        c,
                        b
                      );
                      h2.lanes |= c;
                      break;
                    }
                    k = k.next;
                  }
                } else if (10 === f.tag) g = f.type === b.type ? null : f.child;
                else if (18 === f.tag) {
                  g = f.return;
                  if (null === g) throw Error(p(341));
                  g.lanes |= c;
                  h2 = g.alternate;
                  null !== h2 && (h2.lanes |= c);
                  bh(g, c, b);
                  g = f.sibling;
                } else g = f.child;
                if (null !== g) g.return = f;
                else for (g = f; null !== g; ) {
                  if (g === b) {
                    g = null;
                    break;
                  }
                  f = g.sibling;
                  if (null !== f) {
                    f.return = g.return;
                    g = f;
                    break;
                  }
                  g = g.return;
                }
                f = g;
              }
              Xi(a, b, e.children, c);
              b = b.child;
            }
            return b;
          case 9:
            return e = b.type, d = b.pendingProps.children, ch(b, c), e = eh(e), d = d(e), b.flags |= 1, Xi(a, b, d, c), b.child;
          case 14:
            return d = b.type, e = Ci(d, b.pendingProps), e = Ci(d.type, e), $i(a, b, d, e, c);
          case 15:
            return bj(a, b, b.type, b.pendingProps, c);
          case 17:
            return d = b.type, e = b.pendingProps, e = b.elementType === d ? e : Ci(d, e), ij(a, b), b.tag = 1, Zf(d) ? (a = true, cg(b)) : a = false, ch(b, c), Gi(b, d, e), Ii(b, d, e, c), jj(null, b, d, true, a, c);
          case 19:
            return xj(a, b, c);
          case 22:
            return dj(a, b, c);
        }
        throw Error(p(156, b.tag));
      };
      function Fk(a, b) {
        return ac(a, b);
      }
      function $k(a, b, c, d) {
        this.tag = a;
        this.key = c;
        this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null;
        this.index = 0;
        this.ref = null;
        this.pendingProps = b;
        this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null;
        this.mode = d;
        this.subtreeFlags = this.flags = 0;
        this.deletions = null;
        this.childLanes = this.lanes = 0;
        this.alternate = null;
      }
      function Bg(a, b, c, d) {
        return new $k(a, b, c, d);
      }
      function aj(a) {
        a = a.prototype;
        return !(!a || !a.isReactComponent);
      }
      function Zk(a) {
        if ("function" === typeof a) return aj(a) ? 1 : 0;
        if (void 0 !== a && null !== a) {
          a = a.$$typeof;
          if (a === Da) return 11;
          if (a === Ga) return 14;
        }
        return 2;
      }
      function Pg(a, b) {
        var c = a.alternate;
        null === c ? (c = Bg(a.tag, b, a.key, a.mode), c.elementType = a.elementType, c.type = a.type, c.stateNode = a.stateNode, c.alternate = a, a.alternate = c) : (c.pendingProps = b, c.type = a.type, c.flags = 0, c.subtreeFlags = 0, c.deletions = null);
        c.flags = a.flags & 14680064;
        c.childLanes = a.childLanes;
        c.lanes = a.lanes;
        c.child = a.child;
        c.memoizedProps = a.memoizedProps;
        c.memoizedState = a.memoizedState;
        c.updateQueue = a.updateQueue;
        b = a.dependencies;
        c.dependencies = null === b ? null : { lanes: b.lanes, firstContext: b.firstContext };
        c.sibling = a.sibling;
        c.index = a.index;
        c.ref = a.ref;
        return c;
      }
      function Rg(a, b, c, d, e, f) {
        var g = 2;
        d = a;
        if ("function" === typeof a) aj(a) && (g = 1);
        else if ("string" === typeof a) g = 5;
        else a: switch (a) {
          case ya:
            return Tg(c.children, e, f, b);
          case za:
            g = 8;
            e |= 8;
            break;
          case Aa:
            return a = Bg(12, c, b, e | 2), a.elementType = Aa, a.lanes = f, a;
          case Ea:
            return a = Bg(13, c, b, e), a.elementType = Ea, a.lanes = f, a;
          case Fa:
            return a = Bg(19, c, b, e), a.elementType = Fa, a.lanes = f, a;
          case Ia:
            return pj(c, e, f, b);
          default:
            if ("object" === typeof a && null !== a) switch (a.$$typeof) {
              case Ba:
                g = 10;
                break a;
              case Ca:
                g = 9;
                break a;
              case Da:
                g = 11;
                break a;
              case Ga:
                g = 14;
                break a;
              case Ha:
                g = 16;
                d = null;
                break a;
            }
            throw Error(p(130, null == a ? a : typeof a, ""));
        }
        b = Bg(g, c, b, e);
        b.elementType = a;
        b.type = d;
        b.lanes = f;
        return b;
      }
      function Tg(a, b, c, d) {
        a = Bg(7, a, d, b);
        a.lanes = c;
        return a;
      }
      function pj(a, b, c, d) {
        a = Bg(22, a, d, b);
        a.elementType = Ia;
        a.lanes = c;
        a.stateNode = { isHidden: false };
        return a;
      }
      function Qg(a, b, c) {
        a = Bg(6, a, null, b);
        a.lanes = c;
        return a;
      }
      function Sg(a, b, c) {
        b = Bg(4, null !== a.children ? a.children : [], a.key, b);
        b.lanes = c;
        b.stateNode = { containerInfo: a.containerInfo, pendingChildren: null, implementation: a.implementation };
        return b;
      }
      function al(a, b, c, d, e) {
        this.tag = b;
        this.containerInfo = a;
        this.finishedWork = this.pingCache = this.current = this.pendingChildren = null;
        this.timeoutHandle = -1;
        this.callbackNode = this.pendingContext = this.context = null;
        this.callbackPriority = 0;
        this.eventTimes = zc(0);
        this.expirationTimes = zc(-1);
        this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0;
        this.entanglements = zc(0);
        this.identifierPrefix = d;
        this.onRecoverableError = e;
        this.mutableSourceEagerHydrationData = null;
      }
      function bl(a, b, c, d, e, f, g, h2, k) {
        a = new al(a, b, c, h2, k);
        1 === b ? (b = 1, true === f && (b |= 8)) : b = 0;
        f = Bg(3, null, null, b);
        a.current = f;
        f.stateNode = a;
        f.memoizedState = { element: d, isDehydrated: c, cache: null, transitions: null, pendingSuspenseBoundaries: null };
        kh(f);
        return a;
      }
      function cl(a, b, c) {
        var d = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
        return { $$typeof: wa, key: null == d ? null : "" + d, children: a, containerInfo: b, implementation: c };
      }
      function dl(a) {
        if (!a) return Vf;
        a = a._reactInternals;
        a: {
          if (Vb(a) !== a || 1 !== a.tag) throw Error(p(170));
          var b = a;
          do {
            switch (b.tag) {
              case 3:
                b = b.stateNode.context;
                break a;
              case 1:
                if (Zf(b.type)) {
                  b = b.stateNode.__reactInternalMemoizedMergedChildContext;
                  break a;
                }
            }
            b = b.return;
          } while (null !== b);
          throw Error(p(171));
        }
        if (1 === a.tag) {
          var c = a.type;
          if (Zf(c)) return bg(a, c, b);
        }
        return b;
      }
      function el(a, b, c, d, e, f, g, h2, k) {
        a = bl(c, d, true, a, e, f, g, h2, k);
        a.context = dl(null);
        c = a.current;
        d = R();
        e = yi(c);
        f = mh(d, e);
        f.callback = void 0 !== b && null !== b ? b : null;
        nh(c, f, e);
        a.current.lanes = e;
        Ac(a, e, d);
        Dk(a, d);
        return a;
      }
      function fl(a, b, c, d) {
        var e = b.current, f = R(), g = yi(e);
        c = dl(c);
        null === b.context ? b.context = c : b.pendingContext = c;
        b = mh(f, g);
        b.payload = { element: a };
        d = void 0 === d ? null : d;
        null !== d && (b.callback = d);
        a = nh(e, b, g);
        null !== a && (gi(a, e, g, f), oh(a, e, g));
        return g;
      }
      function gl(a) {
        a = a.current;
        if (!a.child) return null;
        switch (a.child.tag) {
          case 5:
            return a.child.stateNode;
          default:
            return a.child.stateNode;
        }
      }
      function hl(a, b) {
        a = a.memoizedState;
        if (null !== a && null !== a.dehydrated) {
          var c = a.retryLane;
          a.retryLane = 0 !== c && c < b ? c : b;
        }
      }
      function il(a, b) {
        hl(a, b);
        (a = a.alternate) && hl(a, b);
      }
      function jl() {
        return null;
      }
      var kl = "function" === typeof reportError ? reportError : function(a) {
        console.error(a);
      };
      function ll(a) {
        this._internalRoot = a;
      }
      ml.prototype.render = ll.prototype.render = function(a) {
        var b = this._internalRoot;
        if (null === b) throw Error(p(409));
        fl(a, b, null, null);
      };
      ml.prototype.unmount = ll.prototype.unmount = function() {
        var a = this._internalRoot;
        if (null !== a) {
          this._internalRoot = null;
          var b = a.containerInfo;
          Rk(function() {
            fl(null, a, null, null);
          });
          b[uf] = null;
        }
      };
      function ml(a) {
        this._internalRoot = a;
      }
      ml.prototype.unstable_scheduleHydration = function(a) {
        if (a) {
          var b = Hc();
          a = { blockedOn: null, target: a, priority: b };
          for (var c = 0; c < Qc.length && 0 !== b && b < Qc[c].priority; c++) ;
          Qc.splice(c, 0, a);
          0 === c && Vc(a);
        }
      };
      function nl(a) {
        return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType);
      }
      function ol(a) {
        return !(!a || 1 !== a.nodeType && 9 !== a.nodeType && 11 !== a.nodeType && (8 !== a.nodeType || " react-mount-point-unstable " !== a.nodeValue));
      }
      function pl() {
      }
      function ql(a, b, c, d, e) {
        if (e) {
          if ("function" === typeof d) {
            var f = d;
            d = function() {
              var a2 = gl(g);
              f.call(a2);
            };
          }
          var g = el(b, d, a, 0, null, false, false, "", pl);
          a._reactRootContainer = g;
          a[uf] = g.current;
          sf(8 === a.nodeType ? a.parentNode : a);
          Rk();
          return g;
        }
        for (; e = a.lastChild; ) a.removeChild(e);
        if ("function" === typeof d) {
          var h2 = d;
          d = function() {
            var a2 = gl(k);
            h2.call(a2);
          };
        }
        var k = bl(a, 0, false, null, null, false, false, "", pl);
        a._reactRootContainer = k;
        a[uf] = k.current;
        sf(8 === a.nodeType ? a.parentNode : a);
        Rk(function() {
          fl(b, k, c, d);
        });
        return k;
      }
      function rl(a, b, c, d, e) {
        var f = c._reactRootContainer;
        if (f) {
          var g = f;
          if ("function" === typeof e) {
            var h2 = e;
            e = function() {
              var a2 = gl(g);
              h2.call(a2);
            };
          }
          fl(b, g, a, e);
        } else g = ql(c, b, a, e, d);
        return gl(g);
      }
      Ec = function(a) {
        switch (a.tag) {
          case 3:
            var b = a.stateNode;
            if (b.current.memoizedState.isDehydrated) {
              var c = tc(b.pendingLanes);
              0 !== c && (Cc(b, c | 1), Dk(b, B()), 0 === (K & 6) && (Gj = B() + 500, jg()));
            }
            break;
          case 13:
            Rk(function() {
              var b2 = ih(a, 1);
              if (null !== b2) {
                var c2 = R();
                gi(b2, a, 1, c2);
              }
            }), il(a, 1);
        }
      };
      Fc = function(a) {
        if (13 === a.tag) {
          var b = ih(a, 134217728);
          if (null !== b) {
            var c = R();
            gi(b, a, 134217728, c);
          }
          il(a, 134217728);
        }
      };
      Gc = function(a) {
        if (13 === a.tag) {
          var b = yi(a), c = ih(a, b);
          if (null !== c) {
            var d = R();
            gi(c, a, b, d);
          }
          il(a, b);
        }
      };
      Hc = function() {
        return C;
      };
      Ic = function(a, b) {
        var c = C;
        try {
          return C = a, b();
        } finally {
          C = c;
        }
      };
      yb = function(a, b, c) {
        switch (b) {
          case "input":
            bb(a, c);
            b = c.name;
            if ("radio" === c.type && null != b) {
              for (c = a; c.parentNode; ) c = c.parentNode;
              c = c.querySelectorAll("input[name=" + JSON.stringify("" + b) + '][type="radio"]');
              for (b = 0; b < c.length; b++) {
                var d = c[b];
                if (d !== a && d.form === a.form) {
                  var e = Db(d);
                  if (!e) throw Error(p(90));
                  Wa(d);
                  bb(d, e);
                }
              }
            }
            break;
          case "textarea":
            ib(a, c);
            break;
          case "select":
            b = c.value, null != b && fb(a, !!c.multiple, b, false);
        }
      };
      Gb = Qk;
      Hb = Rk;
      var sl = { usingClientEntryPoint: false, Events: [Cb, ue, Db, Eb, Fb, Qk] };
      var tl = { findFiberByHostInstance: Wc, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" };
      var ul = { bundleType: tl.bundleType, version: tl.version, rendererPackageName: tl.rendererPackageName, rendererConfig: tl.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: ua.ReactCurrentDispatcher, findHostInstanceByFiber: function(a) {
        a = Zb(a);
        return null === a ? null : a.stateNode;
      }, findFiberByHostInstance: tl.findFiberByHostInstance || jl, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
      if ("undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__) {
        vl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
        if (!vl.isDisabled && vl.supportsFiber) try {
          kc = vl.inject(ul), lc = vl;
        } catch (a) {
        }
      }
      var vl;
      exports2.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = sl;
      exports2.createPortal = function(a, b) {
        var c = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
        if (!nl(b)) throw Error(p(200));
        return cl(a, b, null, c);
      };
      exports2.createRoot = function(a, b) {
        if (!nl(a)) throw Error(p(299));
        var c = false, d = "", e = kl;
        null !== b && void 0 !== b && (true === b.unstable_strictMode && (c = true), void 0 !== b.identifierPrefix && (d = b.identifierPrefix), void 0 !== b.onRecoverableError && (e = b.onRecoverableError));
        b = bl(a, 1, false, null, null, c, false, d, e);
        a[uf] = b.current;
        sf(8 === a.nodeType ? a.parentNode : a);
        return new ll(b);
      };
      exports2.findDOMNode = function(a) {
        if (null == a) return null;
        if (1 === a.nodeType) return a;
        var b = a._reactInternals;
        if (void 0 === b) {
          if ("function" === typeof a.render) throw Error(p(188));
          a = Object.keys(a).join(",");
          throw Error(p(268, a));
        }
        a = Zb(b);
        a = null === a ? null : a.stateNode;
        return a;
      };
      exports2.flushSync = function(a) {
        return Rk(a);
      };
      exports2.hydrate = function(a, b, c) {
        if (!ol(b)) throw Error(p(200));
        return rl(null, a, b, true, c);
      };
      exports2.hydrateRoot = function(a, b, c) {
        if (!nl(a)) throw Error(p(405));
        var d = null != c && c.hydratedSources || null, e = false, f = "", g = kl;
        null !== c && void 0 !== c && (true === c.unstable_strictMode && (e = true), void 0 !== c.identifierPrefix && (f = c.identifierPrefix), void 0 !== c.onRecoverableError && (g = c.onRecoverableError));
        b = el(b, null, a, 1, null != c ? c : null, e, false, f, g);
        a[uf] = b.current;
        sf(a);
        if (d) for (a = 0; a < d.length; a++) c = d[a], e = c._getVersion, e = e(c._source), null == b.mutableSourceEagerHydrationData ? b.mutableSourceEagerHydrationData = [c, e] : b.mutableSourceEagerHydrationData.push(
          c,
          e
        );
        return new ml(b);
      };
      exports2.render = function(a, b, c) {
        if (!ol(b)) throw Error(p(200));
        return rl(null, a, b, false, c);
      };
      exports2.unmountComponentAtNode = function(a) {
        if (!ol(a)) throw Error(p(40));
        return a._reactRootContainer ? (Rk(function() {
          rl(null, null, a, false, function() {
            a._reactRootContainer = null;
            a[uf] = null;
          });
        }), true) : false;
      };
      exports2.unstable_batchedUpdates = Qk;
      exports2.unstable_renderSubtreeIntoContainer = function(a, b, c, d) {
        if (!ol(c)) throw Error(p(200));
        if (null == a || void 0 === a._reactInternals) throw Error(p(38));
        return rl(a, b, c, false, d);
      };
      exports2.version = "18.3.1-next-f1338f8080-20240426";
    }
  });

  // node_modules/react-dom/index.js
  var require_react_dom = __commonJS({
    "node_modules/react-dom/index.js"(exports2, module2) {
      "use strict";
      function checkDCE() {
        if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
          return;
        }
        if (false) {
          throw new Error("^_^");
        }
        try {
          __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
        } catch (err) {
          console.error(err);
        }
      }
      if (true) {
        checkDCE();
        module2.exports = require_react_dom_production_min();
      } else {
        module2.exports = null;
      }
    }
  });

  // node_modules/react-dom/client.js
  var require_client = __commonJS({
    "node_modules/react-dom/client.js"(exports2) {
      "use strict";
      var m = require_react_dom();
      if (true) {
        exports2.createRoot = m.createRoot;
        exports2.hydrateRoot = m.hydrateRoot;
      } else {
        i = m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
        exports2.createRoot = function(c, o) {
          i.usingClientEntryPoint = true;
          try {
            return m.createRoot(c, o);
          } finally {
            i.usingClientEntryPoint = false;
          }
        };
        exports2.hydrateRoot = function(c, h2, o) {
          i.usingClientEntryPoint = true;
          try {
            return m.hydrateRoot(c, h2, o);
          } finally {
            i.usingClientEntryPoint = false;
          }
        };
      }
      var i;
    }
  });

  // node_modules/prop-types/lib/ReactPropTypesSecret.js
  var require_ReactPropTypesSecret = __commonJS({
    "node_modules/prop-types/lib/ReactPropTypesSecret.js"(exports2, module2) {
      "use strict";
      var ReactPropTypesSecret = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
      module2.exports = ReactPropTypesSecret;
    }
  });

  // node_modules/prop-types/factoryWithThrowingShims.js
  var require_factoryWithThrowingShims = __commonJS({
    "node_modules/prop-types/factoryWithThrowingShims.js"(exports2, module2) {
      "use strict";
      var ReactPropTypesSecret = require_ReactPropTypesSecret();
      function emptyFunction() {
      }
      function emptyFunctionWithReset() {
      }
      emptyFunctionWithReset.resetWarningCache = emptyFunction;
      module2.exports = function() {
        function shim(props, propName, componentName2, location2, propFullName, secret) {
          if (secret === ReactPropTypesSecret) {
            return;
          }
          var err = new Error(
            "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
          );
          err.name = "Invariant Violation";
          throw err;
        }
        ;
        shim.isRequired = shim;
        function getShim() {
          return shim;
        }
        ;
        var ReactPropTypes = {
          array: shim,
          bigint: shim,
          bool: shim,
          func: shim,
          number: shim,
          object: shim,
          string: shim,
          symbol: shim,
          any: shim,
          arrayOf: getShim,
          element: shim,
          elementType: shim,
          instanceOf: getShim,
          node: shim,
          objectOf: getShim,
          oneOf: getShim,
          oneOfType: getShim,
          shape: getShim,
          exact: getShim,
          checkPropTypes: emptyFunctionWithReset,
          resetWarningCache: emptyFunction
        };
        ReactPropTypes.PropTypes = ReactPropTypes;
        return ReactPropTypes;
      };
    }
  });

  // node_modules/prop-types/index.js
  var require_prop_types = __commonJS({
    "node_modules/prop-types/index.js"(exports2, module2) {
      if (false) {
        ReactIs = null;
        throwOnDirectAccess = true;
        module2.exports = null(ReactIs.isElement, throwOnDirectAccess);
      } else {
        module2.exports = require_factoryWithThrowingShims()();
      }
      var ReactIs;
      var throwOnDirectAccess;
    }
  });

  // node_modules/react-modal/lib/helpers/tabbable.js
  var require_tabbable = __commonJS({
    "node_modules/react-modal/lib/helpers/tabbable.js"(exports2, module2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      exports2.default = findTabbableDescendants;
      var DISPLAY_NONE = "none";
      var DISPLAY_CONTENTS = "contents";
      var tabbableNode = /^(input|select|textarea|button|object|iframe)$/;
      function isNotOverflowing(element, style) {
        return style.getPropertyValue("overflow") !== "visible" || // if 'overflow: visible' set, check if there is actually any overflow
        element.scrollWidth <= 0 && element.scrollHeight <= 0;
      }
      function hidesContents(element) {
        var zeroSize = element.offsetWidth <= 0 && element.offsetHeight <= 0;
        if (zeroSize && !element.innerHTML) return true;
        try {
          var style = window.getComputedStyle(element);
          var displayValue = style.getPropertyValue("display");
          return zeroSize ? displayValue !== DISPLAY_CONTENTS && isNotOverflowing(element, style) : displayValue === DISPLAY_NONE;
        } catch (exception) {
          console.warn("Failed to inspect element style");
          return false;
        }
      }
      function visible(element) {
        var parentElement = element;
        var rootNode = element.getRootNode && element.getRootNode();
        while (parentElement) {
          if (parentElement === document.body) break;
          if (rootNode && parentElement === rootNode) parentElement = rootNode.host.parentNode;
          if (hidesContents(parentElement)) return false;
          parentElement = parentElement.parentNode;
        }
        return true;
      }
      function focusable(element, isTabIndexNotNaN) {
        var nodeName = element.nodeName.toLowerCase();
        var res = tabbableNode.test(nodeName) && !element.disabled || (nodeName === "a" ? element.href || isTabIndexNotNaN : isTabIndexNotNaN);
        return res && visible(element);
      }
      function tabbable(element) {
        var tabIndex = element.getAttribute("tabindex");
        if (tabIndex === null) tabIndex = void 0;
        var isTabIndexNaN = isNaN(tabIndex);
        return (isTabIndexNaN || tabIndex >= 0) && focusable(element, !isTabIndexNaN);
      }
      function findTabbableDescendants(element) {
        var descendants = [].slice.call(element.querySelectorAll("*"), 0).reduce(function(finished, el) {
          return finished.concat(!el.shadowRoot ? [el] : findTabbableDescendants(el.shadowRoot));
        }, []);
        return descendants.filter(tabbable);
      }
      module2.exports = exports2["default"];
    }
  });

  // node_modules/react-modal/lib/helpers/focusManager.js
  var require_focusManager = __commonJS({
    "node_modules/react-modal/lib/helpers/focusManager.js"(exports2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      exports2.resetState = resetState;
      exports2.log = log;
      exports2.handleBlur = handleBlur;
      exports2.handleFocus = handleFocus;
      exports2.markForFocusLater = markForFocusLater;
      exports2.returnFocus = returnFocus;
      exports2.popWithoutFocus = popWithoutFocus;
      exports2.setupScopedFocus = setupScopedFocus;
      exports2.teardownScopedFocus = teardownScopedFocus;
      var _tabbable = require_tabbable();
      var _tabbable2 = _interopRequireDefault(_tabbable);
      function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }
      var focusLaterElements = [];
      var modalElement = null;
      var needToFocus = false;
      function resetState() {
        focusLaterElements = [];
      }
      function log() {
        if (false) {
          console.log("focusManager ----------");
          focusLaterElements.forEach(function(f) {
            var check = f || {};
            console.log(check.nodeName, check.className, check.id);
          });
          console.log("end focusManager ----------");
        }
      }
      function handleBlur() {
        needToFocus = true;
      }
      function handleFocus() {
        if (needToFocus) {
          needToFocus = false;
          if (!modalElement) {
            return;
          }
          setTimeout(function() {
            if (modalElement.contains(document.activeElement)) {
              return;
            }
            var el = (0, _tabbable2.default)(modalElement)[0] || modalElement;
            el.focus();
          }, 0);
        }
      }
      function markForFocusLater() {
        focusLaterElements.push(document.activeElement);
      }
      function returnFocus() {
        var preventScroll = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
        var toFocus = null;
        try {
          if (focusLaterElements.length !== 0) {
            toFocus = focusLaterElements.pop();
            toFocus.focus({ preventScroll });
          }
          return;
        } catch (e) {
          console.warn(["You tried to return focus to", toFocus, "but it is not in the DOM anymore"].join(" "));
        }
      }
      function popWithoutFocus() {
        focusLaterElements.length > 0 && focusLaterElements.pop();
      }
      function setupScopedFocus(element) {
        modalElement = element;
        if (window.addEventListener) {
          window.addEventListener("blur", handleBlur, false);
          document.addEventListener("focus", handleFocus, true);
        } else {
          window.attachEvent("onBlur", handleBlur);
          document.attachEvent("onFocus", handleFocus);
        }
      }
      function teardownScopedFocus() {
        modalElement = null;
        if (window.addEventListener) {
          window.removeEventListener("blur", handleBlur);
          document.removeEventListener("focus", handleFocus);
        } else {
          window.detachEvent("onBlur", handleBlur);
          document.detachEvent("onFocus", handleFocus);
        }
      }
    }
  });

  // node_modules/react-modal/lib/helpers/scopeTab.js
  var require_scopeTab = __commonJS({
    "node_modules/react-modal/lib/helpers/scopeTab.js"(exports2, module2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      exports2.default = scopeTab;
      var _tabbable = require_tabbable();
      var _tabbable2 = _interopRequireDefault(_tabbable);
      function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }
      function getActiveElement2() {
        var el = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : document;
        return el.activeElement.shadowRoot ? getActiveElement2(el.activeElement.shadowRoot) : el.activeElement;
      }
      function scopeTab(node, event) {
        var tabbable = (0, _tabbable2.default)(node);
        if (!tabbable.length) {
          event.preventDefault();
          return;
        }
        var target = void 0;
        var shiftKey = event.shiftKey;
        var head = tabbable[0];
        var tail = tabbable[tabbable.length - 1];
        var activeElement = getActiveElement2();
        if (node === activeElement) {
          if (!shiftKey) return;
          target = tail;
        }
        if (tail === activeElement && !shiftKey) {
          target = head;
        }
        if (head === activeElement && shiftKey) {
          target = tail;
        }
        if (target) {
          event.preventDefault();
          target.focus();
          return;
        }
        var checkSafari = /(\bChrome\b|\bSafari\b)\//.exec(navigator.userAgent);
        var isSafariDesktop = checkSafari != null && checkSafari[1] != "Chrome" && /\biPod\b|\biPad\b/g.exec(navigator.userAgent) == null;
        if (!isSafariDesktop) return;
        var x = tabbable.indexOf(activeElement);
        if (x > -1) {
          x += shiftKey ? -1 : 1;
        }
        target = tabbable[x];
        if (typeof target === "undefined") {
          event.preventDefault();
          target = shiftKey ? tail : head;
          target.focus();
          return;
        }
        event.preventDefault();
        target.focus();
      }
      module2.exports = exports2["default"];
    }
  });

  // node_modules/warning/warning.js
  var require_warning = __commonJS({
    "node_modules/warning/warning.js"(exports2, module2) {
      "use strict";
      var __DEV__ = false;
      var warning2 = function() {
      };
      if (__DEV__) {
        printWarning = function printWarning2(format, args) {
          var len = arguments.length;
          args = new Array(len > 1 ? len - 1 : 0);
          for (var key = 1; key < len; key++) {
            args[key - 1] = arguments[key];
          }
          var argIndex = 0;
          var message = "Warning: " + format.replace(/%s/g, function() {
            return args[argIndex++];
          });
          if (typeof console !== "undefined") {
            console.error(message);
          }
          try {
            throw new Error(message);
          } catch (x) {
          }
        };
        warning2 = function(condition, format, args) {
          var len = arguments.length;
          args = new Array(len > 2 ? len - 2 : 0);
          for (var key = 2; key < len; key++) {
            args[key - 2] = arguments[key];
          }
          if (format === void 0) {
            throw new Error(
              "`warning(condition, format, ...args)` requires a warning message argument"
            );
          }
          if (!condition) {
            printWarning.apply(null, [format].concat(args));
          }
        };
      }
      var printWarning;
      module2.exports = warning2;
    }
  });

  // node_modules/exenv/index.js
  var require_exenv = __commonJS({
    "node_modules/exenv/index.js"(exports2, module2) {
      (function() {
        "use strict";
        var canUseDOM2 = !!(typeof window !== "undefined" && window.document && window.document.createElement);
        var ExecutionEnvironment = {
          canUseDOM: canUseDOM2,
          canUseWorkers: typeof Worker !== "undefined",
          canUseEventListeners: canUseDOM2 && !!(window.addEventListener || window.attachEvent),
          canUseViewport: canUseDOM2 && !!window.screen
        };
        if (typeof define === "function" && typeof define.amd === "object" && define.amd) {
          define(function() {
            return ExecutionEnvironment;
          });
        } else if (typeof module2 !== "undefined" && module2.exports) {
          module2.exports = ExecutionEnvironment;
        } else {
          window.ExecutionEnvironment = ExecutionEnvironment;
        }
      })();
    }
  });

  // node_modules/react-modal/lib/helpers/safeHTMLElement.js
  var require_safeHTMLElement = __commonJS({
    "node_modules/react-modal/lib/helpers/safeHTMLElement.js"(exports2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      exports2.canUseDOM = exports2.SafeNodeList = exports2.SafeHTMLCollection = void 0;
      var _exenv = require_exenv();
      var _exenv2 = _interopRequireDefault(_exenv);
      function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }
      var EE = _exenv2.default;
      var SafeHTMLElement = EE.canUseDOM ? window.HTMLElement : {};
      var SafeHTMLCollection = exports2.SafeHTMLCollection = EE.canUseDOM ? window.HTMLCollection : {};
      var SafeNodeList = exports2.SafeNodeList = EE.canUseDOM ? window.NodeList : {};
      var canUseDOM2 = exports2.canUseDOM = EE.canUseDOM;
      exports2.default = SafeHTMLElement;
    }
  });

  // node_modules/react-modal/lib/helpers/ariaAppHider.js
  var require_ariaAppHider = __commonJS({
    "node_modules/react-modal/lib/helpers/ariaAppHider.js"(exports2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      exports2.resetState = resetState;
      exports2.log = log;
      exports2.assertNodeList = assertNodeList;
      exports2.setElement = setElement;
      exports2.validateElement = validateElement;
      exports2.hide = hide2;
      exports2.show = show2;
      exports2.documentNotReadyOrSSRTesting = documentNotReadyOrSSRTesting;
      var _warning = require_warning();
      var _warning2 = _interopRequireDefault(_warning);
      var _safeHTMLElement = require_safeHTMLElement();
      function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }
      var globalElement = null;
      function resetState() {
        if (globalElement) {
          if (globalElement.removeAttribute) {
            globalElement.removeAttribute("aria-hidden");
          } else if (globalElement.length != null) {
            globalElement.forEach(function(element) {
              return element.removeAttribute("aria-hidden");
            });
          } else {
            document.querySelectorAll(globalElement).forEach(function(element) {
              return element.removeAttribute("aria-hidden");
            });
          }
        }
        globalElement = null;
      }
      function log() {
        if (false) {
          var check = globalElement || {};
          console.log("ariaAppHider ----------");
          console.log(check.nodeName, check.className, check.id);
          console.log("end ariaAppHider ----------");
        }
      }
      function assertNodeList(nodeList, selector) {
        if (!nodeList || !nodeList.length) {
          throw new Error("react-modal: No elements were found for selector " + selector + ".");
        }
      }
      function setElement(element) {
        var useElement = element;
        if (typeof useElement === "string" && _safeHTMLElement.canUseDOM) {
          var el = document.querySelectorAll(useElement);
          assertNodeList(el, useElement);
          useElement = el;
        }
        globalElement = useElement || globalElement;
        return globalElement;
      }
      function validateElement(appElement) {
        var el = appElement || globalElement;
        if (el) {
          return Array.isArray(el) || el instanceof HTMLCollection || el instanceof NodeList ? el : [el];
        } else {
          (0, _warning2.default)(false, ["react-modal: App element is not defined.", "Please use `Modal.setAppElement(el)` or set `appElement={el}`.", "This is needed so screen readers don't see main content", "when modal is opened. It is not recommended, but you can opt-out", "by setting `ariaHideApp={false}`."].join(" "));
          return [];
        }
      }
      function hide2(appElement) {
        var _iteratorNormalCompletion = true;
        var _didIteratorError = false;
        var _iteratorError = void 0;
        try {
          for (var _iterator = validateElement(appElement)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
            var el = _step.value;
            el.setAttribute("aria-hidden", "true");
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion && _iterator.return) {
              _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
      }
      function show2(appElement) {
        var _iteratorNormalCompletion2 = true;
        var _didIteratorError2 = false;
        var _iteratorError2 = void 0;
        try {
          for (var _iterator2 = validateElement(appElement)[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
            var el = _step2.value;
            el.removeAttribute("aria-hidden");
          }
        } catch (err) {
          _didIteratorError2 = true;
          _iteratorError2 = err;
        } finally {
          try {
            if (!_iteratorNormalCompletion2 && _iterator2.return) {
              _iterator2.return();
            }
          } finally {
            if (_didIteratorError2) {
              throw _iteratorError2;
            }
          }
        }
      }
      function documentNotReadyOrSSRTesting() {
        globalElement = null;
      }
    }
  });

  // node_modules/react-modal/lib/helpers/classList.js
  var require_classList = __commonJS({
    "node_modules/react-modal/lib/helpers/classList.js"(exports2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      exports2.resetState = resetState;
      exports2.log = log;
      var htmlClassList = {};
      var docBodyClassList = {};
      function removeClass(at, cls) {
        at.classList.remove(cls);
      }
      function resetState() {
        var htmlElement = document.getElementsByTagName("html")[0];
        for (var cls in htmlClassList) {
          removeClass(htmlElement, htmlClassList[cls]);
        }
        var body = document.body;
        for (var _cls in docBodyClassList) {
          removeClass(body, docBodyClassList[_cls]);
        }
        htmlClassList = {};
        docBodyClassList = {};
      }
      function log() {
        if (false) {
          var classes = document.getElementsByTagName("html")[0].className;
          var buffer = "Show tracked classes:\n\n";
          buffer += "<html /> (" + classes + "):\n  ";
          for (var x in htmlClassList) {
            buffer += "  " + x + " " + htmlClassList[x] + "\n  ";
          }
          classes = document.body.className;
          buffer += "\n\ndoc.body (" + classes + "):\n  ";
          for (var _x in docBodyClassList) {
            buffer += "  " + _x + " " + docBodyClassList[_x] + "\n  ";
          }
          buffer += "\n";
          console.log(buffer);
        }
      }
      var incrementReference = function incrementReference2(poll, className) {
        if (!poll[className]) {
          poll[className] = 0;
        }
        poll[className] += 1;
        return className;
      };
      var decrementReference = function decrementReference2(poll, className) {
        if (poll[className]) {
          poll[className] -= 1;
        }
        return className;
      };
      var trackClass = function trackClass2(classListRef, poll, classes) {
        classes.forEach(function(className) {
          incrementReference(poll, className);
          classListRef.add(className);
        });
      };
      var untrackClass = function untrackClass2(classListRef, poll, classes) {
        classes.forEach(function(className) {
          decrementReference(poll, className);
          poll[className] === 0 && classListRef.remove(className);
        });
      };
      var add = exports2.add = function add2(element, classString) {
        return trackClass(element.classList, element.nodeName.toLowerCase() == "html" ? htmlClassList : docBodyClassList, classString.split(" "));
      };
      var remove = exports2.remove = function remove2(element, classString) {
        return untrackClass(element.classList, element.nodeName.toLowerCase() == "html" ? htmlClassList : docBodyClassList, classString.split(" "));
      };
    }
  });

  // node_modules/react-modal/lib/helpers/portalOpenInstances.js
  var require_portalOpenInstances = __commonJS({
    "node_modules/react-modal/lib/helpers/portalOpenInstances.js"(exports2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      exports2.log = log;
      exports2.resetState = resetState;
      function _classCallCheck(instance2, Constructor) {
        if (!(instance2 instanceof Constructor)) {
          throw new TypeError("Cannot call a class as a function");
        }
      }
      var PortalOpenInstances = function PortalOpenInstances2() {
        var _this = this;
        _classCallCheck(this, PortalOpenInstances2);
        this.register = function(openInstance) {
          if (_this.openInstances.indexOf(openInstance) !== -1) {
            if (false) {
              console.warn("React-Modal: Cannot register modal instance that's already open");
            }
            return;
          }
          _this.openInstances.push(openInstance);
          _this.emit("register");
        };
        this.deregister = function(openInstance) {
          var index = _this.openInstances.indexOf(openInstance);
          if (index === -1) {
            if (false) {
              console.warn("React-Modal: Unable to deregister " + openInstance + " as it was never registered");
            }
            return;
          }
          _this.openInstances.splice(index, 1);
          _this.emit("deregister");
        };
        this.subscribe = function(callback) {
          _this.subscribers.push(callback);
        };
        this.emit = function(eventType) {
          _this.subscribers.forEach(function(subscriber) {
            return subscriber(
              eventType,
              // shallow copy to avoid accidental mutation
              _this.openInstances.slice()
            );
          });
        };
        this.openInstances = [];
        this.subscribers = [];
      };
      var portalOpenInstances = new PortalOpenInstances();
      function log() {
        console.log("portalOpenInstances ----------");
        console.log(portalOpenInstances.openInstances.length);
        portalOpenInstances.openInstances.forEach(function(p) {
          return console.log(p);
        });
        console.log("end portalOpenInstances ----------");
      }
      function resetState() {
        portalOpenInstances = new PortalOpenInstances();
      }
      exports2.default = portalOpenInstances;
    }
  });

  // node_modules/react-modal/lib/helpers/bodyTrap.js
  var require_bodyTrap = __commonJS({
    "node_modules/react-modal/lib/helpers/bodyTrap.js"(exports2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      exports2.resetState = resetState;
      exports2.log = log;
      var _portalOpenInstances = require_portalOpenInstances();
      var _portalOpenInstances2 = _interopRequireDefault(_portalOpenInstances);
      function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }
      var before = void 0;
      var after = void 0;
      var instances = [];
      function resetState() {
        var _arr = [before, after];
        for (var _i = 0; _i < _arr.length; _i++) {
          var item = _arr[_i];
          if (!item) continue;
          item.parentNode && item.parentNode.removeChild(item);
        }
        before = after = null;
        instances = [];
      }
      function log() {
        console.log("bodyTrap ----------");
        console.log(instances.length);
        var _arr2 = [before, after];
        for (var _i2 = 0; _i2 < _arr2.length; _i2++) {
          var item = _arr2[_i2];
          var check = item || {};
          console.log(check.nodeName, check.className, check.id);
        }
        console.log("edn bodyTrap ----------");
      }
      function focusContent() {
        if (instances.length === 0) {
          if (false) {
            console.warn("React-Modal: Open instances > 0 expected");
          }
          return;
        }
        instances[instances.length - 1].focusContent();
      }
      function bodyTrap(eventType, openInstances) {
        if (!before && !after) {
          before = document.createElement("div");
          before.setAttribute("data-react-modal-body-trap", "");
          before.style.position = "absolute";
          before.style.opacity = "0";
          before.setAttribute("tabindex", "0");
          before.addEventListener("focus", focusContent);
          after = before.cloneNode();
          after.addEventListener("focus", focusContent);
        }
        instances = openInstances;
        if (instances.length > 0) {
          if (document.body.firstChild !== before) {
            document.body.insertBefore(before, document.body.firstChild);
          }
          if (document.body.lastChild !== after) {
            document.body.appendChild(after);
          }
        } else {
          if (before.parentElement) {
            before.parentElement.removeChild(before);
          }
          if (after.parentElement) {
            after.parentElement.removeChild(after);
          }
        }
      }
      _portalOpenInstances2.default.subscribe(bodyTrap);
    }
  });

  // node_modules/react-modal/lib/components/ModalPortal.js
  var require_ModalPortal = __commonJS({
    "node_modules/react-modal/lib/components/ModalPortal.js"(exports2, module2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      var _extends3 = Object.assign || function(target) {
        for (var i = 1; i < arguments.length; i++) {
          var source = arguments[i];
          for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
              target[key] = source[key];
            }
          }
        }
        return target;
      };
      var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
        return typeof obj;
      } : function(obj) {
        return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
      };
      var _createClass = /* @__PURE__ */ (function() {
        function defineProperties(target, props) {
          for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
          }
        }
        return function(Constructor, protoProps, staticProps) {
          if (protoProps) defineProperties(Constructor.prototype, protoProps);
          if (staticProps) defineProperties(Constructor, staticProps);
          return Constructor;
        };
      })();
      var _react = require_react();
      var _propTypes = require_prop_types();
      var _propTypes2 = _interopRequireDefault(_propTypes);
      var _focusManager = require_focusManager();
      var focusManager = _interopRequireWildcard(_focusManager);
      var _scopeTab = require_scopeTab();
      var _scopeTab2 = _interopRequireDefault(_scopeTab);
      var _ariaAppHider = require_ariaAppHider();
      var ariaAppHider = _interopRequireWildcard(_ariaAppHider);
      var _classList = require_classList();
      var classList = _interopRequireWildcard(_classList);
      var _safeHTMLElement = require_safeHTMLElement();
      var _safeHTMLElement2 = _interopRequireDefault(_safeHTMLElement);
      var _portalOpenInstances = require_portalOpenInstances();
      var _portalOpenInstances2 = _interopRequireDefault(_portalOpenInstances);
      require_bodyTrap();
      function _interopRequireWildcard(obj) {
        if (obj && obj.__esModule) {
          return obj;
        } else {
          var newObj = {};
          if (obj != null) {
            for (var key in obj) {
              if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
            }
          }
          newObj.default = obj;
          return newObj;
        }
      }
      function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }
      function _classCallCheck(instance2, Constructor) {
        if (!(instance2 instanceof Constructor)) {
          throw new TypeError("Cannot call a class as a function");
        }
      }
      function _possibleConstructorReturn(self2, call) {
        if (!self2) {
          throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        }
        return call && (typeof call === "object" || typeof call === "function") ? call : self2;
      }
      function _inherits(subClass, superClass) {
        if (typeof superClass !== "function" && superClass !== null) {
          throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
        }
        subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
        if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
      }
      var CLASS_NAMES = {
        overlay: "ReactModal__Overlay",
        content: "ReactModal__Content"
      };
      var isTabKey = function isTabKey2(event) {
        return event.code === "Tab" || event.keyCode === 9;
      };
      var isEscKey = function isEscKey2(event) {
        return event.code === "Escape" || event.keyCode === 27;
      };
      var ariaHiddenInstances = 0;
      var ModalPortal = (function(_Component) {
        _inherits(ModalPortal2, _Component);
        function ModalPortal2(props) {
          _classCallCheck(this, ModalPortal2);
          var _this = _possibleConstructorReturn(this, (ModalPortal2.__proto__ || Object.getPrototypeOf(ModalPortal2)).call(this, props));
          _this.setOverlayRef = function(overlay) {
            _this.overlay = overlay;
            _this.props.overlayRef && _this.props.overlayRef(overlay);
          };
          _this.setContentRef = function(content) {
            _this.content = content;
            _this.props.contentRef && _this.props.contentRef(content);
          };
          _this.afterClose = function() {
            var _this$props = _this.props, appElement = _this$props.appElement, ariaHideApp = _this$props.ariaHideApp, htmlOpenClassName = _this$props.htmlOpenClassName, bodyOpenClassName = _this$props.bodyOpenClassName, parentSelector = _this$props.parentSelector;
            var parentDocument = parentSelector && parentSelector().ownerDocument || document;
            bodyOpenClassName && classList.remove(parentDocument.body, bodyOpenClassName);
            htmlOpenClassName && classList.remove(parentDocument.getElementsByTagName("html")[0], htmlOpenClassName);
            if (ariaHideApp && ariaHiddenInstances > 0) {
              ariaHiddenInstances -= 1;
              if (ariaHiddenInstances === 0) {
                ariaAppHider.show(appElement);
              }
            }
            if (_this.props.shouldFocusAfterRender) {
              if (_this.props.shouldReturnFocusAfterClose) {
                focusManager.returnFocus(_this.props.preventScroll);
                focusManager.teardownScopedFocus();
              } else {
                focusManager.popWithoutFocus();
              }
            }
            if (_this.props.onAfterClose) {
              _this.props.onAfterClose();
            }
            _portalOpenInstances2.default.deregister(_this);
          };
          _this.open = function() {
            _this.beforeOpen();
            if (_this.state.afterOpen && _this.state.beforeClose) {
              clearTimeout(_this.closeTimer);
              _this.setState({ beforeClose: false });
            } else {
              if (_this.props.shouldFocusAfterRender) {
                focusManager.setupScopedFocus(_this.node);
                focusManager.markForFocusLater();
              }
              _this.setState({ isOpen: true }, function() {
                _this.openAnimationFrame = requestAnimationFrame(function() {
                  _this.setState({ afterOpen: true });
                  if (_this.props.isOpen && _this.props.onAfterOpen) {
                    _this.props.onAfterOpen({
                      overlayEl: _this.overlay,
                      contentEl: _this.content
                    });
                  }
                });
              });
            }
          };
          _this.close = function() {
            if (_this.props.closeTimeoutMS > 0) {
              _this.closeWithTimeout();
            } else {
              _this.closeWithoutTimeout();
            }
          };
          _this.focusContent = function() {
            return _this.content && !_this.contentHasFocus() && _this.content.focus({ preventScroll: true });
          };
          _this.closeWithTimeout = function() {
            var closesAt = Date.now() + _this.props.closeTimeoutMS;
            _this.setState({ beforeClose: true, closesAt }, function() {
              _this.closeTimer = setTimeout(_this.closeWithoutTimeout, _this.state.closesAt - Date.now());
            });
          };
          _this.closeWithoutTimeout = function() {
            _this.setState({
              beforeClose: false,
              isOpen: false,
              afterOpen: false,
              closesAt: null
            }, _this.afterClose);
          };
          _this.handleKeyDown = function(event) {
            if (isTabKey(event)) {
              (0, _scopeTab2.default)(_this.content, event);
            }
            if (_this.props.shouldCloseOnEsc && isEscKey(event)) {
              event.stopPropagation();
              _this.requestClose(event);
            }
          };
          _this.handleOverlayOnClick = function(event) {
            if (_this.shouldClose === null) {
              _this.shouldClose = true;
            }
            if (_this.shouldClose && _this.props.shouldCloseOnOverlayClick) {
              if (_this.ownerHandlesClose()) {
                _this.requestClose(event);
              } else {
                _this.focusContent();
              }
            }
            _this.shouldClose = null;
          };
          _this.handleContentOnMouseUp = function() {
            _this.shouldClose = false;
          };
          _this.handleOverlayOnMouseDown = function(event) {
            if (!_this.props.shouldCloseOnOverlayClick && event.target == _this.overlay) {
              event.preventDefault();
            }
          };
          _this.handleContentOnClick = function() {
            _this.shouldClose = false;
          };
          _this.handleContentOnMouseDown = function() {
            _this.shouldClose = false;
          };
          _this.requestClose = function(event) {
            return _this.ownerHandlesClose() && _this.props.onRequestClose(event);
          };
          _this.ownerHandlesClose = function() {
            return _this.props.onRequestClose;
          };
          _this.shouldBeClosed = function() {
            return !_this.state.isOpen && !_this.state.beforeClose;
          };
          _this.contentHasFocus = function() {
            return document.activeElement === _this.content || _this.content.contains(document.activeElement);
          };
          _this.buildClassName = function(which, additional) {
            var classNames = (typeof additional === "undefined" ? "undefined" : _typeof(additional)) === "object" ? additional : {
              base: CLASS_NAMES[which],
              afterOpen: CLASS_NAMES[which] + "--after-open",
              beforeClose: CLASS_NAMES[which] + "--before-close"
            };
            var className = classNames.base;
            if (_this.state.afterOpen) {
              className = className + " " + classNames.afterOpen;
            }
            if (_this.state.beforeClose) {
              className = className + " " + classNames.beforeClose;
            }
            return typeof additional === "string" && additional ? className + " " + additional : className;
          };
          _this.attributesFromObject = function(prefix2, items) {
            return Object.keys(items).reduce(function(acc, name) {
              acc[prefix2 + "-" + name] = items[name];
              return acc;
            }, {});
          };
          _this.state = {
            afterOpen: false,
            beforeClose: false
          };
          _this.shouldClose = null;
          _this.moveFromContentToOverlay = null;
          return _this;
        }
        _createClass(ModalPortal2, [{
          key: "componentDidMount",
          value: function componentDidMount() {
            if (this.props.isOpen) {
              this.open();
            }
          }
        }, {
          key: "componentDidUpdate",
          value: function componentDidUpdate(prevProps, prevState) {
            if (false) {
              if (prevProps.bodyOpenClassName !== this.props.bodyOpenClassName) {
                console.warn('React-Modal: "bodyOpenClassName" prop has been modified. This may cause unexpected behavior when multiple modals are open.');
              }
              if (prevProps.htmlOpenClassName !== this.props.htmlOpenClassName) {
                console.warn('React-Modal: "htmlOpenClassName" prop has been modified. This may cause unexpected behavior when multiple modals are open.');
              }
            }
            if (this.props.isOpen && !prevProps.isOpen) {
              this.open();
            } else if (!this.props.isOpen && prevProps.isOpen) {
              this.close();
            }
            if (this.props.shouldFocusAfterRender && this.state.isOpen && !prevState.isOpen) {
              this.focusContent();
            }
          }
        }, {
          key: "componentWillUnmount",
          value: function componentWillUnmount() {
            if (this.state.isOpen) {
              this.afterClose();
            }
            clearTimeout(this.closeTimer);
            cancelAnimationFrame(this.openAnimationFrame);
          }
        }, {
          key: "beforeOpen",
          value: function beforeOpen() {
            var _props = this.props, appElement = _props.appElement, ariaHideApp = _props.ariaHideApp, htmlOpenClassName = _props.htmlOpenClassName, bodyOpenClassName = _props.bodyOpenClassName, parentSelector = _props.parentSelector;
            var parentDocument = parentSelector && parentSelector().ownerDocument || document;
            bodyOpenClassName && classList.add(parentDocument.body, bodyOpenClassName);
            htmlOpenClassName && classList.add(parentDocument.getElementsByTagName("html")[0], htmlOpenClassName);
            if (ariaHideApp) {
              ariaHiddenInstances += 1;
              ariaAppHider.hide(appElement);
            }
            _portalOpenInstances2.default.register(this);
          }
          // Don't steal focus from inner elements
        }, {
          key: "render",
          value: function render() {
            var _props2 = this.props, id = _props2.id, className = _props2.className, overlayClassName = _props2.overlayClassName, defaultStyles = _props2.defaultStyles, children = _props2.children;
            var contentStyles = className ? {} : defaultStyles.content;
            var overlayStyles = overlayClassName ? {} : defaultStyles.overlay;
            if (this.shouldBeClosed()) {
              return null;
            }
            var overlayProps = {
              ref: this.setOverlayRef,
              className: this.buildClassName("overlay", overlayClassName),
              style: _extends3({}, overlayStyles, this.props.style.overlay),
              onClick: this.handleOverlayOnClick,
              onMouseDown: this.handleOverlayOnMouseDown
            };
            var contentProps = _extends3({
              id,
              ref: this.setContentRef,
              style: _extends3({}, contentStyles, this.props.style.content),
              className: this.buildClassName("content", className),
              tabIndex: "-1",
              onKeyDown: this.handleKeyDown,
              onMouseDown: this.handleContentOnMouseDown,
              onMouseUp: this.handleContentOnMouseUp,
              onClick: this.handleContentOnClick,
              role: this.props.role,
              "aria-label": this.props.contentLabel
            }, this.attributesFromObject("aria", _extends3({ modal: true }, this.props.aria)), this.attributesFromObject("data", this.props.data || {}), {
              "data-testid": this.props.testId
            });
            var contentElement = this.props.contentElement(contentProps, children);
            return this.props.overlayElement(overlayProps, contentElement);
          }
        }]);
        return ModalPortal2;
      })(_react.Component);
      ModalPortal.defaultProps = {
        style: {
          overlay: {},
          content: {}
        },
        defaultStyles: {}
      };
      ModalPortal.propTypes = {
        isOpen: _propTypes2.default.bool.isRequired,
        defaultStyles: _propTypes2.default.shape({
          content: _propTypes2.default.object,
          overlay: _propTypes2.default.object
        }),
        style: _propTypes2.default.shape({
          content: _propTypes2.default.object,
          overlay: _propTypes2.default.object
        }),
        className: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.object]),
        overlayClassName: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.object]),
        parentSelector: _propTypes2.default.func,
        bodyOpenClassName: _propTypes2.default.string,
        htmlOpenClassName: _propTypes2.default.string,
        ariaHideApp: _propTypes2.default.bool,
        appElement: _propTypes2.default.oneOfType([_propTypes2.default.instanceOf(_safeHTMLElement2.default), _propTypes2.default.instanceOf(_safeHTMLElement.SafeHTMLCollection), _propTypes2.default.instanceOf(_safeHTMLElement.SafeNodeList), _propTypes2.default.arrayOf(_propTypes2.default.instanceOf(_safeHTMLElement2.default))]),
        onAfterOpen: _propTypes2.default.func,
        onAfterClose: _propTypes2.default.func,
        onRequestClose: _propTypes2.default.func,
        closeTimeoutMS: _propTypes2.default.number,
        shouldFocusAfterRender: _propTypes2.default.bool,
        shouldCloseOnOverlayClick: _propTypes2.default.bool,
        shouldReturnFocusAfterClose: _propTypes2.default.bool,
        preventScroll: _propTypes2.default.bool,
        role: _propTypes2.default.string,
        contentLabel: _propTypes2.default.string,
        aria: _propTypes2.default.object,
        data: _propTypes2.default.object,
        children: _propTypes2.default.node,
        shouldCloseOnEsc: _propTypes2.default.bool,
        overlayRef: _propTypes2.default.func,
        contentRef: _propTypes2.default.func,
        id: _propTypes2.default.string,
        overlayElement: _propTypes2.default.func,
        contentElement: _propTypes2.default.func,
        testId: _propTypes2.default.string
      };
      exports2.default = ModalPortal;
      module2.exports = exports2["default"];
    }
  });

  // node_modules/react-lifecycles-compat/react-lifecycles-compat.cjs.js
  var require_react_lifecycles_compat_cjs = __commonJS({
    "node_modules/react-lifecycles-compat/react-lifecycles-compat.cjs.js"(exports2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", { value: true });
      function componentWillMount() {
        var state = this.constructor.getDerivedStateFromProps(this.props, this.state);
        if (state !== null && state !== void 0) {
          this.setState(state);
        }
      }
      function componentWillReceiveProps(nextProps) {
        function updater(prevState) {
          var state = this.constructor.getDerivedStateFromProps(nextProps, prevState);
          return state !== null && state !== void 0 ? state : null;
        }
        this.setState(updater.bind(this));
      }
      function componentWillUpdate(nextProps, nextState) {
        try {
          var prevProps = this.props;
          var prevState = this.state;
          this.props = nextProps;
          this.state = nextState;
          this.__reactInternalSnapshotFlag = true;
          this.__reactInternalSnapshot = this.getSnapshotBeforeUpdate(
            prevProps,
            prevState
          );
        } finally {
          this.props = prevProps;
          this.state = prevState;
        }
      }
      componentWillMount.__suppressDeprecationWarning = true;
      componentWillReceiveProps.__suppressDeprecationWarning = true;
      componentWillUpdate.__suppressDeprecationWarning = true;
      function polyfill(Component4) {
        var prototype = Component4.prototype;
        if (!prototype || !prototype.isReactComponent) {
          throw new Error("Can only polyfill class components");
        }
        if (typeof Component4.getDerivedStateFromProps !== "function" && typeof prototype.getSnapshotBeforeUpdate !== "function") {
          return Component4;
        }
        var foundWillMountName = null;
        var foundWillReceivePropsName = null;
        var foundWillUpdateName = null;
        if (typeof prototype.componentWillMount === "function") {
          foundWillMountName = "componentWillMount";
        } else if (typeof prototype.UNSAFE_componentWillMount === "function") {
          foundWillMountName = "UNSAFE_componentWillMount";
        }
        if (typeof prototype.componentWillReceiveProps === "function") {
          foundWillReceivePropsName = "componentWillReceiveProps";
        } else if (typeof prototype.UNSAFE_componentWillReceiveProps === "function") {
          foundWillReceivePropsName = "UNSAFE_componentWillReceiveProps";
        }
        if (typeof prototype.componentWillUpdate === "function") {
          foundWillUpdateName = "componentWillUpdate";
        } else if (typeof prototype.UNSAFE_componentWillUpdate === "function") {
          foundWillUpdateName = "UNSAFE_componentWillUpdate";
        }
        if (foundWillMountName !== null || foundWillReceivePropsName !== null || foundWillUpdateName !== null) {
          var componentName2 = Component4.displayName || Component4.name;
          var newApiName = typeof Component4.getDerivedStateFromProps === "function" ? "getDerivedStateFromProps()" : "getSnapshotBeforeUpdate()";
          throw Error(
            "Unsafe legacy lifecycles will not be called for components using new component APIs.\n\n" + componentName2 + " uses " + newApiName + " but also contains the following legacy lifecycles:" + (foundWillMountName !== null ? "\n  " + foundWillMountName : "") + (foundWillReceivePropsName !== null ? "\n  " + foundWillReceivePropsName : "") + (foundWillUpdateName !== null ? "\n  " + foundWillUpdateName : "") + "\n\nThe above lifecycles should be removed. Learn more about this warning here:\nhttps://fb.me/react-async-component-lifecycle-hooks"
          );
        }
        if (typeof Component4.getDerivedStateFromProps === "function") {
          prototype.componentWillMount = componentWillMount;
          prototype.componentWillReceiveProps = componentWillReceiveProps;
        }
        if (typeof prototype.getSnapshotBeforeUpdate === "function") {
          if (typeof prototype.componentDidUpdate !== "function") {
            throw new Error(
              "Cannot polyfill getSnapshotBeforeUpdate() for components that do not define componentDidUpdate() on the prototype"
            );
          }
          prototype.componentWillUpdate = componentWillUpdate;
          var componentDidUpdate = prototype.componentDidUpdate;
          prototype.componentDidUpdate = function componentDidUpdatePolyfill(prevProps, prevState, maybeSnapshot) {
            var snapshot = this.__reactInternalSnapshotFlag ? this.__reactInternalSnapshot : maybeSnapshot;
            componentDidUpdate.call(this, prevProps, prevState, snapshot);
          };
        }
        return Component4;
      }
      exports2.polyfill = polyfill;
    }
  });

  // node_modules/react-modal/lib/components/Modal.js
  var require_Modal = __commonJS({
    "node_modules/react-modal/lib/components/Modal.js"(exports2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      exports2.bodyOpenClassName = exports2.portalClassName = void 0;
      var _extends3 = Object.assign || function(target) {
        for (var i = 1; i < arguments.length; i++) {
          var source = arguments[i];
          for (var key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
              target[key] = source[key];
            }
          }
        }
        return target;
      };
      var _createClass = /* @__PURE__ */ (function() {
        function defineProperties(target, props) {
          for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
          }
        }
        return function(Constructor, protoProps, staticProps) {
          if (protoProps) defineProperties(Constructor.prototype, protoProps);
          if (staticProps) defineProperties(Constructor, staticProps);
          return Constructor;
        };
      })();
      var _react = require_react();
      var _react2 = _interopRequireDefault(_react);
      var _reactDom = require_react_dom();
      var _reactDom2 = _interopRequireDefault(_reactDom);
      var _propTypes = require_prop_types();
      var _propTypes2 = _interopRequireDefault(_propTypes);
      var _ModalPortal = require_ModalPortal();
      var _ModalPortal2 = _interopRequireDefault(_ModalPortal);
      var _ariaAppHider = require_ariaAppHider();
      var ariaAppHider = _interopRequireWildcard(_ariaAppHider);
      var _safeHTMLElement = require_safeHTMLElement();
      var _safeHTMLElement2 = _interopRequireDefault(_safeHTMLElement);
      var _reactLifecyclesCompat = require_react_lifecycles_compat_cjs();
      function _interopRequireWildcard(obj) {
        if (obj && obj.__esModule) {
          return obj;
        } else {
          var newObj = {};
          if (obj != null) {
            for (var key in obj) {
              if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
            }
          }
          newObj.default = obj;
          return newObj;
        }
      }
      function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }
      function _classCallCheck(instance2, Constructor) {
        if (!(instance2 instanceof Constructor)) {
          throw new TypeError("Cannot call a class as a function");
        }
      }
      function _possibleConstructorReturn(self2, call) {
        if (!self2) {
          throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        }
        return call && (typeof call === "object" || typeof call === "function") ? call : self2;
      }
      function _inherits(subClass, superClass) {
        if (typeof superClass !== "function" && superClass !== null) {
          throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
        }
        subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
        if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
      }
      var portalClassName = exports2.portalClassName = "ReactModalPortal";
      var bodyOpenClassName = exports2.bodyOpenClassName = "ReactModal__Body--open";
      var isReact16 = _safeHTMLElement.canUseDOM && _reactDom2.default.createPortal !== void 0;
      var createHTMLElement = function createHTMLElement2(name) {
        return document.createElement(name);
      };
      var getCreatePortal = function getCreatePortal2() {
        return isReact16 ? _reactDom2.default.createPortal : _reactDom2.default.unstable_renderSubtreeIntoContainer;
      };
      function getParentElement(parentSelector) {
        return parentSelector();
      }
      var Modal = (function(_Component) {
        _inherits(Modal2, _Component);
        function Modal2() {
          var _ref;
          var _temp, _this, _ret;
          _classCallCheck(this, Modal2);
          for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Modal2.__proto__ || Object.getPrototypeOf(Modal2)).call.apply(_ref, [this].concat(args))), _this), _this.removePortal = function() {
            !isReact16 && _reactDom2.default.unmountComponentAtNode(_this.node);
            var parent = getParentElement(_this.props.parentSelector);
            if (parent && parent.contains(_this.node)) {
              parent.removeChild(_this.node);
            } else {
              console.warn('React-Modal: "parentSelector" prop did not returned any DOM element. Make sure that the parent element is unmounted to avoid any memory leaks.');
            }
          }, _this.portalRef = function(ref) {
            _this.portal = ref;
          }, _this.renderPortal = function(props) {
            var createPortal3 = getCreatePortal();
            var portal = createPortal3(_this, _react2.default.createElement(_ModalPortal2.default, _extends3({ defaultStyles: Modal2.defaultStyles }, props)), _this.node);
            _this.portalRef(portal);
          }, _temp), _possibleConstructorReturn(_this, _ret);
        }
        _createClass(Modal2, [{
          key: "componentDidMount",
          value: function componentDidMount() {
            if (!_safeHTMLElement.canUseDOM) return;
            if (!isReact16) {
              this.node = createHTMLElement("div");
            }
            this.node.className = this.props.portalClassName;
            var parent = getParentElement(this.props.parentSelector);
            parent.appendChild(this.node);
            !isReact16 && this.renderPortal(this.props);
          }
        }, {
          key: "getSnapshotBeforeUpdate",
          value: function getSnapshotBeforeUpdate(prevProps) {
            var prevParent = getParentElement(prevProps.parentSelector);
            var nextParent = getParentElement(this.props.parentSelector);
            return { prevParent, nextParent };
          }
        }, {
          key: "componentDidUpdate",
          value: function componentDidUpdate(prevProps, _, snapshot) {
            if (!_safeHTMLElement.canUseDOM) return;
            var _props = this.props, isOpen = _props.isOpen, portalClassName2 = _props.portalClassName;
            if (prevProps.portalClassName !== portalClassName2) {
              this.node.className = portalClassName2;
            }
            var prevParent = snapshot.prevParent, nextParent = snapshot.nextParent;
            if (nextParent !== prevParent) {
              prevParent.removeChild(this.node);
              nextParent.appendChild(this.node);
            }
            if (!prevProps.isOpen && !isOpen) return;
            !isReact16 && this.renderPortal(this.props);
          }
        }, {
          key: "componentWillUnmount",
          value: function componentWillUnmount() {
            if (!_safeHTMLElement.canUseDOM || !this.node || !this.portal) return;
            var state = this.portal.state;
            var now = Date.now();
            var closesAt = state.isOpen && this.props.closeTimeoutMS && (state.closesAt || now + this.props.closeTimeoutMS);
            if (closesAt) {
              if (!state.beforeClose) {
                this.portal.closeWithTimeout();
              }
              setTimeout(this.removePortal, closesAt - now);
            } else {
              this.removePortal();
            }
          }
        }, {
          key: "render",
          value: function render() {
            if (!_safeHTMLElement.canUseDOM || !isReact16) {
              return null;
            }
            if (!this.node && isReact16) {
              this.node = createHTMLElement("div");
            }
            var createPortal3 = getCreatePortal();
            return createPortal3(_react2.default.createElement(_ModalPortal2.default, _extends3({
              ref: this.portalRef,
              defaultStyles: Modal2.defaultStyles
            }, this.props)), this.node);
          }
        }], [{
          key: "setAppElement",
          value: function setAppElement(element) {
            ariaAppHider.setElement(element);
          }
          /* eslint-disable react/no-unused-prop-types */
          /* eslint-enable react/no-unused-prop-types */
        }]);
        return Modal2;
      })(_react.Component);
      Modal.propTypes = {
        isOpen: _propTypes2.default.bool.isRequired,
        style: _propTypes2.default.shape({
          content: _propTypes2.default.object,
          overlay: _propTypes2.default.object
        }),
        portalClassName: _propTypes2.default.string,
        bodyOpenClassName: _propTypes2.default.string,
        htmlOpenClassName: _propTypes2.default.string,
        className: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.shape({
          base: _propTypes2.default.string.isRequired,
          afterOpen: _propTypes2.default.string.isRequired,
          beforeClose: _propTypes2.default.string.isRequired
        })]),
        overlayClassName: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.shape({
          base: _propTypes2.default.string.isRequired,
          afterOpen: _propTypes2.default.string.isRequired,
          beforeClose: _propTypes2.default.string.isRequired
        })]),
        appElement: _propTypes2.default.oneOfType([_propTypes2.default.instanceOf(_safeHTMLElement2.default), _propTypes2.default.instanceOf(_safeHTMLElement.SafeHTMLCollection), _propTypes2.default.instanceOf(_safeHTMLElement.SafeNodeList), _propTypes2.default.arrayOf(_propTypes2.default.instanceOf(_safeHTMLElement2.default))]),
        onAfterOpen: _propTypes2.default.func,
        onRequestClose: _propTypes2.default.func,
        closeTimeoutMS: _propTypes2.default.number,
        ariaHideApp: _propTypes2.default.bool,
        shouldFocusAfterRender: _propTypes2.default.bool,
        shouldCloseOnOverlayClick: _propTypes2.default.bool,
        shouldReturnFocusAfterClose: _propTypes2.default.bool,
        preventScroll: _propTypes2.default.bool,
        parentSelector: _propTypes2.default.func,
        aria: _propTypes2.default.object,
        data: _propTypes2.default.object,
        role: _propTypes2.default.string,
        contentLabel: _propTypes2.default.string,
        shouldCloseOnEsc: _propTypes2.default.bool,
        overlayRef: _propTypes2.default.func,
        contentRef: _propTypes2.default.func,
        id: _propTypes2.default.string,
        overlayElement: _propTypes2.default.func,
        contentElement: _propTypes2.default.func
      };
      Modal.defaultProps = {
        isOpen: false,
        portalClassName,
        bodyOpenClassName,
        role: "dialog",
        ariaHideApp: true,
        closeTimeoutMS: 0,
        shouldFocusAfterRender: true,
        shouldCloseOnEsc: true,
        shouldCloseOnOverlayClick: true,
        shouldReturnFocusAfterClose: true,
        preventScroll: false,
        parentSelector: function parentSelector() {
          return document.body;
        },
        overlayElement: function overlayElement(props, contentEl) {
          return _react2.default.createElement(
            "div",
            props,
            contentEl
          );
        },
        contentElement: function contentElement(props, children) {
          return _react2.default.createElement(
            "div",
            props,
            children
          );
        }
      };
      Modal.defaultStyles = {
        overlay: {
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: "rgba(255, 255, 255, 0.75)"
        },
        content: {
          position: "absolute",
          top: "40px",
          left: "40px",
          right: "40px",
          bottom: "40px",
          border: "1px solid #ccc",
          background: "#fff",
          overflow: "auto",
          WebkitOverflowScrolling: "touch",
          borderRadius: "4px",
          outline: "none",
          padding: "20px"
        }
      };
      (0, _reactLifecyclesCompat.polyfill)(Modal);
      if (false) {
        Modal.setCreateHTMLElement = function(fn) {
          return createHTMLElement = fn;
        };
      }
      exports2.default = Modal;
    }
  });

  // node_modules/react-modal/lib/index.js
  var require_lib = __commonJS({
    "node_modules/react-modal/lib/index.js"(exports2, module2) {
      "use strict";
      Object.defineProperty(exports2, "__esModule", {
        value: true
      });
      var _Modal = require_Modal();
      var _Modal2 = _interopRequireDefault(_Modal);
      function _interopRequireDefault(obj) {
        return obj && obj.__esModule ? obj : { default: obj };
      }
      exports2.default = _Modal2.default;
      module2.exports = exports2["default"];
    }
  });

  // node_modules/react-fast-compare/index.js
  var require_react_fast_compare = __commonJS({
    "node_modules/react-fast-compare/index.js"(exports2, module2) {
      "use strict";
      var isArray2 = Array.isArray;
      var keyList = Object.keys;
      var hasProp = Object.prototype.hasOwnProperty;
      var hasElementType = typeof Element !== "undefined";
      function equal(a, b) {
        if (a === b) return true;
        if (a && b && typeof a == "object" && typeof b == "object") {
          var arrA = isArray2(a), arrB = isArray2(b), i, length, key;
          if (arrA && arrB) {
            length = a.length;
            if (length != b.length) return false;
            for (i = length; i-- !== 0; )
              if (!equal(a[i], b[i])) return false;
            return true;
          }
          if (arrA != arrB) return false;
          var dateA = a instanceof Date, dateB = b instanceof Date;
          if (dateA != dateB) return false;
          if (dateA && dateB) return a.getTime() == b.getTime();
          var regexpA = a instanceof RegExp, regexpB = b instanceof RegExp;
          if (regexpA != regexpB) return false;
          if (regexpA && regexpB) return a.toString() == b.toString();
          var keys2 = keyList(a);
          length = keys2.length;
          if (length !== keyList(b).length)
            return false;
          for (i = length; i-- !== 0; )
            if (!hasProp.call(b, keys2[i])) return false;
          if (hasElementType && a instanceof Element && b instanceof Element)
            return a === b;
          for (i = length; i-- !== 0; ) {
            key = keys2[i];
            if (key === "_owner" && a.$$typeof) {
              continue;
            } else {
              if (!equal(a[key], b[key])) return false;
            }
          }
          return true;
        }
        return a !== a && b !== b;
      }
      module2.exports = function exportedEqual(a, b) {
        try {
          return equal(a, b);
        } catch (error) {
          if (error.message && error.message.match(/stack|recursion/i) || error.number === -2146828260) {
            console.warn("Warning: react-fast-compare does not handle circular references.", error.name, error.message);
            return false;
          }
          throw error;
        }
      };
    }
  });

  // node_modules/react-is/cjs/react-is.production.min.js
  var require_react_is_production_min = __commonJS({
    "node_modules/react-is/cjs/react-is.production.min.js"(exports2) {
      "use strict";
      var b = "function" === typeof Symbol && Symbol.for;
      var c = b ? Symbol.for("react.element") : 60103;
      var d = b ? Symbol.for("react.portal") : 60106;
      var e = b ? Symbol.for("react.fragment") : 60107;
      var f = b ? Symbol.for("react.strict_mode") : 60108;
      var g = b ? Symbol.for("react.profiler") : 60114;
      var h2 = b ? Symbol.for("react.provider") : 60109;
      var k = b ? Symbol.for("react.context") : 60110;
      var l = b ? Symbol.for("react.async_mode") : 60111;
      var m = b ? Symbol.for("react.concurrent_mode") : 60111;
      var n = b ? Symbol.for("react.forward_ref") : 60112;
      var p = b ? Symbol.for("react.suspense") : 60113;
      var q = b ? Symbol.for("react.suspense_list") : 60120;
      var r = b ? Symbol.for("react.memo") : 60115;
      var t = b ? Symbol.for("react.lazy") : 60116;
      var v = b ? Symbol.for("react.block") : 60121;
      var w = b ? Symbol.for("react.fundamental") : 60117;
      var x = b ? Symbol.for("react.responder") : 60118;
      var y = b ? Symbol.for("react.scope") : 60119;
      function z(a) {
        if ("object" === typeof a && null !== a) {
          var u = a.$$typeof;
          switch (u) {
            case c:
              switch (a = a.type, a) {
                case l:
                case m:
                case e:
                case g:
                case f:
                case p:
                  return a;
                default:
                  switch (a = a && a.$$typeof, a) {
                    case k:
                    case n:
                    case t:
                    case r:
                    case h2:
                      return a;
                    default:
                      return u;
                  }
              }
            case d:
              return u;
          }
        }
      }
      function A(a) {
        return z(a) === m;
      }
      exports2.AsyncMode = l;
      exports2.ConcurrentMode = m;
      exports2.ContextConsumer = k;
      exports2.ContextProvider = h2;
      exports2.Element = c;
      exports2.ForwardRef = n;
      exports2.Fragment = e;
      exports2.Lazy = t;
      exports2.Memo = r;
      exports2.Portal = d;
      exports2.Profiler = g;
      exports2.StrictMode = f;
      exports2.Suspense = p;
      exports2.isAsyncMode = function(a) {
        return A(a) || z(a) === l;
      };
      exports2.isConcurrentMode = A;
      exports2.isContextConsumer = function(a) {
        return z(a) === k;
      };
      exports2.isContextProvider = function(a) {
        return z(a) === h2;
      };
      exports2.isElement = function(a) {
        return "object" === typeof a && null !== a && a.$$typeof === c;
      };
      exports2.isForwardRef = function(a) {
        return z(a) === n;
      };
      exports2.isFragment = function(a) {
        return z(a) === e;
      };
      exports2.isLazy = function(a) {
        return z(a) === t;
      };
      exports2.isMemo = function(a) {
        return z(a) === r;
      };
      exports2.isPortal = function(a) {
        return z(a) === d;
      };
      exports2.isProfiler = function(a) {
        return z(a) === g;
      };
      exports2.isStrictMode = function(a) {
        return z(a) === f;
      };
      exports2.isSuspense = function(a) {
        return z(a) === p;
      };
      exports2.isValidElementType = function(a) {
        return "string" === typeof a || "function" === typeof a || a === e || a === m || a === g || a === f || a === p || a === q || "object" === typeof a && null !== a && (a.$$typeof === t || a.$$typeof === r || a.$$typeof === h2 || a.$$typeof === k || a.$$typeof === n || a.$$typeof === w || a.$$typeof === x || a.$$typeof === y || a.$$typeof === v);
      };
      exports2.typeOf = z;
    }
  });

  // node_modules/react-is/index.js
  var require_react_is = __commonJS({
    "node_modules/react-is/index.js"(exports2, module2) {
      "use strict";
      if (true) {
        module2.exports = require_react_is_production_min();
      } else {
        module2.exports = null;
      }
    }
  });

  // node_modules/hoist-non-react-statics/dist/hoist-non-react-statics.cjs.js
  var require_hoist_non_react_statics_cjs = __commonJS({
    "node_modules/hoist-non-react-statics/dist/hoist-non-react-statics.cjs.js"(exports2, module2) {
      "use strict";
      var reactIs = require_react_is();
      var REACT_STATICS = {
        childContextTypes: true,
        contextType: true,
        contextTypes: true,
        defaultProps: true,
        displayName: true,
        getDefaultProps: true,
        getDerivedStateFromError: true,
        getDerivedStateFromProps: true,
        mixins: true,
        propTypes: true,
        type: true
      };
      var KNOWN_STATICS = {
        name: true,
        length: true,
        prototype: true,
        caller: true,
        callee: true,
        arguments: true,
        arity: true
      };
      var FORWARD_REF_STATICS = {
        "$$typeof": true,
        render: true,
        defaultProps: true,
        displayName: true,
        propTypes: true
      };
      var MEMO_STATICS = {
        "$$typeof": true,
        compare: true,
        defaultProps: true,
        displayName: true,
        propTypes: true,
        type: true
      };
      var TYPE_STATICS = {};
      TYPE_STATICS[reactIs.ForwardRef] = FORWARD_REF_STATICS;
      TYPE_STATICS[reactIs.Memo] = MEMO_STATICS;
      function getStatics(component) {
        if (reactIs.isMemo(component)) {
          return MEMO_STATICS;
        }
        return TYPE_STATICS[component["$$typeof"]] || REACT_STATICS;
      }
      var defineProperty2 = Object.defineProperty;
      var getOwnPropertyNames = Object.getOwnPropertyNames;
      var getOwnPropertySymbols = Object.getOwnPropertySymbols;
      var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
      var getPrototypeOf = Object.getPrototypeOf;
      var objectPrototype = Object.prototype;
      function hoistNonReactStatics2(targetComponent, sourceComponent, blacklist) {
        if (typeof sourceComponent !== "string") {
          if (objectPrototype) {
            var inheritedComponent = getPrototypeOf(sourceComponent);
            if (inheritedComponent && inheritedComponent !== objectPrototype) {
              hoistNonReactStatics2(targetComponent, inheritedComponent, blacklist);
            }
          }
          var keys2 = getOwnPropertyNames(sourceComponent);
          if (getOwnPropertySymbols) {
            keys2 = keys2.concat(getOwnPropertySymbols(sourceComponent));
          }
          var targetStatics = getStatics(targetComponent);
          var sourceStatics = getStatics(sourceComponent);
          for (var i = 0; i < keys2.length; ++i) {
            var key = keys2[i];
            if (!KNOWN_STATICS[key] && !(blacklist && blacklist[key]) && !(sourceStatics && sourceStatics[key]) && !(targetStatics && targetStatics[key])) {
              var descriptor = getOwnPropertyDescriptor(sourceComponent, key);
              try {
                defineProperty2(targetComponent, key, descriptor);
              } catch (e) {
              }
            }
          }
        }
        return targetComponent;
      }
      module2.exports = hoistNonReactStatics2;
    }
  });

  // node_modules/isarray/index.js
  var require_isarray = __commonJS({
    "node_modules/isarray/index.js"(exports2, module2) {
      module2.exports = Array.isArray || function(arr) {
        return Object.prototype.toString.call(arr) == "[object Array]";
      };
    }
  });

  // node_modules/path-to-regexp/index.js
  var require_path_to_regexp = __commonJS({
    "node_modules/path-to-regexp/index.js"(exports2, module2) {
      var isarray = require_isarray();
      module2.exports = pathToRegexp2;
      module2.exports.parse = parse2;
      module2.exports.compile = compile;
      module2.exports.tokensToFunction = tokensToFunction;
      module2.exports.tokensToRegExp = tokensToRegExp2;
      var PATH_REGEXP = new RegExp([
        // Match escaped characters that would otherwise appear in future matches.
        // This allows the user to escape special characters that won't transform.
        "(\\\\.)",
        // Match Express-style parameters and un-named parameters with a prefix
        // and optional suffixes. Matches appear as:
        //
        // "/:test(\\d+)?" => ["/", "test", "\d+", undefined, "?", undefined]
        // "/route(\\d+)"  => [undefined, undefined, undefined, "\d+", undefined, undefined]
        // "/*"            => ["/", undefined, undefined, undefined, undefined, "*"]
        "([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))"
      ].join("|"), "g");
      function parse2(str, options) {
        var tokens = [];
        var key = 0;
        var index = 0;
        var path = "";
        var defaultDelimiter2 = options && options.delimiter || "/";
        var res;
        while ((res = PATH_REGEXP.exec(str)) != null) {
          var m = res[0];
          var escaped = res[1];
          var offset = res.index;
          path += str.slice(index, offset);
          index = offset + m.length;
          if (escaped) {
            path += escaped[1];
            continue;
          }
          var next = str[index];
          var prefix2 = res[2];
          var name = res[3];
          var capture = res[4];
          var group = res[5];
          var modifier = res[6];
          var asterisk = res[7];
          if (path) {
            tokens.push(path);
            path = "";
          }
          var partial = prefix2 != null && next != null && next !== prefix2;
          var repeat = modifier === "+" || modifier === "*";
          var optional = modifier === "?" || modifier === "*";
          var delimiter = prefix2 || defaultDelimiter2;
          var pattern = capture || group;
          var prevText = prefix2 || (typeof tokens[tokens.length - 1] === "string" ? tokens[tokens.length - 1] : "");
          tokens.push({
            name: name || key++,
            prefix: prefix2 || "",
            delimiter,
            optional,
            repeat,
            partial,
            asterisk: !!asterisk,
            pattern: pattern ? escapeGroup2(pattern) : asterisk ? ".*" : restrictBacktrack(delimiter, prevText)
          });
        }
        if (index < str.length) {
          path += str.substr(index);
        }
        if (path) {
          tokens.push(path);
        }
        return tokens;
      }
      function restrictBacktrack(delimiter, prevText) {
        if (!prevText || prevText.indexOf(delimiter) > -1) {
          return "[^" + escapeString2(delimiter) + "]+?";
        }
        return escapeString2(prevText) + "|(?:(?!" + escapeString2(prevText) + ")[^" + escapeString2(delimiter) + "])+?";
      }
      function compile(str, options) {
        return tokensToFunction(parse2(str, options), options);
      }
      function encodeURIComponentPretty(str) {
        return encodeURI(str).replace(/[\/?#]/g, function(c) {
          return "%" + c.charCodeAt(0).toString(16).toUpperCase();
        });
      }
      function encodeAsterisk(str) {
        return encodeURI(str).replace(/[?#]/g, function(c) {
          return "%" + c.charCodeAt(0).toString(16).toUpperCase();
        });
      }
      function tokensToFunction(tokens, options) {
        var matches = new Array(tokens.length);
        for (var i = 0; i < tokens.length; i++) {
          if (typeof tokens[i] === "object") {
            matches[i] = new RegExp("^(?:" + tokens[i].pattern + ")$", flags(options));
          }
        }
        return function(obj, opts) {
          var path = "";
          var data = obj || {};
          var options2 = opts || {};
          var encode = options2.pretty ? encodeURIComponentPretty : encodeURIComponent;
          for (var i2 = 0; i2 < tokens.length; i2++) {
            var token = tokens[i2];
            if (typeof token === "string") {
              path += token;
              continue;
            }
            var value = data[token.name];
            var segment;
            if (value == null) {
              if (token.optional) {
                if (token.partial) {
                  path += token.prefix;
                }
                continue;
              } else {
                throw new TypeError('Expected "' + token.name + '" to be defined');
              }
            }
            if (isarray(value)) {
              if (!token.repeat) {
                throw new TypeError('Expected "' + token.name + '" to not repeat, but received `' + JSON.stringify(value) + "`");
              }
              if (value.length === 0) {
                if (token.optional) {
                  continue;
                } else {
                  throw new TypeError('Expected "' + token.name + '" to not be empty');
                }
              }
              for (var j = 0; j < value.length; j++) {
                segment = encode(value[j]);
                if (!matches[i2].test(segment)) {
                  throw new TypeError('Expected all "' + token.name + '" to match "' + token.pattern + '", but received `' + JSON.stringify(segment) + "`");
                }
                path += (j === 0 ? token.prefix : token.delimiter) + segment;
              }
              continue;
            }
            segment = token.asterisk ? encodeAsterisk(value) : encode(value);
            if (!matches[i2].test(segment)) {
              throw new TypeError('Expected "' + token.name + '" to match "' + token.pattern + '", but received "' + segment + '"');
            }
            path += token.prefix + segment;
          }
          return path;
        };
      }
      function escapeString2(str) {
        return str.replace(/([.+*?=^!:${}()[\]|\/\\])/g, "\\$1");
      }
      function escapeGroup2(group) {
        return group.replace(/([=!:$\/()])/g, "\\$1");
      }
      function attachKeys(re, keys2) {
        re.keys = keys2;
        return re;
      }
      function flags(options) {
        return options && options.sensitive ? "" : "i";
      }
      function regexpToRegexp(path, keys2) {
        var groups = path.source.match(/\((?!\?)/g);
        if (groups) {
          for (var i = 0; i < groups.length; i++) {
            keys2.push({
              name: i,
              prefix: null,
              delimiter: null,
              optional: false,
              repeat: false,
              partial: false,
              asterisk: false,
              pattern: null
            });
          }
        }
        return attachKeys(path, keys2);
      }
      function arrayToRegexp(path, keys2, options) {
        var parts = [];
        for (var i = 0; i < path.length; i++) {
          parts.push(pathToRegexp2(path[i], keys2, options).source);
        }
        var regexp = new RegExp("(?:" + parts.join("|") + ")", flags(options));
        return attachKeys(regexp, keys2);
      }
      function stringToRegexp2(path, keys2, options) {
        return tokensToRegExp2(parse2(path, options), keys2, options);
      }
      function tokensToRegExp2(tokens, keys2, options) {
        if (!isarray(keys2)) {
          options = /** @type {!Object} */
          keys2 || options;
          keys2 = [];
        }
        options = options || {};
        var strict = options.strict;
        var end = options.end !== false;
        var route = "";
        for (var i = 0; i < tokens.length; i++) {
          var token = tokens[i];
          if (typeof token === "string") {
            route += escapeString2(token);
          } else {
            var prefix2 = escapeString2(token.prefix);
            var capture = "(?:" + token.pattern + ")";
            keys2.push(token);
            if (token.repeat) {
              capture += "(?:" + prefix2 + capture + ")*";
            }
            if (token.optional) {
              if (!token.partial) {
                capture = "(?:" + prefix2 + "(" + capture + "))?";
              } else {
                capture = prefix2 + "(" + capture + ")?";
              }
            } else {
              capture = prefix2 + "(" + capture + ")";
            }
            route += capture;
          }
        }
        var delimiter = escapeString2(options.delimiter || "/");
        var endsWithDelimiter = route.slice(-delimiter.length) === delimiter;
        if (!strict) {
          route = (endsWithDelimiter ? route.slice(0, -delimiter.length) : route) + "(?:" + delimiter + "(?=$))?";
        }
        if (end) {
          route += "$";
        } else {
          route += strict && endsWithDelimiter ? "" : "(?=" + delimiter + "|$)";
        }
        return attachKeys(new RegExp("^" + route, flags(options)), keys2);
      }
      function pathToRegexp2(path, keys2, options) {
        if (!isarray(keys2)) {
          options = /** @type {!Object} */
          keys2 || options;
          keys2 = [];
        }
        options = options || {};
        if (path instanceof RegExp) {
          return regexpToRegexp(
            path,
            /** @type {!Array} */
            keys2
          );
        }
        if (isarray(path)) {
          return arrayToRegexp(
            /** @type {!Array} */
            path,
            /** @type {!Array} */
            keys2,
            options
          );
        }
        return stringToRegexp2(
          /** @type {string} */
          path,
          /** @type {!Array} */
          keys2,
          options
        );
      }
    }
  });

  // node_modules/piral-translate/node_modules/deepmerge/dist/cjs.js
  var require_cjs = __commonJS({
    "node_modules/piral-translate/node_modules/deepmerge/dist/cjs.js"(exports2, module2) {
      "use strict";
      var isMergeableObject3 = function isMergeableObject4(value) {
        return isNonNullObject2(value) && !isSpecial2(value);
      };
      function isNonNullObject2(value) {
        return !!value && typeof value === "object";
      }
      function isSpecial2(value) {
        var stringValue = Object.prototype.toString.call(value);
        return stringValue === "[object RegExp]" || stringValue === "[object Date]" || isReactElement2(value);
      }
      var canUseSymbol2 = typeof Symbol === "function" && Symbol.for;
      var REACT_ELEMENT_TYPE2 = canUseSymbol2 ? Symbol.for("react.element") : 60103;
      function isReactElement2(value) {
        return value.$$typeof === REACT_ELEMENT_TYPE2;
      }
      function emptyTarget2(val) {
        return Array.isArray(val) ? [] : {};
      }
      function cloneUnlessOtherwiseSpecified2(value, options) {
        return options.clone !== false && options.isMergeableObject(value) ? deepmerge3(emptyTarget2(value), value, options) : value;
      }
      function defaultArrayMerge2(target, source, options) {
        return target.concat(source).map(function(element) {
          return cloneUnlessOtherwiseSpecified2(element, options);
        });
      }
      function getMergeFunction(key, options) {
        if (!options.customMerge) {
          return deepmerge3;
        }
        var customMerge = options.customMerge(key);
        return typeof customMerge === "function" ? customMerge : deepmerge3;
      }
      function getEnumerableOwnPropertySymbols(target) {
        return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(target).filter(function(symbol) {
          return Object.propertyIsEnumerable.call(target, symbol);
        }) : [];
      }
      function getKeys(target) {
        return Object.keys(target).concat(getEnumerableOwnPropertySymbols(target));
      }
      function propertyIsOnObject(object, property) {
        try {
          return property in object;
        } catch (_) {
          return false;
        }
      }
      function propertyIsUnsafe(target, key) {
        return propertyIsOnObject(target, key) && !(Object.hasOwnProperty.call(target, key) && Object.propertyIsEnumerable.call(target, key));
      }
      function mergeObject2(target, source, options) {
        var destination = {};
        if (options.isMergeableObject(target)) {
          getKeys(target).forEach(function(key) {
            destination[key] = cloneUnlessOtherwiseSpecified2(target[key], options);
          });
        }
        getKeys(source).forEach(function(key) {
          if (propertyIsUnsafe(target, key)) {
            return;
          }
          if (propertyIsOnObject(target, key) && options.isMergeableObject(source[key])) {
            destination[key] = getMergeFunction(key, options)(target[key], source[key], options);
          } else {
            destination[key] = cloneUnlessOtherwiseSpecified2(source[key], options);
          }
        });
        return destination;
      }
      function deepmerge3(target, source, options) {
        options = options || {};
        options.arrayMerge = options.arrayMerge || defaultArrayMerge2;
        options.isMergeableObject = options.isMergeableObject || isMergeableObject3;
        options.cloneUnlessOtherwiseSpecified = cloneUnlessOtherwiseSpecified2;
        var sourceIsArray = Array.isArray(source);
        var targetIsArray = Array.isArray(target);
        var sourceAndTargetTypesMatch = sourceIsArray === targetIsArray;
        if (!sourceAndTargetTypesMatch) {
          return cloneUnlessOtherwiseSpecified2(source, options);
        } else if (sourceIsArray) {
          return options.arrayMerge(target, source, options);
        } else {
          return mergeObject2(target, source, options);
        }
      }
      deepmerge3.all = function deepmergeAll2(array, options) {
        if (!Array.isArray(array)) {
          throw new Error("first argument should be an array");
        }
        return array.reduce(function(prev, next) {
          return deepmerge3(prev, next, options);
        }, {});
      };
      var deepmerge_12 = deepmerge3;
      module2.exports = deepmerge_12;
    }
  });

  // src/index.tsx
  var React39 = __toESM(require_react());
  var import_client = __toESM(require_client());

  // node_modules/tslib/tslib.es6.mjs
  var tslib_es6_exports = {};
  __export(tslib_es6_exports, {
    __addDisposableResource: () => __addDisposableResource,
    __assign: () => __assign,
    __asyncDelegator: () => __asyncDelegator,
    __asyncGenerator: () => __asyncGenerator,
    __asyncValues: () => __asyncValues,
    __await: () => __await,
    __awaiter: () => __awaiter,
    __classPrivateFieldGet: () => __classPrivateFieldGet,
    __classPrivateFieldIn: () => __classPrivateFieldIn,
    __classPrivateFieldSet: () => __classPrivateFieldSet,
    __createBinding: () => __createBinding,
    __decorate: () => __decorate,
    __disposeResources: () => __disposeResources,
    __esDecorate: () => __esDecorate,
    __exportStar: () => __exportStar,
    __extends: () => __extends,
    __generator: () => __generator,
    __importDefault: () => __importDefault,
    __importStar: () => __importStar,
    __makeTemplateObject: () => __makeTemplateObject,
    __metadata: () => __metadata,
    __param: () => __param,
    __propKey: () => __propKey,
    __read: () => __read,
    __rest: () => __rest,
    __rewriteRelativeImportExtension: () => __rewriteRelativeImportExtension,
    __runInitializers: () => __runInitializers,
    __setFunctionName: () => __setFunctionName,
    __spread: () => __spread,
    __spreadArray: () => __spreadArray,
    __spreadArrays: () => __spreadArrays,
    __values: () => __values,
    default: () => tslib_es6_default
  });
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }
  var __assign = function() {
    __assign = Object.assign || function __assign2(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
    };
    return __assign.apply(this, arguments);
  };
  function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
      t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
      for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
          t[p[i]] = s[p[i]];
      }
    return t;
  }
  function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
  }
  function __param(paramIndex, decorator) {
    return function(target, key) {
      decorator(target, key, paramIndex);
    };
  }
  function __esDecorate(ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) {
      if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected");
      return f;
    }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
      var context2 = {};
      for (var p in contextIn) context2[p] = p === "access" ? {} : contextIn[p];
      for (var p in contextIn.access) context2.access[p] = contextIn.access[p];
      context2.addInitializer = function(f) {
        if (done) throw new TypeError("Cannot add initializers after decoration has completed");
        extraInitializers.push(accept(f || null));
      };
      var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context2);
      if (kind === "accessor") {
        if (result === void 0) continue;
        if (result === null || typeof result !== "object") throw new TypeError("Object expected");
        if (_ = accept(result.get)) descriptor.get = _;
        if (_ = accept(result.set)) descriptor.set = _;
        if (_ = accept(result.init)) initializers.unshift(_);
      } else if (_ = accept(result)) {
        if (kind === "field") initializers.unshift(_);
        else descriptor[key] = _;
      }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
  }
  function __runInitializers(thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
      value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
  }
  function __propKey(x) {
    return typeof x === "symbol" ? x : "".concat(x);
  }
  function __setFunctionName(f, name, prefix2) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix2 ? "".concat(prefix2, " ", name) : name });
  }
  function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
  }
  function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P ? value : new P(function(resolve) {
        resolve(value);
      });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      }
      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e) {
          reject(e);
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  }
  function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() {
      if (t[0] & 1) throw t[1];
      return t[1];
    }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n) {
      return function(v) {
        return step([n, v]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  }
  var __createBinding = Object.create ? (function(o, m, k, k2) {
    if (k2 === void 0) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() {
        return m[k];
      } };
    }
    Object.defineProperty(o, k2, desc);
  }) : (function(o, m, k, k2) {
    if (k2 === void 0) k2 = k;
    o[k2] = m[k];
  });
  function __exportStar(m, o) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
  }
  function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
      next: function() {
        if (o && i >= o.length) o = void 0;
        return { value: o && o[i++], done: !o };
      }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
  }
  function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
      while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    } catch (error) {
      e = { error };
    } finally {
      try {
        if (r && !r.done && (m = i["return"])) m.call(i);
      } finally {
        if (e) throw e.error;
      }
    }
    return ar;
  }
  function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
      ar = ar.concat(__read(arguments[i]));
    return ar;
  }
  function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
      for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
        r[k] = a[j];
    return r;
  }
  function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
        if (!ar) ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
  }
  function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
  }
  function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function() {
      return this;
    }, i;
    function awaitReturn(f) {
      return function(v) {
        return Promise.resolve(v).then(f, reject);
      };
    }
    function verb(n, f) {
      if (g[n]) {
        i[n] = function(v) {
          return new Promise(function(a, b) {
            q.push([n, v, a, b]) > 1 || resume(n, v);
          });
        };
        if (f) i[n] = f(i[n]);
      }
    }
    function resume(n, v) {
      try {
        step(g[n](v));
      } catch (e) {
        settle(q[0][3], e);
      }
    }
    function step(r) {
      r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
      resume("next", value);
    }
    function reject(value) {
      resume("throw", value);
    }
    function settle(f, v) {
      if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
  }
  function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function(e) {
      throw e;
    }), verb("return"), i[Symbol.iterator] = function() {
      return this;
    }, i;
    function verb(n, f) {
      i[n] = o[n] ? function(v) {
        return (p = !p) ? { value: __await(o[n](v)), done: false } : f ? f(v) : v;
      } : f;
    }
  }
  function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
      return this;
    }, i);
    function verb(n) {
      i[n] = o[n] && function(v) {
        return new Promise(function(resolve, reject) {
          v = o[n](v), settle(resolve, reject, v.done, v.value);
        });
      };
    }
    function settle(resolve, reject, d, v) {
      Promise.resolve(v).then(function(v2) {
        resolve({ value: v2, done: d });
      }, reject);
    }
  }
  function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) {
      Object.defineProperty(cooked, "raw", { value: raw });
    } else {
      cooked.raw = raw;
    }
    return cooked;
  }
  var __setModuleDefault = Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
  }) : function(o, v) {
    o["default"] = v;
  };
  var ownKeys = function(o) {
    ownKeys = Object.getOwnPropertyNames || function(o2) {
      var ar = [];
      for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
      return ar;
    };
    return ownKeys(o);
  };
  function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
      for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
    }
    __setModuleDefault(result, mod);
    return result;
  }
  function __importDefault(mod) {
    return mod && mod.__esModule ? mod : { default: mod };
  }
  function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
  }
  function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
  }
  function __classPrivateFieldIn(state, receiver) {
    if (receiver === null || typeof receiver !== "object" && typeof receiver !== "function") throw new TypeError("Cannot use 'in' operator on non-object");
    return typeof state === "function" ? receiver === state : state.has(receiver);
  }
  function __addDisposableResource(env, value, async) {
    if (value !== null && value !== void 0) {
      if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
      var dispose, inner;
      if (async) {
        if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
        dispose = value[Symbol.asyncDispose];
      }
      if (dispose === void 0) {
        if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
        dispose = value[Symbol.dispose];
        if (async) inner = dispose;
      }
      if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
      if (inner) dispose = function() {
        try {
          inner.call(this);
        } catch (e) {
          return Promise.reject(e);
        }
      };
      env.stack.push({ value, dispose, async });
    } else if (async) {
      env.stack.push({ async: true });
    }
    return value;
  }
  var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
  };
  function __disposeResources(env) {
    function fail(e) {
      env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
      env.hasError = true;
    }
    var r, s = 0;
    function next() {
      while (r = env.stack.pop()) {
        try {
          if (!r.async && s === 1) return s = 0, env.stack.push(r), Promise.resolve().then(next);
          if (r.dispose) {
            var result = r.dispose.call(r.value);
            if (r.async) return s |= 2, Promise.resolve(result).then(next, function(e) {
              fail(e);
              return next();
            });
          } else s |= 1;
        } catch (e) {
          fail(e);
        }
      }
      if (s === 1) return env.hasError ? Promise.reject(env.error) : Promise.resolve();
      if (env.hasError) throw env.error;
    }
    return next();
  }
  function __rewriteRelativeImportExtension(path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
      return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function(m, tsx, d, ext, cm) {
        return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : d + ext + "." + cm.toLowerCase() + "js";
      });
    }
    return path;
  }
  var tslib_es6_default = {
    __extends,
    __assign,
    __rest,
    __decorate,
    __param,
    __esDecorate,
    __runInitializers,
    __propKey,
    __setFunctionName,
    __metadata,
    __awaiter,
    __generator,
    __createBinding,
    __exportStar,
    __values,
    __read,
    __spread,
    __spreadArrays,
    __spreadArray,
    __await,
    __asyncGenerator,
    __asyncDelegator,
    __asyncValues,
    __makeTemplateObject,
    __importStar,
    __importDefault,
    __classPrivateFieldGet,
    __classPrivateFieldSet,
    __classPrivateFieldIn,
    __addDisposableResource,
    __disposeResources,
    __rewriteRelativeImportExtension
  };

  // node_modules/piral-base/dist/piral-base-full.mjs
  (function() {
    function errMsg(errCode, msg) {
      return (msg || "") + " (SystemJS Error#" + errCode + " https://github.com/systemjs/systemjs/blob/main/docs/errors.md#" + errCode + ")";
    }
    var hasSymbol = typeof Symbol !== "undefined";
    var hasSelf = typeof self !== "undefined";
    var hasDocument = typeof document !== "undefined";
    var envGlobal = hasSelf ? self : global;
    var baseUrl;
    if (hasDocument) {
      var baseEl = document.querySelector("base[href]");
      if (baseEl)
        baseUrl = baseEl.href;
    }
    if (!baseUrl && typeof location !== "undefined") {
      baseUrl = location.href.split("#")[0].split("?")[0];
      var lastSepIndex = baseUrl.lastIndexOf("/");
      if (lastSepIndex !== -1)
        baseUrl = baseUrl.slice(0, lastSepIndex + 1);
    }
    var backslashRegEx = /\\/g;
    function resolveIfNotPlainOrUrl(relUrl, parentUrl) {
      if (relUrl.indexOf("\\") !== -1)
        relUrl = relUrl.replace(backslashRegEx, "/");
      if (relUrl[0] === "/" && relUrl[1] === "/") {
        return parentUrl.slice(0, parentUrl.indexOf(":") + 1) + relUrl;
      } else if (relUrl[0] === "." && (relUrl[1] === "/" || relUrl[1] === "." && (relUrl[2] === "/" || relUrl.length === 2 && (relUrl += "/")) || relUrl.length === 1 && (relUrl += "/")) || relUrl[0] === "/") {
        var parentProtocol = parentUrl.slice(0, parentUrl.indexOf(":") + 1);
        var pathname;
        if (parentUrl[parentProtocol.length + 1] === "/") {
          if (parentProtocol !== "file:") {
            pathname = parentUrl.slice(parentProtocol.length + 2);
            pathname = pathname.slice(pathname.indexOf("/") + 1);
          } else {
            pathname = parentUrl.slice(8);
          }
        } else {
          pathname = parentUrl.slice(parentProtocol.length + (parentUrl[parentProtocol.length] === "/"));
        }
        if (relUrl[0] === "/")
          return parentUrl.slice(0, parentUrl.length - pathname.length - 1) + relUrl;
        var segmented = pathname.slice(0, pathname.lastIndexOf("/") + 1) + relUrl;
        var output = [];
        var segmentIndex = -1;
        for (var i = 0; i < segmented.length; i++) {
          if (segmentIndex !== -1) {
            if (segmented[i] === "/") {
              output.push(segmented.slice(segmentIndex, i + 1));
              segmentIndex = -1;
            }
          } else if (segmented[i] === ".") {
            if (segmented[i + 1] === "." && (segmented[i + 2] === "/" || i + 2 === segmented.length)) {
              output.pop();
              i += 2;
            } else if (segmented[i + 1] === "/" || i + 1 === segmented.length) {
              i += 1;
            } else {
              segmentIndex = i;
            }
          } else {
            segmentIndex = i;
          }
        }
        if (segmentIndex !== -1)
          output.push(segmented.slice(segmentIndex));
        return parentUrl.slice(0, parentUrl.length - pathname.length) + output.join("");
      }
    }
    function resolveUrl(relUrl, parentUrl) {
      return resolveIfNotPlainOrUrl(relUrl, parentUrl) || (relUrl.indexOf(":") !== -1 ? relUrl : resolveIfNotPlainOrUrl("./" + relUrl, parentUrl));
    }
    function resolveAndComposePackages(packages, outPackages, baseUrl2, parentMap, parentUrl) {
      for (var p in packages) {
        var resolvedLhs = resolveIfNotPlainOrUrl(p, baseUrl2) || p;
        var rhs = packages[p];
        if (typeof rhs !== "string")
          continue;
        var mapped = resolveImportMap(parentMap, resolveIfNotPlainOrUrl(rhs, baseUrl2) || rhs, parentUrl);
        if (!mapped) {
          targetWarning("W1", p, rhs, "bare specifier did not resolve");
        } else
          outPackages[resolvedLhs] = mapped;
      }
    }
    function resolveAndComposeImportMap(json, baseUrl2, outMap) {
      if (json.imports)
        resolveAndComposePackages(json.imports, outMap.imports, baseUrl2, outMap, null);
      var u;
      for (u in json.scopes || {}) {
        var resolvedScope = resolveUrl(u, baseUrl2);
        resolveAndComposePackages(json.scopes[u], outMap.scopes[resolvedScope] || (outMap.scopes[resolvedScope] = {}), baseUrl2, outMap, resolvedScope);
      }
      for (u in json.depcache || {})
        outMap.depcache[resolveUrl(u, baseUrl2)] = json.depcache[u];
      for (u in json.integrity || {})
        outMap.integrity[resolveUrl(u, baseUrl2)] = json.integrity[u];
    }
    function getMatch(path, matchObj) {
      if (matchObj[path])
        return path;
      var sepIndex = path.length;
      do {
        var segment = path.slice(0, sepIndex + 1);
        if (segment in matchObj)
          return segment;
      } while ((sepIndex = path.lastIndexOf("/", sepIndex - 1)) !== -1);
    }
    function applyPackages(id, packages) {
      var pkgName = getMatch(id, packages);
      if (pkgName) {
        var pkg = packages[pkgName];
        if (pkg === null) return;
        if (id.length > pkgName.length && pkg[pkg.length - 1] !== "/") {
          targetWarning("W2", pkgName, pkg, "should have a trailing '/'");
        } else
          return pkg + id.slice(pkgName.length);
      }
    }
    function targetWarning(code, match, target, msg) {
      console.warn(errMsg(code, "Package target " + msg + ", resolving target '" + target + "' for " + match));
    }
    function resolveImportMap(importMap2, resolvedOrPlain, parentUrl) {
      var scopes = importMap2.scopes;
      var scopeUrl = parentUrl && getMatch(parentUrl, scopes);
      while (scopeUrl) {
        var packageResolution = applyPackages(resolvedOrPlain, scopes[scopeUrl]);
        if (packageResolution)
          return packageResolution;
        scopeUrl = getMatch(scopeUrl.slice(0, scopeUrl.lastIndexOf("/")), scopes);
      }
      return applyPackages(resolvedOrPlain, importMap2.imports) || resolvedOrPlain.indexOf(":") !== -1 && resolvedOrPlain;
    }
    var toStringTag$1 = hasSymbol && Symbol.toStringTag;
    var REGISTRY = hasSymbol ? /* @__PURE__ */ Symbol() : "@";
    function SystemJS() {
      this[REGISTRY] = {};
    }
    var systemJSPrototype = SystemJS.prototype;
    systemJSPrototype.import = function(id, parentUrl, meta) {
      var loader8 = this;
      parentUrl && typeof parentUrl === "object" && (meta = parentUrl, parentUrl = void 0);
      return Promise.resolve(loader8.prepareImport()).then(function() {
        return loader8.resolve(id, parentUrl, meta);
      }).then(function(id2) {
        var load = getOrCreateLoad(loader8, id2, void 0, meta);
        return load.C || topLevelLoad(loader8, load);
      });
    };
    systemJSPrototype.createContext = function(parentId) {
      var loader8 = this;
      return {
        url: parentId,
        resolve: function(id, parentUrl) {
          return Promise.resolve(loader8.resolve(id, parentUrl || parentId));
        }
      };
    };
    systemJSPrototype.onload = function() {
    };
    function loadToId(load) {
      return load.id;
    }
    function triggerOnload(loader8, load, err, isErrSource) {
      loader8.onload(err, load.id, load.d && load.d.map(loadToId), !!isErrSource);
      if (err)
        throw err;
    }
    var lastRegister;
    systemJSPrototype.register = function(deps, declare, metas) {
      lastRegister = [deps, declare, metas];
    };
    systemJSPrototype.getRegister = function() {
      var _lastRegister = lastRegister;
      lastRegister = void 0;
      return _lastRegister;
    };
    function getOrCreateLoad(loader8, id, firstParentUrl, meta) {
      var load = loader8[REGISTRY][id];
      if (load)
        return load;
      var importerSetters = [];
      var ns = /* @__PURE__ */ Object.create(null);
      if (toStringTag$1)
        Object.defineProperty(ns, toStringTag$1, { value: "Module" });
      var instantiatePromise = Promise.resolve().then(function() {
        return loader8.instantiate(id, firstParentUrl, meta);
      }).then(function(registration) {
        if (!registration)
          throw Error(errMsg(2, "Module " + id + " did not instantiate"));
        function _export(name, value) {
          load.h = true;
          var changed = false;
          if (typeof name === "string") {
            if (!(name in ns) || ns[name] !== value) {
              ns[name] = value;
              changed = true;
            }
          } else {
            for (var p in name) {
              var value = name[p];
              if (!(p in ns) || ns[p] !== value) {
                ns[p] = value;
                changed = true;
              }
            }
            if (name && name.__esModule) {
              ns.__esModule = name.__esModule;
            }
          }
          if (changed)
            for (var i = 0; i < importerSetters.length; i++) {
              var setter = importerSetters[i];
              if (setter) setter(ns);
            }
          return value;
        }
        var declared = registration[1](_export, registration[1].length === 2 ? {
          import: function(importId, meta2) {
            return loader8.import(importId, id, meta2);
          },
          meta: loader8.createContext(id)
        } : void 0);
        load.e = declared.execute || function() {
        };
        return [registration[0], declared.setters || [], registration[2] || []];
      }, function(err) {
        load.e = null;
        load.er = err;
        triggerOnload(loader8, load, err, true);
        throw err;
      });
      var linkPromise = instantiatePromise.then(function(instantiation) {
        return Promise.all(instantiation[0].map(function(dep, i) {
          var setter = instantiation[1][i];
          var meta2 = instantiation[2][i];
          return Promise.resolve(loader8.resolve(dep, id)).then(function(depId) {
            var depLoad = getOrCreateLoad(loader8, depId, id, meta2);
            return Promise.resolve(depLoad.I).then(function() {
              if (setter) {
                depLoad.i.push(setter);
                if (depLoad.h || !depLoad.I)
                  setter(depLoad.n);
              }
              return depLoad;
            });
          });
        })).then(function(depLoads) {
          load.d = depLoads;
        });
      });
      return load = loader8[REGISTRY][id] = {
        id,
        // importerSetters, the setters functions registered to this dependency
        // we retain this to add more later
        i: importerSetters,
        // module namespace object
        n: ns,
        // extra module information for import assertion
        // shape like: { assert: { type: 'xyz' } }
        m: meta,
        // instantiate
        I: instantiatePromise,
        // link
        L: linkPromise,
        // whether it has hoisted exports
        h: false,
        // On instantiate completion we have populated:
        // dependency load records
        d: void 0,
        // execution function
        e: void 0,
        // On execution we have populated:
        // the execution error if any
        er: void 0,
        // in the case of TLA, the execution promise
        E: void 0,
        // On execution, L, I, E cleared
        // Promise for top-level completion
        C: void 0,
        // parent instantiator / executor
        p: void 0
      };
    }
    function instantiateAll(loader8, load, parent, loaded) {
      if (!loaded[load.id]) {
        loaded[load.id] = true;
        return Promise.resolve(load.L).then(function() {
          if (!load.p || load.p.e === null)
            load.p = parent;
          return Promise.all(load.d.map(function(dep) {
            return instantiateAll(loader8, dep, parent, loaded);
          }));
        }).catch(function(err) {
          if (load.er)
            throw err;
          load.e = null;
          triggerOnload(loader8, load, err, false);
          throw err;
        });
      }
    }
    function topLevelLoad(loader8, load) {
      return load.C = instantiateAll(loader8, load, load, {}).then(function() {
        return postOrderExec(loader8, load, {});
      }).then(function() {
        return load.n;
      });
    }
    var nullContext = Object.freeze(/* @__PURE__ */ Object.create(null));
    function postOrderExec(loader8, load, seen) {
      if (seen[load.id])
        return;
      seen[load.id] = true;
      if (!load.e) {
        if (load.er)
          throw load.er;
        if (load.E)
          return load.E;
        return;
      }
      var exec = load.e;
      load.e = null;
      var depLoadPromises;
      load.d.forEach(function(depLoad) {
        try {
          var depLoadPromise = postOrderExec(loader8, depLoad, seen);
          if (depLoadPromise)
            (depLoadPromises = depLoadPromises || []).push(depLoadPromise);
        } catch (err) {
          load.er = err;
          triggerOnload(loader8, load, err, false);
          throw err;
        }
      });
      if (depLoadPromises)
        return Promise.all(depLoadPromises).then(doExec);
      return doExec();
      function doExec() {
        try {
          var execPromise = exec.call(nullContext);
          if (execPromise) {
            execPromise = execPromise.then(function() {
              load.C = load.n;
              load.E = null;
              if (true) triggerOnload(loader8, load, null, true);
            }, function(err) {
              load.er = err;
              load.E = null;
              if (true) triggerOnload(loader8, load, err, true);
              throw err;
            });
            return load.E = execPromise;
          }
          load.C = load.n;
          load.L = load.I = void 0;
        } catch (err) {
          load.er = err;
          throw err;
        } finally {
          triggerOnload(loader8, load, load.er, true);
        }
      }
    }
    envGlobal.System = new SystemJS();
    var importMapPromise = Promise.resolve();
    var importMap = { imports: {}, scopes: {}, depcache: {}, integrity: {} };
    var processFirst = hasDocument;
    systemJSPrototype.prepareImport = function(doProcessScripts) {
      if (processFirst || doProcessScripts) {
        processScripts();
        processFirst = false;
      }
      return importMapPromise;
    };
    systemJSPrototype.getImportMap = function() {
      return JSON.parse(JSON.stringify(importMap));
    };
    if (hasDocument) {
      processScripts();
      window.addEventListener("DOMContentLoaded", processScripts);
    }
    systemJSPrototype.addImportMap = function(newMap, mapBase) {
      resolveAndComposeImportMap(newMap, mapBase || baseUrl, importMap);
    };
    function processScripts() {
      [].forEach.call(document.querySelectorAll("script"), function(script) {
        if (script.sp)
          return;
        if (script.type === "systemjs-module") {
          script.sp = true;
          if (!script.src)
            return;
          System.import(script.src.slice(0, 7) === "import:" ? script.src.slice(7) : resolveUrl(script.src, baseUrl)).catch(function(e) {
            if (e.message.indexOf("https://github.com/systemjs/systemjs/blob/main/docs/errors.md#3") > -1) {
              var event = document.createEvent("Event");
              event.initEvent("error", false, false);
              script.dispatchEvent(event);
            }
            return Promise.reject(e);
          });
        } else if (script.type === "systemjs-importmap") {
          script.sp = true;
          var fetchPromise = script.src ? (System.fetch || fetch)(script.src, { integrity: script.integrity, priority: script.fetchPriority, passThrough: true }).then(function(res) {
            if (!res.ok)
              throw Error("Invalid status code: " + res.status);
            return res.text();
          }).catch(function(err) {
            err.message = errMsg("W4", "Error fetching systemjs-import map " + script.src) + "\n" + err.message;
            console.warn(err);
            if (typeof script.onerror === "function") {
              script.onerror();
            }
            return "{}";
          }) : script.innerHTML;
          importMapPromise = importMapPromise.then(function() {
            return fetchPromise;
          }).then(function(text) {
            extendImportMap(importMap, text, script.src || baseUrl);
          });
        }
      });
    }
    function extendImportMap(importMap2, newMapText, newMapUrl) {
      var newMap = {};
      try {
        newMap = JSON.parse(newMapText);
      } catch (err) {
        console.warn(Error(errMsg("W5", "systemjs-importmap contains invalid JSON") + "\n\n" + newMapText + "\n"));
      }
      resolveAndComposeImportMap(newMap, newMapUrl, importMap2);
    }
    if (hasDocument) {
      window.addEventListener("error", function(evt) {
        lastWindowErrorUrl = evt.filename;
        lastWindowError = evt.error;
      });
      var baseOrigin = location.origin;
    }
    systemJSPrototype.createScript = function(url) {
      var script = document.createElement("script");
      script.async = true;
      if (url.indexOf(baseOrigin + "/"))
        script.crossOrigin = "anonymous";
      var integrity = importMap.integrity[url];
      if (integrity)
        script.integrity = integrity;
      script.src = url;
      return script;
    };
    var lastAutoImportDeps, lastAutoImportTimeout;
    var autoImportCandidates = {};
    var systemRegister2 = systemJSPrototype.register;
    systemJSPrototype.register = function(deps, declare) {
      if (hasDocument && document.readyState === "loading" && typeof deps !== "string") {
        var scripts = document.querySelectorAll("script[src]");
        var lastScript = scripts[scripts.length - 1];
        if (lastScript) {
          lastScript.src;
          lastAutoImportDeps = deps;
          var loader8 = this;
          lastAutoImportTimeout = setTimeout(function() {
            autoImportCandidates[lastScript.src] = [deps, declare];
            loader8.import(lastScript.src);
          });
        }
      } else {
        lastAutoImportDeps = void 0;
      }
      return systemRegister2.call(this, deps, declare);
    };
    var lastWindowErrorUrl, lastWindowError;
    systemJSPrototype.instantiate = function(url, firstParentUrl) {
      var autoImportRegistration = autoImportCandidates[url];
      if (autoImportRegistration) {
        delete autoImportCandidates[url];
        return autoImportRegistration;
      }
      var loader8 = this;
      return Promise.resolve(systemJSPrototype.createScript(url)).then(function(script) {
        return new Promise(function(resolve, reject) {
          script.addEventListener("error", function() {
            reject(Error(errMsg(3, "Error loading " + url + (firstParentUrl ? " from " + firstParentUrl : ""))));
          });
          script.addEventListener("load", function() {
            document.head.removeChild(script);
            if (lastWindowErrorUrl === url) {
              reject(lastWindowError);
            } else {
              var register = loader8.getRegister(url);
              if (register && register[0] === lastAutoImportDeps)
                clearTimeout(lastAutoImportTimeout);
              resolve(register);
            }
          });
          document.head.appendChild(script);
        });
      });
    };
    systemJSPrototype.shouldFetch = function() {
      return false;
    };
    if (typeof fetch !== "undefined")
      systemJSPrototype.fetch = fetch;
    var instantiate = systemJSPrototype.instantiate;
    var jsContentTypeRegEx = /^(text|application)\/(x-)?javascript(;|$)/;
    systemJSPrototype.instantiate = function(url, parent, meta) {
      var loader8 = this;
      if (!this.shouldFetch(url, parent, meta))
        return instantiate.apply(this, arguments);
      return this.fetch(url, {
        credentials: "same-origin",
        integrity: importMap.integrity[url],
        meta
      }).then(function(res) {
        if (!res.ok)
          throw Error(errMsg(7, res.status + " " + res.statusText + ", loading " + url + (parent ? " from " + parent : "")));
        var contentType = res.headers.get("content-type");
        if (!contentType || !jsContentTypeRegEx.test(contentType))
          throw Error(errMsg(4, 'Unknown Content-Type "' + contentType + '", loading ' + url + (parent ? " from " + parent : "")));
        return res.text().then(function(source) {
          if (source.indexOf("//# sourceURL=") < 0)
            source += "\n//# sourceURL=" + url;
          (0, eval)(source);
          return loader8.getRegister(url);
        });
      });
    };
    systemJSPrototype.resolve = function(id, parentUrl) {
      parentUrl = parentUrl || false || baseUrl;
      return resolveImportMap(importMap, resolveIfNotPlainOrUrl(id, parentUrl) || id, parentUrl) || throwUnresolved(id, parentUrl);
    };
    function throwUnresolved(id, parentUrl) {
      throw Error(errMsg(8, "Unable to resolve bare specifier '" + id + (parentUrl ? "' from " + parentUrl : "'")));
    }
    var systemInstantiate = systemJSPrototype.instantiate;
    systemJSPrototype.instantiate = function(url, firstParentUrl, meta) {
      var preloads = importMap.depcache[url];
      if (preloads) {
        for (var i = 0; i < preloads.length; i++)
          getOrCreateLoad(this, this.resolve(preloads[i], url), url);
      }
      return systemInstantiate.call(this, url, firstParentUrl, meta);
    };
    if (hasSelf && typeof importScripts === "function")
      systemJSPrototype.instantiate = function(url) {
        var loader8 = this;
        return Promise.resolve().then(function() {
          importScripts(url);
          return loader8.getRegister(url);
        });
      };
    (function(global2) {
      var systemJSPrototype2 = global2.System.constructor.prototype;
      var firstGlobalProp, secondGlobalProp, lastGlobalProp;
      function getGlobalProp(useFirstGlobalProp) {
        var cnt = 0;
        var foundLastProp, result;
        for (var p in global2) {
          if (shouldSkipProperty(p))
            continue;
          if (cnt === 0 && p !== firstGlobalProp || cnt === 1 && p !== secondGlobalProp)
            return p;
          if (foundLastProp) {
            lastGlobalProp = p;
            result = useFirstGlobalProp && result || p;
          } else {
            foundLastProp = p === lastGlobalProp;
          }
          cnt++;
        }
        return result;
      }
      function noteGlobalProps() {
        firstGlobalProp = secondGlobalProp = void 0;
        for (var p in global2) {
          if (shouldSkipProperty(p))
            continue;
          if (!firstGlobalProp)
            firstGlobalProp = p;
          else if (!secondGlobalProp)
            secondGlobalProp = p;
          lastGlobalProp = p;
        }
        return lastGlobalProp;
      }
      var impt = systemJSPrototype2.import;
      systemJSPrototype2.import = function(id, parentUrl, meta) {
        noteGlobalProps();
        return impt.call(this, id, parentUrl, meta);
      };
      var emptyInstantiation = [[], function() {
        return {};
      }];
      var getRegister = systemJSPrototype2.getRegister;
      systemJSPrototype2.getRegister = function() {
        var lastRegister2 = getRegister.call(this);
        if (lastRegister2)
          return lastRegister2;
        var globalProp = getGlobalProp(this.firstGlobalProp);
        if (!globalProp)
          return emptyInstantiation;
        var globalExport;
        try {
          globalExport = global2[globalProp];
        } catch (e) {
          return emptyInstantiation;
        }
        return [[], function(_export) {
          return {
            execute: function() {
              _export(globalExport);
              _export({ default: globalExport, __useDefault: true });
            }
          };
        }];
      };
      var isIE11 = typeof navigator !== "undefined" && navigator.userAgent.indexOf("Trident") !== -1;
      function shouldSkipProperty(p) {
        return !global2.hasOwnProperty(p) || !isNaN(p) && p < global2.length || isIE11 && global2[p] && typeof window !== "undefined" && global2[p].parent === window;
      }
    })(typeof self !== "undefined" ? self : global);
    (function(global2) {
      var systemJSPrototype2 = global2.System.constructor.prototype;
      var moduleTypesRegEx = /^[^#?]+\.(css|html|json|wasm)([?#].*)?$/;
      var _shouldFetch = systemJSPrototype2.shouldFetch.bind(systemJSPrototype2);
      systemJSPrototype2.shouldFetch = function(url) {
        return _shouldFetch(url) || moduleTypesRegEx.test(url);
      };
      var jsonContentType = /^application\/json(;|$)/;
      var cssContentType = /^text\/css(;|$)/;
      var wasmContentType = /^application\/wasm(;|$)/;
      var fetch2 = systemJSPrototype2.fetch;
      systemJSPrototype2.fetch = function(url, options) {
        return fetch2(url, options).then(function(res) {
          if (options.passThrough)
            return res;
          if (!res.ok)
            return res;
          var contentType = res.headers.get("content-type");
          if (jsonContentType.test(contentType))
            return res.json().then(function(json) {
              return new Response(new Blob([
                'System.register([],function(e){return{execute:function(){e("default",' + JSON.stringify(json) + ")}}})"
              ], {
                type: "application/javascript"
              }));
            });
          if (cssContentType.test(contentType))
            return res.text().then(function(source) {
              source = source.replace(/url\(\s*(?:(["'])((?:\\.|[^\n\\"'])+)\1|((?:\\.|[^\s,"'()\\])+))\s*\)/g, function(match, quotes, relUrl1, relUrl2) {
                return ["url(", quotes, resolveUrl(relUrl1 || relUrl2, url), quotes, ")"].join("");
              });
              return new Response(new Blob([
                "System.register([],function(e){return{execute:function(){var s=new CSSStyleSheet();s.replaceSync(" + JSON.stringify(source) + ');e("default",s)}}})'
              ], {
                type: "application/javascript"
              }));
            });
          if (wasmContentType.test(contentType))
            return (WebAssembly.compileStreaming ? WebAssembly.compileStreaming(res) : res.arrayBuffer().then(WebAssembly.compile)).then(function(module2) {
              if (!global2.System.wasmModules)
                global2.System.wasmModules = /* @__PURE__ */ Object.create(null);
              global2.System.wasmModules[url] = module2;
              var deps = [];
              var setterSources = [];
              if (WebAssembly.Module.imports)
                WebAssembly.Module.imports(module2).forEach(function(impt) {
                  var key = JSON.stringify(impt.module);
                  if (deps.indexOf(key) === -1) {
                    deps.push(key);
                    setterSources.push("function(m){i[" + key + "]=m}");
                  }
                });
              return new Response(new Blob([
                "System.register([" + deps.join(",") + "],function(e){var i={};return{setters:[" + setterSources.join(",") + "],execute:function(){return WebAssembly.instantiate(System.wasmModules[" + JSON.stringify(url) + "],i).then(function(m){e(m.exports)})}}})"
              ], {
                type: "application/javascript"
              }));
            });
          return res;
        });
      };
    })(typeof self !== "undefined" ? self : global);
    var toStringTag = typeof Symbol !== "undefined" && Symbol.toStringTag;
    systemJSPrototype.get = function(id) {
      var load = this[REGISTRY][id];
      if (load && load.e === null && !load.E) {
        if (load.er)
          return null;
        return load.n;
      }
    };
    systemJSPrototype.set = function(id, module2) {
      {
        try {
          new URL(id);
        } catch (err) {
          console.warn(Error(errMsg("W3", '"' + id + '" is not a valid URL to set in the module registry')));
        }
      }
      var ns;
      if (toStringTag && module2[toStringTag] === "Module") {
        ns = module2;
      } else {
        ns = Object.assign(/* @__PURE__ */ Object.create(null), module2);
        if (toStringTag)
          Object.defineProperty(ns, toStringTag, { value: "Module" });
      }
      var done = Promise.resolve(ns);
      var load = this[REGISTRY][id] || (this[REGISTRY][id] = {
        id,
        i: [],
        h: false,
        d: [],
        e: null,
        er: void 0,
        E: void 0
      });
      if (load.e || load.E)
        return false;
      Object.assign(load, {
        n: ns,
        I: void 0,
        L: void 0,
        C: done
      });
      return ns;
    };
    systemJSPrototype.has = function(id) {
      var load = this[REGISTRY][id];
      return !!load;
    };
    systemJSPrototype.delete = function(id) {
      var registry = this[REGISTRY];
      var load = registry[id];
      if (!load || load.p && load.p.e !== null || load.E)
        return false;
      var importerSetters = load.i;
      if (load.d)
        load.d.forEach(function(depLoad) {
          var importerIndex = depLoad.i.indexOf(load);
          if (importerIndex !== -1)
            depLoad.i.splice(importerIndex, 1);
        });
      delete registry[id];
      return function() {
        var load2 = registry[id];
        if (!load2 || !importerSetters || load2.e !== null || load2.E)
          return false;
        importerSetters.forEach(function(setter) {
          load2.i.push(setter);
          setter(load2.n);
        });
        importerSetters = null;
      };
    };
    var iterator = typeof Symbol !== "undefined" && Symbol.iterator;
    systemJSPrototype.entries = function() {
      var loader8 = this, keys2 = Object.keys(loader8[REGISTRY]);
      var index = 0, ns, key;
      var result = {
        next: function() {
          while ((key = keys2[index++]) !== void 0 && (ns = loader8.get(key)) === void 0) ;
          return {
            done: key === void 0,
            value: key !== void 0 && [key, ns]
          };
        }
      };
      result[iterator] = function() {
        return this;
      };
      return result;
    };
  })();
  (function() {
    (function(global2) {
      var System2 = global2.System;
      setRegisterRegistry(System2);
      var systemJSPrototype = System2.constructor.prototype;
      var constructor = System2.constructor;
      var SystemJS = function() {
        constructor.call(this);
        setRegisterRegistry(this);
      };
      SystemJS.prototype = systemJSPrototype;
      System2.constructor = SystemJS;
      var firstNamedDefine, firstName;
      function setRegisterRegistry(systemInstance) {
        systemInstance.registerRegistry = /* @__PURE__ */ Object.create(null);
        systemInstance.namedRegisterAliases = /* @__PURE__ */ Object.create(null);
      }
      var register = systemJSPrototype.register;
      systemJSPrototype.register = function(name, deps, declare, metas) {
        if (typeof name !== "string")
          return register.apply(this, arguments);
        var define2 = [deps, declare, metas];
        this.registerRegistry[name] = define2;
        if (!firstNamedDefine) {
          firstNamedDefine = define2;
          firstName = name;
        }
        Promise.resolve().then(function() {
          firstNamedDefine = null;
          firstName = null;
        });
        return register.apply(this, [deps, declare, metas]);
      };
      var resolve = systemJSPrototype.resolve;
      systemJSPrototype.resolve = function(id, parentURL) {
        try {
          return resolve.call(this, id, parentURL);
        } catch (err) {
          if (id in this.registerRegistry) {
            return this.namedRegisterAliases[id] || id;
          }
          throw err;
        }
      };
      var instantiate = systemJSPrototype.instantiate;
      systemJSPrototype.instantiate = function(url, firstParentUrl, meta) {
        var result = this.registerRegistry[url];
        if (result) {
          this.registerRegistry[url] = null;
          return result;
        } else {
          return instantiate.call(this, url, firstParentUrl, meta);
        }
      };
      var getRegister = systemJSPrototype.getRegister;
      systemJSPrototype.getRegister = function(url) {
        var register2 = getRegister.call(this, url);
        if (firstName && url) {
          this.namedRegisterAliases[firstName] = url;
        }
        var result = firstNamedDefine || register2;
        firstNamedDefine = null;
        firstName = null;
        return result;
      };
    })(typeof self !== "undefined" ? self : global);
  })();
  var emptyApp = {
    setup() {
    }
  };
  var semver = /^[v^~<>=]*?(\d+)(?:\.([x*]|\d+)(?:\.([x*]|\d+)(?:\.([x*]|\d+))?(?:-([\da-z\-]+(?:\.[\da-z\-]+)*))?(?:\+[\da-z\-]+(?:\.[\da-z\-]+)*)?)?)?$/i;
  var acceptsAll = ["*", "x", ">=0"];
  var operatorResMap = {
    ">": [1],
    ">=": [0, 1],
    "=": [0],
    "<=": [-1, 0],
    "<": [-1]
  };
  function indexOrEnd(str, q) {
    return str.indexOf(q) === -1 ? str.length : str.indexOf(q);
  }
  function splitVersion(v) {
    const c = v.replace(/^v/, "").replace(/\+.*$/, "");
    const patchIndex = indexOrEnd(c, "-");
    const arr = c.substring(0, patchIndex).split(".");
    arr.push(c.substring(patchIndex + 1));
    return arr;
  }
  function parseSegment(v) {
    const n = parseInt(v, 10);
    return isNaN(n) ? v : n;
  }
  function validateAndParse(v) {
    const match = v.match(semver);
    match.shift();
    return match;
  }
  function compareStrings(a, b) {
    const ap = parseSegment(a);
    const bp = parseSegment(b);
    if (ap > bp) {
      return 1;
    } else if (ap < bp) {
      return -1;
    } else {
      return 0;
    }
  }
  function compareSegments(a, b) {
    for (let i = 0; i < 2; i++) {
      const r = compareStrings(a[i] || "0", b[i] || "0");
      if (r !== 0) {
        return r;
      }
    }
    return 0;
  }
  function compareVersions(v1, v2) {
    const s1 = splitVersion(v1);
    const s2 = splitVersion(v2);
    const len = Math.max(s1.length - 1, s2.length - 1);
    for (let i = 0; i < len; i++) {
      const m1 = s1[i] || "0";
      const m2 = s2[i] || "0";
      if (m2 === "x") {
        return 0;
      }
      const n1 = parseInt(m1, 10);
      const n2 = parseInt(m2, 10);
      if (n1 > n2) {
        return 1;
      } else if (n2 > n1) {
        return -1;
      }
    }
    const sp1 = s1[s1.length - 1];
    const sp2 = s2[s2.length - 1];
    if (sp1 && sp2) {
      const p1 = sp1.split(".").map(parseSegment);
      const p2 = sp2.split(".").map(parseSegment);
      const len2 = Math.max(p1.length, p2.length);
      for (let i = 0; i < len2; i++) {
        if (p1[i] === void 0 || typeof p2[i] === "string" && typeof p1[i] === "number") {
          return -1;
        } else if (p2[i] === void 0 || typeof p1[i] === "string" && typeof p2[i] === "number") {
          return 1;
        } else if (p1[i] > p2[i]) {
          return 1;
        } else if (p2[i] > p1[i]) {
          return -1;
        }
      }
    } else if (sp1 || sp2) {
      return sp1 ? -1 : 1;
    }
    return 0;
  }
  function compare(v1, v2, operator) {
    const res = compareVersions(v1, v2);
    return operatorResMap[operator].indexOf(res) > -1;
  }
  function validate(version) {
    return acceptsAll.includes(version) || semver.test(version);
  }
  function satisfies(v, r) {
    if (!acceptsAll.includes(r)) {
      const match = r.match(/^([<>=~^]+)/);
      const op = match ? match[1] : "=";
      if (op !== "^" && op !== "~") {
        return compare(v, r, op);
      }
      const [v1, v2, v3] = validateAndParse(v);
      const [m1, m2, m3] = validateAndParse(r);
      if (compareStrings(v1, m1) !== 0) {
        return false;
      } else if (op === "^") {
        return compareSegments([v2, v3], [m2, m3]) >= 0;
      } else if (compareStrings(v2, m2) !== 0) {
        return false;
      }
      return compareStrings(v3, m3) >= 0;
    }
    return true;
  }
  var systemResolve = System.constructor.prototype.resolve;
  var systemRegister = System.constructor.prototype.register;
  function getLoadedVersions(prefix2) {
    return [...System.entries()].filter(([name]) => name.startsWith(prefix2)).map(([name]) => name.substring(prefix2.length));
  }
  function findMatchingPackage(id) {
    const sep = id.indexOf("@", 1);
    if (sep > 1) {
      const available = Object.keys(System.registerRegistry);
      const name = id.substring(0, sep + 1);
      const versionSpec = id.substring(sep + 1);
      if (validate(versionSpec)) {
        const loadedVersions = getLoadedVersions(name);
        const allVersions = available.filter((m) => m.startsWith(name)).map((m) => m.substring(name.length));
        const availableVersions = [...loadedVersions, ...allVersions.filter((m) => !loadedVersions.includes(m))];
        for (const availableVersion of availableVersions) {
          if (validate(availableVersion) && satisfies(availableVersion, versionSpec)) {
            return name + availableVersion;
          }
        }
      }
    }
    return void 0;
  }
  function isPrimitiveExport(content) {
    const type = typeof content;
    return type === "number" || type === "boolean" || type === "symbol" || type === "string" || type === "bigint" || Array.isArray(content);
  }
  System.constructor.prototype.resolve = function(id, parentUrl) {
    try {
      return systemResolve.call(this, id, parentUrl);
    } catch (ex) {
      const result = findMatchingPackage(id);
      if (!result) {
        throw ex;
      }
      return result;
    }
  };
  System.constructor.prototype.register = function(...args) {
    const getContent = args.pop();
    args.push((_export, ctx) => {
      const exp = (...p) => {
        if (p.length === 1) {
          const content = p[0];
          if (content instanceof Promise) {
            return content.then(exp);
          } else if (typeof content === "function") {
            _export("__esModule", true);
            Object.keys(content).forEach((prop) => {
              _export(prop, content[prop]);
            });
            _export("default", content);
          } else if (isPrimitiveExport(content)) {
            _export("__esModule", true);
            _export("default", content);
          } else if (content) {
            _export(content);
            if (typeof content === "object" && !("default" in content)) {
              _export("default", content);
            }
          }
        } else {
          return _export(...p);
        }
      };
      return getContent(exp, ctx);
    });
    return systemRegister.apply(this, args);
  };
  function tryResolve(name, parent) {
    try {
      return System.resolve(name, parent);
    } catch {
      return void 0;
    }
  }
  function handleFailure(error, link) {
    console.error("Failed to load SystemJS module", link, error);
    return emptyApp;
  }
  function loadSystemPilet(link) {
    return System.import(link).catch((error) => handleFailure(error, link));
  }
  function registerDependencies(modules) {
    const moduleNames = Object.keys(modules);
    moduleNames.forEach((name) => registerModule(name, () => modules[name]));
    return Promise.all(moduleNames.map((name) => System.import(name)));
  }
  function registerModule(name, resolve) {
    System.register(name, [], (_exports) => ({
      execute() {
        const content = resolve();
        if (content instanceof Promise) {
          return content.then(_exports);
        } else {
          _exports(content);
        }
      }
    }));
  }
  function registerDependencyUrls(dependencies) {
    for (const name of Object.keys(dependencies)) {
      if (!System.has(name)) {
        const dependency = dependencies[name];
        registerModule(name, () => System.import(dependency));
      }
    }
  }
  function unregisterModules(baseUrl, dependencies) {
    [...System.entries()].map(([name]) => name).filter((name) => name.startsWith(baseUrl) && !dependencies.includes(name)).forEach((name) => System.delete(name));
  }
  function requireModule(name, parent) {
    const moduleId = tryResolve(name, parent);
    const dependency = moduleId && System.get(moduleId);
    if (!dependency) {
      const error = new Error(`Cannot find module '${name}'`);
      error.code = "MODULE_NOT_FOUND";
      throw error;
    }
    return dependency;
  }
  function isfunc(f) {
    return typeof f === "function";
  }
  function callfunc(f, ...args) {
    isfunc(f) && f(...args);
  }
  function promisify(value) {
    return Promise.resolve(value);
  }
  function getBasePath(link) {
    if (link) {
      const idx = link.lastIndexOf("/");
      return link.substring(0, idx + 1);
    }
    return link;
  }
  function createEvaluatedPilet(meta, mod) {
    const basePath = getBasePath(meta.link);
    const app = checkPiletApp(meta.name, mod);
    return { ...meta, ...app, basePath };
  }
  function checkCreateApi(createApi) {
    if (!isfunc(createApi)) {
      console.warn("Invalid `createApi` function. Skipping pilet installation.");
      return false;
    }
    return true;
  }
  function checkPiletApp(name, app) {
    if (!app) {
      console.error("Invalid module found.", name);
    } else if (typeof app.setup !== "function") {
      console.warn("Setup function is missing.", name);
    } else {
      return app;
    }
    return emptyApp;
  }
  function includeScript(depName, link, integrity, crossOrigin) {
    window[depName] = (moduleId) => requireModule(moduleId, link);
    return includeScriptDependency(link, integrity, crossOrigin).then((s) => s.app);
  }
  function includeScriptDependency(link, integrity, crossOrigin) {
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.async = true;
      s.src = link;
      if (integrity) {
        s.crossOrigin = crossOrigin || "anonymous";
        s.integrity = integrity;
      } else if (crossOrigin) {
        s.crossOrigin = crossOrigin;
      }
      s.onload = () => resolve(s);
      s.onerror = (e) => reject(e);
      document.body.appendChild(s);
    });
  }
  var depContext = {};
  function loadSharedDependencies(dependencies) {
    if (dependencies) {
      const names = Object.keys(dependencies);
      return Promise.all(
        names.map((name) => {
          return depContext[name] || (depContext[name] = includeScriptDependency(dependencies[name]));
        })
      );
    }
    return promisify();
  }
  function handleFailure2(error, name) {
    console.error("Failed to load pilet", name, error);
    return emptyApp;
  }
  function loadFrom(meta, loadPilet) {
    return loadSharedDependencies(meta.dependencies).then(loadPilet).catch((error) => handleFailure2(error, meta.name)).then((app) => createEvaluatedPilet(meta, app));
  }
  var evtName = "unload-pilet";
  function runCleanup(app, api, hooks) {
    if (typeof document !== "undefined") {
      const css = document.querySelector(`link[data-origin=${JSON.stringify(app.name)}]`);
      css?.remove();
    }
    const url = app.basePath;
    callfunc(app.teardown, api);
    callfunc(hooks.cleanupPilet, app);
    if ("requireRef" in app) {
      const depName = app.requireRef;
      delete globalThis[depName];
    }
    if (url) {
      unregisterModules(url, Object.values(app.dependencies));
    }
  }
  function prepareCleanup(app, api, hooks) {
    const handler = (e) => {
      if (e.name === app.name) {
        api.off(evtName, handler);
        runCleanup(app, api, hooks);
      }
    };
    api.on(evtName, handler);
  }
  function logError(name, e) {
    console.error(`Error while setting up ${name}.`, e);
  }
  function withCatch(result, name) {
    if (result instanceof Promise) {
      return result.catch((e) => logError(name, e));
    }
    return promisify(result);
  }
  function setupSinglePilet(app, apiFactory, hooks) {
    const name = app?.name;
    try {
      const api = apiFactory(app);
      callfunc(hooks.setupPilet, app);
      const result = app.setup(api);
      prepareCleanup(app, api, hooks);
      return withCatch(result, name);
    } catch (e) {
      logError(name, e);
    }
    return promisify();
  }
  function setupPiletBundle(app, apiFactory, hooks) {
    const name = app?.name || "pilet bundle";
    try {
      callfunc(hooks.setupPilet, app);
      const result = app.setup(apiFactory);
      return withCatch(result, name);
    } catch (e) {
      logError(name, e);
    }
    return promisify();
  }
  function inspectPilet(meta) {
    const inBrowser = typeof document !== "undefined";
    if ("link" in meta && meta.spec === "v3") {
      return ["v3", meta, setupSinglePilet];
    } else if (inBrowser && "link" in meta && meta.spec === "mf") {
      return ["mf", meta, setupSinglePilet];
    } else if (inBrowser && "link" in meta && meta.spec === "v2") {
      return ["v2", meta, setupSinglePilet];
    } else if (inBrowser && "requireRef" in meta && meta.spec !== "v2") {
      return ["v1", meta, setupSinglePilet];
    } else if (inBrowser && "bundle" in meta && meta.bundle) {
      return ["bundle", meta, setupPiletBundle];
    } else if ("hash" in meta) {
      return ["v0", meta, setupSinglePilet];
    } else {
      return ["unknown", meta, setupSinglePilet];
    }
  }
  function runPilets(createApi, pilets, hooks = {}) {
    const promises = [];
    if (Array.isArray(pilets)) {
      for (const pilet of pilets) {
        const [, , setupPilet] = inspectPilet(pilet);
        const wait = setupPilet(pilet, createApi, hooks);
        promises.push(wait);
      }
    }
    return Promise.all(promises).then(() => pilets);
  }
  function runPilet(createApi, pilet, hooks = {}) {
    const [, , setupPilet] = inspectPilet(pilet);
    const wait = setupPilet(pilet, createApi, hooks);
    return wait.then(() => pilet);
  }
  function initializeApi(target, events) {
    return {
      on: events.on,
      once: events.once,
      off: events.off,
      emit: events.emit,
      meta: Object.assign({}, target)
    };
  }
  function mergeApis(api, extenders, target) {
    const frags = extenders.map((extender) => extender(api, target));
    Object.assign(api, ...frags);
    return api;
  }
  function checkFetchPilets(fetchPilets) {
    if (!isfunc(fetchPilets)) {
      console.error("Could not get the pilets. Provide a valid `fetchPilets` function.");
      return false;
    }
    return true;
  }
  function loadMetadata(fetchPilets) {
    if (checkFetchPilets(fetchPilets)) {
      return fetchPilets().then((pilets) => {
        if (!Array.isArray(pilets)) {
          throw new Error("The fetched pilets metadata is not an array.");
        }
        return pilets.map((meta) => ({ ...meta }));
      });
    }
    return promisify([]);
  }
  function loadPilets(fetchPilets, loadPilet) {
    return loadMetadata(fetchPilets).then((pilets) => Promise.all(pilets.map(loadPilet)));
  }
  function includeBundle(meta, crossOrigin) {
    return includeScript(meta.bundle, meta.link, meta.integrity, crossOrigin);
  }
  function loader(entry, config) {
    const { dependencies = {}, spec = "v1", name = `[bundle] ${entry.link}`, ...rest } = entry;
    const meta = {
      name,
      version: "",
      config: {},
      spec,
      dependencies,
      ...rest
    };
    return loadFrom(meta, () => includeBundle(entry, config.crossOrigin));
  }
  function loader2(entry, _config) {
    const { name, spec = "vx", ...rest } = entry;
    const dependencies = "dependencies" in entry ? entry.dependencies : {};
    const meta = {
      name,
      version: "",
      spec,
      dependencies,
      config: {},
      link: "",
      basePath: "",
      ...rest
    };
    console.warn("Empty pilet found!", name);
    return promisify({ ...meta, ...emptyApp });
  }
  function fetchDependency(url) {
    return fetch(url, {
      method: "GET",
      cache: "force-cache"
    }).then((m) => m.text());
  }
  function evalDependency(name, content, link = "") {
    const mod = {
      exports: {}
    };
    try {
      const sourceUrl = link && `
//# sourceURL=${link}`;
      const importer = new Function("module", "exports", "require", content + sourceUrl);
      const parent = link || name;
      const require2 = (moduleId) => requireModule(moduleId, parent);
      importer(mod, mod.exports, require2);
    } catch (e) {
      console.error(`Error while evaluating ${name}.`, e);
    }
    return mod.exports;
  }
  function loader3(entry, _config) {
    const { name, config = {}, dependencies = {}, spec = "v0" } = entry;
    const meta = {
      name,
      config,
      dependencies,
      spec,
      link: "",
      ...entry
    };
    if ("link" in entry && entry.link) {
      return loadFrom(
        meta,
        () => fetchDependency(entry.link).then((content) => evalDependency(name, content, entry.link))
      );
    } else {
      const content = "content" in entry && entry.content || "";
      return loadFrom(meta, () => evalDependency(name, content, void 0));
    }
  }
  function includeDependency(entry, crossOrigin) {
    return includeScript(entry.requireRef, entry.link, entry.integrity, crossOrigin);
  }
  function loader4(entry, config) {
    const { dependencies = {}, spec = "v1", ...rest } = entry;
    const meta = {
      dependencies,
      config: {},
      spec,
      ...rest
    };
    return loadFrom(meta, () => includeDependency(entry, config.crossOrigin));
  }
  function loader5(entry, _config) {
    const { dependencies = {}, config = {}, link, ...rest } = entry;
    const meta = {
      dependencies,
      config,
      link,
      ...rest
    };
    registerDependencyUrls(dependencies);
    return loadSystemPilet(link).then((app) => createEvaluatedPilet(meta, app));
  }
  function attachStylesToDocument(pilet, url) {
    if (typeof document !== "undefined") {
      const link = document.createElement("link");
      link.setAttribute("data-origin", pilet.name);
      link.type = "text/css";
      link.rel = "stylesheet";
      link.href = url;
      document.head.appendChild(link);
    }
  }
  function loader6(entry, options) {
    const { dependencies = {}, config = {}, link, ...rest } = entry;
    const attachStyles = typeof options.attachStyles === "function" ? options.attachStyles : attachStylesToDocument;
    const meta = {
      dependencies,
      config,
      link,
      ...rest
    };
    registerDependencyUrls(dependencies);
    return loadSystemPilet(link).then((app) => {
      const pilet = createEvaluatedPilet(meta, app);
      if (Array.isArray(app.styles)) {
        for (const style of app.styles) {
          const s = !style.startsWith("//") ? style.replace(/^\/+/, "") : style;
          const url = new URL(s, pilet.basePath).toString();
          attachStyles(pilet, url);
        }
      }
      return pilet;
    });
  }
  var appShell = "piral";
  function populateKnownDependencies(scope) {
    for (const [entry] of System.entries()) {
      const index = entry.lastIndexOf("@");
      if (index > 0 && !entry.match(/^https?:\/\//)) {
        const entryName = entry.substring(0, index);
        const entryVersion = entry.substring(index + 1);
        if (!(entryName in scope)) {
          scope[entryName] = {};
        }
        scope[entryName][entryVersion] = {
          from: appShell,
          eager: false,
          get: () => System.import(entry).then((result) => () => result)
        };
      }
    }
  }
  function extractSharedDependencies(scope) {
    for (const entryName of Object.keys(scope)) {
      const entries = scope[entryName];
      for (const entryVersion of Object.keys(entries)) {
        const entry = entries[entryVersion];
        if (entry.from !== appShell) {
          registerModule(`${entryName}@${entryVersion}`, () => entry.get().then((factory) => factory()));
        }
      }
    }
  }
  function loadMfFactory(piletName, exposedName) {
    const varName = piletName.replace(/^@/, "").replace("/", "-").replace(/\-/g, "_");
    const container = window[varName];
    const scope = {};
    container.init(scope);
    populateKnownDependencies(scope);
    extractSharedDependencies(scope);
    return container.get(exposedName);
  }
  function loader7(entry, _config) {
    const { config = {}, name, link, ...rest } = entry;
    const dependencies = {};
    const exposedName = rest.custom?.exposed || "./pilet";
    const meta = {
      name,
      dependencies,
      config,
      link,
      ...rest
    };
    return includeScriptDependency(link).then(() => loadMfFactory(name, exposedName)).then((factory) => createEvaluatedPilet(meta, factory()));
  }
  function extendLoader(fallback, specLoaders) {
    if (typeof specLoaders === "object" && specLoaders) {
      return (meta) => {
        if (typeof meta.spec === "string") {
          const loaderOverride = specLoaders[meta.spec];
          if (isfunc(loaderOverride)) {
            return loaderOverride(meta);
          }
        }
        return fallback(meta);
      };
    }
    return fallback;
  }
  function getDefaultLoader(config = {}) {
    return (result) => {
      const r = inspectPilet(result);
      switch (r[0]) {
        case "v3":
          return loader6(r[1], config);
        case "v2":
          return loader5(r[1], config);
        case "v1":
          return loader4(r[1], config);
        case "v0":
          return loader3(r[1], config);
        case "mf":
          return loader7(r[1], config);
        case "bundle":
          return loader(r[1], config);
        default:
          return loader2(r[1], config);
      }
    };
  }
  function runAll(createApi, existingPilets, additionalPilets, hooks) {
    if (!Array.isArray(existingPilets)) {
      return Promise.reject(`The existing pilets must be passed as an array.`);
    }
    if (!checkCreateApi(createApi)) {
      return Promise.resolve([]);
    }
    try {
      for (const existing of existingPilets) {
        const { name } = existing;
        const [newPilet] = additionalPilets.filter((pilet) => pilet.name === name);
        if (newPilet) {
          additionalPilets.splice(additionalPilets.indexOf(newPilet), 1);
        }
      }
      const pilets = [...existingPilets, ...additionalPilets];
      return runPilets(createApi, pilets, hooks);
    } catch (err) {
      return Promise.reject(err);
    }
  }
  function createProgressiveStrategy(async) {
    return (options, cb) => {
      const {
        fetchPilets,
        dependencies = {},
        createApi,
        config,
        pilets = [],
        loadPilet = getDefaultLoader(config),
        loaders,
        hooks
      } = options;
      const loadingAll = loadMetadata(fetchPilets);
      const loadSingle = extendLoader(loadPilet, loaders);
      return registerDependencies(dependencies).then(() => {
        if (!checkCreateApi(createApi)) {
          cb(void 0, []);
          return Promise.resolve();
        }
        return runPilets(createApi, pilets, hooks).then((integratedPilets) => {
          if (async && integratedPilets.length > 0) {
            cb(void 0, [...integratedPilets]);
          }
          const followUp = loadingAll.then((metadata) => {
            const promises = metadata.map(
              (m) => loadSingle(m).then((app) => {
                const available = pilets.filter((m2) => m2.name === app.name).length === 0;
                if (available) {
                  return runPilet(createApi, app, hooks).then((additionalPilet) => {
                    integratedPilets.push(additionalPilet);
                    if (async) {
                      cb(void 0, [...integratedPilets]);
                    }
                  });
                }
              })
            );
            return Promise.all(promises).then(() => {
              if (!async) {
                cb(void 0, integratedPilets);
              }
            });
          });
          if (async) {
            followUp.catch(() => {
            });
            return loadingAll.then();
          } else {
            return followUp.then();
          }
        });
      });
    };
  }
  function blazingStrategy(options, cb) {
    const strategy = createProgressiveStrategy(true);
    return strategy(options, cb);
  }
  function standardStrategy(options, cb) {
    const {
      fetchPilets,
      dependencies = {},
      createApi,
      config,
      pilets = [],
      loadPilet = getDefaultLoader(config),
      loaders,
      hooks
    } = options;
    const loadSingle = extendLoader(loadPilet, loaders);
    return registerDependencies(dependencies).then(() => loadPilets(fetchPilets, loadSingle)).then((additionalPilets) => runAll(createApi, pilets, additionalPilets, hooks)).then((integratedPilets) => cb(void 0, integratedPilets)).catch((error) => cb(error, []));
  }
  function startLoadingPilets(options) {
    const state = {
      loaded: false,
      pilets: [],
      error: void 0
    };
    const notifiers = [];
    const call = (notifier) => notifier(state.error, state.pilets, state.loaded);
    const notify = () => notifiers.forEach(call);
    const setPilets = (error, pilets) => {
      state.error = error;
      state.pilets = pilets;
      notify();
    };
    const setLoaded = () => {
      state.loaded = true;
      notify();
    };
    const { strategy = standardStrategy } = options;
    strategy(options, setPilets).then(setLoaded, setLoaded);
    return {
      connect(notifier) {
        if (isfunc(notifier)) {
          notifiers.push(notifier);
          call(notifier);
        }
      },
      disconnect(notifier) {
        const index = notifiers.indexOf(notifier);
        index !== -1 && notifiers.splice(index, 1);
      }
    };
  }
  function nameOf(type) {
    return `piral-${type}`;
  }
  function createListener(state = {}) {
    const eventListeners = [];
    const events = {
      on(type, callback) {
        const listener = ({ detail }) => detail && detail.state === state && callback(detail.arg);
        document.body.addEventListener(nameOf(type), listener);
        eventListeners.push([callback, listener]);
        return events;
      },
      once(type, callback) {
        const cb = (ev) => {
          events.off(type, cb);
          callback(ev);
        };
        return events.on(type, cb);
      },
      off(type, callback) {
        const [listener] = eventListeners.filter((m) => m[0] === callback);
        if (listener) {
          document.body.removeEventListener(nameOf(type), listener[1]);
          eventListeners.splice(eventListeners.indexOf(listener), 1);
        }
        return events;
      },
      emit(type, arg) {
        document.body.dispatchEvent(
          new CustomEvent(nameOf(type), {
            bubbles: false,
            cancelable: false,
            detail: {
              arg,
              state
            }
          })
        );
        return events;
      }
    };
    return events;
  }

  // node_modules/piral-core/lib/components/components.js
  var React2 = __toESM(require_react());

  // node_modules/piral-core/lib/hooks/globalState.js
  var import_react = __toESM(require_react());

  // node_modules/piral-core/lib/state/stateContext.js
  var React = __toESM(require_react());
  var StateContext = React.createContext(void 0);

  // node_modules/piral-core/lib/hooks/globalState.js
  function useGlobalStateContext() {
    return (0, import_react.useContext)(StateContext);
  }
  function useGlobalState(select) {
    const { state: useState5 } = useGlobalStateContext();
    return useState5(select);
  }

  // node_modules/piral-core/lib/hooks/action.js
  function useAction(action) {
    const ctx = useGlobalStateContext();
    return ctx[action];
  }

  // node_modules/piral-core/lib/hooks/media.js
  var import_react2 = __toESM(require_react());

  // node_modules/piral-core/lib/utils/helpers.js
  var removeIndicator = null;
  var none = [];
  var noop = () => {
  };
  function prependItem(items, item) {
    return [item, ...items || none];
  }
  function appendItem(items, item) {
    return [...items || none, item];
  }
  function excludeItem(items, item) {
    return (items || none).filter((m) => m !== item);
  }
  function includeItem(items, item) {
    return appendItem(excludeItem(items, item), item);
  }
  function replaceOrAddItem(items, item, predicate) {
    const newItems = [...items || none];
    for (let i = 0; i < newItems.length; i++) {
      if (predicate(newItems[i])) {
        newItems[i] = item;
        return newItems;
      }
    }
    newItems.push(item);
    return newItems;
  }
  function removeNested(obj, predicate) {
    return Object.keys(obj).reduce((entries, key) => {
      const item = obj[key];
      entries[key] = Object.keys(item).reduce((all2, key2) => {
        const value = item[key2];
        if (Array.isArray(value)) {
          all2[key2] = excludeOn(value, predicate);
        } else if (!value || !predicate(value)) {
          all2[key2] = value;
        }
        return all2;
      }, {});
      return entries;
    }, {});
  }
  function excludeOn(items, predicate) {
    return (items || none).filter((m) => !predicate(m));
  }
  function updateKey(obj, key, value) {
    return value === removeIndicator ? withoutKey(obj, key) : withKey(obj, key, value);
  }
  function withKey(obj, key, value) {
    return {
      ...obj,
      [key]: value
    };
  }
  function withoutKey(obj, key) {
    const { [key]: _, ...newObj } = obj || {};
    return newObj;
  }
  function tryParseJson(content) {
    try {
      return JSON.parse(content);
    } catch {
      return {};
    }
  }

  // node_modules/piral-core/lib/utils/media.js
  var defaultLayouts = ["desktop", "tablet", "mobile"];
  var defaultBreakpoints = ["(min-width: 991px)", "(min-width: 481px)", "(max-width: 480px)"];
  var mm = typeof window === "undefined" || !isfunc(window.matchMedia) ? () => ({ matches: void 0 }) : (q) => window.matchMedia(q);
  function getCurrentLayout(breakpoints = defaultBreakpoints, layouts, defaultLayout) {
    const query = breakpoints.findIndex((q) => mm(q).matches);
    const layout2 = layouts[query];
    return layout2 !== void 0 ? layout2 : defaultLayout;
  }

  // node_modules/piral-core/lib/hooks/media.js
  function useMedia(queries, values, defaultValue) {
    const match = () => getCurrentLayout(queries, values, defaultValue);
    const [value, update] = (0, import_react2.useState)(match);
    (0, import_react2.useEffect)(() => {
      if (typeof document !== "undefined") {
        const handler = () => update(match);
        window.addEventListener("resize", handler);
        return () => window.removeEventListener("resize", handler);
      }
    }, none);
    return value;
  }

  // node_modules/piral-core/lib/components/components.js
  function getPiralComponent(name) {
    return (props) => {
      const Component4 = useGlobalState((s) => s.components[name]);
      return Component4 ? React2.createElement(Component4, { ...props }) : null;
    };
  }
  var RegisteredErrorInfo = getPiralComponent("ErrorInfo");
  var RegisteredLoadingIndicator = getPiralComponent("LoadingIndicator");
  var RegisteredRouter = getPiralComponent("Router");
  var RegisteredRouteSwitch = getPiralComponent("RouteSwitch");
  var RegisteredLayout = getPiralComponent("Layout");
  var RegisteredDebug = getPiralComponent("Debug");

  // node_modules/piral-core/lib/components/ErrorBoundary.js
  var React5 = __toESM(require_react());

  // node_modules/piral-core/lib/utils/compare.js
  function compareObjects(a, b) {
    for (const i in a) {
      if (!(i in b)) {
        return false;
      }
    }
    for (const i in b) {
      if (!isSame(a[i], b[i])) {
        return false;
      }
    }
    return true;
  }
  function compareArrays(a, b) {
    const l = a.length;
    if (l === b.length) {
      for (let i = 0; i < l; i++) {
        if (!isSame(a[i], b[i])) {
          return false;
        }
      }
      return true;
    }
    return false;
  }
  function isSame(a, b) {
    if (a !== b) {
      const ta = typeof a;
      const tb = typeof b;
      if (ta === tb && ta === "object" && a && b) {
        if (Array.isArray(a) && Array.isArray(b)) {
          return compareArrays(a, b);
        } else {
          return compareObjects(a, b);
        }
      }
      return false;
    }
    return true;
  }

  // node_modules/piral-core/lib/utils/data.js
  var defaultTarget = "memory";
  function createDataOptions(options = defaultTarget) {
    if (typeof options === "string") {
      return {
        target: options
      };
    } else if (options && typeof options === "object" && !Array.isArray(options)) {
      return options;
    } else {
      return {
        target: defaultTarget
      };
    }
  }
  function getDataExpiration(expires) {
    if (typeof expires === "number") {
      return expires;
    } else if (expires instanceof Date) {
      return expires.valueOf();
    }
    return -1;
  }

  // node_modules/piral-core/lib/utils/extension.js
  var React3 = __toESM(require_react());
  function removeAll(nodes) {
    nodes.forEach((node) => node.remove());
  }
  var SlotCarrier = ({ nodes }) => {
    const host = React3.useRef();
    React3.useEffect(() => {
      host.current?.append(...nodes);
      return () => removeAll(nodes);
    }, [nodes]);
    if (nodes.length) {
      return React3.createElement("piral-slot", { ref: host });
    }
    return null;
  };
  function toExtension(Component4) {
    return (props) => React3.createElement(Component4, { ...props.params });
  }
  function reactifyContent(childNodes) {
    const nodes = Array.prototype.filter.call(childNodes, Boolean);
    removeAll(nodes);
    return React3.createElement(SlotCarrier, { nodes });
  }

  // node_modules/piral-core/lib/utils/foreign.js
  var import_react3 = __toESM(require_react());
  var import_react_dom = __toESM(require_react_dom());
  var extensionName = "piral-extension";
  var componentName = "piral-component";
  var contentName = "piral-content";
  var portalName = "piral-portal";
  var slotName = "piral-slot";
  function attachDomPortal(id, context2, element, component, props) {
    const portal = (0, import_react_dom.createPortal)((0, import_react3.createElement)(component, props), element);
    context2.showPortal(id, portal);
    return [id, portal];
  }
  function changeDomPortal(id, current, context2, element, component, props) {
    const next = (0, import_react_dom.createPortal)((0, import_react3.createElement)(component, props), element);
    context2.updatePortal(id, current, next);
    return [id, next];
  }
  function convertComponent(converter, component) {
    if (typeof converter !== "function") {
      throw new Error(`No converter for component of type "${component.type}" registered.`);
    }
    return converter(component);
  }
  function renderInDom(context2, element, component, props) {
    const portalId = "pid";
    let parent = element;
    while (parent) {
      if (parent instanceof Element && parent.localName === portalName && parent.hasAttribute(portalId)) {
        const id = parent.getAttribute(portalId);
        return attachDomPortal(id, context2, element, component, props);
      }
      parent = parent.parentNode || parent.host;
    }
    return attachDomPortal("root", context2, element, component, props);
  }
  function defer(cb) {
    setTimeout(cb, 0);
  }

  // node_modules/piral-core/lib/utils/guid.js
  function rand(c) {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  }
  function generateId() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, rand);
  }
  function buildName(prefix2, name) {
    return `${prefix2}://${name}`;
  }

  // node_modules/piral-core/lib/utils/react.js
  var React4 = __toESM(require_react());
  function defaultRender(children, key) {
    return React4.createElement(React4.Fragment, { key }, children);
  }

  // node_modules/piral-core/lib/utils/routes.js
  var defaultDelimiter = escapeString("/");
  var pathExpr = new RegExp([
    "(\\\\.)",
    "([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))"
  ].join("|"), "g");
  function escapeString(str) {
    return str.replace(/([.+*?=^!:${}()[\]|\/\\])/g, "\\$1");
  }
  function escapeGroup(group) {
    return group.replace(/([=!:$\/()])/g, "\\$1");
  }
  function parse(str) {
    const tokens = [];
    let key = 0;
    let index = 0;
    let path = "";
    let res;
    while ((res = pathExpr.exec(str)) !== null) {
      const m = res[0];
      const escaped = res[1];
      const offset = res.index;
      path += str.slice(index, offset);
      index = offset + m.length;
      if (escaped) {
        path += escaped[1];
        continue;
      }
      const next = str[index];
      const prefix2 = res[2];
      const name = res[3];
      const capture = res[4];
      const group = res[5];
      const modifier = res[6];
      const asterisk = res[7];
      if (path) {
        tokens.push(path);
        path = "";
      }
      const partial = prefix2 != null && next != null && next !== prefix2;
      const repeat = modifier === "+" || modifier === "*";
      const optional = modifier === "?" || modifier === "*";
      const delimiter = res[2] || "/";
      const pattern = capture || group;
      tokens.push({
        name: name || `${key++}`,
        prefix: prefix2 || "",
        delimiter,
        optional,
        repeat,
        partial,
        asterisk: !!asterisk,
        pattern: pattern ? escapeGroup(pattern) : asterisk ? ".*" : "[^" + escapeString(delimiter) + "]+?"
      });
    }
    if (index < str.length) {
      path += str.substring(index);
    }
    if (path) {
      tokens.push(path);
    }
    return tokens;
  }
  function tokensToRegExp(tokens) {
    let route = "";
    for (const token of tokens) {
      if (typeof token === "string") {
        route += escapeString(token);
      } else {
        const prefix2 = escapeString(token.prefix);
        let capture = "(?:" + token.pattern + ")";
        if (token.repeat) {
          capture += "(?:" + prefix2 + capture + ")*";
        }
        if (token.optional) {
          if (!token.partial) {
            capture = "(?:" + prefix2 + "(" + capture + "))?";
          } else {
            capture = prefix2 + "(" + capture + ")?";
          }
        } else {
          capture = prefix2 + "(" + capture + ")";
        }
        route += capture;
      }
    }
    const endsWithDelimiter = route.slice(-defaultDelimiter.length) === defaultDelimiter;
    const path = endsWithDelimiter ? route.slice(0, -defaultDelimiter.length) : route;
    return new RegExp(`^${path}(?:${defaultDelimiter}(?=$))?$`, "i");
  }
  function stringToRegexp(path) {
    return tokensToRegExp(parse(path));
  }
  function createRouteMatcher(path) {
    return stringToRegexp(path);
  }

  // node_modules/piral-core/lib/utils/state.js
  var import_react4 = __toESM(require_react());
  function withAll(...dispatchers) {
    return (state) => {
      for (const dispatcher of dispatchers) {
        state = dispatcher(state);
      }
      return state;
    };
  }
  function withPage(name, value) {
    return (state) => ({
      ...state,
      registry: {
        ...state.registry,
        pages: withKey(state.registry.pages, name, value)
      }
    });
  }
  function withoutPage(name) {
    return (state) => ({
      ...state,
      registry: {
        ...state.registry,
        pages: withoutKey(state.registry.pages, name)
      }
    });
  }
  function withExtension(name, value) {
    return (state) => ({
      ...state,
      registry: {
        ...state.registry,
        extensions: withKey(state.registry.extensions, name, appendItem(state.registry.extensions[name], value))
      }
    });
  }
  function withoutExtension(name, reference) {
    return (state) => ({
      ...state,
      registry: {
        ...state.registry,
        extensions: withKey(state.registry.extensions, name, excludeOn(state.registry.extensions[name], (m) => m.reference === reference))
      }
    });
  }
  function withRootExtension(name, component) {
    return withExtension(name, {
      component: toExtension(component),
      defaults: {},
      pilet: "",
      reference: component
    });
  }
  function withProvider(provider) {
    const wrapper = (props) => (0, import_react4.cloneElement)(provider, props);
    return (state) => ({
      ...state,
      provider: !state.provider ? wrapper : (props) => (0, import_react4.createElement)(state.provider, void 0, wrapper(props))
    });
  }
  function withRoute(path, component) {
    return (state) => ({
      ...state,
      routes: withKey(state.routes, path, component)
    });
  }

  // node_modules/piral-core/lib/components/ErrorBoundary.js
  var ErrorBoundary = class extends React5.Component {
    constructor() {
      super(...arguments);
      this.state = {
        error: void 0
      };
    }
    componentDidCatch(error) {
      const { piral, errorType } = this.props;
      const pilet = piral.meta.name;
      console.error(`[${pilet}] Exception in component of type "${errorType}".`, error);
      this.setState({
        error
      });
    }
    componentDidUpdate(_, prevState) {
      const { error } = this.state;
      if (error && !prevState.error) {
        const { piral, errorType } = this.props;
        const pilet = piral.meta.name;
        defer(() => {
          piral.emit("unhandled-error", {
            errorType,
            error,
            pilet
          });
        });
      }
    }
    render() {
      const { children, piral, errorType, ...renderProps } = this.props;
      const { error } = this.state;
      const rest = renderProps;
      if (error) {
        const pilet = piral.meta.name;
        return React5.createElement(RegisteredErrorInfo, { type: errorType, error, pilet, ...rest });
      }
      return React5.createElement(React5.Suspense, { fallback: React5.createElement(RegisteredLoadingIndicator, null) }, children);
    }
  };

  // node_modules/piral-core/lib/components/ExtensionSlot.js
  var React6 = __toESM(require_react());
  function defaultOrder(extensions) {
    return extensions;
  }
  function ExtensionSlot(props) {
    const { name, render = defaultRender, empty, params, children, emptySkipsRender = false, order = defaultOrder } = props;
    const extensions = useGlobalState((s) => s.registry.extensions[name] || none);
    const isEmpty = extensions.length === 0 && isfunc(empty);
    const content = isEmpty ? [defaultRender(empty(params), "empty")] : order(extensions).map(({ component: Component4, reference, defaults = {} }, i) => React6.createElement(Component4, { key: `${reference?.displayName || "_"}${i}`, children, params: {
      ...defaults,
      ...params
    } }));
    if (isEmpty && emptySkipsRender) {
      return content[0];
    }
    return render(content);
  }
  ExtensionSlot.displayName = `ExtensionSlot`;

  // node_modules/piral-core/lib/components/Mediator.js
  var React7 = __toESM(require_react());
  var Mediator = ({ options }) => {
    const { initialize: initialize2, readState: readState2, emit } = useGlobalStateContext();
    React7.useEffect(() => {
      const shouldLoad = readState2((s) => s.app.loading);
      if (shouldLoad) {
        const { connect: connect2, disconnect } = startLoadingPilets(options);
        emit("loading-pilets", { options });
        const notifier = (error, pilets, loaded) => {
          initialize2(!loaded, error, pilets);
          if (loaded) {
            emit("loaded-pilets", { pilets, error });
          }
        };
        connect2(notifier);
        return () => disconnect(notifier);
      }
    }, none);
    return null;
  };

  // node_modules/piral-core/lib/components/PiralGlobals.js
  var React8 = __toESM(require_react());

  // node_modules/piral-core/lib/components/PortalRenderer.js
  var PortalRenderer = ({ id }) => {
    const children = useGlobalState((m) => m.portals[id]) || none;
    return defaultRender(children);
  };

  // node_modules/piral-core/lib/components/PiralGlobals.js
  var PiralGlobals = () => {
    return React8.createElement(
      React8.Fragment,
      null,
      React8.createElement(PortalRenderer, { id: "root" }),
      React8.createElement(RegisteredDebug, null)
    );
  };

  // node_modules/piral-core/lib/components/PiralRoutes.js
  var React19 = __toESM(require_react());

  // src/errors/index.ts
  var errors_exports = {};
  __export(errors_exports, {
    ApiError: () => ApiError,
    ForbiddenError: () => ForbiddenError,
    JsonError: () => JsonError
  });
  var ApiError = class _ApiError extends Error {
    constructor(code, message, body) {
      super(message);
      if (Error.captureStackTrace) {
        Error.captureStackTrace(this, _ApiError);
      }
      this.name = "ApiError";
      this.code = code;
      if (typeof body !== "undefined") {
        this.body = body;
      }
    }
  };
  var ForbiddenError = class _ForbiddenError extends ApiError {
    constructor(code, message, body) {
      super(code, message, body);
      if (Error.captureStackTrace) {
        Error.captureStackTrace(this, _ForbiddenError);
      }
      this.name = "ForbiddenError";
    }
  };
  var JsonError = class _JsonError extends ApiError {
    constructor(code, message, body) {
      super(code, message, body);
      if (Error.captureStackTrace) {
        Error.captureStackTrace(this, _JsonError);
      }
      this.name = "JsonError";
    }
  };

  // src/logo.tsx
  var logo_exports = {};
  __export(logo_exports, {
    Logo: () => Logo
  });
  var import_react5 = __toESM(require_react());
  var Logo = () => {
    return /* @__PURE__ */ import_react5.default.createElement(
      "svg",
      {
        width: "222",
        height: "34",
        viewBox: "0 0 222 34",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ import_react5.default.createElement("title", null, "Silverstripe Search"),
      /* @__PURE__ */ import_react5.default.createElement("g", { clipPath: "url(#clip0_90_3353)" }, /* @__PURE__ */ import_react5.default.createElement(
        "path",
        {
          d: "M13.3287 6.8455L4.03951 16.0996C2.33937 17.7933 2.33937 20.5394 4.03951 22.2331L13.3287 31.4872C15.0289 33.1809 17.7853 33.1809 19.4855 31.4872L28.7747 22.2331C30.4747 20.5394 30.4747 17.7933 28.7747 16.0996L19.4855 6.8455C17.7853 5.15176 15.0289 5.15176 13.3287 6.8455Z",
          fill: "white",
          fillOpacity: "0.4"
        }
      ), /* @__PURE__ */ import_react5.default.createElement(
        "path",
        {
          d: "M13.2566 18.1536C9.44066 14.1597 9.58496 7.82863 13.5788 4.01271C17.5727 0.196805 23.9038 0.341079 27.7197 4.33496C31.5355 8.32884 31.3914 14.66 27.3975 18.4759C23.4036 22.2917 17.0725 22.1475 13.2566 18.1536ZM16.215 15.327C18.4699 17.6869 22.2108 17.7722 24.5708 15.5174C26.9308 13.2626 27.0163 9.52139 24.7614 7.1614C22.5066 4.80139 18.7654 4.71634 16.4055 6.9712C14.0455 9.22603 13.9602 12.967 16.215 15.327ZM0.407174 26.5754C0.342551 26.5077 0.3072 26.417 0.309159 26.3233C0.311137 26.2296 0.350127 26.1405 0.417506 26.0756L6.76282 19.9675C7.0643 19.6773 7.41978 19.4496 7.80894 19.2972C8.19808 19.1449 8.61327 19.071 9.03086 19.0797C9.44848 19.0884 9.86048 19.1796 10.243 19.348C10.6254 19.5165 10.971 19.759 11.2601 20.0616L12.4687 21.3266C12.5333 21.3942 12.5685 21.4848 12.5666 21.5785C12.5646 21.6722 12.5258 21.7614 12.4584 21.8263L7.37597 26.7187C6.43245 27.6269 5.16811 28.1216 3.86124 28.0942C2.55436 28.0669 1.31195 27.5197 0.407233 26.5728L0.407174 26.5754Z",
          fill: "white"
        }
      )),
      /* @__PURE__ */ import_react5.default.createElement(
        "path",
        {
          d: "M217.597 12.049C220.169 12.049 221.862 13.7638 221.862 16.5779V23.3274H219.949V16.6878C219.949 14.8851 218.916 13.8737 217.223 13.8737C215.464 13.8737 214.035 14.907 214.035 17.5013V23.3274H212.123V7.93774H214.035V13.9177C214.849 12.6206 216.058 12.049 217.597 12.049Z",
          fill: "white"
        }
      ),
      /* @__PURE__ */ import_react5.default.createElement(
        "path",
        {
          d: "M205.286 23.6133C201.967 23.6133 199.504 21.085 199.504 17.8312C199.504 14.5774 201.967 12.0491 205.286 12.0491C207.463 12.0491 209.31 13.1923 210.145 14.9291L208.54 15.8525C207.991 14.6873 206.759 13.9178 205.286 13.9178C203.088 13.9178 201.417 15.6107 201.417 17.8312C201.417 20.0297 203.088 21.7225 205.286 21.7225C206.781 21.7225 207.991 20.9531 208.606 19.8098L210.233 20.7552C209.31 22.47 207.441 23.6133 205.286 23.6133Z",
          fill: "white"
        }
      ),
      /* @__PURE__ */ import_react5.default.createElement(
        "path",
        {
          d: "M195.421 14.1816C196.124 12.6426 197.465 12.137 198.85 12.137V14.1376C197.201 14.0717 195.421 14.9071 195.421 17.5013V23.3274H193.508V12.3348H195.421V14.1816Z",
          fill: "white"
        }
      ),
      /* @__PURE__ */ import_react5.default.createElement(
        "path",
        {
          d: "M188.697 12.3349H190.61V23.3275H188.697V21.4367C187.818 22.7778 186.41 23.6133 184.542 23.6133C181.486 23.6133 178.979 21.085 178.979 17.8312C178.979 14.5774 181.486 12.0491 184.542 12.0491C186.41 12.0491 187.818 12.8845 188.697 14.2256V12.3349ZM184.784 21.7665C187.004 21.7665 188.697 20.0737 188.697 17.8312C188.697 15.5887 187.004 13.8958 184.784 13.8958C182.585 13.8958 180.892 15.5887 180.892 17.8312C180.892 20.0737 182.585 21.7665 184.784 21.7665Z",
          fill: "white"
        }
      ),
      /* @__PURE__ */ import_react5.default.createElement(
        "path",
        {
          d: "M168.14 18.7106C168.514 20.6892 170.075 21.8105 172.12 21.8105C173.637 21.8105 174.736 21.107 175.285 20.2056L176.912 21.1289C175.945 22.6239 174.274 23.6133 172.076 23.6133C168.536 23.6133 166.184 21.1289 166.184 17.8312C166.184 14.5774 168.514 12.0491 171.944 12.0491C175.263 12.0491 177.418 14.7752 177.418 17.8532C177.418 18.139 177.396 18.4248 177.352 18.7106H168.14ZM171.944 13.8519C169.877 13.8519 168.448 15.127 168.14 17.0397H175.483C175.154 14.8632 173.593 13.8519 171.944 13.8519Z",
          fill: "white"
        }
      ),
      /* @__PURE__ */ import_react5.default.createElement(
        "path",
        {
          d: "M158.998 23.6133C156.074 23.6133 153.985 22.1403 153.172 19.8319L154.931 18.8206C155.48 20.5134 156.799 21.6127 159.042 21.6127C161.218 21.6127 162.296 20.6233 162.296 19.2383C162.296 17.6554 160.933 17.1277 158.668 16.4242C156.206 15.6327 153.831 14.8632 153.831 12.0052C153.831 9.23503 156.096 7.6521 158.668 7.6521C161.196 7.6521 163.021 9.08114 163.879 11.0158L162.164 12.0052C161.614 10.6861 160.537 9.63077 158.668 9.63077C157.019 9.63077 155.876 10.5102 155.876 11.9172C155.876 13.3463 156.953 13.8739 159.108 14.5554C161.79 15.4348 164.318 16.2263 164.318 19.1943C164.318 21.8985 162.142 23.6133 158.998 23.6133Z",
          fill: "white"
        }
      ),
      /* @__PURE__ */ import_react5.default.createElement(
        "path",
        {
          d: "M130.395 11.9379C133.385 11.9379 135.839 14.4583 135.84 17.724C135.84 20.9898 133.385 23.5121 130.395 23.5121C128.767 23.512 127.584 22.9197 126.78 21.9115V27.2855H123.902V12.2445H126.782V13.5375C127.584 12.5292 128.767 11.9379 130.395 11.9379ZM44.9675 7.35193C47.4939 7.35194 49.6306 8.53687 50.7332 10.5922L48.3181 12.2504C47.636 11.0654 46.3536 10.336 44.9675 10.3441C43.6502 10.3441 42.8768 11.0135 42.8767 11.9066C42.8767 12.8665 43.4902 13.38 45.8992 14.0951C48.4216 14.876 51.108 15.7019 51.1072 18.8949C51.1072 21.8201 48.7213 23.6068 45.3347 23.6068C42.1779 23.6067 40.0723 21.9886 39.1628 19.7679L41.6394 18.0677C42.2444 19.4398 43.5407 20.5921 45.4265 20.5922C47.3124 20.5922 47.9714 19.8116 47.9714 18.9408C47.9714 17.7796 46.9046 17.3321 44.5398 16.6625C42.11 15.9706 39.7449 14.9661 39.7449 11.9965C39.745 9.04819 42.2412 7.35193 44.9675 7.35193ZM78.9167 11.9398C82.1367 11.9399 84.4206 14.5038 84.4207 17.726C84.419 18.1154 84.3824 18.504 84.3113 18.8871L76.1111 18.8861C76.5052 20.3375 77.6986 20.9466 79.1775 20.9467C80.2612 20.9467 81.1927 20.3226 81.6716 19.6888L83.7722 21.1752C82.7495 22.6661 81.2222 23.514 79.1345 23.514C75.4799 23.514 73.1746 20.9928 73.1746 17.726C73.1746 14.4592 75.5016 11.9398 78.9167 11.9398ZM142.683 11.9398C145.902 11.9398 148.187 14.5037 148.187 17.726C148.185 18.1153 148.149 18.5039 148.079 18.8871L139.878 18.8861C140.272 20.3376 141.466 20.9467 142.945 20.9467C144.029 20.9466 144.96 20.3226 145.438 19.6888L147.539 21.1752C146.517 22.6663 144.989 23.514 142.901 23.514C139.247 23.5138 136.941 20.9926 136.941 17.726C136.941 14.4594 139.268 11.94 142.683 11.9398ZM97.4324 11.9379C99.1771 11.938 100.69 12.6954 101.577 14.1097L99.4167 15.5541C98.9759 14.894 98.2357 14.4852 97.4324 14.4584C96.719 14.4584 96.1384 14.7656 96.1384 15.3578C96.1395 16.979 101.891 15.9714 101.896 20.0043C101.896 22.372 99.7983 23.5121 97.4109 23.5121C95.2159 23.512 93.5842 22.6178 92.7673 20.9818L95.0818 19.433C95.4743 20.354 96.3942 20.9516 97.4109 20.9457C98.3262 20.9457 98.9508 20.6389 98.9509 20.0033C98.9509 18.4028 93.1951 19.2802 93.1951 15.4213C93.1951 13.1869 95.1346 11.9379 97.4324 11.9379ZM107.115 12.2445H109.637V14.9623H107.115V19.5219C107.115 20.7053 107.985 20.7281 109.636 20.64V23.2054C105.597 23.6437 104.237 22.4809 104.237 19.5219V14.9623H102.296V12.2445H104.237V10.0306L107.115 8.07751V12.2445ZM55.4851 23.2054H52.6072V12.2445H55.4851V23.2054ZM60.5574 23.2054H57.6794V6.71423H60.5574V23.2054ZM67.5574 19.9164L70.1296 12.2445H73.2986L69.2087 23.2054H65.9285L61.8386 12.2445H65.0076L67.5574 19.9164ZM92.116 15.181C90.6202 15.0059 88.7244 15.6651 88.7244 17.9652V23.2054H85.8464V12.2445H88.7244V14.1293C89.3038 12.6382 90.7099 12.0248 92.116 12.0248V15.181ZM117.41 15.181C115.915 15.0059 114.018 15.6651 114.018 17.9652V23.2054H111.139V12.2445H114.018V14.1293C114.599 12.6383 116.004 12.0248 117.41 12.0248V15.181ZM121.86 23.2054H118.981V12.2445H121.86V23.2054ZM129.859 14.6332C128.096 14.6332 126.78 15.8826 126.78 17.724C126.78 19.5654 128.096 20.8148 129.859 20.8148C131.645 20.8148 132.961 19.5655 132.961 17.724C132.961 15.8826 131.645 14.6332 129.859 14.6332ZM78.9167 14.4818C77.4171 14.4799 76.3943 15.2916 76.0671 16.6957H81.614C81.2662 15.1175 80.0922 14.4819 78.9167 14.4818ZM142.684 14.4799C141.184 14.4799 140.161 15.2908 139.835 16.6937H145.382C145.033 15.1157 143.859 14.48 142.684 14.4799ZM54.0359 7.44373C55.0174 7.45432 55.8104 8.23371 55.821 9.19763C55.8084 10.157 55.0129 10.9281 54.0359 10.9281C53.0669 10.9181 52.284 10.1492 52.2742 9.19763C52.2742 8.25513 53.0772 7.44373 54.0359 7.44373ZM120.409 7.44373C121.39 7.45472 122.182 8.234 122.193 9.19763C122.18 10.1567 121.386 10.9276 120.409 10.9281C119.44 10.9186 118.656 10.1496 118.646 9.19763C118.646 8.25517 119.449 7.44378 120.409 7.44373Z",
          fill: "white"
        }
      ),
      /* @__PURE__ */ import_react5.default.createElement("defs", null, /* @__PURE__ */ import_react5.default.createElement("clipPath", { id: "clip0_90_3353" }, /* @__PURE__ */ import_react5.default.createElement(
        "rect",
        {
          width: "30.8969",
          height: "32.1328",
          fill: "white",
          transform: "translate(0 0.933594)"
        }
      )))
    );
  };

  // node_modules/piral-core/app.codegen
  var _2 = __toESM(require_lib());

  // node_modules/formik/dist/formik.esm.js
  var formik_esm_exports = {};
  __export(formik_esm_exports, {
    ErrorMessage: () => ErrorMessage,
    FastField: () => FastField,
    Field: () => Field,
    FieldArray: () => FieldArray,
    Form: () => Form,
    Formik: () => Formik,
    FormikConsumer: () => FormikConsumer,
    FormikContext: () => FormikContext,
    FormikProvider: () => FormikProvider,
    connect: () => connect,
    getActiveElement: () => getActiveElement,
    getIn: () => getIn,
    insert: () => insert,
    isEmptyArray: () => isEmptyArray,
    isEmptyChildren: () => isEmptyChildren,
    isFunction: () => isFunction2,
    isInputEvent: () => isInputEvent,
    isInteger: () => isInteger,
    isNaN: () => isNaN$1,
    isObject: () => isObject2,
    isPromise: () => isPromise,
    isString: () => isString,
    move: () => move,
    prepareDataForValidation: () => prepareDataForValidation,
    replace: () => replace,
    setIn: () => setIn,
    setNestedObjectValues: () => setNestedObjectValues,
    swap: () => swap,
    useField: () => useField,
    useFormik: () => useFormik,
    useFormikContext: () => useFormikContext,
    validateYupSchema: () => validateYupSchema,
    withFormik: () => withFormik,
    yupToFormErrors: () => yupToFormErrors
  });

  // node_modules/deepmerge/dist/es.js
  var isMergeableObject = function isMergeableObject2(value) {
    return isNonNullObject(value) && !isSpecial(value);
  };
  function isNonNullObject(value) {
    return !!value && typeof value === "object";
  }
  function isSpecial(value) {
    var stringValue = Object.prototype.toString.call(value);
    return stringValue === "[object RegExp]" || stringValue === "[object Date]" || isReactElement(value);
  }
  var canUseSymbol = typeof Symbol === "function" && Symbol.for;
  var REACT_ELEMENT_TYPE = canUseSymbol ? Symbol.for("react.element") : 60103;
  function isReactElement(value) {
    return value.$$typeof === REACT_ELEMENT_TYPE;
  }
  function emptyTarget(val) {
    return Array.isArray(val) ? [] : {};
  }
  function cloneUnlessOtherwiseSpecified(value, options) {
    return options.clone !== false && options.isMergeableObject(value) ? deepmerge(emptyTarget(value), value, options) : value;
  }
  function defaultArrayMerge(target, source, options) {
    return target.concat(source).map(function(element) {
      return cloneUnlessOtherwiseSpecified(element, options);
    });
  }
  function mergeObject(target, source, options) {
    var destination = {};
    if (options.isMergeableObject(target)) {
      Object.keys(target).forEach(function(key) {
        destination[key] = cloneUnlessOtherwiseSpecified(target[key], options);
      });
    }
    Object.keys(source).forEach(function(key) {
      if (!options.isMergeableObject(source[key]) || !target[key]) {
        destination[key] = cloneUnlessOtherwiseSpecified(source[key], options);
      } else {
        destination[key] = deepmerge(target[key], source[key], options);
      }
    });
    return destination;
  }
  function deepmerge(target, source, options) {
    options = options || {};
    options.arrayMerge = options.arrayMerge || defaultArrayMerge;
    options.isMergeableObject = options.isMergeableObject || isMergeableObject;
    var sourceIsArray = Array.isArray(source);
    var targetIsArray = Array.isArray(target);
    var sourceAndTargetTypesMatch = sourceIsArray === targetIsArray;
    if (!sourceAndTargetTypesMatch) {
      return cloneUnlessOtherwiseSpecified(source, options);
    } else if (sourceIsArray) {
      return options.arrayMerge(target, source, options);
    } else {
      return mergeObject(target, source, options);
    }
  }
  deepmerge.all = function deepmergeAll(array, options) {
    if (!Array.isArray(array)) {
      throw new Error("first argument should be an array");
    }
    return array.reduce(function(prev, next) {
      return deepmerge(prev, next, options);
    }, {});
  };
  var deepmerge_1 = deepmerge;
  var es_default = deepmerge_1;

  // node_modules/lodash-es/_freeGlobal.js
  var freeGlobal = typeof global == "object" && global && global.Object === Object && global;
  var freeGlobal_default = freeGlobal;

  // node_modules/lodash-es/_root.js
  var freeSelf = typeof self == "object" && self && self.Object === Object && self;
  var root = freeGlobal_default || freeSelf || Function("return this")();
  var root_default = root;

  // node_modules/lodash-es/_Symbol.js
  var Symbol2 = root_default.Symbol;
  var Symbol_default = Symbol2;

  // node_modules/lodash-es/_getRawTag.js
  var objectProto = Object.prototype;
  var hasOwnProperty = objectProto.hasOwnProperty;
  var nativeObjectToString = objectProto.toString;
  var symToStringTag = Symbol_default ? Symbol_default.toStringTag : void 0;
  function getRawTag(value) {
    var isOwn = hasOwnProperty.call(value, symToStringTag), tag = value[symToStringTag];
    try {
      value[symToStringTag] = void 0;
      var unmasked = true;
    } catch (e) {
    }
    var result = nativeObjectToString.call(value);
    if (unmasked) {
      if (isOwn) {
        value[symToStringTag] = tag;
      } else {
        delete value[symToStringTag];
      }
    }
    return result;
  }
  var getRawTag_default = getRawTag;

  // node_modules/lodash-es/_objectToString.js
  var objectProto2 = Object.prototype;
  var nativeObjectToString2 = objectProto2.toString;
  function objectToString(value) {
    return nativeObjectToString2.call(value);
  }
  var objectToString_default = objectToString;

  // node_modules/lodash-es/_baseGetTag.js
  var nullTag = "[object Null]";
  var undefinedTag = "[object Undefined]";
  var symToStringTag2 = Symbol_default ? Symbol_default.toStringTag : void 0;
  function baseGetTag(value) {
    if (value == null) {
      return value === void 0 ? undefinedTag : nullTag;
    }
    return symToStringTag2 && symToStringTag2 in Object(value) ? getRawTag_default(value) : objectToString_default(value);
  }
  var baseGetTag_default = baseGetTag;

  // node_modules/lodash-es/_overArg.js
  function overArg(func, transform) {
    return function(arg) {
      return func(transform(arg));
    };
  }
  var overArg_default = overArg;

  // node_modules/lodash-es/_getPrototype.js
  var getPrototype = overArg_default(Object.getPrototypeOf, Object);
  var getPrototype_default = getPrototype;

  // node_modules/lodash-es/isObjectLike.js
  function isObjectLike(value) {
    return value != null && typeof value == "object";
  }
  var isObjectLike_default = isObjectLike;

  // node_modules/lodash-es/isPlainObject.js
  var objectTag = "[object Object]";
  var funcProto = Function.prototype;
  var objectProto3 = Object.prototype;
  var funcToString = funcProto.toString;
  var hasOwnProperty2 = objectProto3.hasOwnProperty;
  var objectCtorString = funcToString.call(Object);
  function isPlainObject(value) {
    if (!isObjectLike_default(value) || baseGetTag_default(value) != objectTag) {
      return false;
    }
    var proto = getPrototype_default(value);
    if (proto === null) {
      return true;
    }
    var Ctor = hasOwnProperty2.call(proto, "constructor") && proto.constructor;
    return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString.call(Ctor) == objectCtorString;
  }
  var isPlainObject_default = isPlainObject;

  // node_modules/lodash-es/_listCacheClear.js
  function listCacheClear() {
    this.__data__ = [];
    this.size = 0;
  }
  var listCacheClear_default = listCacheClear;

  // node_modules/lodash-es/eq.js
  function eq(value, other) {
    return value === other || value !== value && other !== other;
  }
  var eq_default = eq;

  // node_modules/lodash-es/_assocIndexOf.js
  function assocIndexOf(array, key) {
    var length = array.length;
    while (length--) {
      if (eq_default(array[length][0], key)) {
        return length;
      }
    }
    return -1;
  }
  var assocIndexOf_default = assocIndexOf;

  // node_modules/lodash-es/_listCacheDelete.js
  var arrayProto = Array.prototype;
  var splice = arrayProto.splice;
  function listCacheDelete(key) {
    var data = this.__data__, index = assocIndexOf_default(data, key);
    if (index < 0) {
      return false;
    }
    var lastIndex = data.length - 1;
    if (index == lastIndex) {
      data.pop();
    } else {
      splice.call(data, index, 1);
    }
    --this.size;
    return true;
  }
  var listCacheDelete_default = listCacheDelete;

  // node_modules/lodash-es/_listCacheGet.js
  function listCacheGet(key) {
    var data = this.__data__, index = assocIndexOf_default(data, key);
    return index < 0 ? void 0 : data[index][1];
  }
  var listCacheGet_default = listCacheGet;

  // node_modules/lodash-es/_listCacheHas.js
  function listCacheHas(key) {
    return assocIndexOf_default(this.__data__, key) > -1;
  }
  var listCacheHas_default = listCacheHas;

  // node_modules/lodash-es/_listCacheSet.js
  function listCacheSet(key, value) {
    var data = this.__data__, index = assocIndexOf_default(data, key);
    if (index < 0) {
      ++this.size;
      data.push([key, value]);
    } else {
      data[index][1] = value;
    }
    return this;
  }
  var listCacheSet_default = listCacheSet;

  // node_modules/lodash-es/_ListCache.js
  function ListCache(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  ListCache.prototype.clear = listCacheClear_default;
  ListCache.prototype["delete"] = listCacheDelete_default;
  ListCache.prototype.get = listCacheGet_default;
  ListCache.prototype.has = listCacheHas_default;
  ListCache.prototype.set = listCacheSet_default;
  var ListCache_default = ListCache;

  // node_modules/lodash-es/_stackClear.js
  function stackClear() {
    this.__data__ = new ListCache_default();
    this.size = 0;
  }
  var stackClear_default = stackClear;

  // node_modules/lodash-es/_stackDelete.js
  function stackDelete(key) {
    var data = this.__data__, result = data["delete"](key);
    this.size = data.size;
    return result;
  }
  var stackDelete_default = stackDelete;

  // node_modules/lodash-es/_stackGet.js
  function stackGet(key) {
    return this.__data__.get(key);
  }
  var stackGet_default = stackGet;

  // node_modules/lodash-es/_stackHas.js
  function stackHas(key) {
    return this.__data__.has(key);
  }
  var stackHas_default = stackHas;

  // node_modules/lodash-es/isObject.js
  function isObject(value) {
    var type = typeof value;
    return value != null && (type == "object" || type == "function");
  }
  var isObject_default = isObject;

  // node_modules/lodash-es/isFunction.js
  var asyncTag = "[object AsyncFunction]";
  var funcTag = "[object Function]";
  var genTag = "[object GeneratorFunction]";
  var proxyTag = "[object Proxy]";
  function isFunction(value) {
    if (!isObject_default(value)) {
      return false;
    }
    var tag = baseGetTag_default(value);
    return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
  }
  var isFunction_default = isFunction;

  // node_modules/lodash-es/_coreJsData.js
  var coreJsData = root_default["__core-js_shared__"];
  var coreJsData_default = coreJsData;

  // node_modules/lodash-es/_isMasked.js
  var maskSrcKey = (function() {
    var uid = /[^.]+$/.exec(coreJsData_default && coreJsData_default.keys && coreJsData_default.keys.IE_PROTO || "");
    return uid ? "Symbol(src)_1." + uid : "";
  })();
  function isMasked(func) {
    return !!maskSrcKey && maskSrcKey in func;
  }
  var isMasked_default = isMasked;

  // node_modules/lodash-es/_toSource.js
  var funcProto2 = Function.prototype;
  var funcToString2 = funcProto2.toString;
  function toSource(func) {
    if (func != null) {
      try {
        return funcToString2.call(func);
      } catch (e) {
      }
      try {
        return func + "";
      } catch (e) {
      }
    }
    return "";
  }
  var toSource_default = toSource;

  // node_modules/lodash-es/_baseIsNative.js
  var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
  var reIsHostCtor = /^\[object .+?Constructor\]$/;
  var funcProto3 = Function.prototype;
  var objectProto4 = Object.prototype;
  var funcToString3 = funcProto3.toString;
  var hasOwnProperty3 = objectProto4.hasOwnProperty;
  var reIsNative = RegExp(
    "^" + funcToString3.call(hasOwnProperty3).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
  );
  function baseIsNative(value) {
    if (!isObject_default(value) || isMasked_default(value)) {
      return false;
    }
    var pattern = isFunction_default(value) ? reIsNative : reIsHostCtor;
    return pattern.test(toSource_default(value));
  }
  var baseIsNative_default = baseIsNative;

  // node_modules/lodash-es/_getValue.js
  function getValue(object, key) {
    return object == null ? void 0 : object[key];
  }
  var getValue_default = getValue;

  // node_modules/lodash-es/_getNative.js
  function getNative(object, key) {
    var value = getValue_default(object, key);
    return baseIsNative_default(value) ? value : void 0;
  }
  var getNative_default = getNative;

  // node_modules/lodash-es/_Map.js
  var Map2 = getNative_default(root_default, "Map");
  var Map_default = Map2;

  // node_modules/lodash-es/_nativeCreate.js
  var nativeCreate = getNative_default(Object, "create");
  var nativeCreate_default = nativeCreate;

  // node_modules/lodash-es/_hashClear.js
  function hashClear() {
    this.__data__ = nativeCreate_default ? nativeCreate_default(null) : {};
    this.size = 0;
  }
  var hashClear_default = hashClear;

  // node_modules/lodash-es/_hashDelete.js
  function hashDelete(key) {
    var result = this.has(key) && delete this.__data__[key];
    this.size -= result ? 1 : 0;
    return result;
  }
  var hashDelete_default = hashDelete;

  // node_modules/lodash-es/_hashGet.js
  var HASH_UNDEFINED = "__lodash_hash_undefined__";
  var objectProto5 = Object.prototype;
  var hasOwnProperty4 = objectProto5.hasOwnProperty;
  function hashGet(key) {
    var data = this.__data__;
    if (nativeCreate_default) {
      var result = data[key];
      return result === HASH_UNDEFINED ? void 0 : result;
    }
    return hasOwnProperty4.call(data, key) ? data[key] : void 0;
  }
  var hashGet_default = hashGet;

  // node_modules/lodash-es/_hashHas.js
  var objectProto6 = Object.prototype;
  var hasOwnProperty5 = objectProto6.hasOwnProperty;
  function hashHas(key) {
    var data = this.__data__;
    return nativeCreate_default ? data[key] !== void 0 : hasOwnProperty5.call(data, key);
  }
  var hashHas_default = hashHas;

  // node_modules/lodash-es/_hashSet.js
  var HASH_UNDEFINED2 = "__lodash_hash_undefined__";
  function hashSet(key, value) {
    var data = this.__data__;
    this.size += this.has(key) ? 0 : 1;
    data[key] = nativeCreate_default && value === void 0 ? HASH_UNDEFINED2 : value;
    return this;
  }
  var hashSet_default = hashSet;

  // node_modules/lodash-es/_Hash.js
  function Hash(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  Hash.prototype.clear = hashClear_default;
  Hash.prototype["delete"] = hashDelete_default;
  Hash.prototype.get = hashGet_default;
  Hash.prototype.has = hashHas_default;
  Hash.prototype.set = hashSet_default;
  var Hash_default = Hash;

  // node_modules/lodash-es/_mapCacheClear.js
  function mapCacheClear() {
    this.size = 0;
    this.__data__ = {
      "hash": new Hash_default(),
      "map": new (Map_default || ListCache_default)(),
      "string": new Hash_default()
    };
  }
  var mapCacheClear_default = mapCacheClear;

  // node_modules/lodash-es/_isKeyable.js
  function isKeyable(value) {
    var type = typeof value;
    return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
  }
  var isKeyable_default = isKeyable;

  // node_modules/lodash-es/_getMapData.js
  function getMapData(map, key) {
    var data = map.__data__;
    return isKeyable_default(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
  }
  var getMapData_default = getMapData;

  // node_modules/lodash-es/_mapCacheDelete.js
  function mapCacheDelete(key) {
    var result = getMapData_default(this, key)["delete"](key);
    this.size -= result ? 1 : 0;
    return result;
  }
  var mapCacheDelete_default = mapCacheDelete;

  // node_modules/lodash-es/_mapCacheGet.js
  function mapCacheGet(key) {
    return getMapData_default(this, key).get(key);
  }
  var mapCacheGet_default = mapCacheGet;

  // node_modules/lodash-es/_mapCacheHas.js
  function mapCacheHas(key) {
    return getMapData_default(this, key).has(key);
  }
  var mapCacheHas_default = mapCacheHas;

  // node_modules/lodash-es/_mapCacheSet.js
  function mapCacheSet(key, value) {
    var data = getMapData_default(this, key), size = data.size;
    data.set(key, value);
    this.size += data.size == size ? 0 : 1;
    return this;
  }
  var mapCacheSet_default = mapCacheSet;

  // node_modules/lodash-es/_MapCache.js
  function MapCache(entries) {
    var index = -1, length = entries == null ? 0 : entries.length;
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  MapCache.prototype.clear = mapCacheClear_default;
  MapCache.prototype["delete"] = mapCacheDelete_default;
  MapCache.prototype.get = mapCacheGet_default;
  MapCache.prototype.has = mapCacheHas_default;
  MapCache.prototype.set = mapCacheSet_default;
  var MapCache_default = MapCache;

  // node_modules/lodash-es/_stackSet.js
  var LARGE_ARRAY_SIZE = 200;
  function stackSet(key, value) {
    var data = this.__data__;
    if (data instanceof ListCache_default) {
      var pairs = data.__data__;
      if (!Map_default || pairs.length < LARGE_ARRAY_SIZE - 1) {
        pairs.push([key, value]);
        this.size = ++data.size;
        return this;
      }
      data = this.__data__ = new MapCache_default(pairs);
    }
    data.set(key, value);
    this.size = data.size;
    return this;
  }
  var stackSet_default = stackSet;

  // node_modules/lodash-es/_Stack.js
  function Stack(entries) {
    var data = this.__data__ = new ListCache_default(entries);
    this.size = data.size;
  }
  Stack.prototype.clear = stackClear_default;
  Stack.prototype["delete"] = stackDelete_default;
  Stack.prototype.get = stackGet_default;
  Stack.prototype.has = stackHas_default;
  Stack.prototype.set = stackSet_default;
  var Stack_default = Stack;

  // node_modules/lodash-es/_arrayEach.js
  function arrayEach(array, iteratee) {
    var index = -1, length = array == null ? 0 : array.length;
    while (++index < length) {
      if (iteratee(array[index], index, array) === false) {
        break;
      }
    }
    return array;
  }
  var arrayEach_default = arrayEach;

  // node_modules/lodash-es/_defineProperty.js
  var defineProperty = (function() {
    try {
      var func = getNative_default(Object, "defineProperty");
      func({}, "", {});
      return func;
    } catch (e) {
    }
  })();
  var defineProperty_default = defineProperty;

  // node_modules/lodash-es/_baseAssignValue.js
  function baseAssignValue(object, key, value) {
    if (key == "__proto__" && defineProperty_default) {
      defineProperty_default(object, key, {
        "configurable": true,
        "enumerable": true,
        "value": value,
        "writable": true
      });
    } else {
      object[key] = value;
    }
  }
  var baseAssignValue_default = baseAssignValue;

  // node_modules/lodash-es/_assignValue.js
  var objectProto7 = Object.prototype;
  var hasOwnProperty6 = objectProto7.hasOwnProperty;
  function assignValue(object, key, value) {
    var objValue = object[key];
    if (!(hasOwnProperty6.call(object, key) && eq_default(objValue, value)) || value === void 0 && !(key in object)) {
      baseAssignValue_default(object, key, value);
    }
  }
  var assignValue_default = assignValue;

  // node_modules/lodash-es/_copyObject.js
  function copyObject(source, props, object, customizer) {
    var isNew = !object;
    object || (object = {});
    var index = -1, length = props.length;
    while (++index < length) {
      var key = props[index];
      var newValue = customizer ? customizer(object[key], source[key], key, object, source) : void 0;
      if (newValue === void 0) {
        newValue = source[key];
      }
      if (isNew) {
        baseAssignValue_default(object, key, newValue);
      } else {
        assignValue_default(object, key, newValue);
      }
    }
    return object;
  }
  var copyObject_default = copyObject;

  // node_modules/lodash-es/_baseTimes.js
  function baseTimes(n, iteratee) {
    var index = -1, result = Array(n);
    while (++index < n) {
      result[index] = iteratee(index);
    }
    return result;
  }
  var baseTimes_default = baseTimes;

  // node_modules/lodash-es/_baseIsArguments.js
  var argsTag = "[object Arguments]";
  function baseIsArguments(value) {
    return isObjectLike_default(value) && baseGetTag_default(value) == argsTag;
  }
  var baseIsArguments_default = baseIsArguments;

  // node_modules/lodash-es/isArguments.js
  var objectProto8 = Object.prototype;
  var hasOwnProperty7 = objectProto8.hasOwnProperty;
  var propertyIsEnumerable = objectProto8.propertyIsEnumerable;
  var isArguments = baseIsArguments_default(/* @__PURE__ */ (function() {
    return arguments;
  })()) ? baseIsArguments_default : function(value) {
    return isObjectLike_default(value) && hasOwnProperty7.call(value, "callee") && !propertyIsEnumerable.call(value, "callee");
  };
  var isArguments_default = isArguments;

  // node_modules/lodash-es/isArray.js
  var isArray = Array.isArray;
  var isArray_default = isArray;

  // node_modules/lodash-es/stubFalse.js
  function stubFalse() {
    return false;
  }
  var stubFalse_default = stubFalse;

  // node_modules/lodash-es/isBuffer.js
  var freeExports = typeof exports == "object" && exports && !exports.nodeType && exports;
  var freeModule = freeExports && typeof module == "object" && module && !module.nodeType && module;
  var moduleExports = freeModule && freeModule.exports === freeExports;
  var Buffer2 = moduleExports ? root_default.Buffer : void 0;
  var nativeIsBuffer = Buffer2 ? Buffer2.isBuffer : void 0;
  var isBuffer = nativeIsBuffer || stubFalse_default;
  var isBuffer_default = isBuffer;

  // node_modules/lodash-es/_isIndex.js
  var MAX_SAFE_INTEGER = 9007199254740991;
  var reIsUint = /^(?:0|[1-9]\d*)$/;
  function isIndex(value, length) {
    var type = typeof value;
    length = length == null ? MAX_SAFE_INTEGER : length;
    return !!length && (type == "number" || type != "symbol" && reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
  }
  var isIndex_default = isIndex;

  // node_modules/lodash-es/isLength.js
  var MAX_SAFE_INTEGER2 = 9007199254740991;
  function isLength(value) {
    return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER2;
  }
  var isLength_default = isLength;

  // node_modules/lodash-es/_baseIsTypedArray.js
  var argsTag2 = "[object Arguments]";
  var arrayTag = "[object Array]";
  var boolTag = "[object Boolean]";
  var dateTag = "[object Date]";
  var errorTag = "[object Error]";
  var funcTag2 = "[object Function]";
  var mapTag = "[object Map]";
  var numberTag = "[object Number]";
  var objectTag2 = "[object Object]";
  var regexpTag = "[object RegExp]";
  var setTag = "[object Set]";
  var stringTag = "[object String]";
  var weakMapTag = "[object WeakMap]";
  var arrayBufferTag = "[object ArrayBuffer]";
  var dataViewTag = "[object DataView]";
  var float32Tag = "[object Float32Array]";
  var float64Tag = "[object Float64Array]";
  var int8Tag = "[object Int8Array]";
  var int16Tag = "[object Int16Array]";
  var int32Tag = "[object Int32Array]";
  var uint8Tag = "[object Uint8Array]";
  var uint8ClampedTag = "[object Uint8ClampedArray]";
  var uint16Tag = "[object Uint16Array]";
  var uint32Tag = "[object Uint32Array]";
  var typedArrayTags = {};
  typedArrayTags[float32Tag] = typedArrayTags[float64Tag] = typedArrayTags[int8Tag] = typedArrayTags[int16Tag] = typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] = typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] = typedArrayTags[uint32Tag] = true;
  typedArrayTags[argsTag2] = typedArrayTags[arrayTag] = typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] = typedArrayTags[dataViewTag] = typedArrayTags[dateTag] = typedArrayTags[errorTag] = typedArrayTags[funcTag2] = typedArrayTags[mapTag] = typedArrayTags[numberTag] = typedArrayTags[objectTag2] = typedArrayTags[regexpTag] = typedArrayTags[setTag] = typedArrayTags[stringTag] = typedArrayTags[weakMapTag] = false;
  function baseIsTypedArray(value) {
    return isObjectLike_default(value) && isLength_default(value.length) && !!typedArrayTags[baseGetTag_default(value)];
  }
  var baseIsTypedArray_default = baseIsTypedArray;

  // node_modules/lodash-es/_baseUnary.js
  function baseUnary(func) {
    return function(value) {
      return func(value);
    };
  }
  var baseUnary_default = baseUnary;

  // node_modules/lodash-es/_nodeUtil.js
  var freeExports2 = typeof exports == "object" && exports && !exports.nodeType && exports;
  var freeModule2 = freeExports2 && typeof module == "object" && module && !module.nodeType && module;
  var moduleExports2 = freeModule2 && freeModule2.exports === freeExports2;
  var freeProcess = moduleExports2 && freeGlobal_default.process;
  var nodeUtil = (function() {
    try {
      var types = freeModule2 && freeModule2.require && freeModule2.require("util").types;
      if (types) {
        return types;
      }
      return freeProcess && freeProcess.binding && freeProcess.binding("util");
    } catch (e) {
    }
  })();
  var nodeUtil_default = nodeUtil;

  // node_modules/lodash-es/isTypedArray.js
  var nodeIsTypedArray = nodeUtil_default && nodeUtil_default.isTypedArray;
  var isTypedArray = nodeIsTypedArray ? baseUnary_default(nodeIsTypedArray) : baseIsTypedArray_default;
  var isTypedArray_default = isTypedArray;

  // node_modules/lodash-es/_arrayLikeKeys.js
  var objectProto9 = Object.prototype;
  var hasOwnProperty8 = objectProto9.hasOwnProperty;
  function arrayLikeKeys(value, inherited) {
    var isArr = isArray_default(value), isArg = !isArr && isArguments_default(value), isBuff = !isArr && !isArg && isBuffer_default(value), isType = !isArr && !isArg && !isBuff && isTypedArray_default(value), skipIndexes = isArr || isArg || isBuff || isType, result = skipIndexes ? baseTimes_default(value.length, String) : [], length = result.length;
    for (var key in value) {
      if ((inherited || hasOwnProperty8.call(value, key)) && !(skipIndexes && // Safari 9 has enumerable `arguments.length` in strict mode.
      (key == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
      isBuff && (key == "offset" || key == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
      isType && (key == "buffer" || key == "byteLength" || key == "byteOffset") || // Skip index properties.
      isIndex_default(key, length)))) {
        result.push(key);
      }
    }
    return result;
  }
  var arrayLikeKeys_default = arrayLikeKeys;

  // node_modules/lodash-es/_isPrototype.js
  var objectProto10 = Object.prototype;
  function isPrototype(value) {
    var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto10;
    return value === proto;
  }
  var isPrototype_default = isPrototype;

  // node_modules/lodash-es/_nativeKeys.js
  var nativeKeys = overArg_default(Object.keys, Object);
  var nativeKeys_default = nativeKeys;

  // node_modules/lodash-es/_baseKeys.js
  var objectProto11 = Object.prototype;
  var hasOwnProperty9 = objectProto11.hasOwnProperty;
  function baseKeys(object) {
    if (!isPrototype_default(object)) {
      return nativeKeys_default(object);
    }
    var result = [];
    for (var key in Object(object)) {
      if (hasOwnProperty9.call(object, key) && key != "constructor") {
        result.push(key);
      }
    }
    return result;
  }
  var baseKeys_default = baseKeys;

  // node_modules/lodash-es/isArrayLike.js
  function isArrayLike(value) {
    return value != null && isLength_default(value.length) && !isFunction_default(value);
  }
  var isArrayLike_default = isArrayLike;

  // node_modules/lodash-es/keys.js
  function keys(object) {
    return isArrayLike_default(object) ? arrayLikeKeys_default(object) : baseKeys_default(object);
  }
  var keys_default = keys;

  // node_modules/lodash-es/_baseAssign.js
  function baseAssign(object, source) {
    return object && copyObject_default(source, keys_default(source), object);
  }
  var baseAssign_default = baseAssign;

  // node_modules/lodash-es/_nativeKeysIn.js
  function nativeKeysIn(object) {
    var result = [];
    if (object != null) {
      for (var key in Object(object)) {
        result.push(key);
      }
    }
    return result;
  }
  var nativeKeysIn_default = nativeKeysIn;

  // node_modules/lodash-es/_baseKeysIn.js
  var objectProto12 = Object.prototype;
  var hasOwnProperty10 = objectProto12.hasOwnProperty;
  function baseKeysIn(object) {
    if (!isObject_default(object)) {
      return nativeKeysIn_default(object);
    }
    var isProto = isPrototype_default(object), result = [];
    for (var key in object) {
      if (!(key == "constructor" && (isProto || !hasOwnProperty10.call(object, key)))) {
        result.push(key);
      }
    }
    return result;
  }
  var baseKeysIn_default = baseKeysIn;

  // node_modules/lodash-es/keysIn.js
  function keysIn(object) {
    return isArrayLike_default(object) ? arrayLikeKeys_default(object, true) : baseKeysIn_default(object);
  }
  var keysIn_default = keysIn;

  // node_modules/lodash-es/_baseAssignIn.js
  function baseAssignIn(object, source) {
    return object && copyObject_default(source, keysIn_default(source), object);
  }
  var baseAssignIn_default = baseAssignIn;

  // node_modules/lodash-es/_cloneBuffer.js
  var freeExports3 = typeof exports == "object" && exports && !exports.nodeType && exports;
  var freeModule3 = freeExports3 && typeof module == "object" && module && !module.nodeType && module;
  var moduleExports3 = freeModule3 && freeModule3.exports === freeExports3;
  var Buffer3 = moduleExports3 ? root_default.Buffer : void 0;
  var allocUnsafe = Buffer3 ? Buffer3.allocUnsafe : void 0;
  function cloneBuffer(buffer, isDeep) {
    if (isDeep) {
      return buffer.slice();
    }
    var length = buffer.length, result = allocUnsafe ? allocUnsafe(length) : new buffer.constructor(length);
    buffer.copy(result);
    return result;
  }
  var cloneBuffer_default = cloneBuffer;

  // node_modules/lodash-es/_copyArray.js
  function copyArray(source, array) {
    var index = -1, length = source.length;
    array || (array = Array(length));
    while (++index < length) {
      array[index] = source[index];
    }
    return array;
  }
  var copyArray_default = copyArray;

  // node_modules/lodash-es/_arrayFilter.js
  function arrayFilter(array, predicate) {
    var index = -1, length = array == null ? 0 : array.length, resIndex = 0, result = [];
    while (++index < length) {
      var value = array[index];
      if (predicate(value, index, array)) {
        result[resIndex++] = value;
      }
    }
    return result;
  }
  var arrayFilter_default = arrayFilter;

  // node_modules/lodash-es/stubArray.js
  function stubArray() {
    return [];
  }
  var stubArray_default = stubArray;

  // node_modules/lodash-es/_getSymbols.js
  var objectProto13 = Object.prototype;
  var propertyIsEnumerable2 = objectProto13.propertyIsEnumerable;
  var nativeGetSymbols = Object.getOwnPropertySymbols;
  var getSymbols = !nativeGetSymbols ? stubArray_default : function(object) {
    if (object == null) {
      return [];
    }
    object = Object(object);
    return arrayFilter_default(nativeGetSymbols(object), function(symbol) {
      return propertyIsEnumerable2.call(object, symbol);
    });
  };
  var getSymbols_default = getSymbols;

  // node_modules/lodash-es/_copySymbols.js
  function copySymbols(source, object) {
    return copyObject_default(source, getSymbols_default(source), object);
  }
  var copySymbols_default = copySymbols;

  // node_modules/lodash-es/_arrayPush.js
  function arrayPush(array, values) {
    var index = -1, length = values.length, offset = array.length;
    while (++index < length) {
      array[offset + index] = values[index];
    }
    return array;
  }
  var arrayPush_default = arrayPush;

  // node_modules/lodash-es/_getSymbolsIn.js
  var nativeGetSymbols2 = Object.getOwnPropertySymbols;
  var getSymbolsIn = !nativeGetSymbols2 ? stubArray_default : function(object) {
    var result = [];
    while (object) {
      arrayPush_default(result, getSymbols_default(object));
      object = getPrototype_default(object);
    }
    return result;
  };
  var getSymbolsIn_default = getSymbolsIn;

  // node_modules/lodash-es/_copySymbolsIn.js
  function copySymbolsIn(source, object) {
    return copyObject_default(source, getSymbolsIn_default(source), object);
  }
  var copySymbolsIn_default = copySymbolsIn;

  // node_modules/lodash-es/_baseGetAllKeys.js
  function baseGetAllKeys(object, keysFunc, symbolsFunc) {
    var result = keysFunc(object);
    return isArray_default(object) ? result : arrayPush_default(result, symbolsFunc(object));
  }
  var baseGetAllKeys_default = baseGetAllKeys;

  // node_modules/lodash-es/_getAllKeys.js
  function getAllKeys(object) {
    return baseGetAllKeys_default(object, keys_default, getSymbols_default);
  }
  var getAllKeys_default = getAllKeys;

  // node_modules/lodash-es/_getAllKeysIn.js
  function getAllKeysIn(object) {
    return baseGetAllKeys_default(object, keysIn_default, getSymbolsIn_default);
  }
  var getAllKeysIn_default = getAllKeysIn;

  // node_modules/lodash-es/_DataView.js
  var DataView = getNative_default(root_default, "DataView");
  var DataView_default = DataView;

  // node_modules/lodash-es/_Promise.js
  var Promise2 = getNative_default(root_default, "Promise");
  var Promise_default = Promise2;

  // node_modules/lodash-es/_Set.js
  var Set2 = getNative_default(root_default, "Set");
  var Set_default = Set2;

  // node_modules/lodash-es/_WeakMap.js
  var WeakMap2 = getNative_default(root_default, "WeakMap");
  var WeakMap_default = WeakMap2;

  // node_modules/lodash-es/_getTag.js
  var mapTag2 = "[object Map]";
  var objectTag3 = "[object Object]";
  var promiseTag = "[object Promise]";
  var setTag2 = "[object Set]";
  var weakMapTag2 = "[object WeakMap]";
  var dataViewTag2 = "[object DataView]";
  var dataViewCtorString = toSource_default(DataView_default);
  var mapCtorString = toSource_default(Map_default);
  var promiseCtorString = toSource_default(Promise_default);
  var setCtorString = toSource_default(Set_default);
  var weakMapCtorString = toSource_default(WeakMap_default);
  var getTag = baseGetTag_default;
  if (DataView_default && getTag(new DataView_default(new ArrayBuffer(1))) != dataViewTag2 || Map_default && getTag(new Map_default()) != mapTag2 || Promise_default && getTag(Promise_default.resolve()) != promiseTag || Set_default && getTag(new Set_default()) != setTag2 || WeakMap_default && getTag(new WeakMap_default()) != weakMapTag2) {
    getTag = function(value) {
      var result = baseGetTag_default(value), Ctor = result == objectTag3 ? value.constructor : void 0, ctorString = Ctor ? toSource_default(Ctor) : "";
      if (ctorString) {
        switch (ctorString) {
          case dataViewCtorString:
            return dataViewTag2;
          case mapCtorString:
            return mapTag2;
          case promiseCtorString:
            return promiseTag;
          case setCtorString:
            return setTag2;
          case weakMapCtorString:
            return weakMapTag2;
        }
      }
      return result;
    };
  }
  var getTag_default = getTag;

  // node_modules/lodash-es/_initCloneArray.js
  var objectProto14 = Object.prototype;
  var hasOwnProperty11 = objectProto14.hasOwnProperty;
  function initCloneArray(array) {
    var length = array.length, result = new array.constructor(length);
    if (length && typeof array[0] == "string" && hasOwnProperty11.call(array, "index")) {
      result.index = array.index;
      result.input = array.input;
    }
    return result;
  }
  var initCloneArray_default = initCloneArray;

  // node_modules/lodash-es/_Uint8Array.js
  var Uint8Array2 = root_default.Uint8Array;
  var Uint8Array_default = Uint8Array2;

  // node_modules/lodash-es/_cloneArrayBuffer.js
  function cloneArrayBuffer(arrayBuffer) {
    var result = new arrayBuffer.constructor(arrayBuffer.byteLength);
    new Uint8Array_default(result).set(new Uint8Array_default(arrayBuffer));
    return result;
  }
  var cloneArrayBuffer_default = cloneArrayBuffer;

  // node_modules/lodash-es/_cloneDataView.js
  function cloneDataView(dataView, isDeep) {
    var buffer = isDeep ? cloneArrayBuffer_default(dataView.buffer) : dataView.buffer;
    return new dataView.constructor(buffer, dataView.byteOffset, dataView.byteLength);
  }
  var cloneDataView_default = cloneDataView;

  // node_modules/lodash-es/_cloneRegExp.js
  var reFlags = /\w*$/;
  function cloneRegExp(regexp) {
    var result = new regexp.constructor(regexp.source, reFlags.exec(regexp));
    result.lastIndex = regexp.lastIndex;
    return result;
  }
  var cloneRegExp_default = cloneRegExp;

  // node_modules/lodash-es/_cloneSymbol.js
  var symbolProto = Symbol_default ? Symbol_default.prototype : void 0;
  var symbolValueOf = symbolProto ? symbolProto.valueOf : void 0;
  function cloneSymbol(symbol) {
    return symbolValueOf ? Object(symbolValueOf.call(symbol)) : {};
  }
  var cloneSymbol_default = cloneSymbol;

  // node_modules/lodash-es/_cloneTypedArray.js
  function cloneTypedArray(typedArray, isDeep) {
    var buffer = isDeep ? cloneArrayBuffer_default(typedArray.buffer) : typedArray.buffer;
    return new typedArray.constructor(buffer, typedArray.byteOffset, typedArray.length);
  }
  var cloneTypedArray_default = cloneTypedArray;

  // node_modules/lodash-es/_initCloneByTag.js
  var boolTag2 = "[object Boolean]";
  var dateTag2 = "[object Date]";
  var mapTag3 = "[object Map]";
  var numberTag2 = "[object Number]";
  var regexpTag2 = "[object RegExp]";
  var setTag3 = "[object Set]";
  var stringTag2 = "[object String]";
  var symbolTag = "[object Symbol]";
  var arrayBufferTag2 = "[object ArrayBuffer]";
  var dataViewTag3 = "[object DataView]";
  var float32Tag2 = "[object Float32Array]";
  var float64Tag2 = "[object Float64Array]";
  var int8Tag2 = "[object Int8Array]";
  var int16Tag2 = "[object Int16Array]";
  var int32Tag2 = "[object Int32Array]";
  var uint8Tag2 = "[object Uint8Array]";
  var uint8ClampedTag2 = "[object Uint8ClampedArray]";
  var uint16Tag2 = "[object Uint16Array]";
  var uint32Tag2 = "[object Uint32Array]";
  function initCloneByTag(object, tag, isDeep) {
    var Ctor = object.constructor;
    switch (tag) {
      case arrayBufferTag2:
        return cloneArrayBuffer_default(object);
      case boolTag2:
      case dateTag2:
        return new Ctor(+object);
      case dataViewTag3:
        return cloneDataView_default(object, isDeep);
      case float32Tag2:
      case float64Tag2:
      case int8Tag2:
      case int16Tag2:
      case int32Tag2:
      case uint8Tag2:
      case uint8ClampedTag2:
      case uint16Tag2:
      case uint32Tag2:
        return cloneTypedArray_default(object, isDeep);
      case mapTag3:
        return new Ctor();
      case numberTag2:
      case stringTag2:
        return new Ctor(object);
      case regexpTag2:
        return cloneRegExp_default(object);
      case setTag3:
        return new Ctor();
      case symbolTag:
        return cloneSymbol_default(object);
    }
  }
  var initCloneByTag_default = initCloneByTag;

  // node_modules/lodash-es/_baseCreate.js
  var objectCreate = Object.create;
  var baseCreate = /* @__PURE__ */ (function() {
    function object() {
    }
    return function(proto) {
      if (!isObject_default(proto)) {
        return {};
      }
      if (objectCreate) {
        return objectCreate(proto);
      }
      object.prototype = proto;
      var result = new object();
      object.prototype = void 0;
      return result;
    };
  })();
  var baseCreate_default = baseCreate;

  // node_modules/lodash-es/_initCloneObject.js
  function initCloneObject(object) {
    return typeof object.constructor == "function" && !isPrototype_default(object) ? baseCreate_default(getPrototype_default(object)) : {};
  }
  var initCloneObject_default = initCloneObject;

  // node_modules/lodash-es/_baseIsMap.js
  var mapTag4 = "[object Map]";
  function baseIsMap(value) {
    return isObjectLike_default(value) && getTag_default(value) == mapTag4;
  }
  var baseIsMap_default = baseIsMap;

  // node_modules/lodash-es/isMap.js
  var nodeIsMap = nodeUtil_default && nodeUtil_default.isMap;
  var isMap = nodeIsMap ? baseUnary_default(nodeIsMap) : baseIsMap_default;
  var isMap_default = isMap;

  // node_modules/lodash-es/_baseIsSet.js
  var setTag4 = "[object Set]";
  function baseIsSet(value) {
    return isObjectLike_default(value) && getTag_default(value) == setTag4;
  }
  var baseIsSet_default = baseIsSet;

  // node_modules/lodash-es/isSet.js
  var nodeIsSet = nodeUtil_default && nodeUtil_default.isSet;
  var isSet = nodeIsSet ? baseUnary_default(nodeIsSet) : baseIsSet_default;
  var isSet_default = isSet;

  // node_modules/lodash-es/_baseClone.js
  var CLONE_DEEP_FLAG = 1;
  var CLONE_FLAT_FLAG = 2;
  var CLONE_SYMBOLS_FLAG = 4;
  var argsTag3 = "[object Arguments]";
  var arrayTag2 = "[object Array]";
  var boolTag3 = "[object Boolean]";
  var dateTag3 = "[object Date]";
  var errorTag2 = "[object Error]";
  var funcTag3 = "[object Function]";
  var genTag2 = "[object GeneratorFunction]";
  var mapTag5 = "[object Map]";
  var numberTag3 = "[object Number]";
  var objectTag4 = "[object Object]";
  var regexpTag3 = "[object RegExp]";
  var setTag5 = "[object Set]";
  var stringTag3 = "[object String]";
  var symbolTag2 = "[object Symbol]";
  var weakMapTag3 = "[object WeakMap]";
  var arrayBufferTag3 = "[object ArrayBuffer]";
  var dataViewTag4 = "[object DataView]";
  var float32Tag3 = "[object Float32Array]";
  var float64Tag3 = "[object Float64Array]";
  var int8Tag3 = "[object Int8Array]";
  var int16Tag3 = "[object Int16Array]";
  var int32Tag3 = "[object Int32Array]";
  var uint8Tag3 = "[object Uint8Array]";
  var uint8ClampedTag3 = "[object Uint8ClampedArray]";
  var uint16Tag3 = "[object Uint16Array]";
  var uint32Tag3 = "[object Uint32Array]";
  var cloneableTags = {};
  cloneableTags[argsTag3] = cloneableTags[arrayTag2] = cloneableTags[arrayBufferTag3] = cloneableTags[dataViewTag4] = cloneableTags[boolTag3] = cloneableTags[dateTag3] = cloneableTags[float32Tag3] = cloneableTags[float64Tag3] = cloneableTags[int8Tag3] = cloneableTags[int16Tag3] = cloneableTags[int32Tag3] = cloneableTags[mapTag5] = cloneableTags[numberTag3] = cloneableTags[objectTag4] = cloneableTags[regexpTag3] = cloneableTags[setTag5] = cloneableTags[stringTag3] = cloneableTags[symbolTag2] = cloneableTags[uint8Tag3] = cloneableTags[uint8ClampedTag3] = cloneableTags[uint16Tag3] = cloneableTags[uint32Tag3] = true;
  cloneableTags[errorTag2] = cloneableTags[funcTag3] = cloneableTags[weakMapTag3] = false;
  function baseClone(value, bitmask, customizer, key, object, stack) {
    var result, isDeep = bitmask & CLONE_DEEP_FLAG, isFlat = bitmask & CLONE_FLAT_FLAG, isFull = bitmask & CLONE_SYMBOLS_FLAG;
    if (customizer) {
      result = object ? customizer(value, key, object, stack) : customizer(value);
    }
    if (result !== void 0) {
      return result;
    }
    if (!isObject_default(value)) {
      return value;
    }
    var isArr = isArray_default(value);
    if (isArr) {
      result = initCloneArray_default(value);
      if (!isDeep) {
        return copyArray_default(value, result);
      }
    } else {
      var tag = getTag_default(value), isFunc = tag == funcTag3 || tag == genTag2;
      if (isBuffer_default(value)) {
        return cloneBuffer_default(value, isDeep);
      }
      if (tag == objectTag4 || tag == argsTag3 || isFunc && !object) {
        result = isFlat || isFunc ? {} : initCloneObject_default(value);
        if (!isDeep) {
          return isFlat ? copySymbolsIn_default(value, baseAssignIn_default(result, value)) : copySymbols_default(value, baseAssign_default(result, value));
        }
      } else {
        if (!cloneableTags[tag]) {
          return object ? value : {};
        }
        result = initCloneByTag_default(value, tag, isDeep);
      }
    }
    stack || (stack = new Stack_default());
    var stacked = stack.get(value);
    if (stacked) {
      return stacked;
    }
    stack.set(value, result);
    if (isSet_default(value)) {
      value.forEach(function(subValue) {
        result.add(baseClone(subValue, bitmask, customizer, subValue, value, stack));
      });
    } else if (isMap_default(value)) {
      value.forEach(function(subValue, key2) {
        result.set(key2, baseClone(subValue, bitmask, customizer, key2, value, stack));
      });
    }
    var keysFunc = isFull ? isFlat ? getAllKeysIn_default : getAllKeys_default : isFlat ? keysIn_default : keys_default;
    var props = isArr ? void 0 : keysFunc(value);
    arrayEach_default(props || value, function(subValue, key2) {
      if (props) {
        key2 = subValue;
        subValue = value[key2];
      }
      assignValue_default(result, key2, baseClone(subValue, bitmask, customizer, key2, value, stack));
    });
    return result;
  }
  var baseClone_default = baseClone;

  // node_modules/lodash-es/cloneDeep.js
  var CLONE_DEEP_FLAG2 = 1;
  var CLONE_SYMBOLS_FLAG2 = 4;
  function cloneDeep(value) {
    return baseClone_default(value, CLONE_DEEP_FLAG2 | CLONE_SYMBOLS_FLAG2);
  }
  var cloneDeep_default = cloneDeep;

  // node_modules/formik/dist/formik.esm.js
  var import_react6 = __toESM(require_react());
  var import_react_fast_compare = __toESM(require_react_fast_compare());

  // node_modules/tiny-warning/dist/tiny-warning.esm.js
  var isProduction = true;
  function warning(condition, message) {
    if (!isProduction) {
      if (condition) {
        return;
      }
      var text = "Warning: " + message;
      if (typeof console !== "undefined") {
        console.warn(text);
      }
      try {
        throw Error(text);
      } catch (x) {
      }
    }
  }
  var tiny_warning_esm_default = warning;

  // node_modules/lodash-es/clone.js
  var CLONE_SYMBOLS_FLAG3 = 4;
  function clone(value) {
    return baseClone_default(value, CLONE_SYMBOLS_FLAG3);
  }
  var clone_default = clone;

  // node_modules/lodash-es/_arrayMap.js
  function arrayMap(array, iteratee) {
    var index = -1, length = array == null ? 0 : array.length, result = Array(length);
    while (++index < length) {
      result[index] = iteratee(array[index], index, array);
    }
    return result;
  }
  var arrayMap_default = arrayMap;

  // node_modules/lodash-es/isSymbol.js
  var symbolTag3 = "[object Symbol]";
  function isSymbol(value) {
    return typeof value == "symbol" || isObjectLike_default(value) && baseGetTag_default(value) == symbolTag3;
  }
  var isSymbol_default = isSymbol;

  // node_modules/lodash-es/memoize.js
  var FUNC_ERROR_TEXT = "Expected a function";
  function memoize(func, resolver) {
    if (typeof func != "function" || resolver != null && typeof resolver != "function") {
      throw new TypeError(FUNC_ERROR_TEXT);
    }
    var memoized = function() {
      var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache2 = memoized.cache;
      if (cache2.has(key)) {
        return cache2.get(key);
      }
      var result = func.apply(this, args);
      memoized.cache = cache2.set(key, result) || cache2;
      return result;
    };
    memoized.cache = new (memoize.Cache || MapCache_default)();
    return memoized;
  }
  memoize.Cache = MapCache_default;
  var memoize_default = memoize;

  // node_modules/lodash-es/_memoizeCapped.js
  var MAX_MEMOIZE_SIZE = 500;
  function memoizeCapped(func) {
    var result = memoize_default(func, function(key) {
      if (cache2.size === MAX_MEMOIZE_SIZE) {
        cache2.clear();
      }
      return key;
    });
    var cache2 = result.cache;
    return result;
  }
  var memoizeCapped_default = memoizeCapped;

  // node_modules/lodash-es/_stringToPath.js
  var rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
  var reEscapeChar = /\\(\\)?/g;
  var stringToPath = memoizeCapped_default(function(string) {
    var result = [];
    if (string.charCodeAt(0) === 46) {
      result.push("");
    }
    string.replace(rePropName, function(match, number, quote, subString) {
      result.push(quote ? subString.replace(reEscapeChar, "$1") : number || match);
    });
    return result;
  });
  var stringToPath_default = stringToPath;

  // node_modules/lodash-es/_toKey.js
  var INFINITY = 1 / 0;
  function toKey(value) {
    if (typeof value == "string" || isSymbol_default(value)) {
      return value;
    }
    var result = value + "";
    return result == "0" && 1 / value == -INFINITY ? "-0" : result;
  }
  var toKey_default = toKey;

  // node_modules/lodash-es/_baseToString.js
  var INFINITY2 = 1 / 0;
  var symbolProto2 = Symbol_default ? Symbol_default.prototype : void 0;
  var symbolToString = symbolProto2 ? symbolProto2.toString : void 0;
  function baseToString(value) {
    if (typeof value == "string") {
      return value;
    }
    if (isArray_default(value)) {
      return arrayMap_default(value, baseToString) + "";
    }
    if (isSymbol_default(value)) {
      return symbolToString ? symbolToString.call(value) : "";
    }
    var result = value + "";
    return result == "0" && 1 / value == -INFINITY2 ? "-0" : result;
  }
  var baseToString_default = baseToString;

  // node_modules/lodash-es/toString.js
  function toString(value) {
    return value == null ? "" : baseToString_default(value);
  }
  var toString_default = toString;

  // node_modules/lodash-es/toPath.js
  function toPath(value) {
    if (isArray_default(value)) {
      return arrayMap_default(value, toKey_default);
    }
    return isSymbol_default(value) ? [value] : copyArray_default(stringToPath_default(toString_default(value)));
  }
  var toPath_default = toPath;

  // node_modules/formik/dist/formik.esm.js
  var import_hoist_non_react_statics = __toESM(require_hoist_non_react_statics_cjs());
  function _extends() {
    _extends = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    return _extends.apply(this, arguments);
  }
  function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    subClass.__proto__ = superClass;
  }
  function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for (i = 0; i < sourceKeys.length; i++) {
      key = sourceKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      target[key] = source[key];
    }
    return target;
  }
  function _assertThisInitialized(self2) {
    if (self2 === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self2;
  }
  var FormikContext = /* @__PURE__ */ (0, import_react6.createContext)(void 0);
  FormikContext.displayName = "FormikContext";
  var FormikProvider = FormikContext.Provider;
  var FormikConsumer = FormikContext.Consumer;
  function useFormikContext() {
    var formik = (0, import_react6.useContext)(FormikContext);
    !!!formik ? false ? tiny_warning_esm_default(false, "Formik context is undefined, please verify you are calling useFormikContext() as child of a <Formik> component.") : tiny_warning_esm_default(false) : void 0;
    return formik;
  }
  var isEmptyArray = function isEmptyArray2(value) {
    return Array.isArray(value) && value.length === 0;
  };
  var isFunction2 = function isFunction3(obj) {
    return typeof obj === "function";
  };
  var isObject2 = function isObject3(obj) {
    return obj !== null && typeof obj === "object";
  };
  var isInteger = function isInteger2(obj) {
    return String(Math.floor(Number(obj))) === obj;
  };
  var isString = function isString2(obj) {
    return Object.prototype.toString.call(obj) === "[object String]";
  };
  var isNaN$1 = function isNaN2(obj) {
    return obj !== obj;
  };
  var isEmptyChildren = function isEmptyChildren2(children) {
    return import_react6.Children.count(children) === 0;
  };
  var isPromise = function isPromise2(value) {
    return isObject2(value) && isFunction2(value.then);
  };
  var isInputEvent = function isInputEvent2(value) {
    return value && isObject2(value) && isObject2(value.target);
  };
  function getActiveElement(doc) {
    doc = doc || (typeof document !== "undefined" ? document : void 0);
    if (typeof doc === "undefined") {
      return null;
    }
    try {
      return doc.activeElement || doc.body;
    } catch (e) {
      return doc.body;
    }
  }
  function getIn(obj, key, def, p) {
    if (p === void 0) {
      p = 0;
    }
    var path = toPath_default(key);
    while (obj && p < path.length) {
      obj = obj[path[p++]];
    }
    if (p !== path.length && !obj) {
      return def;
    }
    return obj === void 0 ? def : obj;
  }
  function setIn(obj, path, value) {
    var res = clone_default(obj);
    var resVal = res;
    var i = 0;
    var pathArray = toPath_default(path);
    for (; i < pathArray.length - 1; i++) {
      var currentPath = pathArray[i];
      var currentObj = getIn(obj, pathArray.slice(0, i + 1));
      if (currentObj && (isObject2(currentObj) || Array.isArray(currentObj))) {
        resVal = resVal[currentPath] = clone_default(currentObj);
      } else {
        var nextPath = pathArray[i + 1];
        resVal = resVal[currentPath] = isInteger(nextPath) && Number(nextPath) >= 0 ? [] : {};
      }
    }
    if ((i === 0 ? obj : resVal)[pathArray[i]] === value) {
      return obj;
    }
    if (value === void 0) {
      delete resVal[pathArray[i]];
    } else {
      resVal[pathArray[i]] = value;
    }
    if (i === 0 && value === void 0) {
      delete res[pathArray[i]];
    }
    return res;
  }
  function setNestedObjectValues(object, value, visited, response) {
    if (visited === void 0) {
      visited = /* @__PURE__ */ new WeakMap();
    }
    if (response === void 0) {
      response = {};
    }
    for (var _i = 0, _Object$keys = Object.keys(object); _i < _Object$keys.length; _i++) {
      var k = _Object$keys[_i];
      var val = object[k];
      if (isObject2(val)) {
        if (!visited.get(val)) {
          visited.set(val, true);
          response[k] = Array.isArray(val) ? [] : {};
          setNestedObjectValues(val, value, visited, response[k]);
        }
      } else {
        response[k] = value;
      }
    }
    return response;
  }
  function formikReducer(state, msg) {
    switch (msg.type) {
      case "SET_VALUES":
        return _extends({}, state, {
          values: msg.payload
        });
      case "SET_TOUCHED":
        return _extends({}, state, {
          touched: msg.payload
        });
      case "SET_ERRORS":
        if ((0, import_react_fast_compare.default)(state.errors, msg.payload)) {
          return state;
        }
        return _extends({}, state, {
          errors: msg.payload
        });
      case "SET_STATUS":
        return _extends({}, state, {
          status: msg.payload
        });
      case "SET_ISSUBMITTING":
        return _extends({}, state, {
          isSubmitting: msg.payload
        });
      case "SET_ISVALIDATING":
        return _extends({}, state, {
          isValidating: msg.payload
        });
      case "SET_FIELD_VALUE":
        return _extends({}, state, {
          values: setIn(state.values, msg.payload.field, msg.payload.value)
        });
      case "SET_FIELD_TOUCHED":
        return _extends({}, state, {
          touched: setIn(state.touched, msg.payload.field, msg.payload.value)
        });
      case "SET_FIELD_ERROR":
        return _extends({}, state, {
          errors: setIn(state.errors, msg.payload.field, msg.payload.value)
        });
      case "RESET_FORM":
        return _extends({}, state, msg.payload);
      case "SET_FORMIK_STATE":
        return msg.payload(state);
      case "SUBMIT_ATTEMPT":
        return _extends({}, state, {
          touched: setNestedObjectValues(state.values, true),
          isSubmitting: true,
          submitCount: state.submitCount + 1
        });
      case "SUBMIT_FAILURE":
        return _extends({}, state, {
          isSubmitting: false
        });
      case "SUBMIT_SUCCESS":
        return _extends({}, state, {
          isSubmitting: false
        });
      default:
        return state;
    }
  }
  var emptyErrors = {};
  var emptyTouched = {};
  function useFormik(_ref) {
    var _ref$validateOnChange = _ref.validateOnChange, validateOnChange = _ref$validateOnChange === void 0 ? true : _ref$validateOnChange, _ref$validateOnBlur = _ref.validateOnBlur, validateOnBlur = _ref$validateOnBlur === void 0 ? true : _ref$validateOnBlur, _ref$validateOnMount = _ref.validateOnMount, validateOnMount = _ref$validateOnMount === void 0 ? false : _ref$validateOnMount, isInitialValid = _ref.isInitialValid, _ref$enableReinitiali = _ref.enableReinitialize, enableReinitialize = _ref$enableReinitiali === void 0 ? false : _ref$enableReinitiali, onSubmit = _ref.onSubmit, rest = _objectWithoutPropertiesLoose(_ref, ["validateOnChange", "validateOnBlur", "validateOnMount", "isInitialValid", "enableReinitialize", "onSubmit"]);
    var props = _extends({
      validateOnChange,
      validateOnBlur,
      validateOnMount,
      onSubmit
    }, rest);
    var initialValues = (0, import_react6.useRef)(props.initialValues);
    var initialErrors = (0, import_react6.useRef)(props.initialErrors || emptyErrors);
    var initialTouched = (0, import_react6.useRef)(props.initialTouched || emptyTouched);
    var initialStatus = (0, import_react6.useRef)(props.initialStatus);
    var isMounted = (0, import_react6.useRef)(false);
    var fieldRegistry = (0, import_react6.useRef)({});
    if (false) {
      (0, import_react6.useEffect)(function() {
        !(typeof isInitialValid === "undefined") ? false ? tiny_warning_esm_default(false, "isInitialValid has been deprecated and will be removed in future versions of Formik. Please use initialErrors or validateOnMount instead.") : tiny_warning_esm_default(false) : void 0;
      }, []);
    }
    (0, import_react6.useEffect)(function() {
      isMounted.current = true;
      return function() {
        isMounted.current = false;
      };
    }, []);
    var _React$useState = (0, import_react6.useState)(0), setIteration = _React$useState[1];
    var stateRef = (0, import_react6.useRef)({
      values: cloneDeep_default(props.initialValues),
      errors: cloneDeep_default(props.initialErrors) || emptyErrors,
      touched: cloneDeep_default(props.initialTouched) || emptyTouched,
      status: cloneDeep_default(props.initialStatus),
      isSubmitting: false,
      isValidating: false,
      submitCount: 0
    });
    var state = stateRef.current;
    var dispatch2 = (0, import_react6.useCallback)(function(action) {
      var prev = stateRef.current;
      stateRef.current = formikReducer(prev, action);
      if (prev !== stateRef.current) setIteration(function(x) {
        return x + 1;
      });
    }, []);
    var runValidateHandler = (0, import_react6.useCallback)(function(values, field) {
      return new Promise(function(resolve, reject) {
        var maybePromisedErrors = props.validate(values, field);
        if (maybePromisedErrors == null) {
          resolve(emptyErrors);
        } else if (isPromise(maybePromisedErrors)) {
          maybePromisedErrors.then(function(errors2) {
            resolve(errors2 || emptyErrors);
          }, function(actualException) {
            if (false) {
              console.warn("Warning: An unhandled error was caught during validation in <Formik validate />", actualException);
            }
            reject(actualException);
          });
        } else {
          resolve(maybePromisedErrors);
        }
      });
    }, [props.validate]);
    var runValidationSchema = (0, import_react6.useCallback)(function(values, field) {
      var validationSchema = props.validationSchema;
      var schema = isFunction2(validationSchema) ? validationSchema(field) : validationSchema;
      var promise = field && schema.validateAt ? schema.validateAt(field, values) : validateYupSchema(values, schema);
      return new Promise(function(resolve, reject) {
        promise.then(function() {
          resolve(emptyErrors);
        }, function(err) {
          if (err.name === "ValidationError") {
            resolve(yupToFormErrors(err));
          } else {
            if (false) {
              console.warn("Warning: An unhandled error was caught during validation in <Formik validationSchema />", err);
            }
            reject(err);
          }
        });
      });
    }, [props.validationSchema]);
    var runSingleFieldLevelValidation = (0, import_react6.useCallback)(function(field, value) {
      return new Promise(function(resolve) {
        return resolve(fieldRegistry.current[field].validate(value));
      });
    }, []);
    var runFieldLevelValidations = (0, import_react6.useCallback)(function(values) {
      var fieldKeysWithValidation = Object.keys(fieldRegistry.current).filter(function(f) {
        return isFunction2(fieldRegistry.current[f].validate);
      });
      var fieldValidations = fieldKeysWithValidation.length > 0 ? fieldKeysWithValidation.map(function(f) {
        return runSingleFieldLevelValidation(f, getIn(values, f));
      }) : [Promise.resolve("DO_NOT_DELETE_YOU_WILL_BE_FIRED")];
      return Promise.all(fieldValidations).then(function(fieldErrorsList) {
        return fieldErrorsList.reduce(function(prev, curr, index) {
          if (curr === "DO_NOT_DELETE_YOU_WILL_BE_FIRED") {
            return prev;
          }
          if (curr) {
            prev = setIn(prev, fieldKeysWithValidation[index], curr);
          }
          return prev;
        }, {});
      });
    }, [runSingleFieldLevelValidation]);
    var runAllValidations = (0, import_react6.useCallback)(function(values) {
      return Promise.all([runFieldLevelValidations(values), props.validationSchema ? runValidationSchema(values) : {}, props.validate ? runValidateHandler(values) : {}]).then(function(_ref2) {
        var fieldErrors = _ref2[0], schemaErrors = _ref2[1], validateErrors = _ref2[2];
        var combinedErrors = es_default.all([fieldErrors, schemaErrors, validateErrors], {
          arrayMerge
        });
        return combinedErrors;
      });
    }, [props.validate, props.validationSchema, runFieldLevelValidations, runValidateHandler, runValidationSchema]);
    var validateFormWithHighPriority = useEventCallback(function(values) {
      if (values === void 0) {
        values = state.values;
      }
      dispatch2({
        type: "SET_ISVALIDATING",
        payload: true
      });
      return runAllValidations(values).then(function(combinedErrors) {
        if (!!isMounted.current) {
          dispatch2({
            type: "SET_ISVALIDATING",
            payload: false
          });
          dispatch2({
            type: "SET_ERRORS",
            payload: combinedErrors
          });
        }
        return combinedErrors;
      });
    });
    (0, import_react6.useEffect)(function() {
      if (validateOnMount && isMounted.current === true && (0, import_react_fast_compare.default)(initialValues.current, props.initialValues)) {
        validateFormWithHighPriority(initialValues.current);
      }
    }, [validateOnMount, validateFormWithHighPriority]);
    var resetForm = (0, import_react6.useCallback)(function(nextState) {
      var values = nextState && nextState.values ? nextState.values : initialValues.current;
      var errors2 = nextState && nextState.errors ? nextState.errors : initialErrors.current ? initialErrors.current : props.initialErrors || {};
      var touched = nextState && nextState.touched ? nextState.touched : initialTouched.current ? initialTouched.current : props.initialTouched || {};
      var status = nextState && nextState.status ? nextState.status : initialStatus.current ? initialStatus.current : props.initialStatus;
      initialValues.current = values;
      initialErrors.current = errors2;
      initialTouched.current = touched;
      initialStatus.current = status;
      var dispatchFn = function dispatchFn2() {
        dispatch2({
          type: "RESET_FORM",
          payload: {
            isSubmitting: !!nextState && !!nextState.isSubmitting,
            errors: errors2,
            touched,
            status,
            values,
            isValidating: !!nextState && !!nextState.isValidating,
            submitCount: !!nextState && !!nextState.submitCount && typeof nextState.submitCount === "number" ? nextState.submitCount : 0
          }
        });
      };
      if (props.onReset) {
        var maybePromisedOnReset = props.onReset(state.values, imperativeMethods);
        if (isPromise(maybePromisedOnReset)) {
          maybePromisedOnReset.then(dispatchFn);
        } else {
          dispatchFn();
        }
      } else {
        dispatchFn();
      }
    }, [props.initialErrors, props.initialStatus, props.initialTouched, props.onReset]);
    (0, import_react6.useEffect)(function() {
      if (isMounted.current === true && !(0, import_react_fast_compare.default)(initialValues.current, props.initialValues)) {
        if (enableReinitialize) {
          initialValues.current = props.initialValues;
          resetForm();
          if (validateOnMount) {
            validateFormWithHighPriority(initialValues.current);
          }
        }
      }
    }, [enableReinitialize, props.initialValues, resetForm, validateOnMount, validateFormWithHighPriority]);
    (0, import_react6.useEffect)(function() {
      if (enableReinitialize && isMounted.current === true && !(0, import_react_fast_compare.default)(initialErrors.current, props.initialErrors)) {
        initialErrors.current = props.initialErrors || emptyErrors;
        dispatch2({
          type: "SET_ERRORS",
          payload: props.initialErrors || emptyErrors
        });
      }
    }, [enableReinitialize, props.initialErrors]);
    (0, import_react6.useEffect)(function() {
      if (enableReinitialize && isMounted.current === true && !(0, import_react_fast_compare.default)(initialTouched.current, props.initialTouched)) {
        initialTouched.current = props.initialTouched || emptyTouched;
        dispatch2({
          type: "SET_TOUCHED",
          payload: props.initialTouched || emptyTouched
        });
      }
    }, [enableReinitialize, props.initialTouched]);
    (0, import_react6.useEffect)(function() {
      if (enableReinitialize && isMounted.current === true && !(0, import_react_fast_compare.default)(initialStatus.current, props.initialStatus)) {
        initialStatus.current = props.initialStatus;
        dispatch2({
          type: "SET_STATUS",
          payload: props.initialStatus
        });
      }
    }, [enableReinitialize, props.initialStatus, props.initialTouched]);
    var validateField = useEventCallback(function(name) {
      if (fieldRegistry.current[name] && isFunction2(fieldRegistry.current[name].validate)) {
        var value = getIn(state.values, name);
        var maybePromise = fieldRegistry.current[name].validate(value);
        if (isPromise(maybePromise)) {
          dispatch2({
            type: "SET_ISVALIDATING",
            payload: true
          });
          return maybePromise.then(function(x) {
            return x;
          }).then(function(error) {
            dispatch2({
              type: "SET_FIELD_ERROR",
              payload: {
                field: name,
                value: error
              }
            });
            dispatch2({
              type: "SET_ISVALIDATING",
              payload: false
            });
          });
        } else {
          dispatch2({
            type: "SET_FIELD_ERROR",
            payload: {
              field: name,
              value: maybePromise
            }
          });
          return Promise.resolve(maybePromise);
        }
      } else if (props.validationSchema) {
        dispatch2({
          type: "SET_ISVALIDATING",
          payload: true
        });
        return runValidationSchema(state.values, name).then(function(x) {
          return x;
        }).then(function(error) {
          dispatch2({
            type: "SET_FIELD_ERROR",
            payload: {
              field: name,
              value: getIn(error, name)
            }
          });
          dispatch2({
            type: "SET_ISVALIDATING",
            payload: false
          });
        });
      }
      return Promise.resolve();
    });
    var registerField = (0, import_react6.useCallback)(function(name, _ref3) {
      var validate2 = _ref3.validate;
      fieldRegistry.current[name] = {
        validate: validate2
      };
    }, []);
    var unregisterField = (0, import_react6.useCallback)(function(name) {
      delete fieldRegistry.current[name];
    }, []);
    var setTouched = useEventCallback(function(touched, shouldValidate) {
      dispatch2({
        type: "SET_TOUCHED",
        payload: touched
      });
      var willValidate = shouldValidate === void 0 ? validateOnBlur : shouldValidate;
      return willValidate ? validateFormWithHighPriority(state.values) : Promise.resolve();
    });
    var setErrors = (0, import_react6.useCallback)(function(errors2) {
      dispatch2({
        type: "SET_ERRORS",
        payload: errors2
      });
    }, []);
    var setValues = useEventCallback(function(values, shouldValidate) {
      var resolvedValues = isFunction2(values) ? values(state.values) : values;
      dispatch2({
        type: "SET_VALUES",
        payload: resolvedValues
      });
      var willValidate = shouldValidate === void 0 ? validateOnChange : shouldValidate;
      return willValidate ? validateFormWithHighPriority(resolvedValues) : Promise.resolve();
    });
    var setFieldError = (0, import_react6.useCallback)(function(field, value) {
      dispatch2({
        type: "SET_FIELD_ERROR",
        payload: {
          field,
          value
        }
      });
    }, []);
    var setFieldValue = useEventCallback(function(field, value, shouldValidate) {
      var resolvedValue = isFunction2(value) ? value(getIn(state.values, field)) : value;
      dispatch2({
        type: "SET_FIELD_VALUE",
        payload: {
          field,
          value: resolvedValue
        }
      });
      var willValidate = shouldValidate === void 0 ? validateOnChange : shouldValidate;
      return willValidate ? validateFormWithHighPriority(setIn(state.values, field, resolvedValue)) : Promise.resolve();
    });
    var executeChange = (0, import_react6.useCallback)(function(eventOrTextValue, maybePath) {
      var field = maybePath;
      var val = eventOrTextValue;
      var parsed;
      if (!isString(eventOrTextValue)) {
        if (eventOrTextValue.persist) {
          eventOrTextValue.persist();
        }
        var target = eventOrTextValue.target ? eventOrTextValue.target : eventOrTextValue.currentTarget;
        var type = target.type, name = target.name, id = target.id, value = target.value, checked = target.checked, outerHTML = target.outerHTML, options = target.options, multiple = target.multiple;
        field = maybePath ? maybePath : name ? name : id;
        if (!field && false) {
          warnAboutMissingIdentifier({
            htmlContent: outerHTML,
            documentationAnchorLink: "handlechange-e-reactchangeeventany--void",
            handlerName: "handleChange"
          });
        }
        val = /number|range/.test(type) ? (parsed = parseFloat(value), isNaN(parsed) ? "" : parsed) : /checkbox/.test(type) ? getValueForCheckbox(getIn(state.values, field), checked, value) : options && multiple ? getSelectedValues(options) : value;
      }
      if (field) {
        setFieldValue(field, val);
      }
    }, [setFieldValue, state.values]);
    var handleChange = useEventCallback(function(eventOrPath) {
      if (isString(eventOrPath)) {
        return function(event) {
          return executeChange(event, eventOrPath);
        };
      } else {
        executeChange(eventOrPath);
      }
    });
    var setFieldTouched = useEventCallback(function(field, touched, shouldValidate) {
      if (touched === void 0) {
        touched = true;
      }
      dispatch2({
        type: "SET_FIELD_TOUCHED",
        payload: {
          field,
          value: touched
        }
      });
      var willValidate = shouldValidate === void 0 ? validateOnBlur : shouldValidate;
      return willValidate ? validateFormWithHighPriority(state.values) : Promise.resolve();
    });
    var executeBlur = (0, import_react6.useCallback)(function(e, path) {
      if (e.persist) {
        e.persist();
      }
      var _e$target = e.target, name = _e$target.name, id = _e$target.id, outerHTML = _e$target.outerHTML;
      var field = path ? path : name ? name : id;
      if (!field && false) {
        warnAboutMissingIdentifier({
          htmlContent: outerHTML,
          documentationAnchorLink: "handleblur-e-any--void",
          handlerName: "handleBlur"
        });
      }
      setFieldTouched(field, true);
    }, [setFieldTouched]);
    var handleBlur = useEventCallback(function(eventOrString) {
      if (isString(eventOrString)) {
        return function(event) {
          return executeBlur(event, eventOrString);
        };
      } else {
        executeBlur(eventOrString);
      }
    });
    var setFormikState = (0, import_react6.useCallback)(function(stateOrCb) {
      if (isFunction2(stateOrCb)) {
        dispatch2({
          type: "SET_FORMIK_STATE",
          payload: stateOrCb
        });
      } else {
        dispatch2({
          type: "SET_FORMIK_STATE",
          payload: function payload() {
            return stateOrCb;
          }
        });
      }
    }, []);
    var setStatus = (0, import_react6.useCallback)(function(status) {
      dispatch2({
        type: "SET_STATUS",
        payload: status
      });
    }, []);
    var setSubmitting = (0, import_react6.useCallback)(function(isSubmitting) {
      dispatch2({
        type: "SET_ISSUBMITTING",
        payload: isSubmitting
      });
    }, []);
    var submitForm = useEventCallback(function() {
      dispatch2({
        type: "SUBMIT_ATTEMPT"
      });
      return validateFormWithHighPriority().then(function(combinedErrors) {
        var isInstanceOfError = combinedErrors instanceof Error;
        var isActuallyValid = !isInstanceOfError && Object.keys(combinedErrors).length === 0;
        if (isActuallyValid) {
          var promiseOrUndefined;
          try {
            promiseOrUndefined = executeSubmit();
            if (promiseOrUndefined === void 0) {
              return;
            }
          } catch (error) {
            throw error;
          }
          return Promise.resolve(promiseOrUndefined).then(function(result) {
            if (!!isMounted.current) {
              dispatch2({
                type: "SUBMIT_SUCCESS"
              });
            }
            return result;
          })["catch"](function(_errors) {
            if (!!isMounted.current) {
              dispatch2({
                type: "SUBMIT_FAILURE"
              });
              throw _errors;
            }
          });
        } else if (!!isMounted.current) {
          dispatch2({
            type: "SUBMIT_FAILURE"
          });
          if (isInstanceOfError) {
            throw combinedErrors;
          }
        }
        return;
      });
    });
    var handleSubmit = useEventCallback(function(e) {
      if (e && e.preventDefault && isFunction2(e.preventDefault)) {
        e.preventDefault();
      }
      if (e && e.stopPropagation && isFunction2(e.stopPropagation)) {
        e.stopPropagation();
      }
      if (false) {
        var activeElement = getActiveElement();
        if (activeElement !== null && activeElement instanceof HTMLButtonElement) {
          !(activeElement.attributes && activeElement.attributes.getNamedItem("type")) ? false ? tiny_warning_esm_default(false, 'You submitted a Formik form using a button with an unspecified `type` attribute.  Most browsers default button elements to `type="submit"`. If this is not a submit button, please add `type="button"`.') : tiny_warning_esm_default(false) : void 0;
        }
      }
      submitForm()["catch"](function(reason) {
        console.warn("Warning: An unhandled error was caught from submitForm()", reason);
      });
    });
    var imperativeMethods = {
      resetForm,
      validateForm: validateFormWithHighPriority,
      validateField,
      setErrors,
      setFieldError,
      setFieldTouched,
      setFieldValue,
      setStatus,
      setSubmitting,
      setTouched,
      setValues,
      setFormikState,
      submitForm
    };
    var executeSubmit = useEventCallback(function() {
      return onSubmit(state.values, imperativeMethods);
    });
    var handleReset = useEventCallback(function(e) {
      if (e && e.preventDefault && isFunction2(e.preventDefault)) {
        e.preventDefault();
      }
      if (e && e.stopPropagation && isFunction2(e.stopPropagation)) {
        e.stopPropagation();
      }
      resetForm();
    });
    var getFieldMeta = (0, import_react6.useCallback)(function(name) {
      return {
        value: getIn(state.values, name),
        error: getIn(state.errors, name),
        touched: !!getIn(state.touched, name),
        initialValue: getIn(initialValues.current, name),
        initialTouched: !!getIn(initialTouched.current, name),
        initialError: getIn(initialErrors.current, name)
      };
    }, [state.errors, state.touched, state.values]);
    var getFieldHelpers = (0, import_react6.useCallback)(function(name) {
      return {
        setValue: function setValue(value, shouldValidate) {
          return setFieldValue(name, value, shouldValidate);
        },
        setTouched: function setTouched2(value, shouldValidate) {
          return setFieldTouched(name, value, shouldValidate);
        },
        setError: function setError(value) {
          return setFieldError(name, value);
        }
      };
    }, [setFieldValue, setFieldTouched, setFieldError]);
    var getFieldProps = (0, import_react6.useCallback)(function(nameOrOptions) {
      var isAnObject = isObject2(nameOrOptions);
      var name = isAnObject ? nameOrOptions.name : nameOrOptions;
      var valueState = getIn(state.values, name);
      var field = {
        name,
        value: valueState,
        onChange: handleChange,
        onBlur: handleBlur
      };
      if (isAnObject) {
        var type = nameOrOptions.type, valueProp = nameOrOptions.value, is = nameOrOptions.as, multiple = nameOrOptions.multiple;
        if (type === "checkbox") {
          if (valueProp === void 0) {
            field.checked = !!valueState;
          } else {
            field.checked = !!(Array.isArray(valueState) && ~valueState.indexOf(valueProp));
            field.value = valueProp;
          }
        } else if (type === "radio") {
          field.checked = valueState === valueProp;
          field.value = valueProp;
        } else if (is === "select" && multiple) {
          field.value = field.value || [];
          field.multiple = true;
        }
      }
      return field;
    }, [handleBlur, handleChange, state.values]);
    var dirty = (0, import_react6.useMemo)(function() {
      return !(0, import_react_fast_compare.default)(initialValues.current, state.values);
    }, [initialValues.current, state.values]);
    var isValid = (0, import_react6.useMemo)(function() {
      return typeof isInitialValid !== "undefined" ? dirty ? state.errors && Object.keys(state.errors).length === 0 : isInitialValid !== false && isFunction2(isInitialValid) ? isInitialValid(props) : isInitialValid : state.errors && Object.keys(state.errors).length === 0;
    }, [isInitialValid, dirty, state.errors, props]);
    var ctx = _extends({}, state, {
      initialValues: initialValues.current,
      initialErrors: initialErrors.current,
      initialTouched: initialTouched.current,
      initialStatus: initialStatus.current,
      handleBlur,
      handleChange,
      handleReset,
      handleSubmit,
      resetForm,
      setErrors,
      setFormikState,
      setFieldTouched,
      setFieldValue,
      setFieldError,
      setStatus,
      setSubmitting,
      setTouched,
      setValues,
      submitForm,
      validateForm: validateFormWithHighPriority,
      validateField,
      isValid,
      dirty,
      unregisterField,
      registerField,
      getFieldProps,
      getFieldMeta,
      getFieldHelpers,
      validateOnBlur,
      validateOnChange,
      validateOnMount
    });
    return ctx;
  }
  function Formik(props) {
    var formikbag = useFormik(props);
    var component = props.component, children = props.children, render = props.render, innerRef = props.innerRef;
    (0, import_react6.useImperativeHandle)(innerRef, function() {
      return formikbag;
    });
    if (false) {
      (0, import_react6.useEffect)(function() {
        !!props.render ? false ? tiny_warning_esm_default(false, "<Formik render> has been deprecated and will be removed in future versions of Formik. Please use a child callback function instead. To get rid of this warning, replace <Formik render={(props) => ...} /> with <Formik>{(props) => ...}</Formik>") : tiny_warning_esm_default(false) : void 0;
      }, []);
    }
    return (0, import_react6.createElement)(FormikProvider, {
      value: formikbag
    }, component ? (0, import_react6.createElement)(component, formikbag) : render ? render(formikbag) : children ? isFunction2(children) ? children(formikbag) : !isEmptyChildren(children) ? import_react6.Children.only(children) : null : null);
  }
  function yupToFormErrors(yupError) {
    var errors2 = {};
    if (yupError.inner) {
      if (yupError.inner.length === 0) {
        return setIn(errors2, yupError.path, yupError.message);
      }
      for (var _iterator = yupError.inner, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator](); ; ) {
        var _ref5;
        if (_isArray) {
          if (_i >= _iterator.length) break;
          _ref5 = _iterator[_i++];
        } else {
          _i = _iterator.next();
          if (_i.done) break;
          _ref5 = _i.value;
        }
        var err = _ref5;
        if (!getIn(errors2, err.path)) {
          errors2 = setIn(errors2, err.path, err.message);
        }
      }
    }
    return errors2;
  }
  function validateYupSchema(values, schema, sync, context2) {
    if (sync === void 0) {
      sync = false;
    }
    var normalizedValues = prepareDataForValidation(values);
    return schema[sync ? "validateSync" : "validate"](normalizedValues, {
      abortEarly: false,
      context: context2 || normalizedValues
    });
  }
  function prepareDataForValidation(values) {
    var data = Array.isArray(values) ? [] : {};
    for (var k in values) {
      if (Object.prototype.hasOwnProperty.call(values, k)) {
        var key = String(k);
        if (Array.isArray(values[key]) === true) {
          data[key] = values[key].map(function(value) {
            if (Array.isArray(value) === true || isPlainObject_default(value)) {
              return prepareDataForValidation(value);
            } else {
              return value !== "" ? value : void 0;
            }
          });
        } else if (isPlainObject_default(values[key])) {
          data[key] = prepareDataForValidation(values[key]);
        } else {
          data[key] = values[key] !== "" ? values[key] : void 0;
        }
      }
    }
    return data;
  }
  function arrayMerge(target, source, options) {
    var destination = target.slice();
    source.forEach(function merge(e, i) {
      if (typeof destination[i] === "undefined") {
        var cloneRequested = options.clone !== false;
        var shouldClone = cloneRequested && options.isMergeableObject(e);
        destination[i] = shouldClone ? es_default(Array.isArray(e) ? [] : {}, e, options) : e;
      } else if (options.isMergeableObject(e)) {
        destination[i] = es_default(target[i], e, options);
      } else if (target.indexOf(e) === -1) {
        destination.push(e);
      }
    });
    return destination;
  }
  function getSelectedValues(options) {
    return Array.from(options).filter(function(el) {
      return el.selected;
    }).map(function(el) {
      return el.value;
    });
  }
  function getValueForCheckbox(currentValue, checked, valueProp) {
    if (typeof currentValue === "boolean") {
      return Boolean(checked);
    }
    var currentArrayOfValues = [];
    var isValueInArray = false;
    var index = -1;
    if (!Array.isArray(currentValue)) {
      if (!valueProp || valueProp == "true" || valueProp == "false") {
        return Boolean(checked);
      }
    } else {
      currentArrayOfValues = currentValue;
      index = currentValue.indexOf(valueProp);
      isValueInArray = index >= 0;
    }
    if (checked && valueProp && !isValueInArray) {
      return currentArrayOfValues.concat(valueProp);
    }
    if (!isValueInArray) {
      return currentArrayOfValues;
    }
    return currentArrayOfValues.slice(0, index).concat(currentArrayOfValues.slice(index + 1));
  }
  var useIsomorphicLayoutEffect = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined" ? import_react6.useLayoutEffect : import_react6.useEffect;
  function useEventCallback(fn) {
    var ref = (0, import_react6.useRef)(fn);
    useIsomorphicLayoutEffect(function() {
      ref.current = fn;
    });
    return (0, import_react6.useCallback)(function() {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      return ref.current.apply(void 0, args);
    }, []);
  }
  function useField(propsOrFieldName) {
    var formik = useFormikContext();
    var getFieldProps = formik.getFieldProps, getFieldMeta = formik.getFieldMeta, getFieldHelpers = formik.getFieldHelpers, registerField = formik.registerField, unregisterField = formik.unregisterField;
    var isAnObject = isObject2(propsOrFieldName);
    var props = isAnObject ? propsOrFieldName : {
      name: propsOrFieldName
    };
    var fieldName = props.name, validateFn = props.validate;
    (0, import_react6.useEffect)(function() {
      if (fieldName) {
        registerField(fieldName, {
          validate: validateFn
        });
      }
      return function() {
        if (fieldName) {
          unregisterField(fieldName);
        }
      };
    }, [registerField, unregisterField, fieldName, validateFn]);
    if (false) {
      !formik ? false ? tiny_warning_esm_default(false, "useField() / <Field /> must be used underneath a <Formik> component or withFormik() higher order component") : tiny_warning_esm_default(false) : void 0;
    }
    !fieldName ? false ? tiny_warning_esm_default(false, "Invalid field name. Either pass `useField` a string or an object containing a `name` key.") : tiny_warning_esm_default(false) : void 0;
    var fieldHelpers = (0, import_react6.useMemo)(function() {
      return getFieldHelpers(fieldName);
    }, [getFieldHelpers, fieldName]);
    return [getFieldProps(props), getFieldMeta(fieldName), fieldHelpers];
  }
  function Field(_ref) {
    var validate2 = _ref.validate, name = _ref.name, render = _ref.render, children = _ref.children, is = _ref.as, component = _ref.component, className = _ref.className, props = _objectWithoutPropertiesLoose(_ref, ["validate", "name", "render", "children", "as", "component", "className"]);
    var _useFormikContext = useFormikContext(), formik = _objectWithoutPropertiesLoose(_useFormikContext, ["validate", "validationSchema"]);
    if (false) {
      (0, import_react6.useEffect)(function() {
        !!render ? false ? tiny_warning_esm_default(false, '<Field render> has been deprecated and will be removed in future versions of Formik. Please use a child callback function instead. To get rid of this warning, replace <Field name="' + name + '" render={({field, form}) => ...} /> with <Field name="' + name + '">{({field, form, meta}) => ...}</Field>') : tiny_warning_esm_default(false) : void 0;
        !!(is && children && isFunction2(children)) ? false ? tiny_warning_esm_default(false, "You should not use <Field as> and <Field children> as a function in the same <Field> component; <Field as> will be ignored.") : tiny_warning_esm_default(false) : void 0;
        !!(component && children && isFunction2(children)) ? false ? tiny_warning_esm_default(false, "You should not use <Field component> and <Field children> as a function in the same <Field> component; <Field component> will be ignored.") : tiny_warning_esm_default(false) : void 0;
        !!(render && children && !isEmptyChildren(children)) ? false ? tiny_warning_esm_default(false, "You should not use <Field render> and <Field children> in the same <Field> component; <Field children> will be ignored") : tiny_warning_esm_default(false) : void 0;
      }, []);
    }
    var registerField = formik.registerField, unregisterField = formik.unregisterField;
    (0, import_react6.useEffect)(function() {
      registerField(name, {
        validate: validate2
      });
      return function() {
        unregisterField(name);
      };
    }, [registerField, unregisterField, name, validate2]);
    var field = formik.getFieldProps(_extends({
      name
    }, props));
    var meta = formik.getFieldMeta(name);
    var legacyBag = {
      field,
      form: formik
    };
    if (render) {
      return render(_extends({}, legacyBag, {
        meta
      }));
    }
    if (isFunction2(children)) {
      return children(_extends({}, legacyBag, {
        meta
      }));
    }
    if (component) {
      if (typeof component === "string") {
        var innerRef = props.innerRef, rest = _objectWithoutPropertiesLoose(props, ["innerRef"]);
        return (0, import_react6.createElement)(component, _extends({
          ref: innerRef
        }, field, rest, {
          className
        }), children);
      }
      return (0, import_react6.createElement)(component, _extends({
        field,
        form: formik
      }, props, {
        className
      }), children);
    }
    var asElement = is || "input";
    if (typeof asElement === "string") {
      var _innerRef = props.innerRef, _rest = _objectWithoutPropertiesLoose(props, ["innerRef"]);
      return (0, import_react6.createElement)(asElement, _extends({
        ref: _innerRef
      }, field, _rest, {
        className
      }), children);
    }
    return (0, import_react6.createElement)(asElement, _extends({}, field, props, {
      className
    }), children);
  }
  var Form = /* @__PURE__ */ (0, import_react6.forwardRef)(function(props, ref) {
    var action = props.action, rest = _objectWithoutPropertiesLoose(props, ["action"]);
    var _action = action != null ? action : "#";
    var _useFormikContext = useFormikContext(), handleReset = _useFormikContext.handleReset, handleSubmit = _useFormikContext.handleSubmit;
    return (0, import_react6.createElement)("form", _extends({
      onSubmit: handleSubmit,
      ref,
      onReset: handleReset,
      action: _action
    }, rest));
  });
  Form.displayName = "Form";
  function withFormik(_ref) {
    var _ref$mapPropsToValues = _ref.mapPropsToValues, mapPropsToValues = _ref$mapPropsToValues === void 0 ? function(vanillaProps) {
      var val = {};
      for (var k in vanillaProps) {
        if (vanillaProps.hasOwnProperty(k) && typeof vanillaProps[k] !== "function") {
          val[k] = vanillaProps[k];
        }
      }
      return val;
    } : _ref$mapPropsToValues, config = _objectWithoutPropertiesLoose(_ref, ["mapPropsToValues"]);
    return function createFormik(Component$1) {
      var componentDisplayName = Component$1.displayName || Component$1.name || Component$1.constructor && Component$1.constructor.name || "Component";
      var C = /* @__PURE__ */ (function(_React$Component) {
        _inheritsLoose(C2, _React$Component);
        function C2() {
          var _this;
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          _this = _React$Component.call.apply(_React$Component, [this].concat(args)) || this;
          _this.validate = function(values) {
            return config.validate(values, _this.props);
          };
          _this.validationSchema = function() {
            return isFunction2(config.validationSchema) ? config.validationSchema(_this.props) : config.validationSchema;
          };
          _this.handleSubmit = function(values, actions) {
            return config.handleSubmit(values, _extends({}, actions, {
              props: _this.props
            }));
          };
          _this.renderFormComponent = function(formikProps) {
            return (0, import_react6.createElement)(Component$1, _extends({}, _this.props, formikProps));
          };
          return _this;
        }
        var _proto = C2.prototype;
        _proto.render = function render() {
          var _this$props = this.props, props = _objectWithoutPropertiesLoose(_this$props, ["children"]);
          return (0, import_react6.createElement)(Formik, _extends({}, props, config, {
            validate: config.validate && this.validate,
            validationSchema: config.validationSchema && this.validationSchema,
            initialValues: mapPropsToValues(this.props),
            initialStatus: config.mapPropsToStatus && config.mapPropsToStatus(this.props),
            initialErrors: config.mapPropsToErrors && config.mapPropsToErrors(this.props),
            initialTouched: config.mapPropsToTouched && config.mapPropsToTouched(this.props),
            onSubmit: this.handleSubmit,
            children: this.renderFormComponent
          }));
        };
        return C2;
      })(import_react6.Component);
      C.displayName = "WithFormik(" + componentDisplayName + ")";
      return (0, import_hoist_non_react_statics.default)(
        C,
        Component$1
        // cast type to ComponentClass (even if SFC)
      );
    };
  }
  function connect(Comp) {
    var C = function C2(props) {
      return (0, import_react6.createElement)(FormikConsumer, null, function(formik) {
        !!!formik ? false ? tiny_warning_esm_default(false, "Formik context is undefined, please verify you are rendering <Form>, <Field>, <FastField>, <FieldArray>, or your custom context-using component as a child of a <Formik> component. Component name: " + Comp.name) : tiny_warning_esm_default(false) : void 0;
        return (0, import_react6.createElement)(Comp, _extends({}, props, {
          formik
        }));
      });
    };
    var componentDisplayName = Comp.displayName || Comp.name || Comp.constructor && Comp.constructor.name || "Component";
    C.WrappedComponent = Comp;
    C.displayName = "FormikConnect(" + componentDisplayName + ")";
    return (0, import_hoist_non_react_statics.default)(
      C,
      Comp
      // cast type to ComponentClass (even if SFC)
    );
  }
  var move = function move2(array, from, to) {
    var copy = copyArrayLike(array);
    var value = copy[from];
    copy.splice(from, 1);
    copy.splice(to, 0, value);
    return copy;
  };
  var swap = function swap2(arrayLike, indexA, indexB) {
    var copy = copyArrayLike(arrayLike);
    var a = copy[indexA];
    copy[indexA] = copy[indexB];
    copy[indexB] = a;
    return copy;
  };
  var insert = function insert2(arrayLike, index, value) {
    var copy = copyArrayLike(arrayLike);
    copy.splice(index, 0, value);
    return copy;
  };
  var replace = function replace2(arrayLike, index, value) {
    var copy = copyArrayLike(arrayLike);
    copy[index] = value;
    return copy;
  };
  var copyArrayLike = function copyArrayLike2(arrayLike) {
    if (!arrayLike) {
      return [];
    } else if (Array.isArray(arrayLike)) {
      return [].concat(arrayLike);
    } else {
      var maxIndex = Object.keys(arrayLike).map(function(key) {
        return parseInt(key);
      }).reduce(function(max, el) {
        return el > max ? el : max;
      }, 0);
      return Array.from(_extends({}, arrayLike, {
        length: maxIndex + 1
      }));
    }
  };
  var createAlterationHandler = function createAlterationHandler2(alteration, defaultFunction) {
    var fn = typeof alteration === "function" ? alteration : defaultFunction;
    return function(data) {
      if (Array.isArray(data) || isObject2(data)) {
        var clone2 = copyArrayLike(data);
        return fn(clone2);
      }
      return data;
    };
  };
  var FieldArrayInner = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose(FieldArrayInner2, _React$Component);
    function FieldArrayInner2(props) {
      var _this;
      _this = _React$Component.call(this, props) || this;
      _this.updateArrayField = function(fn, alterTouched, alterErrors) {
        var _this$props = _this.props, name = _this$props.name, setFormikState = _this$props.formik.setFormikState;
        setFormikState(function(prevState) {
          var updateErrors = createAlterationHandler(alterErrors, fn);
          var updateTouched = createAlterationHandler(alterTouched, fn);
          var values = setIn(prevState.values, name, fn(getIn(prevState.values, name)));
          var fieldError = alterErrors ? updateErrors(getIn(prevState.errors, name)) : void 0;
          var fieldTouched = alterTouched ? updateTouched(getIn(prevState.touched, name)) : void 0;
          if (isEmptyArray(fieldError)) {
            fieldError = void 0;
          }
          if (isEmptyArray(fieldTouched)) {
            fieldTouched = void 0;
          }
          return _extends({}, prevState, {
            values,
            errors: alterErrors ? setIn(prevState.errors, name, fieldError) : prevState.errors,
            touched: alterTouched ? setIn(prevState.touched, name, fieldTouched) : prevState.touched
          });
        });
      };
      _this.push = function(value) {
        return _this.updateArrayField(function(arrayLike) {
          return [].concat(copyArrayLike(arrayLike), [cloneDeep_default(value)]);
        }, false, false);
      };
      _this.handlePush = function(value) {
        return function() {
          return _this.push(value);
        };
      };
      _this.swap = function(indexA, indexB) {
        return _this.updateArrayField(function(array) {
          return swap(array, indexA, indexB);
        }, true, true);
      };
      _this.handleSwap = function(indexA, indexB) {
        return function() {
          return _this.swap(indexA, indexB);
        };
      };
      _this.move = function(from, to) {
        return _this.updateArrayField(function(array) {
          return move(array, from, to);
        }, true, true);
      };
      _this.handleMove = function(from, to) {
        return function() {
          return _this.move(from, to);
        };
      };
      _this.insert = function(index, value) {
        return _this.updateArrayField(function(array) {
          return insert(array, index, value);
        }, function(array) {
          return insert(array, index, null);
        }, function(array) {
          return insert(array, index, null);
        });
      };
      _this.handleInsert = function(index, value) {
        return function() {
          return _this.insert(index, value);
        };
      };
      _this.replace = function(index, value) {
        return _this.updateArrayField(function(array) {
          return replace(array, index, value);
        }, false, false);
      };
      _this.handleReplace = function(index, value) {
        return function() {
          return _this.replace(index, value);
        };
      };
      _this.unshift = function(value) {
        var length = -1;
        _this.updateArrayField(function(array) {
          var arr = array ? [value].concat(array) : [value];
          length = arr.length;
          return arr;
        }, function(array) {
          return array ? [null].concat(array) : [null];
        }, function(array) {
          return array ? [null].concat(array) : [null];
        });
        return length;
      };
      _this.handleUnshift = function(value) {
        return function() {
          return _this.unshift(value);
        };
      };
      _this.handleRemove = function(index) {
        return function() {
          return _this.remove(index);
        };
      };
      _this.handlePop = function() {
        return function() {
          return _this.pop();
        };
      };
      _this.remove = _this.remove.bind(_assertThisInitialized(_this));
      _this.pop = _this.pop.bind(_assertThisInitialized(_this));
      return _this;
    }
    var _proto = FieldArrayInner2.prototype;
    _proto.componentDidUpdate = function componentDidUpdate(prevProps) {
      if (this.props.validateOnChange && this.props.formik.validateOnChange && !(0, import_react_fast_compare.default)(getIn(prevProps.formik.values, prevProps.name), getIn(this.props.formik.values, this.props.name))) {
        this.props.formik.validateForm(this.props.formik.values);
      }
    };
    _proto.remove = function remove(index) {
      var result;
      this.updateArrayField(
        // so this gets call 3 times
        function(array) {
          var copy = array ? copyArrayLike(array) : [];
          if (!result) {
            result = copy[index];
          }
          if (isFunction2(copy.splice)) {
            copy.splice(index, 1);
          }
          return isFunction2(copy.every) ? copy.every(function(v) {
            return v === void 0;
          }) ? [] : copy : copy;
        },
        true,
        true
      );
      return result;
    };
    _proto.pop = function pop() {
      var result;
      this.updateArrayField(
        // so this gets call 3 times
        function(array) {
          var tmp = array.slice();
          if (!result) {
            result = tmp && tmp.pop && tmp.pop();
          }
          return tmp;
        },
        true,
        true
      );
      return result;
    };
    _proto.render = function render() {
      var arrayHelpers = {
        push: this.push,
        pop: this.pop,
        swap: this.swap,
        move: this.move,
        insert: this.insert,
        replace: this.replace,
        unshift: this.unshift,
        remove: this.remove,
        handlePush: this.handlePush,
        handlePop: this.handlePop,
        handleSwap: this.handleSwap,
        handleMove: this.handleMove,
        handleInsert: this.handleInsert,
        handleReplace: this.handleReplace,
        handleUnshift: this.handleUnshift,
        handleRemove: this.handleRemove
      };
      var _this$props2 = this.props, component = _this$props2.component, render2 = _this$props2.render, children = _this$props2.children, name = _this$props2.name, _this$props2$formik = _this$props2.formik, restOfFormik = _objectWithoutPropertiesLoose(_this$props2$formik, ["validate", "validationSchema"]);
      var props = _extends({}, arrayHelpers, {
        form: restOfFormik,
        name
      });
      return component ? (0, import_react6.createElement)(component, props) : render2 ? render2(props) : children ? typeof children === "function" ? children(props) : !isEmptyChildren(children) ? import_react6.Children.only(children) : null : null;
    };
    return FieldArrayInner2;
  })(import_react6.Component);
  FieldArrayInner.defaultProps = {
    validateOnChange: true
  };
  var FieldArray = /* @__PURE__ */ connect(FieldArrayInner);
  var ErrorMessageImpl = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose(ErrorMessageImpl2, _React$Component);
    function ErrorMessageImpl2() {
      return _React$Component.apply(this, arguments) || this;
    }
    var _proto = ErrorMessageImpl2.prototype;
    _proto.shouldComponentUpdate = function shouldComponentUpdate(props) {
      if (getIn(this.props.formik.errors, this.props.name) !== getIn(props.formik.errors, this.props.name) || getIn(this.props.formik.touched, this.props.name) !== getIn(props.formik.touched, this.props.name) || Object.keys(this.props).length !== Object.keys(props).length) {
        return true;
      } else {
        return false;
      }
    };
    _proto.render = function render() {
      var _this$props = this.props, component = _this$props.component, formik = _this$props.formik, render2 = _this$props.render, children = _this$props.children, name = _this$props.name, rest = _objectWithoutPropertiesLoose(_this$props, ["component", "formik", "render", "children", "name"]);
      var touch = getIn(formik.touched, name);
      var error = getIn(formik.errors, name);
      return !!touch && !!error ? render2 ? isFunction2(render2) ? render2(error) : null : children ? isFunction2(children) ? children(error) : null : component ? (0, import_react6.createElement)(component, rest, error) : error : null;
    };
    return ErrorMessageImpl2;
  })(import_react6.Component);
  var ErrorMessage = /* @__PURE__ */ connect(ErrorMessageImpl);
  var FastFieldInner = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose(FastFieldInner2, _React$Component);
    function FastFieldInner2(props) {
      var _this;
      _this = _React$Component.call(this, props) || this;
      var render = props.render, children = props.children, component = props.component, is = props.as, name = props.name;
      !!render ? false ? tiny_warning_esm_default(false, "<FastField render> has been deprecated. Please use a child callback function instead: <FastField name={" + name + "}>{props => ...}</FastField> instead.") : tiny_warning_esm_default(false) : void 0;
      !!(component && render) ? false ? tiny_warning_esm_default(false, "You should not use <FastField component> and <FastField render> in the same <FastField> component; <FastField component> will be ignored") : tiny_warning_esm_default(false) : void 0;
      !!(is && children && isFunction2(children)) ? false ? tiny_warning_esm_default(false, "You should not use <FastField as> and <FastField children> as a function in the same <FastField> component; <FastField as> will be ignored.") : tiny_warning_esm_default(false) : void 0;
      !!(component && children && isFunction2(children)) ? false ? tiny_warning_esm_default(false, "You should not use <FastField component> and <FastField children> as a function in the same <FastField> component; <FastField component> will be ignored.") : tiny_warning_esm_default(false) : void 0;
      !!(render && children && !isEmptyChildren(children)) ? false ? tiny_warning_esm_default(false, "You should not use <FastField render> and <FastField children> in the same <FastField> component; <FastField children> will be ignored") : tiny_warning_esm_default(false) : void 0;
      return _this;
    }
    var _proto = FastFieldInner2.prototype;
    _proto.shouldComponentUpdate = function shouldComponentUpdate(props) {
      if (this.props.shouldUpdate) {
        return this.props.shouldUpdate(props, this.props);
      } else if (props.name !== this.props.name || getIn(props.formik.values, this.props.name) !== getIn(this.props.formik.values, this.props.name) || getIn(props.formik.errors, this.props.name) !== getIn(this.props.formik.errors, this.props.name) || getIn(props.formik.touched, this.props.name) !== getIn(this.props.formik.touched, this.props.name) || Object.keys(this.props).length !== Object.keys(props).length || props.formik.isSubmitting !== this.props.formik.isSubmitting) {
        return true;
      } else {
        return false;
      }
    };
    _proto.componentDidMount = function componentDidMount() {
      this.props.formik.registerField(this.props.name, {
        validate: this.props.validate
      });
    };
    _proto.componentDidUpdate = function componentDidUpdate(prevProps) {
      if (this.props.name !== prevProps.name) {
        this.props.formik.unregisterField(prevProps.name);
        this.props.formik.registerField(this.props.name, {
          validate: this.props.validate
        });
      }
      if (this.props.validate !== prevProps.validate) {
        this.props.formik.registerField(this.props.name, {
          validate: this.props.validate
        });
      }
    };
    _proto.componentWillUnmount = function componentWillUnmount() {
      this.props.formik.unregisterField(this.props.name);
    };
    _proto.render = function render() {
      var _this$props = this.props, name = _this$props.name, render2 = _this$props.render, is = _this$props.as, children = _this$props.children, component = _this$props.component, formik = _this$props.formik, props = _objectWithoutPropertiesLoose(_this$props, ["validate", "name", "render", "as", "children", "component", "shouldUpdate", "formik"]);
      var restOfFormik = _objectWithoutPropertiesLoose(formik, ["validate", "validationSchema"]);
      var field = formik.getFieldProps(_extends({
        name
      }, props));
      var meta = {
        value: getIn(formik.values, name),
        error: getIn(formik.errors, name),
        touched: !!getIn(formik.touched, name),
        initialValue: getIn(formik.initialValues, name),
        initialTouched: !!getIn(formik.initialTouched, name),
        initialError: getIn(formik.initialErrors, name)
      };
      var bag = {
        field,
        meta,
        form: restOfFormik
      };
      if (render2) {
        return render2(bag);
      }
      if (isFunction2(children)) {
        return children(bag);
      }
      if (component) {
        if (typeof component === "string") {
          var innerRef = props.innerRef, rest = _objectWithoutPropertiesLoose(props, ["innerRef"]);
          return (0, import_react6.createElement)(component, _extends({
            ref: innerRef
          }, field, rest), children);
        }
        return (0, import_react6.createElement)(component, _extends({
          field,
          form: formik
        }, props), children);
      }
      var asElement = is || "input";
      if (typeof asElement === "string") {
        var _innerRef = props.innerRef, _rest = _objectWithoutPropertiesLoose(props, ["innerRef"]);
        return (0, import_react6.createElement)(asElement, _extends({
          ref: _innerRef
        }, field, _rest), children);
      }
      return (0, import_react6.createElement)(asElement, _extends({}, field, props), children);
    };
    return FastFieldInner2;
  })(import_react6.Component);
  var FastField = /* @__PURE__ */ connect(FastFieldInner);

  // node_modules/piral-core/app.codegen
  var _5 = __toESM(require_react());
  var _6 = __toESM(require_react_dom());

  // node_modules/react-router/esm/react-router.js
  var react_router_exports = {};
  __export(react_router_exports, {
    MemoryRouter: () => MemoryRouter,
    Prompt: () => Prompt,
    Redirect: () => Redirect,
    Route: () => Route,
    Router: () => Router,
    StaticRouter: () => StaticRouter,
    Switch: () => Switch,
    __HistoryContext: () => historyContext,
    __RouterContext: () => context,
    generatePath: () => generatePath,
    matchPath: () => matchPath,
    useHistory: () => useHistory,
    useLocation: () => useLocation,
    useParams: () => useParams,
    useRouteMatch: () => useRouteMatch,
    withRouter: () => withRouter
  });

  // node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js
  function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t2, e2) {
      return t2.__proto__ = e2, t2;
    }, _setPrototypeOf(t, e);
  }

  // node_modules/@babel/runtime/helpers/esm/inheritsLoose.js
  function _inheritsLoose2(t, o) {
    t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o);
  }

  // node_modules/react-router/esm/react-router.js
  var import_react7 = __toESM(require_react());
  var import_prop_types = __toESM(require_prop_types());

  // node_modules/@babel/runtime/helpers/esm/extends.js
  function _extends2() {
    return _extends2 = Object.assign ? Object.assign.bind() : function(n) {
      for (var e = 1; e < arguments.length; e++) {
        var t = arguments[e];
        for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
      }
      return n;
    }, _extends2.apply(null, arguments);
  }

  // node_modules/resolve-pathname/esm/resolve-pathname.js
  function isAbsolute(pathname) {
    return pathname.charAt(0) === "/";
  }
  function spliceOne(list, index) {
    for (var i = index, k = i + 1, n = list.length; k < n; i += 1, k += 1) {
      list[i] = list[k];
    }
    list.pop();
  }
  function resolvePathname(to, from) {
    if (from === void 0) from = "";
    var toParts = to && to.split("/") || [];
    var fromParts = from && from.split("/") || [];
    var isToAbs = to && isAbsolute(to);
    var isFromAbs = from && isAbsolute(from);
    var mustEndAbs = isToAbs || isFromAbs;
    if (to && isAbsolute(to)) {
      fromParts = toParts;
    } else if (toParts.length) {
      fromParts.pop();
      fromParts = fromParts.concat(toParts);
    }
    if (!fromParts.length) return "/";
    var hasTrailingSlash;
    if (fromParts.length) {
      var last = fromParts[fromParts.length - 1];
      hasTrailingSlash = last === "." || last === ".." || last === "";
    } else {
      hasTrailingSlash = false;
    }
    var up = 0;
    for (var i = fromParts.length; i >= 0; i--) {
      var part = fromParts[i];
      if (part === ".") {
        spliceOne(fromParts, i);
      } else if (part === "..") {
        spliceOne(fromParts, i);
        up++;
      } else if (up) {
        spliceOne(fromParts, i);
        up--;
      }
    }
    if (!mustEndAbs) for (; up--; up) fromParts.unshift("..");
    if (mustEndAbs && fromParts[0] !== "" && (!fromParts[0] || !isAbsolute(fromParts[0])))
      fromParts.unshift("");
    var result = fromParts.join("/");
    if (hasTrailingSlash && result.substr(-1) !== "/") result += "/";
    return result;
  }
  var resolve_pathname_default = resolvePathname;

  // node_modules/value-equal/esm/value-equal.js
  function valueOf(obj) {
    return obj.valueOf ? obj.valueOf() : Object.prototype.valueOf.call(obj);
  }
  function valueEqual(a, b) {
    if (a === b) return true;
    if (a == null || b == null) return false;
    if (Array.isArray(a)) {
      return Array.isArray(b) && a.length === b.length && a.every(function(item, index) {
        return valueEqual(item, b[index]);
      });
    }
    if (typeof a === "object" || typeof b === "object") {
      var aValue = valueOf(a);
      var bValue = valueOf(b);
      if (aValue !== a || bValue !== b) return valueEqual(aValue, bValue);
      return Object.keys(Object.assign({}, a, b)).every(function(key) {
        return valueEqual(a[key], b[key]);
      });
    }
    return false;
  }
  var value_equal_default = valueEqual;

  // node_modules/tiny-invariant/dist/esm/tiny-invariant.js
  var isProduction2 = true;
  var prefix = "Invariant failed";
  function invariant(condition, message) {
    if (condition) {
      return;
    }
    if (isProduction2) {
      throw new Error(prefix);
    }
    var provided = typeof message === "function" ? message() : message;
    var value = provided ? "".concat(prefix, ": ").concat(provided) : prefix;
    throw new Error(value);
  }

  // node_modules/history/esm/history.js
  function addLeadingSlash(path) {
    return path.charAt(0) === "/" ? path : "/" + path;
  }
  function stripLeadingSlash(path) {
    return path.charAt(0) === "/" ? path.substr(1) : path;
  }
  function hasBasename(path, prefix2) {
    return path.toLowerCase().indexOf(prefix2.toLowerCase()) === 0 && "/?#".indexOf(path.charAt(prefix2.length)) !== -1;
  }
  function stripBasename(path, prefix2) {
    return hasBasename(path, prefix2) ? path.substr(prefix2.length) : path;
  }
  function stripTrailingSlash(path) {
    return path.charAt(path.length - 1) === "/" ? path.slice(0, -1) : path;
  }
  function parsePath(path) {
    var pathname = path || "/";
    var search = "";
    var hash = "";
    var hashIndex = pathname.indexOf("#");
    if (hashIndex !== -1) {
      hash = pathname.substr(hashIndex);
      pathname = pathname.substr(0, hashIndex);
    }
    var searchIndex = pathname.indexOf("?");
    if (searchIndex !== -1) {
      search = pathname.substr(searchIndex);
      pathname = pathname.substr(0, searchIndex);
    }
    return {
      pathname,
      search: search === "?" ? "" : search,
      hash: hash === "#" ? "" : hash
    };
  }
  function createPath(location2) {
    var pathname = location2.pathname, search = location2.search, hash = location2.hash;
    var path = pathname || "/";
    if (search && search !== "?") path += search.charAt(0) === "?" ? search : "?" + search;
    if (hash && hash !== "#") path += hash.charAt(0) === "#" ? hash : "#" + hash;
    return path;
  }
  function createLocation(path, state, key, currentLocation) {
    var location2;
    if (typeof path === "string") {
      location2 = parsePath(path);
      location2.state = state;
    } else {
      location2 = _extends2({}, path);
      if (location2.pathname === void 0) location2.pathname = "";
      if (location2.search) {
        if (location2.search.charAt(0) !== "?") location2.search = "?" + location2.search;
      } else {
        location2.search = "";
      }
      if (location2.hash) {
        if (location2.hash.charAt(0) !== "#") location2.hash = "#" + location2.hash;
      } else {
        location2.hash = "";
      }
      if (state !== void 0 && location2.state === void 0) location2.state = state;
    }
    try {
      location2.pathname = decodeURI(location2.pathname);
    } catch (e) {
      if (e instanceof URIError) {
        throw new URIError('Pathname "' + location2.pathname + '" could not be decoded. This is likely caused by an invalid percent-encoding.');
      } else {
        throw e;
      }
    }
    if (key) location2.key = key;
    if (currentLocation) {
      if (!location2.pathname) {
        location2.pathname = currentLocation.pathname;
      } else if (location2.pathname.charAt(0) !== "/") {
        location2.pathname = resolve_pathname_default(location2.pathname, currentLocation.pathname);
      }
    } else {
      if (!location2.pathname) {
        location2.pathname = "/";
      }
    }
    return location2;
  }
  function locationsAreEqual(a, b) {
    return a.pathname === b.pathname && a.search === b.search && a.hash === b.hash && a.key === b.key && value_equal_default(a.state, b.state);
  }
  function createTransitionManager() {
    var prompt = null;
    function setPrompt(nextPrompt) {
      false ? tiny_warning_esm_default(prompt == null, "A history supports only one prompt at a time") : void 0;
      prompt = nextPrompt;
      return function() {
        if (prompt === nextPrompt) prompt = null;
      };
    }
    function confirmTransitionTo(location2, action, getUserConfirmation, callback) {
      if (prompt != null) {
        var result = typeof prompt === "function" ? prompt(location2, action) : prompt;
        if (typeof result === "string") {
          if (typeof getUserConfirmation === "function") {
            getUserConfirmation(result, callback);
          } else {
            false ? tiny_warning_esm_default(false, "A history needs a getUserConfirmation function in order to use a prompt message") : void 0;
            callback(true);
          }
        } else {
          callback(result !== false);
        }
      } else {
        callback(true);
      }
    }
    var listeners = [];
    function appendListener(fn) {
      var isActive = true;
      function listener() {
        if (isActive) fn.apply(void 0, arguments);
      }
      listeners.push(listener);
      return function() {
        isActive = false;
        listeners = listeners.filter(function(item) {
          return item !== listener;
        });
      };
    }
    function notifyListeners() {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      listeners.forEach(function(listener) {
        return listener.apply(void 0, args);
      });
    }
    return {
      setPrompt,
      confirmTransitionTo,
      appendListener,
      notifyListeners
    };
  }
  var canUseDOM = !!(typeof window !== "undefined" && window.document && window.document.createElement);
  function getConfirmation(message, callback) {
    callback(window.confirm(message));
  }
  function supportsHistory() {
    var ua = window.navigator.userAgent;
    if ((ua.indexOf("Android 2.") !== -1 || ua.indexOf("Android 4.0") !== -1) && ua.indexOf("Mobile Safari") !== -1 && ua.indexOf("Chrome") === -1 && ua.indexOf("Windows Phone") === -1) return false;
    return window.history && "pushState" in window.history;
  }
  function supportsPopStateOnHashChange() {
    return window.navigator.userAgent.indexOf("Trident") === -1;
  }
  function supportsGoWithoutReloadUsingHash() {
    return window.navigator.userAgent.indexOf("Firefox") === -1;
  }
  function isExtraneousPopstateEvent(event) {
    return event.state === void 0 && navigator.userAgent.indexOf("CriOS") === -1;
  }
  var PopStateEvent = "popstate";
  var HashChangeEvent = "hashchange";
  function getHistoryState() {
    try {
      return window.history.state || {};
    } catch (e) {
      return {};
    }
  }
  function createBrowserHistory(props) {
    if (props === void 0) {
      props = {};
    }
    !canUseDOM ? false ? invariant(false, "Browser history needs a DOM") : invariant(false) : void 0;
    var globalHistory = window.history;
    var canUseHistory = supportsHistory();
    var needsHashChangeListener = !supportsPopStateOnHashChange();
    var _props = props, _props$forceRefresh = _props.forceRefresh, forceRefresh = _props$forceRefresh === void 0 ? false : _props$forceRefresh, _props$getUserConfirm = _props.getUserConfirmation, getUserConfirmation = _props$getUserConfirm === void 0 ? getConfirmation : _props$getUserConfirm, _props$keyLength = _props.keyLength, keyLength = _props$keyLength === void 0 ? 6 : _props$keyLength;
    var basename = props.basename ? stripTrailingSlash(addLeadingSlash(props.basename)) : "";
    function getDOMLocation(historyState) {
      var _ref = historyState || {}, key = _ref.key, state = _ref.state;
      var _window$location = window.location, pathname = _window$location.pathname, search = _window$location.search, hash = _window$location.hash;
      var path = pathname + search + hash;
      false ? tiny_warning_esm_default(!basename || hasBasename(path, basename), 'You are attempting to use a basename on a page whose URL path does not begin with the basename. Expected path "' + path + '" to begin with "' + basename + '".') : void 0;
      if (basename) path = stripBasename(path, basename);
      return createLocation(path, state, key);
    }
    function createKey() {
      return Math.random().toString(36).substr(2, keyLength);
    }
    var transitionManager = createTransitionManager();
    function setState(nextState) {
      _extends2(history, nextState);
      history.length = globalHistory.length;
      transitionManager.notifyListeners(history.location, history.action);
    }
    function handlePopState(event) {
      if (isExtraneousPopstateEvent(event)) return;
      handlePop(getDOMLocation(event.state));
    }
    function handleHashChange() {
      handlePop(getDOMLocation(getHistoryState()));
    }
    var forceNextPop = false;
    function handlePop(location2) {
      if (forceNextPop) {
        forceNextPop = false;
        setState();
      } else {
        var action = "POP";
        transitionManager.confirmTransitionTo(location2, action, getUserConfirmation, function(ok) {
          if (ok) {
            setState({
              action,
              location: location2
            });
          } else {
            revertPop(location2);
          }
        });
      }
    }
    function revertPop(fromLocation) {
      var toLocation = history.location;
      var toIndex = allKeys.indexOf(toLocation.key);
      if (toIndex === -1) toIndex = 0;
      var fromIndex = allKeys.indexOf(fromLocation.key);
      if (fromIndex === -1) fromIndex = 0;
      var delta = toIndex - fromIndex;
      if (delta) {
        forceNextPop = true;
        go(delta);
      }
    }
    var initialLocation = getDOMLocation(getHistoryState());
    var allKeys = [initialLocation.key];
    function createHref(location2) {
      return basename + createPath(location2);
    }
    function push(path, state) {
      false ? tiny_warning_esm_default(!(typeof path === "object" && path.state !== void 0 && state !== void 0), "You should avoid providing a 2nd state argument to push when the 1st argument is a location-like object that already has state; it is ignored") : void 0;
      var action = "PUSH";
      var location2 = createLocation(path, state, createKey(), history.location);
      transitionManager.confirmTransitionTo(location2, action, getUserConfirmation, function(ok) {
        if (!ok) return;
        var href = createHref(location2);
        var key = location2.key, state2 = location2.state;
        if (canUseHistory) {
          globalHistory.pushState({
            key,
            state: state2
          }, null, href);
          if (forceRefresh) {
            window.location.href = href;
          } else {
            var prevIndex = allKeys.indexOf(history.location.key);
            var nextKeys = allKeys.slice(0, prevIndex + 1);
            nextKeys.push(location2.key);
            allKeys = nextKeys;
            setState({
              action,
              location: location2
            });
          }
        } else {
          false ? tiny_warning_esm_default(state2 === void 0, "Browser history cannot push state in browsers that do not support HTML5 history") : void 0;
          window.location.href = href;
        }
      });
    }
    function replace3(path, state) {
      false ? tiny_warning_esm_default(!(typeof path === "object" && path.state !== void 0 && state !== void 0), "You should avoid providing a 2nd state argument to replace when the 1st argument is a location-like object that already has state; it is ignored") : void 0;
      var action = "REPLACE";
      var location2 = createLocation(path, state, createKey(), history.location);
      transitionManager.confirmTransitionTo(location2, action, getUserConfirmation, function(ok) {
        if (!ok) return;
        var href = createHref(location2);
        var key = location2.key, state2 = location2.state;
        if (canUseHistory) {
          globalHistory.replaceState({
            key,
            state: state2
          }, null, href);
          if (forceRefresh) {
            window.location.replace(href);
          } else {
            var prevIndex = allKeys.indexOf(history.location.key);
            if (prevIndex !== -1) allKeys[prevIndex] = location2.key;
            setState({
              action,
              location: location2
            });
          }
        } else {
          false ? tiny_warning_esm_default(state2 === void 0, "Browser history cannot replace state in browsers that do not support HTML5 history") : void 0;
          window.location.replace(href);
        }
      });
    }
    function go(n) {
      globalHistory.go(n);
    }
    function goBack() {
      go(-1);
    }
    function goForward() {
      go(1);
    }
    var listenerCount = 0;
    function checkDOMListeners(delta) {
      listenerCount += delta;
      if (listenerCount === 1 && delta === 1) {
        window.addEventListener(PopStateEvent, handlePopState);
        if (needsHashChangeListener) window.addEventListener(HashChangeEvent, handleHashChange);
      } else if (listenerCount === 0) {
        window.removeEventListener(PopStateEvent, handlePopState);
        if (needsHashChangeListener) window.removeEventListener(HashChangeEvent, handleHashChange);
      }
    }
    var isBlocked = false;
    function block(prompt) {
      if (prompt === void 0) {
        prompt = false;
      }
      var unblock = transitionManager.setPrompt(prompt);
      if (!isBlocked) {
        checkDOMListeners(1);
        isBlocked = true;
      }
      return function() {
        if (isBlocked) {
          isBlocked = false;
          checkDOMListeners(-1);
        }
        return unblock();
      };
    }
    function listen(listener) {
      var unlisten = transitionManager.appendListener(listener);
      checkDOMListeners(1);
      return function() {
        checkDOMListeners(-1);
        unlisten();
      };
    }
    var history = {
      length: globalHistory.length,
      action: "POP",
      location: initialLocation,
      createHref,
      push,
      replace: replace3,
      go,
      goBack,
      goForward,
      block,
      listen
    };
    return history;
  }
  var HashChangeEvent$1 = "hashchange";
  var HashPathCoders = {
    hashbang: {
      encodePath: function encodePath(path) {
        return path.charAt(0) === "!" ? path : "!/" + stripLeadingSlash(path);
      },
      decodePath: function decodePath(path) {
        return path.charAt(0) === "!" ? path.substr(1) : path;
      }
    },
    noslash: {
      encodePath: stripLeadingSlash,
      decodePath: addLeadingSlash
    },
    slash: {
      encodePath: addLeadingSlash,
      decodePath: addLeadingSlash
    }
  };
  function stripHash(url) {
    var hashIndex = url.indexOf("#");
    return hashIndex === -1 ? url : url.slice(0, hashIndex);
  }
  function getHashPath() {
    var href = window.location.href;
    var hashIndex = href.indexOf("#");
    return hashIndex === -1 ? "" : href.substring(hashIndex + 1);
  }
  function pushHashPath(path) {
    window.location.hash = path;
  }
  function replaceHashPath(path) {
    window.location.replace(stripHash(window.location.href) + "#" + path);
  }
  function createHashHistory(props) {
    if (props === void 0) {
      props = {};
    }
    !canUseDOM ? false ? invariant(false, "Hash history needs a DOM") : invariant(false) : void 0;
    var globalHistory = window.history;
    var canGoWithoutReload = supportsGoWithoutReloadUsingHash();
    var _props = props, _props$getUserConfirm = _props.getUserConfirmation, getUserConfirmation = _props$getUserConfirm === void 0 ? getConfirmation : _props$getUserConfirm, _props$hashType = _props.hashType, hashType = _props$hashType === void 0 ? "slash" : _props$hashType;
    var basename = props.basename ? stripTrailingSlash(addLeadingSlash(props.basename)) : "";
    var _HashPathCoders$hashT = HashPathCoders[hashType], encodePath2 = _HashPathCoders$hashT.encodePath, decodePath2 = _HashPathCoders$hashT.decodePath;
    function getDOMLocation() {
      var path2 = decodePath2(getHashPath());
      false ? tiny_warning_esm_default(!basename || hasBasename(path2, basename), 'You are attempting to use a basename on a page whose URL path does not begin with the basename. Expected path "' + path2 + '" to begin with "' + basename + '".') : void 0;
      if (basename) path2 = stripBasename(path2, basename);
      return createLocation(path2);
    }
    var transitionManager = createTransitionManager();
    function setState(nextState) {
      _extends2(history, nextState);
      history.length = globalHistory.length;
      transitionManager.notifyListeners(history.location, history.action);
    }
    var forceNextPop = false;
    var ignorePath = null;
    function locationsAreEqual$$1(a, b) {
      return a.pathname === b.pathname && a.search === b.search && a.hash === b.hash;
    }
    function handleHashChange() {
      var path2 = getHashPath();
      var encodedPath2 = encodePath2(path2);
      if (path2 !== encodedPath2) {
        replaceHashPath(encodedPath2);
      } else {
        var location2 = getDOMLocation();
        var prevLocation = history.location;
        if (!forceNextPop && locationsAreEqual$$1(prevLocation, location2)) return;
        if (ignorePath === createPath(location2)) return;
        ignorePath = null;
        handlePop(location2);
      }
    }
    function handlePop(location2) {
      if (forceNextPop) {
        forceNextPop = false;
        setState();
      } else {
        var action = "POP";
        transitionManager.confirmTransitionTo(location2, action, getUserConfirmation, function(ok) {
          if (ok) {
            setState({
              action,
              location: location2
            });
          } else {
            revertPop(location2);
          }
        });
      }
    }
    function revertPop(fromLocation) {
      var toLocation = history.location;
      var toIndex = allPaths.lastIndexOf(createPath(toLocation));
      if (toIndex === -1) toIndex = 0;
      var fromIndex = allPaths.lastIndexOf(createPath(fromLocation));
      if (fromIndex === -1) fromIndex = 0;
      var delta = toIndex - fromIndex;
      if (delta) {
        forceNextPop = true;
        go(delta);
      }
    }
    var path = getHashPath();
    var encodedPath = encodePath2(path);
    if (path !== encodedPath) replaceHashPath(encodedPath);
    var initialLocation = getDOMLocation();
    var allPaths = [createPath(initialLocation)];
    function createHref(location2) {
      var baseTag = document.querySelector("base");
      var href = "";
      if (baseTag && baseTag.getAttribute("href")) {
        href = stripHash(window.location.href);
      }
      return href + "#" + encodePath2(basename + createPath(location2));
    }
    function push(path2, state) {
      false ? tiny_warning_esm_default(state === void 0, "Hash history cannot push state; it is ignored") : void 0;
      var action = "PUSH";
      var location2 = createLocation(path2, void 0, void 0, history.location);
      transitionManager.confirmTransitionTo(location2, action, getUserConfirmation, function(ok) {
        if (!ok) return;
        var path3 = createPath(location2);
        var encodedPath2 = encodePath2(basename + path3);
        var hashChanged = getHashPath() !== encodedPath2;
        if (hashChanged) {
          ignorePath = path3;
          pushHashPath(encodedPath2);
          var prevIndex = allPaths.lastIndexOf(createPath(history.location));
          var nextPaths = allPaths.slice(0, prevIndex + 1);
          nextPaths.push(path3);
          allPaths = nextPaths;
          setState({
            action,
            location: location2
          });
        } else {
          false ? tiny_warning_esm_default(false, "Hash history cannot PUSH the same path; a new entry will not be added to the history stack") : void 0;
          setState();
        }
      });
    }
    function replace3(path2, state) {
      false ? tiny_warning_esm_default(state === void 0, "Hash history cannot replace state; it is ignored") : void 0;
      var action = "REPLACE";
      var location2 = createLocation(path2, void 0, void 0, history.location);
      transitionManager.confirmTransitionTo(location2, action, getUserConfirmation, function(ok) {
        if (!ok) return;
        var path3 = createPath(location2);
        var encodedPath2 = encodePath2(basename + path3);
        var hashChanged = getHashPath() !== encodedPath2;
        if (hashChanged) {
          ignorePath = path3;
          replaceHashPath(encodedPath2);
        }
        var prevIndex = allPaths.indexOf(createPath(history.location));
        if (prevIndex !== -1) allPaths[prevIndex] = path3;
        setState({
          action,
          location: location2
        });
      });
    }
    function go(n) {
      false ? tiny_warning_esm_default(canGoWithoutReload, "Hash history go(n) causes a full page reload in this browser") : void 0;
      globalHistory.go(n);
    }
    function goBack() {
      go(-1);
    }
    function goForward() {
      go(1);
    }
    var listenerCount = 0;
    function checkDOMListeners(delta) {
      listenerCount += delta;
      if (listenerCount === 1 && delta === 1) {
        window.addEventListener(HashChangeEvent$1, handleHashChange);
      } else if (listenerCount === 0) {
        window.removeEventListener(HashChangeEvent$1, handleHashChange);
      }
    }
    var isBlocked = false;
    function block(prompt) {
      if (prompt === void 0) {
        prompt = false;
      }
      var unblock = transitionManager.setPrompt(prompt);
      if (!isBlocked) {
        checkDOMListeners(1);
        isBlocked = true;
      }
      return function() {
        if (isBlocked) {
          isBlocked = false;
          checkDOMListeners(-1);
        }
        return unblock();
      };
    }
    function listen(listener) {
      var unlisten = transitionManager.appendListener(listener);
      checkDOMListeners(1);
      return function() {
        checkDOMListeners(-1);
        unlisten();
      };
    }
    var history = {
      length: globalHistory.length,
      action: "POP",
      location: initialLocation,
      createHref,
      push,
      replace: replace3,
      go,
      goBack,
      goForward,
      block,
      listen
    };
    return history;
  }
  function clamp(n, lowerBound, upperBound) {
    return Math.min(Math.max(n, lowerBound), upperBound);
  }
  function createMemoryHistory(props) {
    if (props === void 0) {
      props = {};
    }
    var _props = props, getUserConfirmation = _props.getUserConfirmation, _props$initialEntries = _props.initialEntries, initialEntries = _props$initialEntries === void 0 ? ["/"] : _props$initialEntries, _props$initialIndex = _props.initialIndex, initialIndex = _props$initialIndex === void 0 ? 0 : _props$initialIndex, _props$keyLength = _props.keyLength, keyLength = _props$keyLength === void 0 ? 6 : _props$keyLength;
    var transitionManager = createTransitionManager();
    function setState(nextState) {
      _extends2(history, nextState);
      history.length = history.entries.length;
      transitionManager.notifyListeners(history.location, history.action);
    }
    function createKey() {
      return Math.random().toString(36).substr(2, keyLength);
    }
    var index = clamp(initialIndex, 0, initialEntries.length - 1);
    var entries = initialEntries.map(function(entry) {
      return typeof entry === "string" ? createLocation(entry, void 0, createKey()) : createLocation(entry, void 0, entry.key || createKey());
    });
    var createHref = createPath;
    function push(path, state) {
      false ? tiny_warning_esm_default(!(typeof path === "object" && path.state !== void 0 && state !== void 0), "You should avoid providing a 2nd state argument to push when the 1st argument is a location-like object that already has state; it is ignored") : void 0;
      var action = "PUSH";
      var location2 = createLocation(path, state, createKey(), history.location);
      transitionManager.confirmTransitionTo(location2, action, getUserConfirmation, function(ok) {
        if (!ok) return;
        var prevIndex = history.index;
        var nextIndex = prevIndex + 1;
        var nextEntries = history.entries.slice(0);
        if (nextEntries.length > nextIndex) {
          nextEntries.splice(nextIndex, nextEntries.length - nextIndex, location2);
        } else {
          nextEntries.push(location2);
        }
        setState({
          action,
          location: location2,
          index: nextIndex,
          entries: nextEntries
        });
      });
    }
    function replace3(path, state) {
      false ? tiny_warning_esm_default(!(typeof path === "object" && path.state !== void 0 && state !== void 0), "You should avoid providing a 2nd state argument to replace when the 1st argument is a location-like object that already has state; it is ignored") : void 0;
      var action = "REPLACE";
      var location2 = createLocation(path, state, createKey(), history.location);
      transitionManager.confirmTransitionTo(location2, action, getUserConfirmation, function(ok) {
        if (!ok) return;
        history.entries[history.index] = location2;
        setState({
          action,
          location: location2
        });
      });
    }
    function go(n) {
      var nextIndex = clamp(history.index + n, 0, history.entries.length - 1);
      var action = "POP";
      var location2 = history.entries[nextIndex];
      transitionManager.confirmTransitionTo(location2, action, getUserConfirmation, function(ok) {
        if (ok) {
          setState({
            action,
            location: location2,
            index: nextIndex
          });
        } else {
          setState();
        }
      });
    }
    function goBack() {
      go(-1);
    }
    function goForward() {
      go(1);
    }
    function canGo(n) {
      var nextIndex = history.index + n;
      return nextIndex >= 0 && nextIndex < history.entries.length;
    }
    function block(prompt) {
      if (prompt === void 0) {
        prompt = false;
      }
      return transitionManager.setPrompt(prompt);
    }
    function listen(listener) {
      return transitionManager.appendListener(listener);
    }
    var history = {
      length: entries.length,
      action: "POP",
      location: entries[index],
      index,
      entries,
      createHref,
      push,
      replace: replace3,
      go,
      goBack,
      goForward,
      canGo,
      block,
      listen
    };
    return history;
  }

  // node_modules/react-router/esm/react-router.js
  var import_path_to_regexp = __toESM(require_path_to_regexp());
  var import_react_is = __toESM(require_react_is());

  // node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js
  function _objectWithoutPropertiesLoose2(r, e) {
    if (null == r) return {};
    var t = {};
    for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
      if (-1 !== e.indexOf(n)) continue;
      t[n] = r[n];
    }
    return t;
  }

  // node_modules/react-router/esm/react-router.js
  var import_hoist_non_react_statics2 = __toESM(require_hoist_non_react_statics_cjs());
  var MAX_SIGNED_31_BIT_INT = 1073741823;
  var commonjsGlobal = typeof globalThis !== "undefined" ? (
    // eslint-disable-next-line no-undef
    globalThis
  ) : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {};
  function getUniqueId() {
    var key = "__global_unique_id__";
    return commonjsGlobal[key] = (commonjsGlobal[key] || 0) + 1;
  }
  function objectIs(x, y) {
    if (x === y) {
      return x !== 0 || 1 / x === 1 / y;
    } else {
      return x !== x && y !== y;
    }
  }
  function createEventEmitter(value) {
    var handlers = [];
    return {
      on: function on(handler) {
        handlers.push(handler);
      },
      off: function off(handler) {
        handlers = handlers.filter(function(h2) {
          return h2 !== handler;
        });
      },
      get: function get() {
        return value;
      },
      set: function set(newValue, changedBits) {
        value = newValue;
        handlers.forEach(function(handler) {
          return handler(value, changedBits);
        });
      }
    };
  }
  function onlyChild(children) {
    return Array.isArray(children) ? children[0] : children;
  }
  function createReactContext(defaultValue, calculateChangedBits) {
    var _Provider$childContex, _Consumer$contextType;
    var contextProp = "__create-react-context-" + getUniqueId() + "__";
    var Provider = /* @__PURE__ */ (function(_React$Component) {
      _inheritsLoose2(Provider2, _React$Component);
      function Provider2() {
        var _this;
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
        _this = _React$Component.call.apply(_React$Component, [this].concat(args)) || this;
        _this.emitter = createEventEmitter(_this.props.value);
        return _this;
      }
      var _proto = Provider2.prototype;
      _proto.getChildContext = function getChildContext() {
        var _ref;
        return _ref = {}, _ref[contextProp] = this.emitter, _ref;
      };
      _proto.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
        if (this.props.value !== nextProps.value) {
          var oldValue = this.props.value;
          var newValue = nextProps.value;
          var changedBits;
          if (objectIs(oldValue, newValue)) {
            changedBits = 0;
          } else {
            changedBits = typeof calculateChangedBits === "function" ? calculateChangedBits(oldValue, newValue) : MAX_SIGNED_31_BIT_INT;
            if (false) {
              false ? tiny_warning_esm_default((changedBits & MAX_SIGNED_31_BIT_INT) === changedBits, "calculateChangedBits: Expected the return value to be a 31-bit integer. Instead received: " + changedBits) : void 0;
            }
            changedBits |= 0;
            if (changedBits !== 0) {
              this.emitter.set(nextProps.value, changedBits);
            }
          }
        }
      };
      _proto.render = function render() {
        return this.props.children;
      };
      return Provider2;
    })(import_react7.default.Component);
    Provider.childContextTypes = (_Provider$childContex = {}, _Provider$childContex[contextProp] = import_prop_types.default.object.isRequired, _Provider$childContex);
    var Consumer = /* @__PURE__ */ (function(_React$Component2) {
      _inheritsLoose2(Consumer2, _React$Component2);
      function Consumer2() {
        var _this2;
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }
        _this2 = _React$Component2.call.apply(_React$Component2, [this].concat(args)) || this;
        _this2.observedBits = void 0;
        _this2.state = {
          value: _this2.getValue()
        };
        _this2.onUpdate = function(newValue, changedBits) {
          var observedBits = _this2.observedBits | 0;
          if ((observedBits & changedBits) !== 0) {
            _this2.setState({
              value: _this2.getValue()
            });
          }
        };
        return _this2;
      }
      var _proto2 = Consumer2.prototype;
      _proto2.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
        var observedBits = nextProps.observedBits;
        this.observedBits = observedBits === void 0 || observedBits === null ? MAX_SIGNED_31_BIT_INT : observedBits;
      };
      _proto2.componentDidMount = function componentDidMount() {
        if (this.context[contextProp]) {
          this.context[contextProp].on(this.onUpdate);
        }
        var observedBits = this.props.observedBits;
        this.observedBits = observedBits === void 0 || observedBits === null ? MAX_SIGNED_31_BIT_INT : observedBits;
      };
      _proto2.componentWillUnmount = function componentWillUnmount() {
        if (this.context[contextProp]) {
          this.context[contextProp].off(this.onUpdate);
        }
      };
      _proto2.getValue = function getValue4() {
        if (this.context[contextProp]) {
          return this.context[contextProp].get();
        } else {
          return defaultValue;
        }
      };
      _proto2.render = function render() {
        return onlyChild(this.props.children)(this.state.value);
      };
      return Consumer2;
    })(import_react7.default.Component);
    Consumer.contextTypes = (_Consumer$contextType = {}, _Consumer$contextType[contextProp] = import_prop_types.default.object, _Consumer$contextType);
    return {
      Provider,
      Consumer
    };
  }
  var createContext3 = import_react7.default.createContext || createReactContext;
  var createNamedContext = function createNamedContext2(name) {
    var context2 = createContext3();
    context2.displayName = name;
    return context2;
  };
  var historyContext = /* @__PURE__ */ createNamedContext("Router-History");
  var context = /* @__PURE__ */ createNamedContext("Router");
  var Router = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose2(Router2, _React$Component);
    Router2.computeRootMatch = function computeRootMatch(pathname) {
      return {
        path: "/",
        url: "/",
        params: {},
        isExact: pathname === "/"
      };
    };
    function Router2(props) {
      var _this;
      _this = _React$Component.call(this, props) || this;
      _this.state = {
        location: props.history.location
      };
      _this._isMounted = false;
      _this._pendingLocation = null;
      if (!props.staticContext) {
        _this.unlisten = props.history.listen(function(location2) {
          _this._pendingLocation = location2;
        });
      }
      return _this;
    }
    var _proto = Router2.prototype;
    _proto.componentDidMount = function componentDidMount() {
      var _this2 = this;
      this._isMounted = true;
      if (this.unlisten) {
        this.unlisten();
      }
      if (!this.props.staticContext) {
        this.unlisten = this.props.history.listen(function(location2) {
          if (_this2._isMounted) {
            _this2.setState({
              location: location2
            });
          }
        });
      }
      if (this._pendingLocation) {
        this.setState({
          location: this._pendingLocation
        });
      }
    };
    _proto.componentWillUnmount = function componentWillUnmount() {
      if (this.unlisten) {
        this.unlisten();
        this._isMounted = false;
        this._pendingLocation = null;
      }
    };
    _proto.render = function render() {
      return /* @__PURE__ */ import_react7.default.createElement(context.Provider, {
        value: {
          history: this.props.history,
          location: this.state.location,
          match: Router2.computeRootMatch(this.state.location.pathname),
          staticContext: this.props.staticContext
        }
      }, /* @__PURE__ */ import_react7.default.createElement(historyContext.Provider, {
        children: this.props.children || null,
        value: this.props.history
      }));
    };
    return Router2;
  })(import_react7.default.Component);
  if (false) {
    Router.propTypes = {
      children: import_prop_types.default.node,
      history: import_prop_types.default.object.isRequired,
      staticContext: import_prop_types.default.object
    };
    Router.prototype.componentDidUpdate = function(prevProps) {
      false ? tiny_warning_esm_default(prevProps.history === this.props.history, "You cannot change <Router history>") : void 0;
    };
  }
  var MemoryRouter = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose2(MemoryRouter2, _React$Component);
    function MemoryRouter2() {
      var _this;
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _React$Component.call.apply(_React$Component, [this].concat(args)) || this;
      _this.history = createMemoryHistory(_this.props);
      return _this;
    }
    var _proto = MemoryRouter2.prototype;
    _proto.render = function render() {
      return /* @__PURE__ */ import_react7.default.createElement(Router, {
        history: this.history,
        children: this.props.children
      });
    };
    return MemoryRouter2;
  })(import_react7.default.Component);
  if (false) {
    MemoryRouter.propTypes = {
      initialEntries: import_prop_types.default.array,
      initialIndex: import_prop_types.default.number,
      getUserConfirmation: import_prop_types.default.func,
      keyLength: import_prop_types.default.number,
      children: import_prop_types.default.node
    };
    MemoryRouter.prototype.componentDidMount = function() {
      false ? tiny_warning_esm_default(!this.props.history, "<MemoryRouter> ignores the history prop. To use a custom history, use `import { Router }` instead of `import { MemoryRouter as Router }`.") : void 0;
    };
  }
  var Lifecycle = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose2(Lifecycle2, _React$Component);
    function Lifecycle2() {
      return _React$Component.apply(this, arguments) || this;
    }
    var _proto = Lifecycle2.prototype;
    _proto.componentDidMount = function componentDidMount() {
      if (this.props.onMount) this.props.onMount.call(this, this);
    };
    _proto.componentDidUpdate = function componentDidUpdate(prevProps) {
      if (this.props.onUpdate) this.props.onUpdate.call(this, this, prevProps);
    };
    _proto.componentWillUnmount = function componentWillUnmount() {
      if (this.props.onUnmount) this.props.onUnmount.call(this, this);
    };
    _proto.render = function render() {
      return null;
    };
    return Lifecycle2;
  })(import_react7.default.Component);
  function Prompt(_ref) {
    var message = _ref.message, _ref$when = _ref.when, when = _ref$when === void 0 ? true : _ref$when;
    return /* @__PURE__ */ import_react7.default.createElement(context.Consumer, null, function(context2) {
      !context2 ? false ? invariant(false, "You should not use <Prompt> outside a <Router>") : invariant(false) : void 0;
      if (!when || context2.staticContext) return null;
      var method = context2.history.block;
      return /* @__PURE__ */ import_react7.default.createElement(Lifecycle, {
        onMount: function onMount(self2) {
          self2.release = method(message);
        },
        onUpdate: function onUpdate(self2, prevProps) {
          if (prevProps.message !== message) {
            self2.release();
            self2.release = method(message);
          }
        },
        onUnmount: function onUnmount(self2) {
          self2.release();
        },
        message
      });
    });
  }
  if (false) {
    messageType = import_prop_types.default.oneOfType([import_prop_types.default.func, import_prop_types.default.string]);
    Prompt.propTypes = {
      when: import_prop_types.default.bool,
      message: messageType.isRequired
    };
  }
  var messageType;
  var cache = {};
  var cacheLimit = 1e4;
  var cacheCount = 0;
  function compilePath(path) {
    if (cache[path]) return cache[path];
    var generator = import_path_to_regexp.default.compile(path);
    if (cacheCount < cacheLimit) {
      cache[path] = generator;
      cacheCount++;
    }
    return generator;
  }
  function generatePath(path, params) {
    if (path === void 0) {
      path = "/";
    }
    if (params === void 0) {
      params = {};
    }
    return path === "/" ? path : compilePath(path)(params, {
      pretty: true
    });
  }
  function Redirect(_ref) {
    var computedMatch = _ref.computedMatch, to = _ref.to, _ref$push = _ref.push, push = _ref$push === void 0 ? false : _ref$push;
    return /* @__PURE__ */ import_react7.default.createElement(context.Consumer, null, function(context2) {
      !context2 ? false ? invariant(false, "You should not use <Redirect> outside a <Router>") : invariant(false) : void 0;
      var history = context2.history, staticContext = context2.staticContext;
      var method = push ? history.push : history.replace;
      var location2 = createLocation(computedMatch ? typeof to === "string" ? generatePath(to, computedMatch.params) : _extends2({}, to, {
        pathname: generatePath(to.pathname, computedMatch.params)
      }) : to);
      if (staticContext) {
        method(location2);
        return null;
      }
      return /* @__PURE__ */ import_react7.default.createElement(Lifecycle, {
        onMount: function onMount() {
          method(location2);
        },
        onUpdate: function onUpdate(self2, prevProps) {
          var prevLocation = createLocation(prevProps.to);
          if (!locationsAreEqual(prevLocation, _extends2({}, location2, {
            key: prevLocation.key
          }))) {
            method(location2);
          }
        },
        to
      });
    });
  }
  if (false) {
    Redirect.propTypes = {
      push: import_prop_types.default.bool,
      from: import_prop_types.default.string,
      to: import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.object]).isRequired
    };
  }
  var cache$1 = {};
  var cacheLimit$1 = 1e4;
  var cacheCount$1 = 0;
  function compilePath$1(path, options) {
    var cacheKey = "" + options.end + options.strict + options.sensitive;
    var pathCache = cache$1[cacheKey] || (cache$1[cacheKey] = {});
    if (pathCache[path]) return pathCache[path];
    var keys2 = [];
    var regexp = (0, import_path_to_regexp.default)(path, keys2, options);
    var result = {
      regexp,
      keys: keys2
    };
    if (cacheCount$1 < cacheLimit$1) {
      pathCache[path] = result;
      cacheCount$1++;
    }
    return result;
  }
  function matchPath(pathname, options) {
    if (options === void 0) {
      options = {};
    }
    if (typeof options === "string" || Array.isArray(options)) {
      options = {
        path: options
      };
    }
    var _options = options, path = _options.path, _options$exact = _options.exact, exact = _options$exact === void 0 ? false : _options$exact, _options$strict = _options.strict, strict = _options$strict === void 0 ? false : _options$strict, _options$sensitive = _options.sensitive, sensitive = _options$sensitive === void 0 ? false : _options$sensitive;
    var paths = [].concat(path);
    return paths.reduce(function(matched, path2) {
      if (!path2 && path2 !== "") return null;
      if (matched) return matched;
      var _compilePath = compilePath$1(path2, {
        end: exact,
        strict,
        sensitive
      }), regexp = _compilePath.regexp, keys2 = _compilePath.keys;
      var match = regexp.exec(pathname);
      if (!match) return null;
      var url = match[0], values = match.slice(1);
      var isExact = pathname === url;
      if (exact && !isExact) return null;
      return {
        path: path2,
        // the path used to match
        url: path2 === "/" && url === "" ? "/" : url,
        // the matched portion of the URL
        isExact,
        // whether or not we matched exactly
        params: keys2.reduce(function(memo2, key, index) {
          memo2[key.name] = values[index];
          return memo2;
        }, {})
      };
    }, null);
  }
  function isEmptyChildren3(children) {
    return import_react7.default.Children.count(children) === 0;
  }
  var Route = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose2(Route2, _React$Component);
    function Route2() {
      return _React$Component.apply(this, arguments) || this;
    }
    var _proto = Route2.prototype;
    _proto.render = function render() {
      var _this = this;
      return /* @__PURE__ */ import_react7.default.createElement(context.Consumer, null, function(context$1) {
        !context$1 ? false ? invariant(false, "You should not use <Route> outside a <Router>") : invariant(false) : void 0;
        var location2 = _this.props.location || context$1.location;
        var match = _this.props.computedMatch ? _this.props.computedMatch : _this.props.path ? matchPath(location2.pathname, _this.props) : context$1.match;
        var props = _extends2({}, context$1, {
          location: location2,
          match
        });
        var _this$props = _this.props, children = _this$props.children, component = _this$props.component, render2 = _this$props.render;
        if (Array.isArray(children) && isEmptyChildren3(children)) {
          children = null;
        }
        return /* @__PURE__ */ import_react7.default.createElement(context.Provider, {
          value: props
        }, props.match ? children ? typeof children === "function" ? false ? evalChildrenDev(children, props, _this.props.path) : children(props) : children : component ? /* @__PURE__ */ import_react7.default.createElement(component, props) : render2 ? render2(props) : null : typeof children === "function" ? false ? evalChildrenDev(children, props, _this.props.path) : children(props) : null);
      });
    };
    return Route2;
  })(import_react7.default.Component);
  if (false) {
    Route.propTypes = {
      children: import_prop_types.default.oneOfType([import_prop_types.default.func, import_prop_types.default.node]),
      component: function component(props, propName) {
        if (props[propName] && !(0, import_react_is.isValidElementType)(props[propName])) {
          return new Error("Invalid prop 'component' supplied to 'Route': the prop is not a valid React component");
        }
      },
      exact: import_prop_types.default.bool,
      location: import_prop_types.default.object,
      path: import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.arrayOf(import_prop_types.default.string)]),
      render: import_prop_types.default.func,
      sensitive: import_prop_types.default.bool,
      strict: import_prop_types.default.bool
    };
    Route.prototype.componentDidMount = function() {
      false ? tiny_warning_esm_default(!(this.props.children && !isEmptyChildren3(this.props.children) && this.props.component), "You should not use <Route component> and <Route children> in the same route; <Route component> will be ignored") : void 0;
      false ? tiny_warning_esm_default(!(this.props.children && !isEmptyChildren3(this.props.children) && this.props.render), "You should not use <Route render> and <Route children> in the same route; <Route render> will be ignored") : void 0;
      false ? tiny_warning_esm_default(!(this.props.component && this.props.render), "You should not use <Route component> and <Route render> in the same route; <Route render> will be ignored") : void 0;
    };
    Route.prototype.componentDidUpdate = function(prevProps) {
      false ? tiny_warning_esm_default(!(this.props.location && !prevProps.location), '<Route> elements should not change from uncontrolled to controlled (or vice versa). You initially used no "location" prop and then provided one on a subsequent render.') : void 0;
      false ? tiny_warning_esm_default(!(!this.props.location && prevProps.location), '<Route> elements should not change from controlled to uncontrolled (or vice versa). You provided a "location" prop initially but omitted it on a subsequent render.') : void 0;
    };
  }
  function addLeadingSlash2(path) {
    return path.charAt(0) === "/" ? path : "/" + path;
  }
  function addBasename(basename, location2) {
    if (!basename) return location2;
    return _extends2({}, location2, {
      pathname: addLeadingSlash2(basename) + location2.pathname
    });
  }
  function stripBasename2(basename, location2) {
    if (!basename) return location2;
    var base = addLeadingSlash2(basename);
    if (location2.pathname.indexOf(base) !== 0) return location2;
    return _extends2({}, location2, {
      pathname: location2.pathname.substr(base.length)
    });
  }
  function createURL(location2) {
    return typeof location2 === "string" ? location2 : createPath(location2);
  }
  function staticHandler(methodName) {
    return function() {
      false ? invariant(false, "You cannot %s with <StaticRouter>", methodName) : invariant(false);
    };
  }
  function noop2() {
  }
  var StaticRouter = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose2(StaticRouter2, _React$Component);
    function StaticRouter2() {
      var _this;
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _React$Component.call.apply(_React$Component, [this].concat(args)) || this;
      _this.handlePush = function(location2) {
        return _this.navigateTo(location2, "PUSH");
      };
      _this.handleReplace = function(location2) {
        return _this.navigateTo(location2, "REPLACE");
      };
      _this.handleListen = function() {
        return noop2;
      };
      _this.handleBlock = function() {
        return noop2;
      };
      return _this;
    }
    var _proto = StaticRouter2.prototype;
    _proto.navigateTo = function navigateTo(location2, action) {
      var _this$props = this.props, _this$props$basename = _this$props.basename, basename = _this$props$basename === void 0 ? "" : _this$props$basename, _this$props$context = _this$props.context, context2 = _this$props$context === void 0 ? {} : _this$props$context;
      context2.action = action;
      context2.location = addBasename(basename, createLocation(location2));
      context2.url = createURL(context2.location);
    };
    _proto.render = function render() {
      var _this$props2 = this.props, _this$props2$basename = _this$props2.basename, basename = _this$props2$basename === void 0 ? "" : _this$props2$basename, _this$props2$context = _this$props2.context, context2 = _this$props2$context === void 0 ? {} : _this$props2$context, _this$props2$location = _this$props2.location, location2 = _this$props2$location === void 0 ? "/" : _this$props2$location, rest = _objectWithoutPropertiesLoose2(_this$props2, ["basename", "context", "location"]);
      var history = {
        createHref: function createHref(path) {
          return addLeadingSlash2(basename + createURL(path));
        },
        action: "POP",
        location: stripBasename2(basename, createLocation(location2)),
        push: this.handlePush,
        replace: this.handleReplace,
        go: staticHandler("go"),
        goBack: staticHandler("goBack"),
        goForward: staticHandler("goForward"),
        listen: this.handleListen,
        block: this.handleBlock
      };
      return /* @__PURE__ */ import_react7.default.createElement(Router, _extends2({}, rest, {
        history,
        staticContext: context2
      }));
    };
    return StaticRouter2;
  })(import_react7.default.Component);
  if (false) {
    StaticRouter.propTypes = {
      basename: import_prop_types.default.string,
      context: import_prop_types.default.object,
      location: import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.object])
    };
    StaticRouter.prototype.componentDidMount = function() {
      false ? tiny_warning_esm_default(!this.props.history, "<StaticRouter> ignores the history prop. To use a custom history, use `import { Router }` instead of `import { StaticRouter as Router }`.") : void 0;
    };
  }
  var Switch = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose2(Switch2, _React$Component);
    function Switch2() {
      return _React$Component.apply(this, arguments) || this;
    }
    var _proto = Switch2.prototype;
    _proto.render = function render() {
      var _this = this;
      return /* @__PURE__ */ import_react7.default.createElement(context.Consumer, null, function(context2) {
        !context2 ? false ? invariant(false, "You should not use <Switch> outside a <Router>") : invariant(false) : void 0;
        var location2 = _this.props.location || context2.location;
        var element, match;
        import_react7.default.Children.forEach(_this.props.children, function(child) {
          if (match == null && /* @__PURE__ */ import_react7.default.isValidElement(child)) {
            element = child;
            var path = child.props.path || child.props.from;
            match = path ? matchPath(location2.pathname, _extends2({}, child.props, {
              path
            })) : context2.match;
          }
        });
        return match ? /* @__PURE__ */ import_react7.default.cloneElement(element, {
          location: location2,
          computedMatch: match
        }) : null;
      });
    };
    return Switch2;
  })(import_react7.default.Component);
  if (false) {
    Switch.propTypes = {
      children: import_prop_types.default.node,
      location: import_prop_types.default.object
    };
    Switch.prototype.componentDidUpdate = function(prevProps) {
      false ? tiny_warning_esm_default(!(this.props.location && !prevProps.location), '<Switch> elements should not change from uncontrolled to controlled (or vice versa). You initially used no "location" prop and then provided one on a subsequent render.') : void 0;
      false ? tiny_warning_esm_default(!(!this.props.location && prevProps.location), '<Switch> elements should not change from controlled to uncontrolled (or vice versa). You provided a "location" prop initially but omitted it on a subsequent render.') : void 0;
    };
  }
  function withRouter(Component4) {
    var displayName = "withRouter(" + (Component4.displayName || Component4.name) + ")";
    var C = function C2(props) {
      var wrappedComponentRef = props.wrappedComponentRef, remainingProps = _objectWithoutPropertiesLoose2(props, ["wrappedComponentRef"]);
      return /* @__PURE__ */ import_react7.default.createElement(context.Consumer, null, function(context2) {
        !context2 ? false ? invariant(false, "You should not use <" + displayName + " /> outside a <Router>") : invariant(false) : void 0;
        return /* @__PURE__ */ import_react7.default.createElement(Component4, _extends2({}, remainingProps, context2, {
          ref: wrappedComponentRef
        }));
      });
    };
    C.displayName = displayName;
    C.WrappedComponent = Component4;
    if (false) {
      C.propTypes = {
        wrappedComponentRef: import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.func, import_prop_types.default.object])
      };
    }
    return (0, import_hoist_non_react_statics2.default)(C, Component4);
  }
  var useContext3 = import_react7.default.useContext;
  function useHistory() {
    if (false) {
      !(typeof useContext3 === "function") ? false ? invariant(false, "You must use React >= 16.8 in order to use useHistory()") : invariant(false) : void 0;
    }
    return useContext3(historyContext);
  }
  function useLocation() {
    if (false) {
      !(typeof useContext3 === "function") ? false ? invariant(false, "You must use React >= 16.8 in order to use useLocation()") : invariant(false) : void 0;
    }
    return useContext3(context).location;
  }
  function useParams() {
    if (false) {
      !(typeof useContext3 === "function") ? false ? invariant(false, "You must use React >= 16.8 in order to use useParams()") : invariant(false) : void 0;
    }
    var match = useContext3(context).match;
    return match ? match.params : {};
  }
  function useRouteMatch(path) {
    if (false) {
      !(typeof useContext3 === "function") ? false ? invariant(false, "You must use React >= 16.8 in order to use useRouteMatch()") : invariant(false) : void 0;
    }
    var location2 = useLocation();
    var match = useContext3(context).match;
    return path ? matchPath(location2.pathname, path) : match;
  }
  if (false) {
    if (typeof window !== "undefined") {
      global$1 = window;
      key = "__react_router_build__";
      buildNames = {
        cjs: "CommonJS",
        esm: "ES modules",
        umd: "UMD"
      };
      if (global$1[key] && global$1[key] !== "esm") {
        initialBuildName = buildNames[global$1[key]];
        secondaryBuildName = buildNames["esm"];
        throw new Error("You are loading the " + secondaryBuildName + " build of React Router " + ("on a page that is already running the " + initialBuildName + " ") + "build, so things won't work right.");
      }
      global$1[key] = "esm";
    }
  }
  var global$1;
  var key;
  var buildNames;
  var initialBuildName;
  var secondaryBuildName;

  // node_modules/react-router-dom/esm/react-router-dom.js
  var react_router_dom_exports = {};
  __export(react_router_dom_exports, {
    BrowserRouter: () => BrowserRouter,
    HashRouter: () => HashRouter,
    Link: () => Link,
    MemoryRouter: () => MemoryRouter,
    NavLink: () => NavLink,
    Prompt: () => Prompt,
    Redirect: () => Redirect,
    Route: () => Route,
    Router: () => Router,
    StaticRouter: () => StaticRouter,
    Switch: () => Switch,
    generatePath: () => generatePath,
    matchPath: () => matchPath,
    useHistory: () => useHistory,
    useLocation: () => useLocation,
    useParams: () => useParams,
    useRouteMatch: () => useRouteMatch,
    withRouter: () => withRouter
  });
  var import_react8 = __toESM(require_react());
  var BrowserRouter = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose2(BrowserRouter2, _React$Component);
    function BrowserRouter2() {
      var _this;
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _React$Component.call.apply(_React$Component, [this].concat(args)) || this;
      _this.history = createBrowserHistory(_this.props);
      return _this;
    }
    var _proto = BrowserRouter2.prototype;
    _proto.render = function render() {
      return /* @__PURE__ */ import_react8.default.createElement(Router, {
        history: this.history,
        children: this.props.children
      });
    };
    return BrowserRouter2;
  })(import_react8.default.Component);
  if (false) {
    BrowserRouter.propTypes = {
      basename: import_prop_types.default.string,
      children: import_prop_types.default.node,
      forceRefresh: import_prop_types.default.bool,
      getUserConfirmation: import_prop_types.default.func,
      keyLength: import_prop_types.default.number
    };
    BrowserRouter.prototype.componentDidMount = function() {
      false ? tiny_warning_esm_default(!this.props.history, "<BrowserRouter> ignores the history prop. To use a custom history, use `import { Router }` instead of `import { BrowserRouter as Router }`.") : void 0;
    };
  }
  var HashRouter = /* @__PURE__ */ (function(_React$Component) {
    _inheritsLoose2(HashRouter2, _React$Component);
    function HashRouter2() {
      var _this;
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _React$Component.call.apply(_React$Component, [this].concat(args)) || this;
      _this.history = createHashHistory(_this.props);
      return _this;
    }
    var _proto = HashRouter2.prototype;
    _proto.render = function render() {
      return /* @__PURE__ */ import_react8.default.createElement(Router, {
        history: this.history,
        children: this.props.children
      });
    };
    return HashRouter2;
  })(import_react8.default.Component);
  if (false) {
    HashRouter.propTypes = {
      basename: import_prop_types.default.string,
      children: import_prop_types.default.node,
      getUserConfirmation: import_prop_types.default.func,
      hashType: import_prop_types.default.oneOf(["hashbang", "noslash", "slash"])
    };
    HashRouter.prototype.componentDidMount = function() {
      false ? tiny_warning_esm_default(!this.props.history, "<HashRouter> ignores the history prop. To use a custom history, use `import { Router }` instead of `import { HashRouter as Router }`.") : void 0;
    };
  }
  var resolveToLocation = function resolveToLocation2(to, currentLocation) {
    return typeof to === "function" ? to(currentLocation) : to;
  };
  var normalizeToLocation = function normalizeToLocation2(to, currentLocation) {
    return typeof to === "string" ? createLocation(to, null, null, currentLocation) : to;
  };
  var forwardRefShim = function forwardRefShim2(C) {
    return C;
  };
  var forwardRef2 = import_react8.default.forwardRef;
  if (typeof forwardRef2 === "undefined") {
    forwardRef2 = forwardRefShim;
  }
  function isModifiedEvent(event) {
    return !!(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);
  }
  var LinkAnchor = forwardRef2(function(_ref, forwardedRef) {
    var innerRef = _ref.innerRef, navigate = _ref.navigate, _onClick = _ref.onClick, rest = _objectWithoutPropertiesLoose2(_ref, ["innerRef", "navigate", "onClick"]);
    var target = rest.target;
    var props = _extends2({}, rest, {
      onClick: function onClick(event) {
        try {
          if (_onClick) _onClick(event);
        } catch (ex) {
          event.preventDefault();
          throw ex;
        }
        if (!event.defaultPrevented && // onClick prevented default
        event.button === 0 && // ignore everything but left clicks
        (!target || target === "_self") && // let browser handle "target=_blank" etc.
        !isModifiedEvent(event)) {
          event.preventDefault();
          navigate();
        }
      }
    });
    if (forwardRefShim !== forwardRef2) {
      props.ref = forwardedRef || innerRef;
    } else {
      props.ref = innerRef;
    }
    return /* @__PURE__ */ import_react8.default.createElement("a", props);
  });
  if (false) {
    LinkAnchor.displayName = "LinkAnchor";
  }
  var Link = forwardRef2(function(_ref2, forwardedRef) {
    var _ref2$component = _ref2.component, component = _ref2$component === void 0 ? LinkAnchor : _ref2$component, replace3 = _ref2.replace, to = _ref2.to, innerRef = _ref2.innerRef, rest = _objectWithoutPropertiesLoose2(_ref2, ["component", "replace", "to", "innerRef"]);
    return /* @__PURE__ */ import_react8.default.createElement(context.Consumer, null, function(context2) {
      !context2 ? false ? invariant(false, "You should not use <Link> outside a <Router>") : invariant(false) : void 0;
      var history = context2.history;
      var location2 = normalizeToLocation(resolveToLocation(to, context2.location), context2.location);
      var href = location2 ? history.createHref(location2) : "";
      var props = _extends2({}, rest, {
        href,
        navigate: function navigate() {
          var location3 = resolveToLocation(to, context2.location);
          var isDuplicateNavigation = createPath(context2.location) === createPath(normalizeToLocation(location3));
          var method = replace3 || isDuplicateNavigation ? history.replace : history.push;
          method(location3);
        }
      });
      if (forwardRefShim !== forwardRef2) {
        props.ref = forwardedRef || innerRef;
      } else {
        props.innerRef = innerRef;
      }
      return /* @__PURE__ */ import_react8.default.createElement(component, props);
    });
  });
  if (false) {
    toType = import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.object, import_prop_types.default.func]);
    refType = import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.func, import_prop_types.default.shape({
      current: import_prop_types.default.any
    })]);
    Link.displayName = "Link";
    Link.propTypes = {
      innerRef: refType,
      onClick: import_prop_types.default.func,
      replace: import_prop_types.default.bool,
      target: import_prop_types.default.string,
      to: toType.isRequired
    };
  }
  var toType;
  var refType;
  var forwardRefShim$1 = function forwardRefShim3(C) {
    return C;
  };
  var forwardRef$1 = import_react8.default.forwardRef;
  if (typeof forwardRef$1 === "undefined") {
    forwardRef$1 = forwardRefShim$1;
  }
  function joinClassnames() {
    for (var _len = arguments.length, classnames = new Array(_len), _key = 0; _key < _len; _key++) {
      classnames[_key] = arguments[_key];
    }
    return classnames.filter(function(i) {
      return i;
    }).join(" ");
  }
  var NavLink = forwardRef$1(function(_ref, forwardedRef) {
    var _ref$ariaCurrent = _ref["aria-current"], ariaCurrent = _ref$ariaCurrent === void 0 ? "page" : _ref$ariaCurrent, _ref$activeClassName = _ref.activeClassName, activeClassName = _ref$activeClassName === void 0 ? "active" : _ref$activeClassName, activeStyle = _ref.activeStyle, classNameProp = _ref.className, exact = _ref.exact, isActiveProp = _ref.isActive, locationProp = _ref.location, sensitive = _ref.sensitive, strict = _ref.strict, styleProp = _ref.style, to = _ref.to, innerRef = _ref.innerRef, rest = _objectWithoutPropertiesLoose2(_ref, ["aria-current", "activeClassName", "activeStyle", "className", "exact", "isActive", "location", "sensitive", "strict", "style", "to", "innerRef"]);
    return /* @__PURE__ */ import_react8.default.createElement(context.Consumer, null, function(context2) {
      !context2 ? false ? invariant(false, "You should not use <NavLink> outside a <Router>") : invariant(false) : void 0;
      var currentLocation = locationProp || context2.location;
      var toLocation = normalizeToLocation(resolveToLocation(to, currentLocation), currentLocation);
      var path = toLocation.pathname;
      var escapedPath = path && path.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
      var match = escapedPath ? matchPath(currentLocation.pathname, {
        path: escapedPath,
        exact,
        sensitive,
        strict
      }) : null;
      var isActive = !!(isActiveProp ? isActiveProp(match, currentLocation) : match);
      var className = typeof classNameProp === "function" ? classNameProp(isActive) : classNameProp;
      var style = typeof styleProp === "function" ? styleProp(isActive) : styleProp;
      if (isActive) {
        className = joinClassnames(className, activeClassName);
        style = _extends2({}, style, activeStyle);
      }
      var props = _extends2({
        "aria-current": isActive && ariaCurrent || null,
        className,
        style,
        to: toLocation
      }, rest);
      if (forwardRefShim$1 !== forwardRef$1) {
        props.ref = forwardedRef || innerRef;
      } else {
        props.innerRef = innerRef;
      }
      return /* @__PURE__ */ import_react8.default.createElement(Link, props);
    });
  });
  if (false) {
    NavLink.displayName = "NavLink";
    ariaCurrentType = import_prop_types.default.oneOf(["page", "step", "location", "date", "time", "true", "false"]);
    NavLink.propTypes = _extends2({}, Link.propTypes, {
      "aria-current": ariaCurrentType,
      activeClassName: import_prop_types.default.string,
      activeStyle: import_prop_types.default.object,
      className: import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.func]),
      exact: import_prop_types.default.bool,
      isActive: import_prop_types.default.func,
      location: import_prop_types.default.object,
      sensitive: import_prop_types.default.bool,
      strict: import_prop_types.default.bool,
      style: import_prop_types.default.oneOfType([import_prop_types.default.object, import_prop_types.default.func])
    });
  }
  var ariaCurrentType;

  // node_modules/piral-core/lib/defaults/DefaultErrorInfo.js
  var React13 = __toESM(require_react());

  // node_modules/piral-core/lib/components/SwitchErrorInfo.js
  var React12 = __toESM(require_react());
  function renderComponent(components, props) {
    const name = props.type;
    const Component4 = components[name];
    if (false) {
      React12.useEffect(() => console.error("[dev-info] An error occurred in the Piral instance.", props), none);
    }
    if (!Component4) {
      const Unknown = components.unknown;
      if (Unknown) {
        return React12.createElement(Unknown, { ...props, type: "unknown" });
      }
      return defaultRender(`Error: ${props.type}`);
    }
    return React12.createElement(Component4, { ...props });
  }
  var SwitchErrorInfo = (props) => {
    const components = useGlobalState((m) => m.errorComponents);
    return renderComponent(components, props);
  };

  // node_modules/piral-core/lib/defaults/DefaultErrorInfo.js
  var DefaultErrorInfo = (props) => React13.createElement(ExtensionSlot, { name: "error", params: props, empty: () => React13.createElement(SwitchErrorInfo, { ...props }) });
  DefaultErrorInfo.displayName = "DefaultErrorInfo";

  // node_modules/piral-core/lib/defaults/DefaultLoadingIndicator.js
  var React14 = __toESM(require_react());
  var DefaultLoadingIndicator = () => React14.createElement("div", null, "Loading");
  DefaultLoadingIndicator.displayName = "DefaultLoadingIndicator";

  // node_modules/piral-core/lib/defaults/DefaultLayout.js
  var DefaultLayout = ({ children }) => defaultRender(children);
  DefaultLayout.displayName = "DefaultLayout";

  // node_modules/piral-core/lib/defaults/DefaultRouter_v5.js
  var React15 = __toESM(require_react());
  var DefaultRouter = ({ children, publicPath: publicPath2 }) => {
    return React15.createElement(BrowserRouter, { basename: publicPath2 }, children);
  };
  DefaultRouter.displayName = "DefaultRouter";

  // node_modules/piral-core/lib/defaults/DefaultRouteSwitch_v5.js
  var React16 = __toESM(require_react());
  var DefaultRouteSwitch = ({ paths, NotFound: NotFound2, ...props }) => {
    return React16.createElement(
      Switch,
      { ...props },
      paths.map(({ path, Component: Component4 }) => React16.createElement(Route, { exact: true, key: path, path, component: Component4 })),
      React16.createElement(Route, { component: NotFound2 })
    );
  };
  DefaultRouteSwitch.displayName = "DefaultRouteSwitch";

  // node_modules/piral-core/lib/defaults/navigator_v5.js
  var React17 = __toESM(require_react());
  var _nav;
  var _noop = () => {
  };
  function useRouterContext() {
    return React17.useContext(context);
  }
  function useCurrentNavigation() {
    const ctx = useRouterContext();
    const location2 = useLocation();
    React17.useEffect(() => {
      if (_nav) {
        window.dispatchEvent(new CustomEvent("piral-navigate", {
          detail: {
            location: location2
          }
        }));
      }
    }, [location2]);
    React17.useEffect(() => {
      _nav = ctx.history;
      return () => {
        _nav = void 0;
      };
    }, []);
  }
  function createNavigation(publicPath2) {
    const enhance = (location2, action) => ({
      action,
      location: {
        get href() {
          return _nav.createHref(location2);
        },
        ...location2
      }
    });
    return {
      get path() {
        const loc = _nav ? _nav.location : location;
        return loc.pathname;
      },
      get url() {
        const loc = _nav ? _nav.location : location;
        return `${loc.pathname}${loc.search}${loc.hash}`;
      },
      push(target, state) {
        if (_nav) {
          _nav.push(target, state);
        }
      },
      replace(target, state) {
        if (_nav) {
          _nav.replace(target, state);
        }
      },
      go(n) {
        if (_nav) {
          _nav.go(n);
        }
      },
      block(blocker) {
        if (!_nav) {
          return _noop;
        }
        return _nav.block((location2, action) => blocker(enhance(location2, action)));
      },
      listen(listener) {
        const handler = (e) => listener(enhance(e.detail.location, _nav.action));
        window.addEventListener("piral-navigate", handler);
        return () => {
          window.removeEventListener("piral-navigate", handler);
        };
      },
      router: {
        get history() {
          return _nav;
        }
      },
      publicPath: publicPath2
    };
  }

  // node_modules/piral-debug-utils/lib/ExtensionCatalogue.js
  var React18 = __toESM(require_react());
  var changeEvent = "extension-catalogue-changed";
  var store = {
    current: void 0,
    observe(setState) {
      const handler = () => {
        setState(store.current);
      };
      window.addEventListener(changeEvent, handler);
      return () => {
        window.removeEventListener(changeEvent, handler);
      };
    }
  };
  function changeExtensionCatalogueStore(state) {
    store.current = {
      ...state,
      params: JSON.stringify(state.params)
    };
    window.dispatchEvent(new CustomEvent(changeEvent));
  }
  var ExtensionCatalogue = () => {
    const [state, setState] = React18.useState(store.current);
    React18.useEffect(() => {
      return store.observe(setState);
    }, []);
    if (state) {
      const { name = "", params = "" } = state;
      return React18.createElement("piral-extension", { name, params });
    }
    return null;
  };

  // node_modules/piral-debug-utils/lib/decycle.js
  function getValue2(value) {
    try {
      return value && value.toJSON instanceof Function ? value.toJSON() : value;
    } catch {
      return `<protected>`;
    }
  }
  function decycle(obj) {
    const objects = [];
    const paths = [];
    const derez = (value, path) => {
      const _value = getValue2(value);
      if (_value === null || _value === void 0) {
        return void 0;
      } else if (typeof _value === "function") {
        return `<function>`;
      } else if (_value instanceof Error) {
        return `<error>`;
      } else if (_value instanceof Node) {
        return `<node>`;
      } else if (_value["$$typeof"] === Symbol.for("react.element")) {
        return "<react.element>";
      } else if (typeof _value === "object") {
        for (let i = 0; i < objects.length; i++) {
          if (objects[i] === _value) {
            return { $ref: paths[i] };
          }
        }
        objects.push(_value);
        paths.push(path);
        if (Array.isArray(_value)) {
          const nu = [];
          for (let i = 0; i < _value.length; i += 1) {
            nu[i] = derez(_value[i], `${path}[${i}]`);
          }
          return nu;
        } else {
          const nu = {};
          for (const name in _value) {
            if (Object.prototype.hasOwnProperty.call(_value, name)) {
              nu[name] = derez(_value[name], `${path}[${JSON.stringify(name)}]`);
            }
          }
          return nu;
        }
      } else if (typeof _value === "symbol") {
        return "<symbol>";
      } else if (typeof _value === "bigint") {
        return "<bigint>";
      }
      return _value;
    };
    return derez(obj, "$");
  }

  // node_modules/piral-debug-utils/lib/stack.js
  var installPromise;
  function install() {
    if (!installPromise) {
      installPromise = new Promise((resolve, reject) => {
        const sts = document.createElement("script");
        sts.src = "https://cdnjs.cloudflare.com/ajax/libs/stacktrace.js/2.0.2/stacktrace.min.js";
        document.head.appendChild(sts);
        sts.onload = () => resolve();
        sts.onerror = () => reject();
      });
    }
    return installPromise;
  }
  async function convertError(error, start = 0, end = -1) {
    await install();
    const frames = await window.StackTrace.fromError(error);
    return frames.slice(start, end).map((sf) => sf.toString()).join("\n");
  }

  // node_modules/piral-debug-utils/lib/overlay.js
  function h(e, attrs = {}, ...children) {
    const elem = document.createElement(e);
    for (const [k, v] of Object.entries(attrs)) {
      elem.setAttribute(k, v);
    }
    elem.append(...children);
    return elem;
  }
  var templateStyle = (
    /*css*/
    `
:host {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 99999;
  --monospace: 'SFMono-Regular', Consolas,
  'Liberation Mono', Menlo, Courier, monospace;
  --red: #ff5555;
  --yellow: #e2aa53;
  --purple: #cfa4ff;
  --cyan: #2dd9da;
  --dim: #c9c9c9;

  --window-background: #181818;
  --window-color: #d8d8d8;
}

.backdrop {
  position: fixed;
  z-index: 99999;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  overflow-y: scroll;
  margin: 0;
  background: rgba(0, 0, 0, 0.66);
}

.window {
  font-family: var(--monospace);
  line-height: 1.5;
  max-width: 80vw;
  color: var(--window-color);
  box-sizing: border-box;
  margin: 30px auto;
  padding: 2.5vh 4vw;
  position: relative;
  background: var(--window-background);
  border-radius: 6px 6px 8px 8px;
  box-shadow: 0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);
  overflow: hidden;
  border-top: 8px solid var(--red);
  direction: ltr;
  text-align: left;
}

pre {
  font-family: var(--monospace);
  font-size: 16px;
  margin-top: 0;
  margin-bottom: 1em;
  overflow-x: scroll;
  scrollbar-width: none;
}

pre::-webkit-scrollbar {
  display: none;
}

pre.frame::-webkit-scrollbar {
  display: block;
  height: 5px;
}

pre.frame::-webkit-scrollbar-thumb {
  background: #999;
  border-radius: 5px;
}

pre.frame {
  scrollbar-width: thin;
}

.message {
  line-height: 1.3;
  font-weight: 600;
  white-space: pre-wrap;
}

.message-body {
  color: var(--red);
}

.plugin {
  color: var(--purple);
}

.file {
  color: var(--cyan);
  margin-bottom: 0;
  white-space: pre-wrap;
  word-break: break-all;
}

.frame {
  color: var(--yellow);
}

.stack {
  font-size: 13px;
  color: var(--dim);
}

.tip {
  font-size: 13px;
  color: #999;
  border-top: 1px dotted #999;
  padding-top: 13px;
  line-height: 1.8;
}

code {
  font-size: 13px;
  font-family: var(--monospace);
  color: var(--yellow);
}

.file-link {
  text-decoration: underline;
  cursor: pointer;
}

kbd {
  line-height: 1.5;
  font-family: ui-monospace, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  font-size: 0.75rem;
  font-weight: 700;
  background-color: rgb(38, 40, 44);
  color: rgb(166, 167, 171);
  padding: 0.15rem 0.3rem;
  border-radius: 0.25rem;
  border-width: 0.0625rem 0.0625rem 0.1875rem;
  border-style: solid;
  border-color: rgb(54, 57, 64);
  border-image: initial;
}
`
  );
  var createTemplate = () => h("div", { class: "backdrop", part: "backdrop" }, h("div", { class: "window", part: "window" }, h("pre", { class: "message", part: "message" }, h("span", { class: "plugin", part: "plugin" }), h("span", { class: "message-body", part: "message-body" })), h("pre", { class: "file", part: "file" }), h("pre", { class: "frame", part: "frame" }), h("pre", { class: "stack", part: "stack" }), h("div", { class: "tip", part: "tip" }, "Click outside, press ", h("kbd", {}, "Esc"), " key, or fix the code to dismiss.", h("br"), "You can also disable this overlay by setting ", h("code", { part: "config-option-name" }, "dbg:error-overlay"), " to ", h("code", { part: "config-option-value" }, '"off"'), " in ", h("code", { part: "config-file-name" }, "sessionStorage"), ".")), h("style", {}, templateStyle));
  var fileRE = /(?:[a-zA-Z]:\\|\/).*?:\d+:\d*/g;
  var codeframeRE = /^(?:>?\s*\d+\s+\|.*|\s+\|\s*\^.*)\r?\n/gm;
  var overlayId = "piral-error-overlay";
  if (typeof window !== "undefined" && "customElements" in window) {
    class ErrorOverlay extends HTMLElement {
      constructor(props, links = true) {
        super();
        const { error, pilet, errorType } = props;
        this.root = this.attachShadow({ mode: "open" });
        this.root.appendChild(createTemplate());
        codeframeRE.lastIndex = 0;
        const hasFrame = error.frame && codeframeRE.test(error.frame);
        const message = hasFrame ? error.message.replace(codeframeRE, "") : error.message;
        if (pilet) {
          this.text(".plugin", `[${pilet}] `);
        }
        this.text(".message-body", message.trim());
        const [file] = (error.loc?.file || error.id || "unknown file").split(`?`);
        if (error.loc) {
          this.text(".file", `${file}:${error.loc.line}:${error.loc.column}`, links);
        } else if (error.id) {
          this.text(".file", file);
        }
        if (hasFrame) {
          this.text(".frame", error.frame.trim());
        }
        this.text(".stack", error.stack.split("\n").slice(0, 15).join("\n"), links);
        convertError(error, 0, 15).then((newStack) => {
          this.text(".stack", newStack, links);
        });
        this.root.querySelector(".window").addEventListener("click", (e) => {
          e.stopPropagation();
        });
        this.addEventListener("click", () => {
          this.close();
        });
        this.closeOnEsc = (e) => {
          if (e.key === "Escape" || e.code === "Escape") {
            this.close();
          }
        };
        this.closeOnReload = () => this.close();
        window.addEventListener("pilets-reloaded", this.closeOnReload);
        document.addEventListener("keydown", this.closeOnEsc);
      }
      text(selector, text, linkFiles = false) {
        const el = this.root.querySelector(selector);
        el.textContent = "";
        if (linkFiles) {
          let curIndex = 0;
          let match;
          fileRE.lastIndex = 0;
          while (match = fileRE.exec(text)) {
            const { 0: file, index } = match;
            if (index != null) {
              const frag = text.slice(curIndex, index);
              el.appendChild(document.createTextNode(frag));
              const link = document.createElement("a");
              link.textContent = file;
              link.className = "file-link";
              link.onclick = () => {
                console.log("Clicked");
              };
              el.appendChild(link);
              curIndex += frag.length + file.length;
            }
          }
        } else {
          el.textContent = text;
        }
      }
      close() {
        this.parentNode?.removeChild(this);
        window.removeEventListener("pilets-reloaded", this.closeOnReload);
        document.removeEventListener("keydown", this.closeOnEsc);
      }
    }
    customElements.define(overlayId, ErrorOverlay);
  }

  // node_modules/piral-debug-utils/lib/visualizer.js
  var visualizerName = "piral-inspector-visualizer";
  var persistAttribute = "persist";
  var piletColorMap = {};
  var colors = [
    "#001F3F",
    "#0074D9",
    "#7FDBFF",
    "#39CCCC",
    "#3D9970",
    "#2ECC40",
    "#01FF70",
    "#FFDC00",
    "#FF851B",
    "#FF4136",
    "#85144B",
    "#F012BE",
    "#B10DC9"
  ];
  function getTarget(element) {
    const row = element.childNodes;
    const rects = Array.prototype.map.call(row, (item) => {
      if (item instanceof Element) {
        return item.getBoundingClientRect();
      } else if (item instanceof Text) {
        const range = document.createRange();
        range.selectNode(item);
        return range.getBoundingClientRect();
      } else {
        return new DOMRectReadOnly(0, 0, 0, 0);
      }
    });
    const relevant = rects.filter((m) => m.height !== 0 && m.width !== 0);
    if (relevant.length === 0) {
      return new DOMRectReadOnly(0, 0, 0, 0);
    }
    return relevant.reduce((a, b) => {
      const x = Math.min(a.left, b.left);
      const y = Math.min(a.top, b.top);
      const width = Math.max(a.right, b.right) - x;
      const height = Math.max(a.bottom, b.bottom) - y;
      return new DOMRectReadOnly(x, y, width, height);
    });
  }
  function hide(vis) {
    vis.style.opacity = "0";
  }
  function show(vis) {
    vis.style.opacity = "1";
  }
  function updatePosition(source, vis) {
    const targetRect = getTarget(source);
    vis.style.left = targetRect.left + "px";
    vis.style.top = targetRect.top + "px";
    vis.style.width = targetRect.width + "px";
    vis.style.height = targetRect.height + "px";
  }
  var PiralInspectorVisualizer = class extends HTMLElement {
    constructor() {
      super(...arguments);
      this.update = () => {
        const persist = this.getAttribute(persistAttribute) !== null;
        this.innerText = "";
        document.querySelectorAll("piral-component").forEach((element) => {
          const pilet = element.getAttribute("origin");
          const vis = this.appendChild(document.createElement("div"));
          const info = vis.appendChild(document.createElement("div"));
          vis.style.position = "absolute";
          vis.style.zIndex = "2147483647";
          vis.style.border = "1px solid #ccc";
          vis.style.pointerEvents = "none";
          info.style.color = "white";
          info.textContent = pilet;
          info.style.position = "absolute";
          info.style.right = "0";
          info.style.top = "0";
          info.style.fontSize = "8px";
          info.style.background = piletColorMap[pilet] || (piletColorMap[pilet] = colors[Object.keys(piletColorMap).length % colors.length]);
          if (!persist) {
            hide(vis);
            element.addEventListener("mouseenter", () => {
              updatePosition(element, vis);
              show(vis);
            });
            element.addEventListener("mouseleave", () => {
              hide(vis);
            });
          } else {
            updatePosition(element, vis);
            show(vis);
          }
        });
      };
    }
    connectedCallback() {
      this.style.position = "absolute";
      this.style.top = "0";
      this.style.left = "0";
      this.style.width = "0";
      this.style.height = "0";
      window.addEventListener("resize", this.update);
      window.addEventListener("add-component", this.update);
      window.addEventListener("remove-component", this.update);
      this.update();
    }
    disconnectedCallback() {
      window.removeEventListener("resize", this.update);
      window.removeEventListener("add-component", this.update);
      window.removeEventListener("remove-component", this.update);
    }
    static get observedAttributes() {
      return [persistAttribute];
    }
    attributeChangedCallback(name, oldValue, newValue) {
      if (name === persistAttribute && oldValue !== newValue) {
        this.update();
      }
    }
  };
  customElements.define(visualizerName, PiralInspectorVisualizer);
  function createVisualizer() {
    const visualizer = document.querySelector(visualizerName);
    if (!visualizer) {
      document.body.appendChild(document.createElement(visualizerName));
    }
  }
  function destroyVisualizer() {
    const visualizer = document.querySelector(visualizerName);
    if (visualizer) {
      visualizer.remove();
    }
  }
  function toggleVisualizer() {
    const visualizer = document.querySelector(visualizerName);
    if (visualizer) {
      if (visualizer.getAttribute(persistAttribute) !== null) {
        visualizer.removeAttribute(persistAttribute);
      } else {
        visualizer.setAttribute(persistAttribute, "");
      }
    }
  }

  // node_modules/piral-debug-utils/lib/state.js
  var settingsKeys = {
    viewState: "dbg:view-state",
    loadPilets: "dbg:load-pilets",
    hardRefresh: "dbg:hard-refresh",
    viewOrigins: "dbg:view-origins",
    extensionCatalogue: "dbg:extension-catalogue",
    clearConsole: "dbg:clear-console",
    persistSettings: "dbg:persist-settings-data",
    errorOverlay: "dbg:error-overlay"
  };
  var persistKey = settingsKeys.persistSettings;
  var persistSettings = !!localStorage.getItem(persistKey);
  var defaultSetter = (name, value) => {
    sessionStorage.setItem(name, value);
  };
  var persistentSetter = (name, value) => {
    defaultSetter(name, value);
    const data = JSON.parse(localStorage.getItem(persistKey));
    data[name] = value;
    localStorage.setItem(persistKey, JSON.stringify(data));
  };
  function getValue3(key, defaultValue, fallbackValue) {
    const value = sessionStorage.getItem(key);
    const actualValue = value === "on";
    if (["on", "off"].includes(value)) {
      return actualValue;
    }
    const currentValue = typeof defaultValue === "boolean" ? defaultValue : fallbackValue;
    if (actualValue !== currentValue) {
      sessionStorage.setItem(key, currentValue ? "on" : "off");
    }
    return currentValue;
  }
  if (persistSettings) {
    try {
      const settings = JSON.parse(localStorage.getItem(persistKey));
      Object.keys(settings).forEach((name) => {
        const value = settings[name];
        sessionStorage.setItem(name, value);
      });
    } catch {
      localStorage.setItem(persistKey, "{}");
    }
  }
  function enablePersistance() {
    const data = {};
    const validKeys = Object.keys(settingsKeys).map((m) => settingsKeys[m]);
    for (let i = 0; i < sessionStorage.length; i++) {
      const name = sessionStorage.key(i);
      if (validKeys.includes(name)) {
        const value = sessionStorage.getItem(name);
        data[name] = value;
      }
    }
    localStorage.setItem(persistKey, JSON.stringify(data));
    return persistentSetter;
  }
  function disablePersistance() {
    localStorage.removeItem(persistKey);
    return defaultSetter;
  }
  var initialSetter = persistSettings ? persistentSetter : defaultSetter;
  function getInitialSettings(defaultValues) {
    return {
      viewState: getValue3(settingsKeys.viewState, defaultValues.viewState, true),
      loadPilets: getValue3(settingsKeys.loadPilets, defaultValues.loadPilets, false),
      hardRefresh: getValue3(settingsKeys.hardRefresh, defaultValues.hardRefresh, false),
      viewOrigins: getValue3(settingsKeys.viewOrigins, defaultValues.viewOrigins, false),
      extensionCatalogue: getValue3(settingsKeys.extensionCatalogue, defaultValues.extensionCatalogue, true),
      clearConsole: getValue3(settingsKeys.clearConsole, defaultValues.clearConsole, false),
      errorOverlay: getValue3(settingsKeys.errorOverlay, defaultValues.errorOverlay, true),
      persistSettings,
      cataloguePath: "/$debug-extension-catalogue"
    };
  }

  // node_modules/piral-debug-utils/lib/debug.js
  function installPiralDebug(options) {
    const { getGlobalState, getExtensions, getDependencies, getRoutes, getPilets, fireEvent, integrate, removePilet: removePilet2, updatePilet, addPilet: addPilet2, navigate, emulator = true, customSettings = {}, defaultSettings = {} } = options;
    const events = [];
    const legacyBrowser = !new Error().stack;
    const selfSource = "piral-debug-api";
    const debugApiVersion = "v1";
    let setValue = initialSetter;
    const initialSettings = getInitialSettings(defaultSettings);
    const emulatorSettings = emulator ? {
      loadPilets: {
        value: initialSettings.loadPilets,
        type: "boolean",
        label: "Load available pilets",
        group: "general",
        onChange(value) {
          setValue(settingsKeys.loadPilets, value ? "on" : "off");
        }
      },
      hardRefresh: {
        value: initialSettings.hardRefresh,
        type: "boolean",
        label: "Full refresh on change",
        group: "general",
        onChange(value) {
          setValue(settingsKeys.hardRefresh, value ? "on" : "off");
        }
      }
    } : {};
    const settings = {
      ...customSettings,
      viewState: {
        value: initialSettings.viewState,
        type: "boolean",
        label: "State container logging",
        group: "general",
        onChange(value) {
          setValue(settingsKeys.viewState, value ? "on" : "off");
        }
      },
      ...emulatorSettings,
      viewOrigins: {
        value: initialSettings.viewOrigins,
        type: "boolean",
        label: "Visualize component origins",
        group: "extensions",
        onChange(value, prev) {
          setValue(settingsKeys.viewOrigins, value ? "on" : "off");
          if (prev !== value) {
            updateVisualize(value);
          }
        }
      },
      errorOverlay: {
        value: initialSettings.errorOverlay,
        type: "boolean",
        label: "Show error overlay",
        group: "extensions",
        onChange(value) {
          setValue(settingsKeys.errorOverlay, value ? "on" : "off");
        }
      },
      extensionCatalogue: {
        value: initialSettings.extensionCatalogue,
        type: "boolean",
        label: "Enable extension catalogue",
        group: "extensions",
        onChange(value) {
          setValue(settingsKeys.extensionCatalogue, value ? "on" : "off");
        }
      },
      clearConsole: {
        value: initialSettings.clearConsole,
        type: "boolean",
        label: "Clear console during HMR",
        group: "general",
        onChange(value) {
          setValue(settingsKeys.clearConsole, value ? "on" : "off");
        }
      },
      persistSettings: {
        value: initialSettings.persistSettings,
        type: "boolean",
        label: "Persist settings",
        group: "inspector",
        onChange(value) {
          setValue = value ? enablePersistance() : disablePersistance();
        }
      }
    };
    const excludedRoutes = [initialSettings.cataloguePath];
    if (initialSettings.viewOrigins) {
      createVisualizer();
    }
    const sendMessage = (content) => {
      window.postMessage({
        content,
        source: selfSource,
        version: debugApiVersion
      }, "*");
    };
    const getSettings2 = () => {
      return Object.keys(settings).reduce((obj, key) => {
        const setting = settings[key];
        if (setting && typeof setting === "object" && typeof setting.label === "string" && typeof setting.type === "string" && ["boolean", "string", "number"].includes(typeof setting.value)) {
          obj[key] = {
            label: setting.label,
            value: setting.value,
            type: setting.type
          };
        }
        return obj;
      }, {});
    };
    const updateSettings = (values) => {
      Object.keys(values).forEach((key) => {
        const setting = settings[key];
        switch (setting.type) {
          case "boolean": {
            const prev = setting.value;
            const value = values[key];
            setting.value = value;
            setting.onChange(value, prev);
            break;
          }
          case "number": {
            const prev = setting.value;
            const value = values[key];
            setting.value = value;
            setting.onChange(value, prev);
            break;
          }
          case "string": {
            const prev = setting.value;
            const value = values[key];
            setting.value = value;
            setting.onChange(value, prev);
            break;
          }
        }
      });
      sendMessage({
        settings: getSettings2(),
        type: "settings"
      });
    };
    const togglePilet = (name) => {
      const pilet = getPilets().find((m) => m.name === name);
      if (!pilet) {
      } else if (pilet.disabled) {
        if (pilet.original) {
          updatePilet(pilet.original);
        } else {
          updatePilet({ ...pilet, disabled: false });
        }
      } else {
        updatePilet({ name, disabled: true, original: pilet });
      }
    };
    const updateVisualize = (active) => {
      if (active) {
        createVisualizer();
      } else {
        destroyVisualizer();
      }
    };
    const eventDispatcher = document.body.dispatchEvent;
    const systemResolve2 = System.constructor.prototype.resolve;
    const depMap = {};
    const subDeps = {};
    const findAncestor = (parent) => {
      while (subDeps[parent]) {
        parent = subDeps[parent];
      }
      return parent;
    };
    System.constructor.prototype.resolve = function(...args) {
      const [url, parent] = args;
      const result = systemResolve2.call(this, ...args);
      if (!parent) {
        return result;
      }
      const ancestor = findAncestor(parent);
      if (url.startsWith("./")) {
        subDeps[result] = ancestor;
      } else {
        const deps = depMap[ancestor] || {};
        deps[url] = result;
        depMap[ancestor] = deps;
      }
      return result;
    };
    const debugApi = {
      debug: debugApiVersion,
      instance: {
        name: process.env.BUILD_PCKG_NAME,
        version: process.env.BUILD_PCKG_VERSION,
        dependencies: process.env.SHARED_DEPENDENCIES
      },
      build: {
        date: process.env.BUILD_TIME_FULL,
        cli: process.env.PIRAL_CLI_VERSION,
        compat: process.env.DEBUG_PIRAL
      }
    };
    const details = {
      name: debugApi.instance.name,
      version: debugApi.instance.version,
      kind: debugApiVersion,
      mode: true ? "production" : "development",
      capabilities: [
        "events",
        "container",
        "routes",
        "pilets",
        "settings",
        "extensions",
        "dependencies",
        "dependency-map"
      ]
    };
    const start = () => {
      const container = decycle(getGlobalState());
      const routes = getRoutes().filter((r) => !excludedRoutes.includes(r));
      const extensions = getExtensions();
      const settings2 = getSettings2();
      const dependencies = getDependencies();
      const pilets = getPilets().map((pilet) => ({
        name: pilet.name,
        version: pilet.version,
        disabled: pilet.disabled
      }));
      sendMessage({
        type: "available",
        ...details,
        state: {
          routes,
          pilets,
          container,
          settings: settings2,
          events,
          extensions,
          dependencies
        }
      });
    };
    const check = () => {
      sendMessage({
        type: "info",
        ...details
      });
    };
    const getDependencyMap = () => {
      const dependencyMap = {};
      const addDeps = (pilet, dependencies) => {
        const deps = dependencyMap[pilet] || [];
        for (const depName of Object.keys(dependencies)) {
          if (!deps.some((m) => m.demanded === depName)) {
            deps.push({
              demanded: depName,
              resolved: dependencies[depName]
            });
          }
        }
        dependencyMap[pilet] = deps;
      };
      const pilets = getPilets().map((pilet) => ({
        name: pilet.name,
        link: pilet.link,
        base: pilet.base
      })).filter((m) => m.link);
      Object.keys(depMap).forEach((url) => {
        const dependencies = depMap[url];
        const pilet = pilets.find((p) => p.link === url);
        if (pilet) {
          addDeps(pilet.name, dependencies);
        } else if (!pilet) {
          const parent = pilets.find((p) => url.startsWith(p.base));
          if (parent) {
            addDeps(parent.name, dependencies);
          }
        }
      });
      sendMessage({
        type: "dependency-map",
        dependencyMap
      });
    };
    document.body.dispatchEvent = function(ev) {
      if (ev.type.startsWith("piral-")) {
        const name = ev.type.replace("piral-", "");
        const args = ev.detail.arg;
        events.unshift({
          id: events.length.toString(),
          name,
          args: decycle(args),
          time: Date.now()
        });
        if (name === "unhandled-error" && args.errorType && typeof customElements !== "undefined" && sessionStorage.getItem(settingsKeys.errorOverlay) !== "off") {
          const ErrorOverlay = customElements.get(overlayId);
          document.body.appendChild(new ErrorOverlay(args));
        }
        sendMessage({
          events,
          type: "events"
        });
      }
      return eventDispatcher.call(this, ev);
    };
    window.addEventListener("storage", (event) => {
      if (!legacyBrowser && event.storageArea === sessionStorage) {
        updateSettings({
          viewState: sessionStorage.getItem(settingsKeys.viewState) !== "off",
          loadPilets: sessionStorage.getItem(settingsKeys.loadPilets) === "on",
          hardRefresh: sessionStorage.getItem(settingsKeys.hardRefresh) === "on",
          viewOrigins: sessionStorage.getItem(settingsKeys.viewOrigins) === "on",
          extensionCatalogue: sessionStorage.getItem(settingsKeys.extensionCatalogue) !== "off",
          clearConsole: sessionStorage.getItem(settingsKeys.clearConsole) === "on",
          errorOverlay: sessionStorage.getItem(settingsKeys.errorOverlay) !== "off"
        });
      }
    });
    window.addEventListener("message", (event) => {
      const { source, version, content } = event.data;
      if (source !== selfSource && version === debugApiVersion) {
        switch (content.type) {
          case "init":
            return start();
          case "check-piral":
            return check();
          case "get-dependency-map":
            return getDependencyMap();
          case "update-settings":
            return updateSettings(content.settings);
          case "append-pilet":
            return addPilet2(content.meta);
          case "remove-pilet":
            return removePilet2(content.name);
          case "toggle-pilet":
            return togglePilet(content.name);
          case "emit-event":
            return fireEvent(content.name, content.args);
          case "goto-route":
            if (content.route === initialSettings.cataloguePath && content.state) {
              changeExtensionCatalogueStore(content.state);
            }
            return navigate(content.route, content.state);
          case "visualize-all":
            return toggleVisualizer();
        }
      }
    });
    integrate({
      routes: {
        [initialSettings.cataloguePath]: ExtensionCatalogue
      },
      onChange(previous, current, changed) {
        if (changed.state) {
          if (settings.viewState.value) {
            if (!legacyBrowser) {
              const err = new Error();
              const lastLine = err.stack.split("\n")[6];
              if (lastLine) {
                const action = lastLine.replace(/^\s+at\s+(Atom\.|Object\.)?/, "");
                console.group(`%c Piral State Change %c ${(/* @__PURE__ */ new Date()).toLocaleTimeString()}`, "color: gray; font-weight: lighter;", "color: black; font-weight: bold;");
                console.log("%c Previous", `color: #9E9E9E; font-weight: bold`, previous);
                console.log("%c Action", `color: #03A9F4; font-weight: bold`, action);
                console.log("%c Next", `color: #4CAF50; font-weight: bold`, current);
                console.groupEnd();
              }
            } else {
              console.log("Changed state", previous, current);
            }
          }
          sendMessage({
            type: "container",
            container: decycle(getGlobalState())
          });
        }
        if (changed.pilets) {
          sendMessage({
            type: "pilets",
            pilets: getPilets().map((pilet) => ({
              name: pilet.name,
              version: pilet.version,
              disabled: !!pilet.disabled
            }))
          });
        }
        if (changed.pages) {
          sendMessage({
            type: "routes",
            routes: getRoutes().filter((r) => !excludedRoutes.includes(r))
          });
        }
        if (changed.extensions) {
          sendMessage({
            type: "extensions",
            extensions: getExtensions()
          });
        }
        if (changed.dependencies) {
          sendMessage({
            type: "dependencies",
            dependencies: getDependencies()
          });
        }
      }
    });
    window["dbg:piral"] = debugApi;
    start();
  }

  // node_modules/piral-debug-utils/lib/routeRefresh.js
  var debugRouteCache = {
    active: 0,
    paths: []
  };
  function freezeRouteRefresh() {
    debugRouteCache.active++;
    return () => {
      debugRouteCache.active--;
      if (!debugRouteCache.active) {
        window.dispatchEvent(new CustomEvent("pilets-reloaded"));
      }
    };
  }

  // node_modules/piral-debug-utils/lib/emulator.js
  function installPiletEmulator(requestPilets, options) {
    const { addPilet: addPilet2, removePilet: removePilet2, integrate, defaultFeedUrl = "https://feed.piral.cloud/api/v1/pilet/emulator-website" } = options;
    integrate(() => {
      const dbgPiletApiKey = "dbg:pilet-api";
      const loadPilets2 = sessionStorage.getItem("dbg:load-pilets") === "on";
      const noPilets = () => Promise.resolve([]);
      const requester = loadPilets2 ? requestPilets : noPilets;
      const promise = requester();
      const feedUrl2 = window[dbgPiletApiKey] || sessionStorage.getItem(dbgPiletApiKey) || defaultFeedUrl;
      const initialTarget = /^https?:/.test(feedUrl2) ? feedUrl2 : `${location.origin}${feedUrl2[0] === "/" ? "" : "/"}${feedUrl2}`;
      const updateTarget = initialTarget.replace("http", "ws");
      const ws = new WebSocket(updateTarget);
      const timeoutCache = {};
      const timeout = 150;
      const appendix = fetch(initialTarget).then((res) => res.json()).then((item) => Array.isArray(item) ? item : item && typeof item === "object" ? Array.isArray(item.items) ? item.items : [item] : []);
      ws.onmessage = ({ data }) => {
        const hardRefresh = sessionStorage.getItem("dbg:hard-refresh") === "on";
        if (!hardRefresh) {
          const meta = JSON.parse(data);
          const name = meta.name;
          clearTimeout(timeoutCache[name]);
          timeoutCache[name] = setTimeout(() => {
            const unfreeze = freezeRouteRefresh();
            removePilet2(meta.name).then(() => {
              const clearConsole = sessionStorage.getItem("dbg:clear-console") === "on";
              if (clearConsole) {
                console.clear();
              }
              console.log("Updating pilet %c%s ...", "color: green; background: white; font-weight: bold", name);
            }).then(() => addPilet2(meta)).then(unfreeze, unfreeze);
          }, timeout);
        } else {
          location.reload();
        }
      };
      return promise.catch((err) => {
        console.error(`Requesting the pilets failed. We'll continue loading without pilets (DEBUG only).`, err);
        return [];
      }).then((pilets) => appendix.then((debugPilets) => {
        const debugPiletNames = debugPilets.map((m) => m.name);
        const feedPilets = pilets.filter((m) => !debugPiletNames.includes(m.name));
        return [...feedPilets, ...debugPilets];
      }));
    });
  }

  // node_modules/piral-debug-utils/lib/useDebugRouteFilter.js
  var import_react9 = __toESM(require_react());
  function useDebugRouteFilter(paths) {
    const [_, triggerChange] = (0, import_react9.useState)(0);
    (0, import_react9.useEffect)(() => {
      const handler = () => {
        triggerChange((s) => s + 1);
      };
      window.addEventListener("pilets-reloaded", handler);
      return () => {
        window.removeEventListener("pilets-reloaded", handler);
      };
    }, []);
    if (!debugRouteCache.active) {
      debugRouteCache.paths = paths;
    }
    return debugRouteCache.paths;
  }

  // node_modules/piral-core/lib/tools/debugger.js
  function integrateDebugger(context2, options, debug = {}) {
    installPiralDebug({
      emulator: debug.emulator,
      customSettings: debug.customSettings,
      defaultSettings: debug.defaultSettings,
      addPilet: context2.addPilet,
      removePilet: context2.removePilet,
      updatePilet(pilet) {
        if (!pilet.disabled) {
          context2.addPilet(pilet);
        } else {
          context2.injectPilet(pilet);
        }
      },
      fireEvent: context2.emit,
      getDependencies() {
        return Object.keys(options.dependencies);
      },
      getExtensions() {
        return context2.readState((s) => Object.keys(s.registry.extensions));
      },
      getRoutes() {
        const registeredRoutes = context2.readState((state) => Object.keys(state.registry.pages));
        const componentRoutes = context2.readState((state) => Object.keys(state.routes));
        return [...componentRoutes, ...registeredRoutes];
      },
      getGlobalState() {
        return context2.readState((s) => s);
      },
      navigate(path, state) {
        return context2.navigation.push(path, state);
      },
      getPilets() {
        return context2.readState((s) => s.modules);
      },
      integrate(dbg) {
        context2.dispatch((s) => ({
          ...s,
          routes: {
            ...s.routes,
            ...dbg.routes
          }
        }));
        context2.state.subscribe((current, previous) => {
          const pilets = current.modules !== previous.modules;
          const pages = current.registry.pages !== previous.registry.pages || current.routes !== previous.routes;
          const extensions = current.registry.extensions !== previous.registry.extensions;
          const state = current !== previous;
          dbg.onChange(previous, current, {
            pilets,
            pages,
            extensions,
            state
          });
        });
      }
    });
  }

  // node_modules/piral-core/lib/tools/emulator.js
  function integrateEmulator(context2, options, debug = {}) {
    installPiletEmulator(options.fetchPilets, {
      defaultFeedUrl: debug.defaultFeedUrl,
      addPilet: context2.addPilet,
      removePilet: context2.removePilet,
      integrate(requester) {
        options.fetchPilets = requester;
      }
    });
  }

  // node_modules/piral-core/app.codegen
  function applyStyle(element) {
    element.style.display = "contents";
  }
  function fillDependencies(deps) {
    deps["silverstripe-search-admin"] = { ...errors_exports, ...logo_exports };
    deps["react-modal"] = _2;
    deps["react-modal@3.16.3"] = _2;
    deps["formik"] = formik_esm_exports;
    deps["formik@2.4.9"] = formik_esm_exports;
    deps["tslib"] = tslib_es6_exports;
    deps["tslib@2.8.1"] = tslib_es6_exports;
    deps["react"] = _5;
    deps["react@18.3.1"] = _5;
    deps["react-dom"] = _6;
    deps["react-dom@18.3.1"] = _6;
    deps["react-router"] = react_router_exports;
    deps["react-router@5.3.4"] = react_router_exports;
    deps["react-router-dom"] = react_router_dom_exports;
    deps["react-router-dom@5.3.4"] = react_router_dom_exports;
  }
  var publicPath = "/";
  function createDefaultState() {
    return {
      app: {
        error: void 0,
        loading: typeof window !== "undefined",
        wrap: true
      },
      components: {
        ErrorInfo: DefaultErrorInfo,
        LoadingIndicator: DefaultLoadingIndicator,
        Router: DefaultRouter,
        RouteSwitch: DefaultRouteSwitch,
        Layout: DefaultLayout
      },
      errorComponents: {},
      registry: {
        extensions: {},
        pages: {},
        wrappers: {}
      },
      routes: {},
      data: {},
      portals: {},
      modules: []
    };
  }
  function integrateDebugger2(context2, options, debug) {
    return integrateDebugger(context2, options, {
      defaultSettings: {},
      emulator: true,
      ...debug
    });
  }
  function useRouteFilter(paths) {
    useCurrentNavigation();
    return useDebugRouteFilter(paths);
  }

  // node_modules/piral-core/lib/components/PiralRoutes.js
  function useShellRoutes() {
    const routes = useGlobalState((s) => s.routes);
    return React19.useMemo(() => Object.entries(routes).map(([path, Component4]) => ({
      path,
      Component: Component4,
      meta: Component4?.meta || {},
      matcher: createRouteMatcher(path)
    })), [routes]);
  }
  function usePiletRoutes() {
    const pages = useGlobalState((s) => s.registry.pages);
    return React19.useMemo(() => Object.entries(pages).map(([path, entry]) => ({
      path,
      Component: entry.component,
      meta: entry.meta,
      matcher: createRouteMatcher(path)
    })), [pages]);
  }
  function useRoutes() {
    const shellRoutes = useShellRoutes();
    const piletRoutes = usePiletRoutes();
    return useRouteFilter([...shellRoutes, ...piletRoutes]);
  }
  var PiralRoutes = ({ NotFound: NotFound2, RouteSwitch, ...props }) => {
    const paths = useRoutes();
    return React19.createElement(RouteSwitch, { NotFound: NotFound2, paths, ...props });
  };
  PiralRoutes.displayName = "Routes";

  // node_modules/piral-core/lib/components/PiralSuspense.js
  var React20 = __toESM(require_react());
  var PiralSuspense = ({ children }) => {
    const { error, loading } = useGlobalState((m) => m.app);
    return error ? React20.createElement(RegisteredErrorInfo, { type: "loading", error }) : loading ? React20.createElement(RegisteredLoadingIndicator, null) : React20.createElement(React20.Fragment, null, children);
  };

  // node_modules/piral-core/lib/components/PiralView.js
  var React22 = __toESM(require_react());

  // node_modules/piral-core/lib/components/ResponsiveLayout.js
  var React21 = __toESM(require_react());
  var ResponsiveLayout = ({ breakpoints = defaultBreakpoints, Layout, children }) => {
    const selected = useMedia(breakpoints, defaultLayouts, "desktop");
    return React21.createElement(Layout, { currentLayout: selected }, children);
  };
  ResponsiveLayout.displayName = "ResponsiveLayout";

  // node_modules/piral-core/lib/components/PiralView.js
  var NotFound = (props) => React22.createElement(RegisteredErrorInfo, { type: "not_found", ...props });
  var PiralView = ({ breakpoints, children }) => React22.createElement(
    React22.Fragment,
    null,
    React22.createElement(PiralGlobals, null),
    React22.createElement(
      PiralSuspense,
      null,
      React22.createElement(
        ResponsiveLayout,
        { breakpoints, Layout: RegisteredLayout },
        React22.createElement(PiralRoutes, { NotFound, RouteSwitch: RegisteredRouteSwitch })
      )
    ),
    children
  );
  PiralView.displayName = "PiralView";

  // node_modules/piral-core/lib/components/wrapComponent.js
  var React24 = __toESM(require_react());

  // node_modules/piral-core/lib/components/ForeignComponentContainer.js
  var React23 = __toESM(require_react());
  var ForeignComponentContainer = class extends React23.Component {
    constructor() {
      super(...arguments);
      this.locals = {};
      this.setNode = (node) => {
        this.current = node;
      };
    }
    componentDidMount() {
      const { current } = this;
      const { $component, $context, innerProps } = this.props;
      const { mount } = $component;
      if (current && isfunc(mount)) {
        mount(current, innerProps, $context, this.locals);
      }
      this.previous = current;
    }
    componentDidUpdate() {
      const { current, previous } = this;
      const { $component, $context, innerProps } = this.props;
      const { update } = $component;
      if (current !== previous) {
        previous && this.componentWillUnmount();
        current && this.componentDidMount();
      } else if (isfunc(update)) {
        update(current, innerProps, $context, this.locals);
      }
    }
    componentWillUnmount() {
      const { previous } = this;
      const { $component } = this.props;
      const { unmount } = $component;
      if (previous && isfunc(unmount)) {
        unmount(previous, this.locals);
      }
      this.previous = void 0;
    }
    render() {
      const { $portalId } = this.props;
      return React23.createElement("piral-portal", { pid: $portalId, ref: this.setNode });
    }
  };

  // node_modules/piral-core/lib/components/wrapComponent.js
  var portalIdBase = 123456;
  function wrapReactComponent(Component4, captured, Wrapper) {
    return (props) => React24.createElement(
      Wrapper,
      { ...props },
      React24.createElement(Component4, { ...props, ...captured })
    );
  }
  function wrapForeignComponent(component, captured, Wrapper) {
    return React24.memo((props) => {
      const { destroyPortal: destroyPortal2, navigation } = useGlobalStateContext();
      const id = React24.useMemo(() => (portalIdBase++).toString(26), none);
      const context2 = React24.useMemo(() => ({ publicPath: navigation.publicPath, navigation, router: navigation.router }), []);
      const innerProps = React24.useMemo(() => ({ ...props, ...captured }), [props]);
      React24.useEffect(() => () => destroyPortal2(id), none);
      return React24.createElement(
        Wrapper,
        { ...props },
        React24.createElement(PortalRenderer, { id }),
        React24.createElement(ForeignComponentContainer, { innerProps, "$portalId": id, "$component": component, "$context": context2 })
      );
    });
  }
  function isNotExotic(component) {
    return !component.$$typeof;
  }
  function wrapComponent(converters, component, captured, Wrapper) {
    if (!component) {
      const pilet = captured.piral.meta.name;
      console.error(`[${pilet}] The given value is not a valid component.`);
      component = () => null;
    }
    if (typeof component === "object" && isNotExotic(component)) {
      const result = convertComponent(converters[component.type], component);
      return wrapForeignComponent(result, captured, Wrapper);
    }
    return wrapReactComponent(component, captured, Wrapper);
  }

  // node_modules/piral-core/lib/modules/element.js
  if (typeof window !== "undefined" && "customElements" in window) {
    class PiralExtension extends HTMLElement {
      constructor() {
        super(...arguments);
        this.dispose = noop;
        this.update = noop;
        this.props = {
          name: this.getAttribute("name"),
          emptySkipsRender: typeof this.getAttribute("empty-skips-render") === "string",
          params: tryParseJson(this.getAttribute("params")),
          empty: void 0,
          order: void 0,
          render: void 0,
          children: reactifyContent(this.childNodes)
        };
      }
      get params() {
        return this.props.params;
      }
      set params(value) {
        if (!isSame(this.props.params, value)) {
          this.props.params = value;
          this.update(this.props);
        }
      }
      get name() {
        return this.props.name;
      }
      set name(value) {
        if (this.props.name !== value) {
          this.props.name = value;
          this.update(this.props);
        }
      }
      get order() {
        return this.props.order;
      }
      set order(value) {
        if (this.props.order !== value) {
          this.props.order = value;
          this.update(this.props);
        }
      }
      get render() {
        return this.props.render;
      }
      set render(value) {
        if (this.props.render !== value) {
          this.props.render = value;
          this.update(this.props);
        }
      }
      get empty() {
        return this.props.empty;
      }
      set empty(value) {
        if (this.props.empty !== value) {
          this.props.empty = value;
          this.update(this.props);
        }
      }
      get emptySkipsRender() {
        return this.props.emptySkipsRender;
      }
      set emptySkipsRender(value) {
        if (this.props.emptySkipsRender !== value) {
          this.props.emptySkipsRender = value;
          this.update(this.props);
        }
      }
      connectedCallback() {
        applyStyle(this);
        if (this.isConnected) {
          this.dispatchEvent(new CustomEvent("render-html", {
            bubbles: true,
            composed: true,
            detail: {
              target: this,
              props: this.props
            }
          }));
        }
      }
      disconnectedCallback() {
        this.dispose();
        this.dispose = noop;
        this.update = noop;
      }
      attributeChangedCallback(name, _, newValue) {
        switch (name) {
          case "name":
            this.name = newValue;
            break;
          case "params":
            this.params = tryParseJson(newValue);
            break;
          case "empty-skips-render":
            this.emptySkipsRender = typeof newValue === "string";
            break;
        }
      }
      static get observedAttributes() {
        return ["name", "params", "empty-skips-render"];
      }
    }
    customElements.define(extensionName, PiralExtension);
    class PiralPortal extends HTMLElement {
      connectedCallback() {
        applyStyle(this);
      }
    }
    customElements.define(portalName, PiralPortal);
    class PiralSlot extends HTMLElement {
      connectedCallback() {
        applyStyle(this);
      }
    }
    customElements.define(slotName, PiralSlot);
    class PiralContent extends HTMLElement {
      constructor() {
        super(...arguments);
        this.dispose = noop;
      }
      connectedCallback() {
        applyStyle(this);
        const cid = this.getAttribute("cid");
        const content = PiralContent.contentAssignments[cid];
        const portal = this.closest("piral-portal");
        if (content && portal) {
          const portalId = portal.getAttribute("pid");
          window.dispatchEvent(new CustomEvent("render-content", {
            detail: { target: this, content, portalId }
          }));
        }
      }
      disconnectedCallback() {
        this.dispose();
        this.dispose = noop;
      }
    }
    PiralContent.contentAssignments = {};
    window.assignContent = (cid, content) => {
      PiralContent.contentAssignments[cid] = content;
    };
    customElements.define(contentName, PiralContent);
    class PiralComponent extends HTMLElement {
      get name() {
        return this.getAttribute("name");
      }
      set name(value) {
        this.setAttribute("name", value);
      }
      get origin() {
        return this.getAttribute("origin");
      }
      set origin(value) {
        this.setAttribute("origin", value);
      }
      connectedCallback() {
        applyStyle(this);
        this.deferEvent("add-component");
      }
      disconnectedCallback() {
        this.deferEvent("remove-component");
      }
      deferEvent(eventName) {
        const ev = new CustomEvent(eventName, {
          detail: { name: this.name, origin: this.origin }
        });
        defer(() => window.dispatchEvent(ev));
      }
    }
    customElements.define(componentName, PiralComponent);
  }
  function renderElement(context2, element, props) {
    if (typeof window !== "undefined") {
      let [id, portal] = renderInDom(context2, element, ExtensionSlot, props);
      const evName = "extension-props-changed";
      const handler = (ev) => update(ev.detail);
      const dispose = () => {
        context2.hidePortal(id, portal);
        element.removeEventListener(evName, handler);
      };
      const update = (newProps) => {
        [id, portal] = changeDomPortal(id, portal, context2, element, ExtensionSlot, newProps);
      };
      element.addEventListener(evName, handler);
      return [dispose, update];
    }
    return [noop, noop];
  }

  // node_modules/piral-core/lib/actions/index.js
  var actions_exports = {};
  __export(actions_exports, {
    addPilet: () => addPilet,
    defineAction: () => defineAction,
    defineActions: () => defineActions,
    destroyPortal: () => destroyPortal,
    dispatch: () => dispatch,
    hidePortal: () => hidePortal,
    includeProvider: () => includeProvider,
    initialize: () => initialize,
    injectPilet: () => injectPilet,
    readDataItem: () => readDataItem,
    readDataValue: () => readDataValue,
    readState: () => readState,
    registerExtension: () => registerExtension,
    registerPage: () => registerPage,
    removePilet: () => removePilet,
    resetData: () => resetData,
    setComponent: () => setComponent,
    setErrorComponent: () => setErrorComponent,
    setRoute: () => setRoute,
    showPortal: () => showPortal,
    tryWriteDataItem: () => tryWriteDataItem,
    unregisterExtension: () => unregisterExtension,
    unregisterPage: () => unregisterPage,
    updatePortal: () => updatePortal,
    writeDataItem: () => writeDataItem
  });

  // node_modules/piral-core/lib/actions/app.js
  function initialize(ctx, loading, error, modules) {
    ctx.dispatch((state) => ({
      ...state,
      app: {
        ...state.app,
        error,
        loading
      },
      modules
    }));
  }
  function addPilet(ctx, meta) {
    return ctx.options.loadPilet(meta).then((pilet) => ctx.injectPilet(pilet)).then((pilet) => runPilet(ctx.options.createApi, pilet, ctx.options.hooks)).then(noop);
  }
  function removePilet(ctx, name) {
    ctx.dispatch((state) => ({
      ...state,
      modules: state.modules.filter((m) => m.name !== name),
      registry: removeNested(state.registry, (m) => m.pilet === name)
    }));
    ctx.emit("unload-pilet", {
      name
    });
    return Promise.resolve();
  }
  function injectPilet(ctx, pilet) {
    ctx.dispatch((state) => ({
      ...state,
      modules: replaceOrAddItem(state.modules, pilet, (m) => m.name === pilet.name),
      registry: removeNested(state.registry, (m) => m.pilet === pilet.name)
    }));
    ctx.emit("unload-pilet", {
      name: pilet.name
    });
    return pilet;
  }
  function setComponent(ctx, name, component) {
    ctx.dispatch((state) => ({
      ...state,
      components: withKey(state.components, name, component)
    }));
  }
  function setErrorComponent(ctx, type, component) {
    ctx.dispatch((state) => ({
      ...state,
      errorComponents: withKey(state.errorComponents, type, component)
    }));
  }
  function setRoute(ctx, path, component) {
    ctx.dispatch(withRoute(path, component));
  }
  function includeProvider(ctx, provider) {
    ctx.dispatch(withProvider(provider));
  }

  // node_modules/piral-core/lib/actions/components.js
  function registerPage(ctx, name, value) {
    ctx.dispatch(withPage(name, value));
  }
  function unregisterPage(ctx, name) {
    ctx.dispatch(withoutPage(name));
  }
  function registerExtension(ctx, name, value) {
    ctx.dispatch(withExtension(name, value));
  }
  function unregisterExtension(ctx, name, reference) {
    ctx.dispatch(withoutExtension(name, reference));
  }

  // node_modules/piral-core/lib/actions/data.js
  function resetData(ctx) {
    ctx.dispatch((state) => ({
      ...state,
      data: {}
    }));
  }
  function readDataItem(ctx, key) {
    return ctx.readState((state) => state.data[key]);
  }
  function readDataValue(ctx, key) {
    const item = readDataItem(ctx, key);
    return item && item.value;
  }
  function writeDataItem(ctx, key, value, owner, target, expires) {
    const isNull = !value && typeof value === "object";
    const data = isNull ? value : {
      value,
      owner,
      target,
      expires
    };
    ctx.dispatch((state) => ({
      ...state,
      data: updateKey(state.data, key, data)
    }));
    ctx.emit("store-data", {
      name: key,
      target,
      value,
      owner,
      expires
    });
  }
  function tryWriteDataItem(ctx, key, value, owner, target, expires) {
    const item = readDataItem(ctx, key);
    if (item && item.owner !== owner) {
      console.error(`Invalid data write to '${key}'. This item currently belongs to '${item.owner}' (write attempted from '${owner}'). The action has been ignored.`);
      return false;
    }
    writeDataItem(ctx, key, value, owner, target, expires);
    return true;
  }

  // node_modules/piral-core/lib/actions/define.js
  function defineAction(ctx, actionName, action) {
    ctx[actionName] = action.bind(ctx, ctx);
  }
  function defineActions(ctx, actions) {
    for (const actionName of Object.keys(actions)) {
      const action = actions[actionName];
      defineAction(ctx, actionName, action);
    }
  }

  // node_modules/piral-core/lib/actions/portal.js
  function destroyPortal(ctx, id) {
    ctx.dispatch((state) => ({
      ...state,
      portals: withoutKey(state.portals, id)
    }));
  }
  function hidePortal(ctx, id, entry) {
    ctx.dispatch((state) => ({
      ...state,
      portals: withKey(state.portals, id, excludeItem(state.portals[id], entry))
    }));
  }
  function updatePortal(ctx, id, current, next) {
    ctx.dispatch((state) => ({
      ...state,
      portals: withKey(state.portals, id, replaceOrAddItem(state.portals[id], next, (m) => m === current))
    }));
  }
  function showPortal(ctx, id, entry) {
    ctx.dispatch((state) => ({
      ...state,
      portals: withKey(state.portals, id, includeItem(state.portals[id], entry))
    }));
  }

  // node_modules/piral-core/lib/actions/state.js
  function dispatch(ctx, update) {
    const oldState = ctx.state.getState();
    const newState = update(oldState);
    if (!isSame(oldState, newState)) {
      ctx.state.setState(newState);
    }
  }
  function readState(ctx, read) {
    return read(ctx.state.getState());
  }

  // node_modules/piral-core/lib/state/createActions.js
  function createContext4(state, events) {
    const ctx = {
      ...events,
      apis: {},
      converters: {
        html: ({ component }) => component
      },
      navigation: createNavigation(publicPath),
      state
    };
    return ctx;
  }
  function includeActions(ctx, actions) {
    const actionNames = Object.keys(actions);
    for (const actionName of actionNames) {
      const action = actions[actionName];
      ctx[actionName] = action.bind(ctx, ctx);
    }
  }
  function createActions(state, events) {
    const context2 = createContext4(state, events);
    includeActions(context2, actions_exports);
    return context2;
  }

  // node_modules/zustand/esm/index.js
  var import_react10 = __toESM(require_react());
  function createStore(createState) {
    let state;
    const listeners = /* @__PURE__ */ new Set();
    const setState = (partial, replace3) => {
      const nextState = typeof partial === "function" ? partial(state) : partial;
      if (nextState !== state) {
        const previousState = state;
        state = replace3 ? nextState : Object.assign({}, state, nextState);
        listeners.forEach((listener) => listener(state, previousState));
      }
    };
    const getState = () => state;
    const subscribeWithSelector = (listener, selector = getState, equalityFn = Object.is) => {
      console.warn("[DEPRECATED] Please use `subscribeWithSelector` middleware");
      let currentSlice = selector(state);
      function listenerToAdd() {
        const nextSlice = selector(state);
        if (!equalityFn(currentSlice, nextSlice)) {
          const previousSlice = currentSlice;
          listener(currentSlice = nextSlice, previousSlice);
        }
      }
      listeners.add(listenerToAdd);
      return () => listeners.delete(listenerToAdd);
    };
    const subscribe = (listener, selector, equalityFn) => {
      if (selector || equalityFn) {
        return subscribeWithSelector(listener, selector, equalityFn);
      }
      listeners.add(listener);
      return () => listeners.delete(listener);
    };
    const destroy = () => listeners.clear();
    const api = { setState, getState, subscribe, destroy };
    state = createState(setState, getState, api);
    return api;
  }
  var isSSR = typeof window === "undefined" || !window.navigator || /ServerSideRendering|^Deno\//.test(window.navigator.userAgent);
  var useIsomorphicLayoutEffect2 = isSSR ? import_react10.useEffect : import_react10.useLayoutEffect;
  function create(createState) {
    const api = typeof createState === "function" ? createStore(createState) : createState;
    const useStore = (selector = api.getState, equalityFn = Object.is) => {
      const [, forceUpdate] = (0, import_react10.useReducer)((c) => c + 1, 0);
      const state = api.getState();
      const stateRef = (0, import_react10.useRef)(state);
      const selectorRef = (0, import_react10.useRef)(selector);
      const equalityFnRef = (0, import_react10.useRef)(equalityFn);
      const erroredRef = (0, import_react10.useRef)(false);
      const currentSliceRef = (0, import_react10.useRef)();
      if (currentSliceRef.current === void 0) {
        currentSliceRef.current = selector(state);
      }
      let newStateSlice;
      let hasNewStateSlice = false;
      if (stateRef.current !== state || selectorRef.current !== selector || equalityFnRef.current !== equalityFn || erroredRef.current) {
        newStateSlice = selector(state);
        hasNewStateSlice = !equalityFn(currentSliceRef.current, newStateSlice);
      }
      useIsomorphicLayoutEffect2(() => {
        if (hasNewStateSlice) {
          currentSliceRef.current = newStateSlice;
        }
        stateRef.current = state;
        selectorRef.current = selector;
        equalityFnRef.current = equalityFn;
        erroredRef.current = false;
      });
      const stateBeforeSubscriptionRef = (0, import_react10.useRef)(state);
      useIsomorphicLayoutEffect2(() => {
        const listener = () => {
          try {
            const nextState = api.getState();
            const nextStateSlice = selectorRef.current(nextState);
            if (!equalityFnRef.current(currentSliceRef.current, nextStateSlice)) {
              stateRef.current = nextState;
              currentSliceRef.current = nextStateSlice;
              forceUpdate();
            }
          } catch (error) {
            erroredRef.current = true;
            forceUpdate();
          }
        };
        const unsubscribe = api.subscribe(listener);
        if (api.getState() !== stateBeforeSubscriptionRef.current) {
          listener();
        }
        return unsubscribe;
      }, []);
      const sliceToReturn = hasNewStateSlice ? newStateSlice : currentSliceRef.current;
      (0, import_react10.useDebugValue)(sliceToReturn);
      return sliceToReturn;
    };
    Object.assign(useStore, api);
    useStore[Symbol.iterator] = function() {
      console.warn("[useStore, api] = create() is deprecated and will be removed in v4");
      const items = [useStore, api];
      return {
        next() {
          const done = items.length <= 0;
          return { value: items.shift(), done };
        }
      };
    };
    return useStore;
  }

  // node_modules/piral-core/lib/state/createGlobalState.js
  function extend(defaultState, customState) {
    for (const key of Object.keys(customState)) {
      if (key === "__proto__" || key === "constructor") {
        continue;
      }
      const value = customState[key];
      const original = defaultState[key];
      const nested = typeof original === "object" && typeof value === "object";
      defaultState[key] = nested ? extend(original, value) : value;
    }
    return defaultState;
  }
  function createGlobalState(customState = {}) {
    const defaultState = createDefaultState();
    return create(() => extend(defaultState, customState));
  }

  // node_modules/piral-core/lib/state/withApi.js
  var React25 = __toESM(require_react());
  var DefaultWrapper = (props) => defaultRender(props.children);
  function getWrapper(wrappers, wrapperType) {
    const WrapAll = wrappers["*"];
    const WrapType = wrappers[wrapperType];
    if (WrapAll && WrapType) {
      return (props) => React25.createElement(
        WrapAll,
        { ...props },
        React25.createElement(WrapType, { ...props })
      );
    }
    return WrapType || WrapAll || DefaultWrapper;
  }
  function makeWrapper(context2, outerProps, wrapperType, errorType) {
    const wrapped = context2.readState((m) => m.app.wrap);
    const OuterWrapper = context2.readState((m) => getWrapper(m.registry.wrappers, wrapperType));
    const Wrapper = (props) => React25.createElement(
      OuterWrapper,
      { ...outerProps, ...props },
      React25.createElement(ErrorBoundary, { ...outerProps, ...props, errorType }, props.children)
    );
    return wrapped ? (props) => React25.createElement(
      "piral-component",
      { origin: outerProps.piral.meta.name },
      React25.createElement(Wrapper, { ...props })
    ) : Wrapper;
  }
  function withApi(context2, component, piral, errorType, wrapperType = errorType, captured = {}) {
    const outerProps = { ...captured, piral };
    const converters = context2.converters;
    const Wrapper = makeWrapper(context2, outerProps, wrapperType, errorType);
    return wrapComponent(converters, component, outerProps, Wrapper);
  }

  // node_modules/piral-core/lib/modules/core.js
  function createCoreApi(context2) {
    return (api, meta) => {
      const pilet = meta.name;
      return {
        getData(name) {
          return context2.readDataValue(name);
        },
        setData(name, value, options) {
          const { target = "memory", expires } = createDataOptions(options);
          const expiration = getDataExpiration(expires);
          return context2.tryWriteDataItem(name, value, pilet, target, expiration);
        },
        registerPage(route, arg, meta2 = {}) {
          const component = withApi(context2, arg, api, "page", void 0, { meta: meta2 });
          context2.registerPage(route, {
            pilet,
            meta: meta2,
            component
          });
          return () => api.unregisterPage(route);
        },
        unregisterPage(route) {
          context2.unregisterPage(route);
        },
        registerExtension(name, reference, defaults) {
          const component = withApi(context2, reference, api, "extension");
          context2.registerExtension(name, {
            pilet,
            component,
            reference,
            defaults
          });
          return () => api.unregisterExtension(name, reference);
        },
        unregisterExtension(name, arg) {
          context2.unregisterExtension(name, arg);
        },
        renderHtmlExtension(element, props) {
          const [dispose] = renderElement(context2, element, props);
          return dispose;
        },
        Extension: ExtensionSlot
      };
    };
  }

  // node_modules/piral-core/lib/modules/api.js
  function createExtenders(context2, apis) {
    const creators = [createCoreApi, ...apis.filter(isfunc)];
    return creators.map((c) => {
      const ctx = c(context2);
      if (isfunc(ctx)) {
        return ctx;
      } else {
        return () => ({
          ...ctx
        });
      }
    });
  }
  function defaultApiFactory(context2, apis) {
    const extenders = createExtenders(context2, apis);
    return (target) => {
      const api = initializeApi(target, context2);
      context2.apis[target.name] = api;
      return mergeApis(api, extenders, target);
    };
  }

  // node_modules/piral-core/lib/modules/dependencies.js
  var globalDependencies = {};
  if (isfunc(fillDependencies)) {
    fillDependencies(globalDependencies);
  }
  function defaultDependencySelector(dependencies) {
    return dependencies;
  }
  function defaultModuleRequester() {
    return Promise.resolve([]);
  }

  // node_modules/piral-core/lib/helpers.js
  function createPiletOptions({ hooks, context: context2, loaders, loaderConfig, availablePilets, strategy, createApi, loadPilet, requestPilets, shareDependencies, debug }) {
    const options = {
      config: loaderConfig,
      strategy,
      loadPilet: extendLoader(loadPilet ?? getDefaultLoader(loaderConfig), loaders),
      createApi,
      pilets: availablePilets,
      fetchPilets: requestPilets,
      hooks,
      dependencies: shareDependencies(globalDependencies)
    };
    integrateDebugger2(context2, options, debug);
    integrateEmulator(context2, options, debug);
    return options;
  }

  // node_modules/piral-core/lib/createInstance.js
  function createInstance(config = {}) {
    const { id = generateId(), state, actions, availablePilets = [], plugins, requestPilets = defaultModuleRequester, loaderConfig, async = false, shareDependencies = defaultDependencySelector, loadPilet, loaders, debug, apiFactory = defaultApiFactory } = config;
    const globalState = createGlobalState(state);
    const events = createListener(globalState);
    const context2 = createActions(globalState, events);
    const definedPlugins = plugins || [];
    const usedPlugins = Array.isArray(definedPlugins) ? definedPlugins : [definedPlugins];
    const createApi = apiFactory(context2, usedPlugins);
    const root3 = createApi({
      name: "_",
      version: "0",
      spec: "v0",
      basePath: "",
      link: "",
      config: {},
      dependencies: {}
    });
    const options = createPiletOptions({
      context: context2,
      createApi,
      loaders,
      loadPilet,
      availablePilets,
      loaderConfig,
      shareDependencies,
      strategy: isfunc(async) ? async : async ? blazingStrategy : standardStrategy,
      requestPilets,
      debug
    });
    if (actions) {
      includeActions(context2, actions);
    }
    context2.options = options;
    return __assign(events, {
      id,
      createApi,
      context: context2,
      root: root3,
      options
    });
  }

  // node_modules/piral-core/lib/Piral.js
  var React28 = __toESM(require_react());

  // node_modules/piral-core/lib/PiralContext.js
  var React27 = __toESM(require_react());

  // node_modules/piral-core/lib/RootListener.js
  var React26 = __toESM(require_react());
  var import_react_dom2 = __toESM(require_react_dom());
  var renderHtmlEvent = "render-html";
  var renderContentEvent = "render-content";
  var forwardEventEvent = "forward-event";
  var RootListener = () => {
    const context2 = useGlobalStateContext();
    React26.useLayoutEffect(() => {
      if (typeof document !== "undefined") {
        const renderHtml = (ev) => {
          ev.stopPropagation();
          const { target, props } = ev.detail;
          const [dispose, update] = renderElement(context2, target, props);
          target.dispose = dispose;
          target.update = update;
        };
        const renderContent = (ev) => {
          ev.stopPropagation();
          const { target, content, portalId } = ev.detail;
          const portal = (0, import_react_dom2.createPortal)(content, target);
          const dispose = () => context2.hidePortal(portalId, portal);
          context2.showPortal(portalId, portal);
          target.dispose = dispose;
        };
        const forwardEvent = (ev) => {
          ev.stopPropagation();
          const { type, args } = ev.detail;
          context2.emit(type, args);
        };
        document.body.addEventListener(renderHtmlEvent, renderHtml, false);
        document.body.addEventListener(forwardEventEvent, forwardEvent, false);
        window.addEventListener(renderContentEvent, renderContent, false);
        return () => {
          document.body.removeEventListener(renderHtmlEvent, renderHtml, false);
          document.body.removeEventListener(forwardEventEvent, forwardEvent, false);
          window.removeEventListener(renderContentEvent, renderContent, false);
        };
      }
    }, [context2]);
    return null;
  };

  // node_modules/piral-core/lib/PiralContext.js
  var PiralProvider = ({ children }) => {
    const Provider = useGlobalState((m) => m.provider || React27.Fragment);
    return React27.createElement(Provider, null, children);
  };
  var PiralContext = ({ instance: instance2 = createInstance(), children }) => React27.createElement(
    StateContext.Provider,
    { value: instance2.context },
    React27.createElement(Mediator, { options: instance2.options, key: instance2.id }),
    React27.createElement(RootListener, null),
    React27.createElement(PiralProvider, null, children)
  );
  PiralContext.displayName = "PiralContext";

  // node_modules/piral-core/lib/Piral.js
  var Piral = ({ instance: instance2 = createInstance(), breakpoints, children }) => React28.createElement(
    PiralContext,
    { instance: instance2 },
    React28.createElement(
      RegisteredRouter,
      { publicPath: instance2.context.navigation.publicPath },
      React28.createElement(PiralView, { breakpoints }, children)
    )
  );
  Piral.displayName = "Piral";

  // node_modules/piral-translate/lib/create.js
  var deepmerge2 = __toESM(require_cjs());

  // node_modules/piral-translate/lib/actions.js
  function createActions2(localizer) {
    return {
      selectLanguage(ctx, selected) {
        ctx.dispatch((state) => {
          localizer.language = selected;
          const previousLanguage = state.language.selected;
          const currentLanguage = selected;
          setTimeout(() => {
            ctx.emit("select-language", {
              previousLanguage,
              currentLanguage
            });
          }, 0);
          return {
            ...state,
            language: {
              ...state.language,
              loading: selected === void 0,
              selected
            }
          };
        });
      },
      translate(_, key, variables) {
        return localizer && localizer.localizeGlobal(key, variables);
      },
      setTranslations(ctx, language, data) {
        localizer.messages[language] = data.global;
        for (const item of data.locals) {
          const api = ctx.apis[item.name];
          if (api) {
            const translations = api.getTranslations();
            translations[language] = item.value;
            api.setTranslations(translations);
          }
        }
      },
      getTranslations(ctx, language) {
        return {
          global: localizer.messages[language],
          locals: Object.keys(ctx.apis).map((name) => ({
            name,
            value: ctx.apis[name].getTranslations()[language]
          }))
        };
      }
    };
  }

  // node_modules/piral-translate/lib/flatten-translations.js
  function flat(source) {
    const target = {};
    flatten(source, target);
    return target;
  }
  function flatten(source, target, prop = "") {
    if (typeof source === "string") {
      target[prop] = source;
      return;
    }
    if (typeof source === "object" && source !== null) {
      Object.keys(source).forEach((key) => {
        flatten(source[key], target, prop ? `${prop}.${key}` : key);
      });
      return;
    }
  }
  function flattenTranslations(messages) {
    return Object.fromEntries(Object.entries(messages).map(([language, translations]) => {
      return [language, flat(translations)];
    }));
  }

  // node_modules/piral-translate/lib/localize.js
  function defaultFallback(key, language) {
    if (true) {
      return language ? "..." : "";
    } else {
      if (language) {
        console.warn(`Missing translation of "${key}" in language "${language}".`);
        return `__${language}_${key}__`;
      } else {
        return "";
      }
    }
  }
  function formatMessage(message, variables) {
    return message.replace(/{{\s*([A-Za-z0-9_.]+)\s*}}/g, (_match, p1) => {
      return p1 in variables ? variables[p1] ?? "" : `{{${p1}}}`;
    });
  }
  var Localizer = class {
    /**
     * Creates a new instance of a localizer.
     */
    constructor(messages, language, languages = [language], fallbackLanguage, fallback = defaultFallback) {
      this.language = language;
      this.languages = languages;
      this.fallbackLanguage = fallbackLanguage;
      this.fallback = fallback;
      this.messages = flattenTranslations(messages);
    }
    /**
     * Localizes the given key via the global translations.
     * @param key The key of the translation snippet.
     * @param variables The optional variables to use.
     */
    localizeGlobal(key, variables) {
      return this.localizeBase(key, variables);
    }
    /**
     * Localizes the given key via the local translations.
     * Uses the global translations as fallback mechanism.
     * @param localMessages The local translations to prefer.
     * @param key The key of the translation snippet.
     * @param variables The optional variables to use.
     */
    localizeLocal(localMessages, key, variables) {
      const message = this.translateMessage(localMessages, key, variables);
      if (message === void 0) {
        return this.localizeBase(key, variables);
      }
      return message;
    }
    localizeBase(key, variables) {
      const message = this.translateMessage(this.messages, key, variables);
      if (message === void 0) {
        return this.fallback(key, this.language, this.messages, variables);
      }
      return message;
    }
    translateMessage(messages, key, variables) {
      const language = this.language;
      const fallbackLanguage = this.fallbackLanguage;
      const translations = language && messages[language];
      const fallbackTranslations = fallbackLanguage && messages[fallbackLanguage];
      const translation = translations && translations[key] || fallbackTranslations && fallbackTranslations[key];
      return translation && (variables ? formatMessage(translation, variables) : translation);
    }
  };

  // node_modules/piral-translate/lib/default.js
  var DefaultPicker = (props) => defaultRender(void 0);

  // node_modules/piral-translate/lib/create.js
  function setupLocalizer(config = {}) {
    const msgs = config.messages || {};
    const languages = Object.keys(msgs);
    const defaultLang = languages[0] || "en";
    const computeLang = config.language;
    const usedLang = typeof computeLang === "function" ? computeLang(languages, defaultLang, "en") : computeLang;
    const language = usedLang || defaultLang;
    return new Localizer(msgs, language, languages.length ? languages : [language], config.fallbackLanguage, config.fallback);
  }
  function createLocaleApi(localizer = setupLocalizer()) {
    return (context2) => {
      context2.defineActions(createActions2(localizer));
      context2.dispatch((state) => ({
        ...state,
        components: {
          LanguagesPicker: DefaultPicker,
          ...state.components
        },
        language: {
          loading: false,
          available: localizer.languages,
          selected: localizer.language
        }
      }));
      return (api) => {
        let localTranslations = {};
        const setTranslations = (messages) => {
          localTranslations = flattenTranslations(messages);
        };
        return {
          addTranslations(messages, isOverriding = true) {
            const current = localizer.messages;
            setTranslations(deepmerge2.all(isOverriding ? [current, ...messages] : [...messages, current]));
          },
          getCurrentLanguage(cb) {
            const selected = context2.readState((s) => s.language.selected);
            if (cb) {
              cb(selected);
              const handler = (ev) => {
                cb(ev.currentLanguage);
              };
              api.on("select-language", handler);
              return () => api.off("select-language", handler);
            }
            return selected;
          },
          setTranslations,
          getTranslations() {
            return localTranslations;
          },
          translate(tag, variables) {
            return localizer.localizeLocal(localTranslations, tag, variables);
          }
        };
      };
    };
  }

  // node_modules/piral-dashboard/lib/actions.js
  var actions_exports2 = {};
  __export(actions_exports2, {
    registerTile: () => registerTile,
    unregisterTile: () => unregisterTile
  });
  function registerTile(ctx, name, value) {
    ctx.dispatch((state) => ({
      ...state,
      registry: {
        ...state.registry,
        tiles: withKey(state.registry.tiles, name, value)
      }
    }));
  }
  function unregisterTile(ctx, name) {
    ctx.dispatch((state) => ({
      ...state,
      registry: {
        ...state.registry,
        tiles: withoutKey(state.registry.tiles, name)
      }
    }));
  }

  // node_modules/piral-dashboard/lib/Dashboard.js
  var React29 = __toESM(require_react());

  // node_modules/piral-dashboard/lib/components.js
  var PiralDashboardContainer = getPiralComponent("DashboardContainer");
  var PiralDashboardTile = getPiralComponent("DashboardTile");

  // node_modules/piral-dashboard/lib/Dashboard.js
  var Dashboard = (props) => {
    const tiles = useGlobalState((s) => s.registry.tiles);
    const { filter = () => true } = props;
    const children = Object.keys(tiles).filter((tile) => filter(tiles[tile])).map((tile) => {
      const { component: Component4, preferences } = tiles[tile];
      const { initialColumns = 1, initialRows = 1, resizable = false } = preferences;
      return React29.createElement(
        PiralDashboardTile,
        { key: tile, columns: initialColumns, rows: initialRows, resizable, meta: preferences },
        React29.createElement(Component4, { columns: initialColumns, rows: initialRows })
      );
    });
    return React29.createElement(PiralDashboardContainer, { ...props, children });
  };
  Dashboard.displayName = "Dashboard";

  // node_modules/piral-dashboard/lib/default.js
  var React30 = __toESM(require_react());
  var DefaultContainer = (props) => React30.createElement(ExtensionSlot, { name: "dashboard", params: props, empty: () => defaultRender(props.children, "default_dashboard") });
  var DefaultTile = (props) => defaultRender(props.children);

  // node_modules/piral-dashboard/lib/helpers.js
  function getPreferences(defaultPreferences, customPreferences = {}) {
    return {
      ...defaultPreferences,
      ...customPreferences
    };
  }
  function getTiles(items, defaultPreferences) {
    const tiles = {};
    let i = 0;
    for (const { component, preferences } of items) {
      tiles[`global-${i++}`] = {
        pilet: void 0,
        component,
        preferences: getPreferences(defaultPreferences, preferences)
      };
    }
    return tiles;
  }
  function withTiles(tiles) {
    return (state) => ({
      ...state,
      components: {
        DashboardTile: DefaultTile,
        DashboardContainer: DefaultContainer,
        ...state.components
      },
      registry: {
        ...state.registry,
        tiles
      }
    });
  }
  function withRoutes(routes) {
    return (state) => ({
      ...state,
      routes: {
        ...state.routes,
        ...routes.reduce((newRoutes, route) => {
          newRoutes[route] = Dashboard;
          return newRoutes;
        }, {})
      }
    });
  }

  // node_modules/piral-dashboard/lib/create.js
  function createDashboardApi(config = {}) {
    const { tiles = [], defaultPreferences = {}, routes = ["/"] } = config;
    return (context2) => {
      context2.defineActions(actions_exports2);
      context2.dispatch(withAll(withTiles(getTiles(tiles, defaultPreferences)), withRootExtension("piral-dashboard", Dashboard), withRoutes(routes)));
      return (api, target) => {
        const pilet = target.name;
        let next = 0;
        return {
          registerTile(name, arg, preferences) {
            if (typeof name !== "string") {
              preferences = arg;
              arg = name;
              name = next++;
            }
            const id = buildName(pilet, name);
            context2.registerTile(id, {
              pilet,
              component: withApi(context2, arg, api, "tile"),
              preferences: getPreferences(defaultPreferences, preferences)
            });
            return () => api.unregisterTile(name);
          },
          unregisterTile(name) {
            const id = buildName(pilet, name);
            context2.unregisterTile(id);
          }
        };
      };
    };
  }

  // node_modules/piral-menu/lib/actions.js
  var actions_exports3 = {};
  __export(actions_exports3, {
    registerMenuItem: () => registerMenuItem,
    unregisterMenuItem: () => unregisterMenuItem
  });
  function registerMenuItem(ctx, name, value) {
    ctx.dispatch((state) => ({
      ...state,
      registry: {
        ...state.registry,
        menuItems: withKey(state.registry.menuItems, name, value)
      }
    }));
  }
  function unregisterMenuItem(ctx, name) {
    ctx.dispatch((state) => ({
      ...state,
      registry: {
        ...state.registry,
        menuItems: withoutKey(state.registry.menuItems, name)
      }
    }));
  }

  // node_modules/piral-menu/lib/default.js
  var React31 = __toESM(require_react());
  var DefaultContainer2 = (props) => React31.createElement(ExtensionSlot, { name: `menu_${props.type}`, params: props, empty: () => defaultRender(props.children, "default_menu") });
  var DefaultItem = (props) => defaultRender(props.children);

  // node_modules/piral-menu/lib/Menu.js
  var React32 = __toESM(require_react());

  // node_modules/piral-menu/lib/components.js
  var PiralMenuContainer = getPiralComponent("MenuContainer");
  var PiralMenuItem = getPiralComponent("MenuItem");

  // node_modules/piral-menu/lib/Menu.js
  var Menu = ({ type = "general" }) => {
    const menuItems = useGlobalState((s) => s.registry.menuItems);
    const renderItems = Object.keys(menuItems).filter((name) => menuItems[name].settings.type === type).map((name) => ({
      name,
      Component: menuItems[name].component,
      meta: menuItems[name].settings
    }));
    const children = renderItems.map(({ name, Component: Component4, meta }) => React32.createElement(
      PiralMenuItem,
      { key: name, type, meta },
      React32.createElement(Component4, null)
    ));
    return React32.createElement(PiralMenuContainer, { type }, children);
  };
  Menu.displayName = "Menu";

  // node_modules/piral-menu/lib/create.js
  function getSettings(defaultSettings, customSettings = {}) {
    return {
      type: "general",
      ...defaultSettings,
      ...customSettings
    };
  }
  function getMenuItems(items, defaultSettings) {
    const menuItems = {};
    let i = 0;
    for (const { component, settings } of items) {
      menuItems[`global-${i++}`] = {
        pilet: void 0,
        component,
        settings: getSettings(defaultSettings, settings)
      };
    }
    return menuItems;
  }
  function withMenu(menuItems) {
    return (state) => ({
      ...state,
      components: {
        MenuContainer: DefaultContainer2,
        MenuItem: DefaultItem,
        ...state.components
      },
      registry: {
        ...state.registry,
        menuItems
      }
    });
  }
  function createMenuApi(config = {}) {
    const { items = [], defaultSettings = {} } = config;
    return (context2) => {
      context2.defineActions(actions_exports3);
      context2.dispatch(withAll(withMenu(getMenuItems(items, defaultSettings)), withRootExtension("piral-menu", Menu)));
      return (api, target) => {
        const pilet = target.name;
        let next = 0;
        return {
          registerMenu(name, arg, settings) {
            if (typeof name !== "string") {
              settings = arg;
              arg = name;
              name = next++;
            }
            const id = buildName(pilet, name);
            context2.registerMenuItem(id, {
              pilet,
              component: withApi(context2, arg, api, "menu"),
              settings: getSettings(defaultSettings, settings)
            });
            return () => api.unregisterMenu(name);
          },
          unregisterMenu(name) {
            const id = buildName(pilet, name);
            context2.unregisterMenuItem(id);
          }
        };
      };
    };
  }

  // node_modules/piral-notifications/lib/actions.js
  var actions_exports4 = {};
  __export(actions_exports4, {
    closeNotification: () => closeNotification,
    openNotification: () => openNotification
  });
  function openNotification(ctx, dialog) {
    ctx.dispatch((state) => ({
      ...state,
      notifications: prependItem(state.notifications, dialog)
    }));
  }
  function closeNotification(ctx, dialog) {
    ctx.dispatch((state) => ({
      ...state,
      notifications: excludeOn(state.notifications, (notification) => notification.id === dialog.id)
    }));
  }

  // node_modules/piral-notifications/lib/create.js
  var import_react11 = __toESM(require_react());

  // node_modules/piral-notifications/lib/default.js
  var React33 = __toESM(require_react());
  var DefaultHost = (props) => React33.createElement("div", { className: "piral-notifications-host", key: "default_notifications" }, props.children);
  var DefaultToast = ({ children }) => defaultRender(children);

  // node_modules/piral-notifications/lib/Notifications.js
  var React34 = __toESM(require_react());

  // node_modules/piral-notifications/lib/components.js
  var PiralNotificationsHost = getPiralComponent("NotificationsHost");
  var PiralNotificationsToast = getPiralComponent("NotificationsToast");

  // node_modules/piral-notifications/lib/Notifications.js
  var Notifications = () => {
    const notifications = useGlobalState((s) => s.notifications);
    return React34.createElement(PiralNotificationsHost, null, notifications.map(({ component: Component4, close, options, id }) => React34.createElement(
      PiralNotificationsToast,
      { onClose: close, options, key: id },
      React34.createElement(Component4, { onClose: close, options })
    )));
  };
  Notifications.displayName = "Notifications";

  // node_modules/piral-notifications/lib/create.js
  function isElement(element) {
    return (0, import_react11.isValidElement)(element);
  }
  function toComponent(component) {
    if (typeof component === "string") {
      const text = component;
      return () => defaultRender(text);
    } else if ((0, import_react11.isValidElement)(component)) {
      const element = component;
      return () => element;
    }
    return component;
  }
  function createNotification(context2, id, content, defaultOptions, customOptions = {}) {
    const options = {
      ...defaultOptions,
      ...customOptions
    };
    const notification = {
      id,
      component: toComponent(content),
      options,
      close() {
        setTimeout(() => context2.closeNotification(notification), 0);
      }
    };
    if (typeof options.autoClose === "number" && options.autoClose > 0) {
      setTimeout(notification.close, options.autoClose);
    }
    return notification;
  }
  function getNotifications(context2, messages, defaultOptions) {
    const notifications = [];
    let i = 0;
    for (const { content, options } of messages) {
      notifications.push(createNotification(context2, `global-${i++}`, content, defaultOptions, options));
    }
    return notifications;
  }
  function withNotifications(notifications) {
    return (state) => ({
      ...state,
      components: {
        NotificationsHost: DefaultHost,
        NotificationsToast: DefaultToast,
        ...state.components
      },
      notifications
    });
  }
  function createNotificationsApi(config = {}) {
    const { defaultOptions = {}, selectId = () => `${~~(Math.random() * 1e4)}`, messages = [] } = config;
    return (context2) => {
      context2.defineActions(actions_exports4);
      context2.dispatch(withAll(withNotifications(getNotifications(context2, messages, defaultOptions)), withRootExtension("piral-notifications", Notifications)));
      return (api) => ({
        showNotification(content, customOptions) {
          const Component4 = typeof content === "string" ? content : isElement(content) ? content : withApi(context2, content, api, "extension");
          const notification = createNotification(context2, selectId(), Component4, defaultOptions, customOptions);
          context2.openNotification(notification);
          return notification.close;
        }
      });
    };
  }

  // node_modules/piral-modals/lib/actions.js
  var actions_exports5 = {};
  __export(actions_exports5, {
    closeModal: () => closeModal,
    openModal: () => openModal,
    registerModal: () => registerModal,
    unregisterModal: () => unregisterModal
  });
  function openModal(ctx, dialog) {
    ctx.dispatch((state) => ({
      ...state,
      modals: prependItem(state.modals, dialog)
    }));
  }
  function closeModal(ctx, dialog) {
    ctx.dispatch((state) => ({
      ...state,
      modals: excludeOn(state.modals, (modal) => modal.id === dialog.id)
    }));
  }
  function registerModal(ctx, name, value) {
    ctx.dispatch((state) => ({
      ...state,
      registry: {
        ...state.registry,
        modals: withKey(state.registry.modals, name, value)
      }
    }));
  }
  function unregisterModal(ctx, name) {
    ctx.dispatch((state) => ({
      ...state,
      registry: {
        ...state.registry,
        modals: withoutKey(state.registry.modals, name)
      }
    }));
  }

  // node_modules/piral-modals/lib/default.js
  var React35 = __toESM(require_react());
  var DefaultHost2 = (props) => React35.createElement("div", { className: "piral-modals-host" }, props.open && React35.createElement("div", { className: "piral-modals-overlay" }, props.children));
  var DefaultDialog = (props) => defaultRender(props.children);

  // node_modules/piral-modals/lib/Modals.js
  var React36 = __toESM(require_react());

  // node_modules/piral-modals/lib/components.js
  var PiralModalsHost = getPiralComponent("ModalsHost");
  var PiralModalsDialog = getPiralComponent("ModalsDialog");

  // node_modules/piral-modals/lib/Modals.js
  function closeAll(modals) {
    modals.forEach((m) => m.close());
  }
  function findModal(modals, name) {
    if (name) {
      const [modal] = Object.keys(modals).filter((m) => modals[m].name === name).map((m) => modals[m]);
      return modal;
    }
    return void 0;
  }
  var Modals = () => {
    const modals = useGlobalState((s) => s.registry.modals);
    const dialogs = useGlobalState((s) => s.modals);
    const close = () => closeAll(dialogs);
    const children = dialogs.map((n) => {
      const reg = modals[n.name] || findModal(modals, n.alternative);
      const Component4 = reg && reg.component;
      const defaults = reg && reg.defaults;
      const options = {
        ...defaults,
        ...n.options
      };
      return Component4 && React36.createElement(
        PiralModalsDialog,
        { ...n, options, defaults: reg.defaults, layout: reg.layout, key: n.name },
        React36.createElement(Component4, { onClose: n.close, options })
      );
    }).filter(Boolean).reverse();
    const open = children.length > 0;
    return React36.createElement(PiralModalsHost, { open, close }, children);
  };
  Modals.displayName = "Modals";

  // node_modules/piral-modals/lib/create.js
  function getModalDialogs(dialogs) {
    const modals = {};
    for (const { name, component, defaults, layout: layout2 = {} } of dialogs) {
      modals[`global-${name}`] = {
        pilet: void 0,
        name,
        component,
        defaults,
        layout: layout2
      };
    }
    return modals;
  }
  function withModals(modals) {
    return (state) => ({
      ...state,
      components: {
        ModalsHost: DefaultHost2,
        ModalsDialog: DefaultDialog,
        ...state.components
      },
      registry: {
        ...state.registry,
        modals
      },
      modals: []
    });
  }
  function createModalsApi(config = {}) {
    const { dialogs = [], selectId = (name) => `${name}-${~~(Math.random() * 1e4)}` } = config;
    return (context2) => {
      context2.defineActions(actions_exports5);
      context2.dispatch(withAll(withModals(getModalDialogs(dialogs)), withRootExtension("piral-modals", Modals)));
      return (api, target) => {
        const pilet = target.name;
        return {
          showModal(simpleName, options) {
            const name = buildName(pilet, simpleName);
            const dialog = {
              id: selectId(name),
              name,
              alternative: simpleName,
              options,
              close() {
                context2.closeModal(dialog);
              }
            };
            context2.openModal(dialog);
            return dialog.close;
          },
          registerModal(name, arg, defaults, layout2 = {}) {
            const id = buildName(pilet, name);
            context2.registerModal(id, {
              pilet,
              name,
              component: withApi(context2, arg, api, "modal"),
              defaults,
              layout: layout2
            });
            return () => api.unregisterModal(name);
          },
          unregisterModal(name) {
            const id = buildName(pilet, name);
            context2.unregisterModal(id);
          }
        };
      };
    };
  }

  // node_modules/piral-feeds/lib/actions.js
  var actions_exports6 = {};
  __export(actions_exports6, {
    createFeed: () => createFeed,
    destroyFeed: () => destroyFeed,
    loadFeed: () => loadFeed,
    loadedFeed: () => loadedFeed,
    updateFeed: () => updateFeed
  });
  function createFeed(ctx, id) {
    ctx.dispatch((state) => ({
      ...state,
      feeds: withKey(state.feeds, id, {
        data: void 0,
        error: void 0,
        loaded: false,
        loading: false
      })
    }));
  }
  function destroyFeed(ctx, id) {
    ctx.dispatch((state) => ({
      ...state,
      feeds: withoutKey(state.feeds, id)
    }));
  }
  function loadFeed(ctx, options) {
    const { id } = options;
    ctx.dispatch((state) => ({
      ...state,
      feeds: withKey(state.feeds, id, {
        data: void 0,
        error: void 0,
        loaded: false,
        loading: true
      })
    }));
    return options.initialize().then((baseData) => {
      loadedFeed(ctx, id, baseData, void 0);
      options.dispose = options.connect((item) => {
        updateFeed(ctx, id, item, options.update);
      });
    }, (err) => loadedFeed(ctx, id, void 0, err));
  }
  function loadedFeed(ctx, id, data, error) {
    ctx.dispatch((state) => ({
      ...state,
      feeds: withKey(state.feeds, id, {
        loading: false,
        loaded: true,
        error,
        data
      })
    }));
  }
  function updateFeed(ctx, id, item, reducer) {
    const feed = ctx.readState((state) => state.feeds[id]);
    const result = reducer(feed.data, item);
    if (result instanceof Promise) {
      return result.then((data) => loadedFeed(ctx, id, data, void 0)).catch((error) => loadedFeed(ctx, id, void 0, error));
    } else if (result !== feed.data) {
      loadedFeed(ctx, id, result, void 0);
    }
  }

  // node_modules/piral-feeds/lib/withFeed.js
  var React37 = __toESM(require_react());

  // node_modules/piral-feeds/lib/useFeed.js
  var import_react12 = __toESM(require_react());
  function useFeed(options) {
    const { loaded, loading, error, data } = useGlobalState((s) => s.feeds[options.id]);
    const load = useAction("loadFeed");
    (0, import_react12.useEffect)(() => {
      if (!loaded && !loading) {
        load(options);
      }
    }, [loaded]);
    return [loaded, data, error];
  }

  // node_modules/piral-feeds/lib/withFeed.js
  function withFeed(Component4, options) {
    const FeedView = (props) => {
      const [loaded, data, error] = useFeed(options);
      if (!loaded) {
        return React37.createElement(RegisteredLoadingIndicator, null);
      } else if (data) {
        return React37.createElement(Component4, { ...props, data });
      } else {
        return React37.createElement(RegisteredErrorInfo, { type: "feed", error });
      }
    };
    FeedView.displayName = `FeedView_${options.id}`;
    return FeedView;
  }

  // node_modules/piral-feeds/lib/utils.js
  var noop3 = () => {
  };
  function createFeedOptions(id, resolver) {
    if (isfunc(resolver)) {
      return {
        id,
        initialize() {
          return resolver();
        },
        connect() {
          return noop3;
        },
        update(data) {
          return Promise.resolve(data);
        },
        immediately: false,
        reducers: {}
      };
    } else {
      return {
        id,
        initialize() {
          return resolver.initialize();
        },
        connect(cb) {
          if (typeof resolver.connect === "function") {
            return resolver.connect(cb);
          } else {
            return noop3;
          }
        },
        update(data, item) {
          if (typeof resolver.update === "function") {
            return resolver.update(data, item);
          } else {
            return Promise.resolve(data);
          }
        },
        immediately: resolver.immediately,
        reducers: resolver.reducers || {}
      };
    }
  }

  // node_modules/piral-feeds/lib/create.js
  function createFeedsApi(config = {}) {
    return (context2) => {
      context2.defineActions(actions_exports6);
      context2.dispatch((state) => ({
        ...state,
        feeds: {}
      }));
      return (_, target) => {
        let feeds = 0;
        return {
          createConnector(resolver) {
            const id = buildName(target.name, feeds++);
            const options = createFeedOptions(id, resolver);
            const invalidate = () => {
              options.dispose?.();
              context2.createFeed(options.id);
            };
            if (options.immediately) {
              context2.loadFeed(options);
            } else {
              invalidate();
            }
            const connect2 = ((component) => withFeed(component, options));
            Object.keys(options.reducers).forEach((type) => {
              const reducer = options.reducers[type];
              if (typeof reducer === "function") {
                connect2[type] = (...args) => {
                  context2.updateFeed(id, args, (data, item) => reducer.call(connect2, data, ...item));
                };
              }
            });
            connect2.invalidate = invalidate;
            return connect2;
          }
        };
      };
    };
  }

  // node_modules/piral-ext/lib/create.js
  function createStandardApi(settings = {}) {
    const { locale = void 0, dashboard = void 0, menu = void 0, notifications = void 0, modals = void 0, feeds = void 0 } = settings;
    return [
      locale !== false && createLocaleApi(locale),
      dashboard !== false && createDashboardApi(dashboard),
      menu !== false && createMenuApi(menu),
      notifications !== false && createNotificationsApi(notifications),
      modals !== false && createModalsApi(modals),
      feeds !== false && createFeedsApi(feeds)
    ].filter(Boolean);
  }

  // src/layout.module.css
  var adminContainer = "layout-module__adminContainer_H5TJ8a__100";
  var breadcrumbs = "layout-module__breadcrumbs_H5TJ8a__100";
  var contentHeader = "layout-module__contentHeader_H5TJ8a__100";
  var header = "layout-module__header_H5TJ8a__100";
  var headerTitle = "layout-module__headerTitle_H5TJ8a__100";
  var nav = "layout-module__nav_H5TJ8a__100";
  var navList = "layout-module__navList_H5TJ8a__100";
  var title = "layout-module__title_H5TJ8a__100";
  var layout_default = {
    "adminContainer": adminContainer,
    "breadcrumbs": breadcrumbs,
    "contentHeader": contentHeader,
    "header": header,
    "headerTitle": headerTitle,
    "nav": nav,
    "navList": navList,
    "title": title
  };

  // src/layout.tsx
  var React38 = __toESM(require_react());
  var MenuItem = ({ children }) => /* @__PURE__ */ React38.createElement("li", null, children);
  var errors = {
    not_found: () => /* @__PURE__ */ React38.createElement("div", null, /* @__PURE__ */ React38.createElement("p", { className: "error" }, "Could not find the requested page. Are you sure it exists?"), /* @__PURE__ */ React38.createElement("p", null, "Go back ", /* @__PURE__ */ React38.createElement(Link, { to: "/" }, "to the Silverstripe Search dashboard"), "."))
  };
  var layout = {
    ErrorInfo: (props) => /* @__PURE__ */ React38.createElement("div", null, /* @__PURE__ */ React38.createElement("h1", null, "Error"), /* @__PURE__ */ React38.createElement(SwitchErrorInfo, { ...props })),
    DashboardContainer: ({ children }) => /* @__PURE__ */ React38.createElement("div", null, /* @__PURE__ */ React38.createElement("h2", null, "Search administration"), /* @__PURE__ */ React38.createElement("div", { className: "tiles" }, children)),
    DashboardTile: ({ columns, rows, children }) => /* @__PURE__ */ React38.createElement("div", { className: `tile cols-${columns} rows-${rows}` }, children),
    Layout: ({ children }) => /* @__PURE__ */ React38.createElement("div", { className: "silverstripe-search-admin" }, /* @__PURE__ */ React38.createElement(Notifications, null), /* @__PURE__ */ React38.createElement("div", { className: layout_default.adminContainer }, /* @__PURE__ */ React38.createElement("div", { className: `${layout_default.header} ${layout_default.headerTitle} vertical-align-items` }, /* @__PURE__ */ React38.createElement("span", { className: layout_default.title }, "Silverstripe Search")), /* @__PURE__ */ React38.createElement("div", { className: `${layout_default.header} ${layout_default.breadcrumbs}` }), /* @__PURE__ */ React38.createElement("div", { className: layout_default.sidebar }, /* @__PURE__ */ React38.createElement(Menu, { type: "general" })), /* @__PURE__ */ React38.createElement("div", { className: layout_default.contentHeader }, children))),
    MenuContainer: ({ children }) => {
      return /* @__PURE__ */ React38.createElement("nav", { className: layout_default.nav, "aria-label": "Silverstripe Search administration" }, /* @__PURE__ */ React38.createElement("ul", { className: layout_default.navList }, children));
    },
    MenuItem,
    NotificationsHost: ({ children }) => /* @__PURE__ */ React38.createElement("div", { className: "notifications" }, children),
    NotificationsToast: ({ options, onClose, children }) => /* @__PURE__ */ React38.createElement("div", { className: `notification-toast ${options.type}` }, /* @__PURE__ */ React38.createElement("div", { className: "notification-toast-details" }, options.title && /* @__PURE__ */ React38.createElement("div", { className: "notification-toast-title" }, options.title), /* @__PURE__ */ React38.createElement("div", { className: "notification-toast-description" }, children)), /* @__PURE__ */ React38.createElement("div", { className: "notification-toast-close", onClick: onClose }))
  };

  // src/index.tsx
  var apiBase = "admin/silverstripesearch/api/v1";
  var feedUrl = `${apiBase}/pilets`;
  var instance = createInstance({
    state: {
      components: layout,
      errorComponents: errors
    },
    plugins: [...createStandardApi({ dashboard: false })],
    requestPilets() {
      return fetch(feedUrl).then((res) => res.json()).then((res) => res.items);
    }
  });
  var root2 = (0, import_client.createRoot)(document.querySelector(".SilverstripeSearchAdmin"));
  root2.render(/* @__PURE__ */ React39.createElement(Piral, { instance }));
})();
/*! Bundled license information:

react/cjs/react.production.min.js:
  (**
   * @license React
   * react.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

scheduler/cjs/scheduler.production.min.js:
  (**
   * @license React
   * scheduler.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-dom/cjs/react-dom.production.min.js:
  (**
   * @license React
   * react-dom.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

react-modal/lib/helpers/tabbable.js:
  (*!
   * Adapted from jQuery UI core
   *
   * http://jqueryui.com
   *
   * Copyright 2014 jQuery Foundation and other contributors
   * Released under the MIT license.
   * http://jquery.org/license
   *
   * http://api.jqueryui.com/category/ui-core/
   *)

exenv/index.js:
  (*!
    Copyright (c) 2015 Jed Watson.
    Based on code that is Copyright 2013-2015, Facebook, Inc.
    All rights reserved.
  *)

react-is/cjs/react-is.production.min.js:
  (** @license React v16.13.1
   * react-is.production.min.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

piral-base/dist/piral-base-full.mjs:
  (*! Bundled license information:
  
  systemjs/dist/system.js:
    (*!
     * SystemJS 6.15.1
     *)
  *)
*/
//# sourceMappingURL=/main.js.map
